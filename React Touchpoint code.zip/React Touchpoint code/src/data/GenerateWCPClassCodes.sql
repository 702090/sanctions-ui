/*select * into #States from(
select 'AL' as [state] 
union
select 'AR' as [state] 
union
select 'GA' as [state] 
union
select 'IA' as [state] 
union
select 'IL' as [state] 
union
select 'KS' as [state] 
union
select 'KY' as [state] 
union
select 'MO' as [state] 
union
select 'MS' as [state] 
union
select 'NC' as [state] 
union
select 'NE' as [state] 
union
select 'NM' as [state] 
union
select 'OK' as [state] 
union
select 'SC' as [state] 
union
select 'SD' as [state] 
union
select 'TN' as [state] 
union
select 'TX' as [state]
)t

select * from #states*/


select 
  concat('{"classCodes":{',
    STUFF(
      (select 
        concat(',"',st.state, '":{'),
        (STUFF(
          (select --query to put id as the key of each question
            concat(',"',classNumber,descriptionId ,'":'),
            (select --query to put question into the json
              classNumber as [cn],
              classDescription as [desc],
              userClassDescription as [uDesc],
              descriptionId as [dId],
              (case 
                when ccp.permission > 1
                then ccp.permission
                else null--put null in there is no dependent answer because FOR JSON ignores any field with null as it's value unless you tell it otherwise
              end) as [p],
			  (case
				when ccp.effdte<>00000000
				then ccp.effdte
				else null
			  end) as [sd],
			  (case
				when ccp.enddte<>30001231
				then ccp.enddte
				else null
			  end) as [ed]
            from classCodes innerQuery 
            where idQuery.id = innerQuery.id
            FOR JSON Auto, WITHOUT_ARRAY_WRAPPER)
          from ClassCodes idQuery
          inner join ClassCodePermissions ccp on ccp.class_id = idQuery.id
          where prod = 'WCP' and ccp.state = st.state
          FOR XML PATH(''))
          ,1,1,'')--end of Stuff to remove leading comma
        ),
        ('}') 
      from #states st FOR XML PATH(''))
      ,1,1,''--end of Stuff to remove leading comma
    ),
    '}}'
  )
FOR XML PATH('')
