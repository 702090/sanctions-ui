--to run this query, you need to have your "Maximum number of characters displayed in each column" maxed , and the maximum size of text and ntext returned from a Select statement maxed

select 
  concat('{"sfgQuestions":{',--add beginning for proper json
    STUFF(
      (select  --query to put id as the key of each question
        concat(',"q',id,'":'),
        (select--query to put question into the json
          (select --query to get the optional answers for this question
            (case 
              when questionQuery.questionType <>'D'
              then '-1'
              else id--put null in there is no dependent answer because FOR JSON ignores any field with null as it's value unless you tell it otherwise
            end) as value,
            answerText as text, 
            minValue as mn, 
            maxValue as mx,
            result as r
          from UnderwritingQuestions_Options optionQuery 
          where questionQuery.id = optionQuery.underwritingQuestionId 
          FOR JSON PATH) as o,
          (case
            when( 
              select 
                count(result) 
                from UnderwritingQuestions_Options rq 
                where rq.underwritingQuestionId = questionQuery.id and rq.result = 'N' and questionQuery.questionType='D' 
              )>=1
            then 
              (select top 1 id 
              from UnderwritingQuestions_Options rq2 
              where rq2.underwritingQuestionId = questionQuery.id and rq2.result = 'N' and questionQuery.questionType='D' 
              order by answerText)
            else null--put null in there is no dependent answer because FOR JSON ignores any field with null as it's value unless you tell it otherwise
          end) as d,
          questionQuery.questionText as qt,
          questionQuery.questionType as qy,
          (case
            when (
              select count(dq.underwritingQuestionId) 
              from UnderwritingQuestions_Options dq 
              where dq.id = questionQuery.dependentAnswer 
            )>0
            then 
              concat('q',
                ( select daQuery.underwritingQuestionId 
                from UnderwritingQuestions_Options daQuery 
                where daQuery.id = questionQuery.dependentAnswer )
                ,'_'
                ,questionQuery.dependentAnswer
              )
            else null--put null in there is no dependent answer because FOR JSON ignores any field with null as it's value unless you tell it otherwise
          end) as da,
          sortOrder as [order]
        from UnderwritingQuestions questionQuery 
        where questionQuery.id = idQuery.id and questionLevel = 'P' and prod='BOP'
        FOR JSON Auto, WITHOUT_ARRAY_WRAPPER)
      FROM UnderwritingQuestions idQuery 
      where questionLevel = 'P' and prod='BOP' --class level only
      order by sortOrder
      FOR XML PATH(''))
      ,1,1,''--end of Stuff to remove leading comma
    )
    ,'}}'--add closing for proper json
  )
FOR XML PATH('')
