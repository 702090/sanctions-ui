/*select * into #States from(
select 'AL' as [state] 
union
select 'AR' as [state] 
union
select 'GA' as [state] 
union
select 'IA' as [state] 
union
select 'IL' as [state] 
union
select 'KS' as [state] 
union
select 'KY' as [state] 
union
select 'MO' as [state] 
union
select 'MS' as [state] 
union
select 'NC' as [state] 
union
select 'NE' as [state] 
union
select 'NM' as [state] 
union
select 'OK' as [state] 
union
select 'SC' as [state] 
union
select 'SD' as [state] 
union
select 'TN' as [state] 
union
select 'TX' as [state]
)t

select * from #states*/


select
  CONCAT('{"classCodes":{',
    STUFF(
      (select
    CONCAT(',"',st.state, '":{',
          (STUFF(
            (select --query to put id as the key of each question
      CONCAT(',"',RTRIM(classNumber),STRING_ESCAPE(classDescription,'json'),'":'),
      (select --query to put question into the json
        RTRIM(classNumber) as [cn],
        classDescription as [desc],
        userClassDescription as [uDesc],
        IIF (ccp.permission > 1,ccp.permission,null)as [p],
        NULLIF(rateNo,'')as rateNo,
        NULLIF(rateGroup,'')as rateGroup,
        NULLIF(riskLevel,'')as riskLevel,
        NULLIF(cppPma,'')as cppPma,
        NULLIF(classCode4,'')as classCode4,
        occupancyCode as [oc],
        NULLIF(veriskUse, '')as u,
        NULLIF(eqRateGrade,'')as eqrg,
        (case
                  when ccp.effdte<>00000000
                  then ccp.effdte
                  else null
                end) as [sd],
        (case
                  when ccp.enddte<>30001231
                  then ccp.enddte
                  else null
                end) as [ed],
        (case
                  when 
                    (select
          COUNT(questionId)
        from
          (select questionId
          from UnderwritingQuestions_ClassCodes
          where classId =idQuery.id)t 
                    ) >= 1
                  then 
                    (select
          CONCAT('[',
                        STUFF(
                          (select
            CONCAT(',"q',questionId,'"')
          from UnderwritingQuestions_ClassCodes uq
          where classId =idQuery.id
            and uq.enddte > format(GETDATE(),'yyyyMMdd')
          FOR XML PATH('')),
                        1,1,''--end of Stuff to remove leading comma
                        ),
                      ']'
                      )
                    )
                  else null--put null in there is no value because FOR JSON ignores any field with null as it's value unless you tell it otherwise
                end) as [questions]
      from classCodes innerQuery
      where idQuery.id = innerQuery.id
      FOR JSON Auto, WITHOUT_ARRAY_WRAPPER
              )
    from ClassCodes idQuery
      inner join ClassCodePermissions ccp on ccp.class_id = idQuery.id
    where  prod = 'BOP' and ccp.state = st.state and idQuery.occupancyCode is not null
    FOR XML PATH('')
            )
          ,1,1,''
		      )),--end of Stuff to remove leading comma
        '}')
  from #states st
  FOR XML PATH('')
	  )
    ,1,1,''),--end of Stuff to remove leading comma
  '}}')
FOR XML PATH('')
