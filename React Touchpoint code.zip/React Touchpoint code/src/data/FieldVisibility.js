import _ from 'lodash';
import {
	additionalPipAllowed,
	additionalPipSelected,
	askSubcontracting,
	bankAccountSame,
	canopyQuestion,
	checkAdditionalInsuredType,
	checkAmusementArea,
	checkBuildingUpdates,
	checkFloodCoverage,
	checkGaWest95,
	checkIfLeasing,
	checkLiabilityExposureBasis,
	checkMasonryVeneer,
	checkNumberOfSwimmingPools,
	checkOwnerOccupied,
	checkPlayground,
	checkRoofArea,
	checkTotalPayroll,
	checkTotalSales,
	checkwindstormHailRoofACV,
	displayPDFields,
	hadPreviousWCPCarrier,
	hasBuildingLimit,
	hasCDBBorCDBS,
	hasCDFD,
	hasCDOH,
	hasCDPC,
	hasCDPN,
	hasCDSC,
	hasCigBillingAccount,
	hasCODO,
	hasColl,
	hasCollSymbol,
	hasCompOrCollSymbol,
	hasCompSymbol,
	hasEarthquakeAndBPPLimit,
	hasEarthquakeAndBuildingLimit,
	hasHiredPhysicalDamage,
	hasMedPaySymbol,
	hasNonOwnLiabilitySymbol,
	hasOtc,
	hasPLPM,
	hasPools,
	hasPredStateTx,
	hasPriorLostTimeClaim,
	hasPrivatePassenger,
	hasQuoteId,
	hasReferrals,
	hasRestaurantClassCodes,
	hasTowSymbol,
	hasUimSymbol,
	hasVETL,
	isAccountBill,
	isAddBp0412Form,
	isAncillaryBuilding,
	isCompany,
	isContractorOccupancy,
	isCorporationOrLLC,
	isEarthquake,
	isHasBP1203,
	isHasBP1203orBP1231,
	isHasPriorCarrier,
	isHasPriorCarrierCap,
	isHasPriorCarrierCup,
	isHasPriorCarrierWcp,
	isMetalRoof,
	isNotAllContactsSame,
	isNotCompany,
	isNotFirstBuilding,
	isNotHomeOffice,
	isNotMetalRoof,
	isPriorCig,
	isPriorCigCap,
	isPriorCigCup,
	isPriorCigWcp,
	isPriorNotCig,
	isPriorNotCigCap,
	isPriorNotCigCup,
	isPriorNotCigWcp,
	liabilitySymbol,
	manualEntry,
	needNumberOfOfficersIncluded,
	needsBillingName,
	needsCupTerrorismExclusion,
	needsILMineSubsidenceRejection,
	needsMOEPLIAcknowledgement,
	needsSfgTerrorismExclusion,
	needVehSize,
	needWcpRiskId,
	newEftAccount,
	newVenture,
	noCigBillingAccount,
	noLosses,
	noLossesCap,
	noLossesCup,
	noLossesWcp,
	notAgencyBill,
	notAgencyBillCAP,
	notAgencyBillCUP,
	notAgencyBillWCP,
	notTier1County,
	officerTitleOther,
	otcCollCoverageSymbol,
	pipAllowed,
	registeredStateCdKansas,
	registeredStateCdSouthDakota,
	seatingCapacity,
	secondaryClassCode,
	showEarthquake,
	showSfgDriverCount,
	texasDefaultExpMod,
	tier1County,
	umUimCoverageSymbol,
	useDifferentAccount,
	vehRadius,
	wcpTwelveMonthsOrMore,
} from 'utils/FieldDisplay';

export const requiredQuestionMessage = 'An answer to this question is required.';

export function getFieldDisplayArray(pageName) {
	let returnValues;
	switch (pageName) {
		case 'generalInformation':
			returnValues = [
				{
					name: 'underwriterReferralOverride',
					cacheName: 'hasReferrals',
					method: hasReferrals,
				},
				{
					name: 'blockAgentEdit',
					cacheName: 'hasQuoteId',
					method: hasQuoteId,
				},
				{
					name: 'numberYearsExperience',
					cacheName: 'newVenture',
					method: newVenture,
				},
				{
					name: 'insuredName.first',
					cacheName: 'notCompany',
					method: isNotCompany,
				},
				{
					name: 'insuredName.last',
					cacheName: 'notCompany',
					method: isNotCompany,
				},
				{
					name: 'insuredName.company',
					cacheName: 'isCompany',
					method: isCompany,
				},
			];
			break;
		case 'sfgPolicyInformation':
			returnValues = [
				{
					name: 'sfg.percentSubcontracting',
					cacheName: 'askSubcontracting',
					method: askSubcontracting,
				},
			];
			break;
		case 'safeguardLocation':
			returnValues = [
				{
					name: 'windHailDeductible',
					cacheName: 'notTier1County',
					method: notTier1County,
				},
				{
					name: 'gaWest95',
					cacheName: checkGaWest95,
					method: checkGaWest95,
				},
				{
					name: 'island',
					cacheName: 'tier1County',
					method: tier1County,
				},
				{
					name: 'tidalWater',
					cacheName: 'tier1County',
					method: tier1County,
				},
				{
					name: 'separateWind',
					cacheName: 'tier1County',
					method: tier1County,
				},
				{
					name: 'floodCoverage',
					cacheName: 'checkFloodCoverage',
					method: checkFloodCoverage,
				},
			];
			break;
		case 'safeguardBuilding':
			returnValues = [
				{
					name: 'ancillaryBuilding',
					cacheName: 'ancillaryBuilding',
					method: isNotFirstBuilding,
				},
				{
					name: 'ancillaryDescription',
					cacheName: 'isAncillaryBuilding',
					method: isAncillaryBuilding,
				},
				{
					name: 'separateCanopy',
					cacheName: 'canopyQuestion',
					method: canopyQuestion,
				},
				{
					name: 'percentSubcontracting',
					cacheName: 'askSubcontracting',
					method: askSubcontracting,
				},
				{
					name: 'homeOffice',
					cacheName: 'homeOffice',
					method: isContractorOccupancy,
				},
				{
					name: 'additionalInsuredType',
					cacheName: 'additionalInsuredType',
					method: checkAdditionalInsuredType,
				},
				{
					name: 'ownerOccupied',
					cacheName: 'ownerOccupied',
					method: checkOwnerOccupied,
				},
				{
					name: 'numberOfTenants',
					cacheName: 'numberOfTenants',
					method: checkIfLeasing,
				},
				{
					name: 'playground',
					cacheName: 'playground',
					method: checkPlayground,
				},
				{
					name: 'amusementArea',
					cacheName: 'amusementArea',
					method: checkAmusementArea,
				},
				{
					name: 'numberOfSwimmingPools',
					cacheName: 'numberOfSwimmingPools',
					method: checkNumberOfSwimmingPools,
				},
				{
					name: 'hasPools',
					cacheName: 'hasPools',
					method: hasPools,
				},
				{
					name: 'poolFenced',
					cacheName: 'hasPools',
					method: hasPools,
				},
				{
					name: 'poolDiving',
					cacheName: 'hasPools',
					method: hasPools,
				},
				{
					name: 'poolGates',
					cacheName: 'hasPools',
					method: hasPools,
				},
				{
					name: 'poolRules',
					cacheName: 'hasPools',
					method: hasPools,
				},
				{
					name: 'poolDepth',
					cacheName: 'hasPools',
					method: hasPools,
				},
				{
					name: 'poolSafety',
					cacheName: 'hasPools',
					method: hasPools,
				},
				{
					name: 'poolSafety',
					cacheName: 'hasPools',
					method: hasPools,
				},
				{
					name: 'permanentYard',
					cacheName: 'permanentYard',
					method: isContractorOccupancy,
				},
				{
					name: 'roofYear',
					cacheName: 'checkBuildingUpdates',
					method: checkBuildingUpdates,
				},
				{
					name: 'roofType',
					cacheName: 'isNotHomeOffice',
					method: isNotHomeOffice,
				},
				{
					name: 'roofSurfaceLimitation',
					cacheName: 'roofSurfaceLimitation',
					method: isNotMetalRoof,
				},
				{
					name: 'roofSurfaceLimitationMetal',
					cacheName: 'roofSurfaceLimitationMetal',
					method: isMetalRoof,
				},
				{
					name: 'wiringYear',
					cacheName: 'checkBuildingUpdates',
					method: checkBuildingUpdates,
				},
				{
					name: 'plumbingYear',
					cacheName: 'checkBuildingUpdates',
					method: checkBuildingUpdates,
				},
				{
					name: 'primaryHeatingYear',
					cacheName: 'checkBuildingUpdates',
					method: checkBuildingUpdates,
				},
				{
					name: 'numberOfStories',
					cacheName: 'isNotHomeOffice',
					method: isNotHomeOffice,
				},
				{
					name: 'squareFootage',
					cacheName: 'isNotHomeOffice',
					method: isNotHomeOffice,
				},
				{
					name: 'roofArea',
					cacheName: checkRoofArea,
					method: checkRoofArea,
				},
				{
					name: 'sprinkler',
					cacheName: 'isNotHomeOffice',
					method: isNotHomeOffice,
				},
				{
					name: 'buildingLimit',
					cacheName: 'isNotHomeOffice',
					method: isNotHomeOffice,
				},
				{
					name: 'buildingValuation',
					cacheName: 'buildingValuation',
					method: hasBuildingLimit,
				},
				{
					name: 'totalPayroll',
					cacheName: 'totalPayroll',
					method: checkTotalPayroll,
				},
				{
					name: 'totalSales',
					cacheName: 'totalSales',
					method: checkTotalSales,
				},
				{
					name: 'liabilityExposureBasis',
					cacheName: 'liabilityExposureBasis',
					method: checkLiabilityExposureBasis,
				},
				{
					name: 'windstormHailRoofACV',
					cacheName: 'windstormHailRoofACV',
					method: checkwindstormHailRoofACV,
				},
				{
					name: 'pdDeductible',
					cacheName: 'pdDeductible',
					method: displayPDFields,
				},
				{
					name: 'pdDeductibleType',
					cacheName: 'pdDeductibleType',
					method: displayPDFields,
				},
				{
					name: 'earthquakeCoverage',
					cacheName: 'showEarthquake',
					method: showEarthquake,
				},
				{
					name: 'eqDeductible',
					cacheName: 'isEarthquake',
					method: isEarthquake,
				},
				{
					name: 'eqBuildingClassification',
					cacheName: 'isEarthquake',
					method: isEarthquake,
				},
				{
					name: 'eqBuildingSubLimit',
					cacheName: 'hasEarthquakeAndBuildingLimit',
					method: hasEarthquakeAndBuildingLimit,
				},
				{
					name: 'eqBPPSubLimit',
					cacheName: 'hasEarthquakeAndBPPLimit',
					method: hasEarthquakeAndBPPLimit,
				},
				{
					name: 'masonryVeneer',
					cacheName: 'masonryVeneer',
					method: checkMasonryVeneer,
				},
				{
					name: 'rateGrade',
					cacheName: 'rateGrade',
					method: hasEarthquakeAndBPPLimit,
				},
			];
			break;
		case 'safeguardLosses':
			returnValues = [
				{
					name: 'noLosses',
					cacheName: 'noLosses',
					method: noLosses,
				},
			];
			break;
		case 'safeguardPriorCarrier':
			returnValues = [
				{
					name: 'sfg.cigPriorCarrier',
					cacheName: 'isHasPriorCarrier',
					method: isHasPriorCarrier,
				},
				{
					name: 'sfg.priorPolicyNumber',
					cacheName: 'isPriorCig',
					method: isPriorCig,
				},
				{
					name: 'sfg.cancelReason',
					cacheName: 'isPriorCig',
					method: isPriorCig,
				},
				{
					name: 'sfg.carrierName',
					cacheName: 'isPriorNotCig',
					method: isPriorNotCig,
				},
				{
					name: 'sfg.expirationDate',
					cacheName: 'isHasPriorCarrier',
					method: isHasPriorCarrier,
				},
				{
					name: 'sfg.annualPremium',
					cacheName: 'isHasPriorCarrier',
					method: isHasPriorCarrier,
				},
			];
			break;
		case 'commercialAuto':
			returnValues = [
				{
					name: 'cap.symbols.pip',
					cacheName: 'pipAllowed',
					method: pipAllowed,
				},
				{
					name: 'cap.symbols.additionalPip',
					cacheName: 'additionalPipAllowed',
					method: additionalPipAllowed,
				},
				{
					name: 'cap.symbols.tow',
					cacheName: 'hasCompOrCollSymbol',
					method: hasCompOrCollSymbol,
				},
				{
					name: 'cap.compDeductible',
					cacheName: 'hasCompSymbol',
					method: hasCompSymbol,
				},
				{
					name: 'cap.collDeductible',
					cacheName: 'hasCollSymbol',
					method: hasCollSymbol,
				},
				{
					name: 'cap.umCombinedSingleLimit',
					cacheName: 'hasUimSymbol',
					method: hasUimSymbol,
				},
				{
					name: 'cap.towingLimitDisablement',
					cacheName: 'hasTowSymbol',
					method: hasTowSymbol,
				},
				{
					name: 'cap.hiredNonOwn',
					cacheName: 'hasNonOwnLiabilitySymbol',
					method: hasNonOwnLiabilitySymbol,
				},
				{
					name: 'cap.hiredAutoLiability',
					cacheName: 'hasNonOwnLiabilitySymbol',
					method: hasNonOwnLiabilitySymbol,
				},
				{
					name: 'cap.otherThanCollisionAnnualCost',
					cacheName: 'hasHiredPhysicalDamage',
					method: hasHiredPhysicalDamage,
				},
				{
					name: 'cap.otherThanCollisionDeductible',
					cacheName: 'hasHiredPhysicalDamage',
					method: hasHiredPhysicalDamage,
				},
				{
					name: 'cap.collisionCostHireAmount',
					cacheName: 'hasHiredPhysicalDamage',
					method: hasHiredPhysicalDamage,
				},
				{
					name: 'cap.collisionDeductible',
					cacheName: 'hasHiredPhysicalDamage',
					method: hasHiredPhysicalDamage,
				},
				{
					name: 'cap.driveOtherCar',
					cacheName: 'isCorporationOrLLC',
					method: isCorporationOrLLC,
				},
				{
					name: 'cap.medPayLimit',
					cacheName: 'hasMedPaySymbol',
					method: hasMedPaySymbol,
				},
				{
					name: 'cap.coverages.GA.addOnCoverage',
					cacheName: 'hasUimSymbol',
					method: hasUimSymbol,
				},
				{
					name: 'cap.coverages.GA.umDeductible',
					cacheName: 'hasUimSymbol',
					method: hasUimSymbol,
				},
				{
					name: 'cap.coverages.AR.umDeductible',
					cacheName: 'hasUimSymbol',
					method: hasUimSymbol,
				},
			];
			break;
		case 'capPriorCarrier':
			returnValues = [
				{
					name: 'cap.cigPriorCarrier',
					cacheName: 'isHasPriorCarrierCap',
					method: isHasPriorCarrierCap,
				},
				{
					name: 'cap.priorPolicyNumber',
					cacheName: 'isPriorCigCap',
					method: isPriorCigCap,
				},
				{
					name: 'cap.carrierName',
					cacheName: 'isPriorNotCigCap',
					method: isPriorNotCigCap,
				},
				{
					name: 'cap.expirationDate',
					cacheName: 'isHasPriorCarrierCap',
					method: isHasPriorCarrierCap,
				},
				{
					name: 'cap.annualPremium',
					cacheName: 'isHasPriorCarrierCap',
					method: isHasPriorCarrierCap,
				},
			];
			break;
		case 'commercialAutoLosses':
			returnValues = [
				{
					name: 'noLosses',
					cacheName: 'noLossesCap',
					method: noLossesCap,
				},
			];
			break;
		case 'contact':
			returnValues = [
				{
					name: 'contacts.inspection.firstName',
					cacheName: 'isNotAllContactsSame',
					method: isNotAllContactsSame,
				},
				{
					name: 'contacts.inspection.lastName',
					cacheName: 'isNotAllContactsSame',
					method: isNotAllContactsSame,
				},
				{
					name: 'contacts.inspection.phone',
					cacheName: 'isNotAllContactsSame',
					method: isNotAllContactsSame,
				},
				{
					name: 'contacts.inspection.email',
					cacheName: 'isNotAllContactsSame',
					method: isNotAllContactsSame,
				},
				{
					name: 'contacts.claims.firstName',
					cacheName: 'isNotAllContactsSame',
					method: isNotAllContactsSame,
				},
				{
					name: 'contacts.claims.lastName',
					cacheName: 'isNotAllContactsSame',
					method: isNotAllContactsSame,
				},
				{
					name: 'contacts.claims.phone',
					cacheName: 'isNotAllContactsSame',
					method: isNotAllContactsSame,
				},
				{
					name: 'contacts.claims.email',
					cacheName: 'isNotAllContactsSame',
					method: isNotAllContactsSame,
				},
				{
					name: 'contacts.other.firstName',
					cacheName: 'isNotAllContactsSame',
					method: isNotAllContactsSame,
				},
				{
					name: 'contacts.other.lastName',
					cacheName: 'isNotAllContactsSame',
					method: isNotAllContactsSame,
				},
				{
					name: 'contacts.other.phone',
					cacheName: 'isNotAllContactsSame',
					method: isNotAllContactsSame,
				},
				{
					name: 'contacts.other.email',
					cacheName: 'isNotAllContactsSame',
					method: isNotAllContactsSame,
				},
			];
			break;
		case 'billingInformation':
			returnValues = [
				{
					name: 'billing.existingAccountBill',
					cacheName: 'isAccountBill',
					method: isAccountBill,
				},
				{
					name: 'billing.accountBillNumber',
					cacheName: 'hasCigBillingAccount',
					method: hasCigBillingAccount,
				},
				{
					name: 'billing.billingSameAsApplicant',
					cacheName: 'noCigBillingAccount',
					method: noCigBillingAccount,
				},
				{
					name: 'billing.name.firstName',
					cacheName: 'needsBillingName',
					method: needsBillingName,
				},
				{
					name: 'billing.name.middleInitial',
					cacheName: 'needsBillingName',
					method: needsBillingName,
				},
				{
					name: 'billing.name.lastName',
					cacheName: 'needsBillingName',
					method: needsBillingName,
				},
				{
					name: 'billing.address.fullAddress',
					cacheName: 'needsBillingName',
					method: needsBillingName,
				},
				{
					name: 'billing.bankAccountType',
					cacheName: 'newEftAccount',
					method: newEftAccount,
				},
				{
					name: 'billing.bankName',
					cacheName: 'newEftAccount',
					method: newEftAccount,
				},
				{
					name: 'billing.bankRoutingNumber',
					cacheName: 'newEftAccount',
					method: newEftAccount,
				},
				{
					name: 'billing.bankAccountNumber',
					cacheName: 'newEftAccount',
					method: newEftAccount,
				},
				{
					name: 'billing.downPaymentMethod',
					cacheName: 'notAgencyBill',
					method: notAgencyBill,
				},
				{
					name: 'billing.sfgDownPaymentAmount',
					cacheName: 'notAgencyBill',
					method: notAgencyBill,
				},
				{
					name: 'billing.capDownPaymentAmount',
					cacheName: 'notAgencyBillCAP',
					method: notAgencyBillCAP,
				},
				{
					name: 'billing.wcpDownPaymentAmount',
					cacheName: 'notAgencyBillWCP',
					method: notAgencyBillWCP,
				},
				{
					name: 'billing.cupDownPaymentAmount',
					cacheName: 'notAgencyBillCUP',
					method: notAgencyBillCUP,
				},
				{
					name: 'billing.bankAccountSame',
					cacheName: 'bankAccountSame',
					method: bankAccountSame,
				},
				{
					name: 'billing.downPayment.bankAccountType',
					cacheName: 'useDifferentAccount',
					method: useDifferentAccount,
				},
				{
					name: 'billing.downPayment.bankName',
					cacheName: 'useDifferentAccount',
					method: useDifferentAccount,
				},
				{
					name: 'billing.downPayment.routingNumber',
					cacheName: 'useDifferentAccount',
					method: useDifferentAccount,
				},
				{
					name: 'billing.downPayment.accountNumber',
					cacheName: 'useDifferentAccount',
					method: useDifferentAccount,
				},
			];
			break;
		case 'workcomp':
			returnValues = [
				{
					name: 'wcp.riskId',
					cacheName: 'needWcpRiskId',
					method: needWcpRiskId,
				},
				{
					name: 'wcp.numberOfOfficersIncluded',
					cacheName: 'needNumberOfOfficersIncluded',
					method: needNumberOfOfficersIncluded,
				},
				{
					name: 'wcp.monthsInBusiness',
					cacheName: 'texasDefaultExpMod',
					method: texasDefaultExpMod,
				},
				{
					name: 'wcp.previousInsurance',
					cacheName: 'wcpTwelveMonthsOrMore',
					method: wcpTwelveMonthsOrMore,
				},
				{
					name: 'wcp.lostTimeClaims',
					cacheName: 'hadPreviousWCPCarrier',
					method: hadPreviousWCPCarrier,
				},
				{
					name: 'wcp.numberOfLostTimeClaims',
					cacheName: 'hasPriorLostTimeClaim',
					method: hasPriorLostTimeClaim,
				},
				{
					name: 'wcp.smallDeductible1',
					cacheName: 'hasPredStateTx',
					method: hasPredStateTx,
				},
				{
					name: 'wcp.smallDeductible2',
					cacheName: 'hasPredStateTx',
					method: hasPredStateTx,
				},
			];
			break;
		case 'wcpPriorCarrier':
			returnValues = [
				{
					name: 'wcp.cigPriorCarrier',
					cacheName: 'isHasPriorCarrierWcp',
					method: isHasPriorCarrierWcp,
				},
				{
					name: 'wcp.priorPolicyNumber',
					cacheName: 'isPriorCigWcp',
					method: isPriorCigWcp,
				},
				{
					name: 'wcp.carrierName',
					cacheName: 'isPriorNotCigWcp',
					method: isPriorNotCigWcp,
				},
				{
					name: 'wcp.expirationDate',
					cacheName: 'isHasPriorCarrierWcp',
					method: isHasPriorCarrierWcp,
				},
				{
					name: 'wcp.annualPremium',
					cacheName: 'isHasPriorCarrierWcp',
					method: isHasPriorCarrierWcp,
				},
			];
			break;
		case 'wcpLosses':
			returnValues = [
				{
					name: 'noLosses',
					cacheName: 'noLossesWcp',
					method: noLossesWcp,
				},
			];
			break;
		case 'vehicle':
			returnValues = [
				{ name: 'otcDedOverride', cacheName: 'hasOtc', method: hasOtc },
				{ name: 'collDedOverride', cacheName: 'hasColl', method: hasColl },
				{
					name: 'seatingCapacity',
					cacheName: 'seatingCapacity',
					method: seatingCapacity,
				},
				{
					name: 'vehRadius',
					cacheName: 'vehRadius',
					method: vehRadius,
				},
				{
					name: 'secondaryClassCode',
					cacheName: 'secondaryClassCode',
					method: secondaryClassCode,
				},
				{
					name: 'hasPrivatePassenger',
					cacheName: 'hasPrivatePassenger',
					method: hasPrivatePassenger,
				},
				{
					name: 'liability',
					cacheName: 'liabilitySymbol',
					method: liabilitySymbol,
				},
				{
					name: 'registeredStateCdKansas',
					cacheName: 'registeredStateCdKansas',
					method: registeredStateCdKansas,
				},
				{
					name: 'registeredStateCdSouthDakota',
					cacheName: 'registeredStateCdSouthDakota',
					method: registeredStateCdSouthDakota,
				},
				{
					name: 'umUimCoverageSymbol',
					cacheName: 'umUimCoverageSymbol',
					method: umUimCoverageSymbol,
				},
				{
					name: 'otcCoverageSymbol',
					cacheName: 'otcCollCoverageSymbol',
					method: otcCollCoverageSymbol,
				},
				{
					name: 'collCoverageSymbol',
					cacheName: 'otcCollCoverageSymbol',
					method: otcCollCoverageSymbol,
				},
				{
					name: 'vehSize',
					cacheName: 'needVehSize',
					method: needVehSize,
				},
				{
					name: 'otcCoverage',
					cacheName: 'otcCollCoverageSymbol',
					method: otcCollCoverageSymbol,
				},
				{
					name: 'collCoverage',
					cacheName: 'otcCollCoverageSymbol',
					method: otcCollCoverageSymbol,
				},
				{
					name: 'umUimCoverage',
					cacheName: 'umUimCoverageSymbol',
					method: umUimCoverageSymbol,
				},
				{
					name: 'additionalPIPCoverage',
					cacheName: 'additionalPipSelected',
					method: additionalPipSelected,
				},
				{
					name: 'pptUse',
					cacheName: 'hasPrivatePassenger',
					method: hasPrivatePassenger,
				},
				{
					name: 'pptExperience',
					cacheName: 'hasPrivatePassenger',
					method: hasPrivatePassenger,
				},
			];
			break;
		case 'officers':
			returnValues = [
				{
					name: 'titleOther',
					cacheName: 'officerTitleOther',
					method: officerTitleOther,
				},
			];
			break;
		case 'commercialUmbrella':
			returnValues = [
				{
					name: 'cup.restaurantLiquor',
					cacheName: 'hasRestaurantClassCodes',
					method: hasRestaurantClassCodes,
				},
				{
					name: 'cup.clergyProfessionalCount',
					cacheName: 'hasCDPC',
					method: hasCDPC,
				},
				{
					name: 'cup.barbersBeuticiansCount',
					cacheName: 'hasCDBBorCDBS',
					method: hasCDBBorCDBS,
				},
				{
					name: 'cup.veterinariansCount',
					cacheName: 'hasVETL',
					method: hasVETL,
				},
				{
					name: 'cup.funeralDirectorsMorticiansCount',
					cacheName: 'hasCDFD',
					method: hasCDFD,
				},
				{
					name: 'cup.pharmacistsCount',
					cacheName: 'hasPLPM',
					method: hasPLPM,
				},
				{
					name: 'cup.printersEOCount',
					cacheName: 'hasCDPN',
					method: hasCDPN,
				},
				{
					name: 'cup.condoDirectorsOfficersCount',
					cacheName: 'hasCODO',
					method: hasCODO,
				},
				{
					name: 'cup.opticiansOptometristsCount',
					cacheName: 'hasCDOH',
					method: hasCDOH,
				},
				{
					name: 'cup.seniorCitizensCount',
					cacheName: 'hasCDSC',
					method: hasCDSC,
				},
			];
			break;
		case 'underlyingPolicies':
			returnValues = [
				{
					name: 'cup.underlyingPolicies.sfg.driverCount',
					cacheName: 'showSfgDriverCount',
					method: showSfgDriverCount,
				},
				{
					name: 'cup.underlyingPolicies.wcp.carrier',
					cacheName: 'manualEntry',
					method: manualEntry,
				},
				{
					name: 'cup.underlyingPolicies.wcp.policyNumber',
					cacheName: 'manualEntry',
					method: manualEntry,
				},
				{
					name: 'cup.underlyingPolicies.wcp.effectiveDate',
					cacheName: 'manualEntry',
					method: manualEntry,
				},
				{
					name: 'cup.underlyingPolicies.wcp.expirationDate',
					cacheName: 'manualEntry',
					method: manualEntry,
				},
				{
					name: 'cup.underlyingPolicies.wcp.limitPerAccident',
					cacheName: 'manualEntry',
					method: manualEntry,
				},
				{
					name: 'cup.underlyingPolicies.wcp.biPerPerson',
					cacheName: 'manualEntry',
					method: manualEntry,
				},
				{
					name: 'cup.underlyingPolicies.wcp.liabilityMedicalAggLimit',
					cacheName: 'manualEntry',
					method: manualEntry,
				},
			];
			break;
		case 'commercialUmbrellaLosses':
			returnValues = [
				{
					name: 'noLosses',
					cacheName: 'noLossesCup',
					method: noLossesCup,
				},
			];
			break;
		case 'cupPriorCarrier':
			returnValues = [
				{
					name: 'cup.cigPriorCarrier',
					cacheName: 'isHasPriorCarrier',
					method: isHasPriorCarrierCup,
				},
				{
					name: 'cup.priorPolicyNumber',
					cacheName: 'isPriorCigCup',
					method: isPriorCigCup,
				},
				{
					name: 'cup.carrierName',
					cacheName: 'isPriorNotCig',
					method: isPriorNotCigCup,
				},
				{
					name: 'cup.expirationDate',
					cacheName: 'isHasPriorCarrier',
					method: isHasPriorCarrierCup,
				},
				{
					name: 'cup.annualPremium',
					cacheName: 'isHasPriorCarrier',
					method: isHasPriorCarrierCup,
				},
			];
			break;
		case 'additionalInterest':
			returnValues = [
				{
					name: 'sfgProvisionApplicable',
					cacheName: 'isHasBP1203',
					method: isHasBP1203,
				},
				{
					name: 'sfgDescriptionOfProperty',
					cacheName: 'isHasBP1203orBP1231',
					method: isHasBP1203orBP1231,
				},
			];
			break;
		case 'additionalForms':
			returnValues = [
				{
					name: 'ilMineSubsidence',
					cacheName: 'needsILMineSubsidenceRejection',
					method: needsILMineSubsidenceRejection,
				},
				{
					name: 'sfgTerrorismExclusion',
					cacheName: 'needsSfgTerrorismExclusion',
					method: needsSfgTerrorismExclusion,
				},
				{
					name: 'cupTerrorismExclusion',
					cacheName: 'needsCupTerrorismExclusion',
					method: needsCupTerrorismExclusion,
				},
				{
					name: 'moEPLIAcknowledgement',
					cacheName: 'needsMOEPLIAcknowledgement',
					method: needsMOEPLIAcknowledgement,
				},
			];
		case 'fillinForms':
			returnValues = [
				{
					name: 'fillinForms.bp0412.premises',
					cacheName: 'addBp0412Form',
					method: isAddBp0412Form,
				},
				{
					name: 'fillinForms.bp0412.project',
					cacheName: 'addBp0412Form',
					method: isAddBp0412Form,
				},
			];
			break;
		default:
			returnValues = [];
	}
	return returnValues;
}

export function updateSectionVisibility(quote, state, values) {
	const sectionVisibility = [];
	sectionVisibility[`cap.coverages.${state}.numberIndividualsCovered`] = false;
	sectionVisibility[`cap.coverages.${state}.additionalPip`] = false;
	sectionVisibility[`cap.coverages.${state}.pipMisc1`] = false;
	sectionVisibility[`cap.coverages.${state}.pipLimit`] = false;
	sectionVisibility[`cap.coverages.${state}.umDeductible`] = false;
	sectionVisibility[`cap.coverages.${state}.addOnCoverage`] = false;
	sectionVisibility[`cap.coverages.${state}.umCombinedSingleLimit`] = false;
	sectionVisibility[`cap.coverages.${state}.numberIndividualsCovered`] = false;
	sectionVisibility[`cap.coverages.${state}.umPdLimit`] = false;

	switch (state) {
		case 'AR':
			if (hasUimSymbol(quote)) {
				sectionVisibility[`cap.coverages.${state}.umPdLimit`] = true;
			}
			break;
		case 'GA':
			if (hasUimSymbol(quote, values)) {
				sectionVisibility[`cap.coverages.${state}.umDeductible`] = true;
				sectionVisibility[`cap.coverages.${state}.addOnCoverage`] = true;
			}
			break;
		case 'KS':
			if (additionalPipSelected(quote, values)) {
				sectionVisibility[`cap.coverages.${state}.additionalPip`] = true;
			}
			break;
		case 'KY':
			if (additionalPipSelected(quote, values)) {
				sectionVisibility[`cap.coverages.${state}.additionalPip`] = true;
			}
			if (_.get(values, `cap.coverages.${state}.tortRejectionIndicator`, 'N') === 'N') {
				sectionVisibility[`cap.coverages.${state}.pipMisc1`] = true;
			}
			break;
		case 'TX':
			if (!_.includes(['0', ''], _.get(quote, 'cap.symbols.pip', ''))) {
				sectionVisibility[`cap.coverages.${state}.pipLimit`] = true;
			}
			break;
		default:
			break;
	}

	if (hasUimSymbol(quote, values)) {
		sectionVisibility[`cap.coverages.${state}.umCombinedSingleLimit`] = true;
	}

	if (_.get(values, `cap.coverages.${state}.driveOtherCar`, '') === 'Y') {
		sectionVisibility[`cap.coverages.${state}.numberIndividualsCovered`] = true;
	}

	return sectionVisibility;
}
