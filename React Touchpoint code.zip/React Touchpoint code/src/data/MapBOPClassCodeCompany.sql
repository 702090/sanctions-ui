-- You must load the excel sheet into Commercial..ClassCodeCompanyPlacementTemp
-- Whatever way works, but I usually just convert to text file and import via SSMS

select * into #tempCoPlacement 
from (
  select [id]
        ,[Class_Code]
	      ,[State]
	      ,[Company]
  from  (
	  select [id]
          ,[Class_Code]
          ,[AR]
          ,[MO]
          ,[IL]
          ,[NE]
          ,[IA]
          ,[SD]
          ,[KS]
          ,[OK]
          ,[TX]
          ,[AL]
          ,[GA]
          ,[KY]
          ,[MS]
          ,[TN]
	  from Commercial..ClassCodeCompanyPlacementTemp
  ) as src
  unpivot
	  ([Company] for [State] in ([AR], [MO], IL, NE, IA, SD, KS, OK, TX, AL, GA, KY, MS, TN)) pvt
) x;

-- select * from #tempCoPlacement;
-- drop table #tempCoPlacement;

update s
set s.company = case x.Company
					when 'N' then '09'
					when 'M' then '02'
					when 'A' then '13'
				end
from Commercial..ClassCodePermissions s inner join
	#tempCoPlacement x on s.class_id = x.id and s.state = x.State
