import DriverDashboardRules from 'commercialAuto/drivers/DriverDashboardRules';
import DriverRules from 'commercialAuto/drivers/DriverRules';
import CapLossesDashboardRules from 'commercialAuto/losses/CapLossesDashboardRules';
import CapLossRules from 'commercialAuto/losses/CapLossRules';
import CapPriorCarrierRules from 'commercialAuto/priorCarrier/CapPriorCarrierRules';
import StateCoveragesRules from 'commercialAuto/stateCoverages/StateCoveragesRules';
import SymbolsLimitsRules from 'commercialAuto/symbolsLimits/SymbolsLimitsRules';
import VehicleDashboardRules from 'commercialAuto/vehicles/VehicleDashboardRules';
import VehicleRules from 'commercialAuto/vehicles/VehicleRules';
import CupLossesDashboardRules from 'commercialUmbrella/losses/CupLossesDashboardRules';
import CupLossRules from 'commercialUmbrella/losses/CupLossRules';
import CupPolicyInformationRules from 'commercialUmbrella/policyInformation/CupPolicyInformationRules';
import CupPriorCarrierRules from 'commercialUmbrella/priorCarrier/CupPriorCarrierRules';
import UnderlyingPoliciesRules from 'commercialUmbrella/underlyingPolicies/UnderlyingPoliciesRules';
import bopClassCodesJson from 'data/BOPClassCodes';
import occupancyQuestionsJson from 'data/OccupancyQuestions';
import sfgQuestionsJson from 'data/sfgPolicyQuestions';
import GeneralInformationRules from 'generalInformation/GeneralInformationRules';
import AdditionalInterestRules from 'issue/additionalInterest/AdditionalInterestRules';
import AdditionalQuestionsRules from 'issue/additionalQuestions/AdditionalQuestionsRules';
import BillingInformationRules from 'issue/billingInformation/BillingInformationRules';
import ContactRules from 'issue/contact/ContactRules';
import FillinFormRules from 'issue/fillinForms/FillinFormRules';
import OfficersDashboardRules from 'issue/officers/OfficersDashboardRules';
import PolicyQuestionRules from 'issue/policyQuestions/PolicyQuestionRules';
import _ from 'lodash';
import ModifierRules from 'modifiers/ModifierRules';
import BuildingRules from 'safeguard/locationDashboard/building/BuildingRules';
import BuildingCoveragesRules from 'safeguard/locationDashboard/buildingCoverages/BuildingCoveragesRules';
import BuildingQuestionRules from 'safeguard/locationDashboard/buildingQuestions/BuildingQuestionRules';
import SfgLocationRules from 'safeguard/locationDashboard/location/SfgLocationRules';
import SfgLocationCoverageRules from 'safeguard/locationDashboard/locationCoverage/SfgLocationCoverageRules';
import SfgLocationDashboardRules from 'safeguard/locationDashboard/SfgLocationDashboardRules';
import SafeguardLossesDashboardRules from 'safeguard/losses/SfgLossesDashboardRules';
import SfgLossRules from 'safeguard/losses/SfgLossRules';
import SfgPolicyCoveragesRules from 'safeguard/policyCoverages/SfgPolicyCoveragesRules';
import SfgPolicyInformationRules from 'safeguard/policyInformation/SfgPolicyInformationRules';
import SfgPriorCarrierRules from 'safeguard/priorCarrier/SfgPriorCarrierRules';
import { buildingHasQuestions, distillBuildings, getAdditionalInterestTypes } from 'utils/BusinessFunctions';
import { duplicate, getSet } from 'utils/ObjectFunctions';
import { isBlank } from 'utils/StringFunctions';
import { validate, validateNew } from 'validation/Validate';
import WcpLossesDashboardRules from 'workcomp/losses/WcpLossesDashboardRules';
import WcpLossRules from 'workcomp/losses/WcpLossRules';
import WcpPolicyInformationRules from 'workcomp/policyInformation/WcpPolicyInformationRules';
import WcpPriorCarrierRules from 'workcomp/priorCarrier/WcpPriorCarrierRules';

const { occupancyQuestions } = occupancyQuestionsJson;
const { sfgQuestions } = sfgQuestionsJson;

export function runAllGeneralInformationRules(quote) {
	const rules = GeneralInformationRules.rules(quote, quote);
	const structure = duplicate(GeneralInformationRules.requiredStructure);
	return validate(quote, rules, structure);
}

export function runAllPolicyInformationRules(quote) {
	const rules = SfgPolicyInformationRules.rules(quote, quote);
	const structure = duplicate(SfgPolicyInformationRules.requiredStructure);
	return validate(quote, rules, structure);
}

export function runAllBuildingRules(quote, location, locationId, errors, serviceStatus) {
	let dataObject = {};
	let rulesObject = {};
	let structureObject = {};
	const state = _.get(quote, `addresses[${locationId}].state`);

	const buildings = duplicate({ ..._.get(location, 'buildings') });
	_.forIn(buildings, (building, id) => {
		dataObject = {};
		rulesObject = {};
		structureObject = {};
		// building Rules
		_.merge(structureObject, duplicate(BuildingRules.requiredStructure));
		_.set(building, 'locationId', locationId);
		_.merge(dataObject, building);
		_.set(dataObject, 'id', id);
		_.merge(rulesObject, BuildingRules.rules(quote, dataObject, undefined, serviceStatus));
		if (!isBlank(building.classId)) {
			if (buildingHasQuestions(locationId, building, quote, state)) {
				// building question Rules
				if (!dataObject.questions) {
					dataObject.questions = {};
				}

				_.merge(structureObject, duplicate(BuildingQuestionRules.requiredStructure));
				// This is needed for the dashboard to dynamically build required question structure
				const questionStructure = { questions: {} };
				const occupancyQuestionsIds = occupancyQuestions[building.occupancyType];
				let classQuestions = bopClassCodesJson.classCodes[state][building.classId].questions;
				if (!isBlank(occupancyQuestionsIds)) {
					classQuestions = classQuestions.concat(occupancyQuestionsIds);
				}
				classQuestions.forEach((qidObj, index) => {
					const qid = _.isObject(qidObj) ? qidObj.id : qidObj;
					questionStructure.questions[qid] = '';
				});
				_.merge(structureObject, questionStructure);

				_.merge(rulesObject, BuildingQuestionRules.rules(quote, locationId, building.classId));
			}

			if (!dataObject.coverages) {
				dataObject.coverages = { currentCoverages: new Set([]) };
			} else {
				dataObject.coverages.currentCoverages = getSet(dataObject.coverages.currentCoverages);
			}

			// building coverages Rules
			_.merge(structureObject, duplicate(BuildingCoveragesRules.requiredStructure));
			_.merge(rulesObject, BuildingCoveragesRules.rules(quote, dataObject));
		}

		const buildingValidResults = validate(dataObject, rulesObject, structureObject);
		if (!isBlank(buildingValidResults)) {
			errors[`${locationId}|${id}`] = buildingValidResults;
		}
	});
}

export function runAllLocationRules(quote, serviceStatus) {
	const errors = {};
	let dataObject = {};
	let rulesObject = {};
	let structureObject = {};

	const locations = duplicate({ ..._.get(quote, 'sfg.locations') });
	_.forIn(locations, (location, id) => {
		dataObject = {};
		rulesObject = {};
		structureObject = {};
		const addressData = _.get(quote, `addresses.${id}`, {});

		const sfgReqStruct = duplicate(SfgLocationRules.requiredStructure);
		location.addressL = addressData;
		// Location Rules
		_.merge(structureObject, sfgReqStruct);
		_.merge(dataObject, location);
		_.merge(rulesObject, SfgLocationRules.rules(quote, location, false, serviceStatus, id));

		// Location Coverage Rules
		if (!dataObject.coverages) {
			dataObject.coverages = { currentCoverages: new Set([]) };
		} else {
			dataObject.coverages.currentCoverages = getSet(dataObject.coverages.currentCoverages);
		}

		_.merge(structureObject, duplicate(SfgLocationCoverageRules.requiredStructure));
		// The undefined below is a visibility object which will be created inside the rules for any sfg location coverage dashboard rule call
		_.merge(rulesObject, SfgLocationCoverageRules.rules(quote, dataObject, undefined, id));

		const locationValidResults = validate(dataObject, rulesObject, structureObject);
		if (!isBlank(locationValidResults)) {
			errors[id] = locationValidResults;
		}
		if (!isBlank(addressData.fullAddress)) {
			// call all Building Rules
			runAllBuildingRules(quote, location, id, errors, serviceStatus);
		}
	});
	return errors;
}

export function runAllDriverRules(quote) {
	const errors = {};
	let dataObject = {};
	let rulesObject = {};
	let structureObject = {};

	const drivers = duplicate({ ..._.get(quote, 'cap.drivers') });
	_.forIn(drivers, (driver, id) => {
		dataObject = {};
		rulesObject = {};
		structureObject = {};
		driver.id = id;

		const driverReqStruct = duplicate(DriverRules.requiredStructure);
		// Vehicle Rules
		_.merge(structureObject, driverReqStruct);
		_.merge(dataObject, driver);
		_.merge(rulesObject, DriverRules.rules(quote, driver, false, id));

		const driverValidResults = validate(dataObject, rulesObject, structureObject);
		if (!isBlank(driverValidResults)) {
			errors[id] = driverValidResults;
		}
	});

	return errors;
}

export function runAllVehicleRules(quote) {
	const errors = {};
	let dataObject = {};
	let rulesObject = {};
	let structureObject = {};

	const vehicles = duplicate({ ..._.get(quote, 'cap.vehicles') });
	_.forIn(vehicles, (vehicle, id) => {
		dataObject = {};
		rulesObject = {};
		structureObject = {};

		const vehicleReqStruct = duplicate(VehicleRules.requiredStructure);
		// Vehicle Rules
		_.merge(structureObject, vehicleReqStruct);
		_.merge(dataObject, vehicle);
		_.merge(rulesObject, VehicleRules.rules(quote, vehicle, false, id));

		const vehicleValidResults = validate(dataObject, rulesObject, structureObject);
		if (!isBlank(vehicleValidResults)) {
			errors[id] = vehicleValidResults;
		}
	});

	return errors;
}

export function runDashboardAndAllRules(quote, values, dashboardClass, allRules) {
	let errors = validateNew(quote, values, dashboardClass);

	errors = _.merge(errors, allRules(quote));
	return errors;
}

export function runDashboardAndAllRulesNew(quote, values, dashboardClass, allRules, serviceStatus) {
	let errors = validateNew(quote, values, dashboardClass);

	errors = _.merge(errors, allRules(quote, serviceStatus));
	return errors;
}

export function runAllSfgPolicyCoveragesRules(quote) {
	const { buildingCoverages, totalBppLimits } = distillBuildings(_.get(quote, 'sfg.locations', {}));
	if (quote.sfg && quote.sfg.coverages) {
		quote.sfg.coverages.currentCoverages = getSet(quote.sfg.coverages.currentCoverages);
		const rules = SfgPolicyCoveragesRules.rules(quote, quote, undefined, [...buildingCoverages], totalBppLimits);

		const structure = duplicate(
			SfgPolicyCoveragesRules.requiredStructure(_.get(quote, 'sfg.coverages.CITE.schedule.length')),
		);

		return validate(quote, rules, structure);
	} else {
		return { error: 'Safeguard not initalized' };
	}
}

export function runAllSafeguardPriorCarriersRules(quote) {
	const rules = SfgPriorCarrierRules.rules(quote, quote);

	const structure = duplicate(SfgPriorCarrierRules.requiredStructure);
	return validate(quote, rules, structure);
}

function runAllLossHistoryRules(losses, quote, onPage, ruleClass, dashboardClass) {
	let dataObject = {};
	let rulesObject = {};
	let structureObject = {};
	let errors = onPage
		? {}
		: validate(quote, dashboardClass.rules(quote, quote), duplicate(dashboardClass.requiredStructure));
	_.forIn(losses, (loss, id) => {
		if (!loss.fromLexisNexis) {
			dataObject = {};
			rulesObject = {};
			structureObject = {};
			_.merge(structureObject, duplicate(ruleClass.requiredStructure));
			_.merge(dataObject, loss);
			_.merge(rulesObject, ruleClass.rules(quote, loss));
			const lossValidResults = validate(dataObject, rulesObject, structureObject);
			if (!isBlank(lossValidResults)) {
				errors[id] = lossValidResults;
			}
		}
	});
	return errors;
}

export function runAllSfgLossRules(quote, onPage) {
	if (quote.sfg && quote.sfg.losses) {
		return runAllLossHistoryRules(quote.sfg.losses, quote, onPage, SfgLossRules, SafeguardLossesDashboardRules);
	}
}

export function runAllWorkCompRules(quote) {
	if (quote.wcp && _.includes(_.get(quote, 'products', ['sfg']), 'wcp')) {
		const rules = WcpPolicyInformationRules.rules(quote, quote);

		const structure = duplicate(WcpPolicyInformationRules.requiredStructure(quote, quote));
		return validate(quote, rules, structure);
	}
	return { error: 'Workers compensation not initialized' };
}

export function runAllWorkCompPriorCarriersRules(quote) {
	if (_.get(quote, 'newVenture') !== 'Y') {
		if (quote.wcp && quote.wcp.priorCarrier) {
			const rules = WcpPriorCarrierRules.rules(quote, quote);
			const structure = duplicate(WcpPriorCarrierRules.requiredStructure);
			return validate(quote, rules, structure);
		}
		return { error: 'Workers compensation not initialized' };
	}
}

export function runAllWcpLossRules(quote, onPage) {
	if (quote.wcp && quote.wcp.losses && _.includes(_.get(quote, 'products', ['sfg']), 'wcp')) {
		return runAllLossHistoryRules(quote.wcp.losses, quote, onPage, WcpLossRules, WcpLossesDashboardRules);
	}
}

export function runAllCommercialAutoSymbolRules(quote) {
	if (quote.cap && quote.cap.symbols) {
		const rules = SymbolsLimitsRules.rules(quote, quote);
		const structure = duplicate(SymbolsLimitsRules.requiredStructure);
		return validate(quote, rules, structure);
	}
	return { error: 'Commercial auto not initialized' };
}

export function runAllCommercialAutoStateCoverageRules(quote) {
	//TODO: Figure out why this doesn't work
	if (quote.cap && quote.cap.coverages) {
		const rules = StateCoveragesRules.rules(quote, quote);
		const structure = duplicate(StateCoveragesRules.requiredStructure(quote, quote));
		return validate(quote, rules, structure);
	}
	return { error: 'Commercial auto not initialized' };
}

export function runAllCommercialAutoPriorCarrierRules(quote) {
	if (_.get(quote, 'newVenture') !== 'Y') {
		if (quote.cap && quote.cap.priorCarrier) {
			const rules = CapPriorCarrierRules.rules(quote, quote);
			const structure = duplicate(CapPriorCarrierRules.requiredStructure);
			return validate(quote, rules, structure);
		}
		return { error: 'Commercial auto not initialized' };
	}
}

export function runAllCapLossRules(quote, onPage) {
	if (quote.cap && quote.cap.losses && _.includes(_.get(quote, 'products', ['sfg']), 'cap')) {
		return runAllLossHistoryRules(quote.cap.losses, quote, onPage, CapLossRules, CapLossesDashboardRules);
	}
}

export function runAllCommercialUmbrellaRules(quote) {
	if (quote.cup && _.includes(_.get(quote, 'products', ['sfg']), 'cup')) {
		return validate(
			quote,
			CupPolicyInformationRules.rules(quote, quote),
			duplicate(CupPolicyInformationRules.requiredStructure),
		);
	}
	return { error: 'Commercial umbrella not initialized' };
}

export function runAllCommercialUmbrellaUnderlyingPoliciesRules(quote) {
	if (quote.cup && _.includes(_.get(quote, 'products', ['sfg']), 'cup')) {
		const errors = validate(
			quote,
			UnderlyingPoliciesRules.rules(quote, quote),
			duplicate(UnderlyingPoliciesRules.requiredStructure),
		);
		return errors;
	}
	return { error: 'Commercial umbrella not initialized' };
}

export function runAllCommercialUmbrellaPriorCarrierRules(quote) {
	if (_.get(quote, 'newVenture') !== 'Y') {
		if (quote.cup && quote.cup.priorCarrier && _.includes(quote.products, 'cup')) {
			const rules = CupPriorCarrierRules.rules(quote, quote);
			const structure = duplicate(CupPriorCarrierRules.requiredStructure);
			return validate(quote, rules, structure);
		}
		return { error: 'Commercial umbrella not initialized' };
	}
}

export function runAllCupLossRules(quote, onPage) {
	if (quote.cup && quote.cup.losses && _.includes(_.get(quote, 'products', ['sfg']), 'cup')) {
		return runAllLossHistoryRules(quote.cup.losses, quote, onPage, CupLossRules, CupLossesDashboardRules);
	}
}

export function runAllModifierRules(quote) {
	const rules = ModifierRules.rules(quote, quote);
	const structure = duplicate(ModifierRules.requiredStructure(quote, quote));
	return validate(quote, rules, structure);
}

export function runAllPolicyQuestionRules(quote) {
	if (_.get(quote, 'policyQuestions')) {
		let visibility = {};

		_.forIn(sfgQuestions, (q, qid) => {
			q.id = qid;
			if (q.da) {
				const dependencyParts = _.split(q.da, '_');
				if (_.get(quote, 'policyQuestions')[dependencyParts[0]] == dependencyParts[1] /* eslint eqeqeq: [0] */) {
					visibility[qid] = true;
				} else {
					visibility[qid] = false;
				}
			}
		});
		const rules = PolicyQuestionRules.rules(quote, visibility);

		const structure = duplicate(PolicyQuestionRules.requiredStructure);
		return validate(quote, rules, structure);
	} else {
		return {};
	}
}

export function runAllAdditionalInterestRules(quote) {
	const errors = {};
	let dataObject = {};
	let rulesObject = {};
	let structureObject = {};
	let optionsObject = {};
	optionsObject = getAdditionalInterestTypes(quote);
	const additionalInterests = { ..._.get(quote, 'additionalInterests') };
	_.forIn(additionalInterests, (additionalInterest, id) => {
		dataObject = {};
		rulesObject = {};
		structureObject = {};
		_.merge(structureObject, duplicate(AdditionalInterestRules.requiredStructure));
		_.merge(dataObject, additionalInterest);
		_.merge(rulesObject, AdditionalInterestRules.rules(quote, dataObject, optionsObject));
		const additionalInterestValidResults = validate(dataObject, rulesObject, structureObject);
		if (!isBlank(additionalInterestValidResults)) {
			errors[id] = additionalInterestValidResults;
		}
	});
	return errors;
}

export function runAllOfficersRules(quote) {
	if (_.includes(_.get(quote, 'products', ['sfg']), 'wcp')) {
		const rules = OfficersDashboardRules.rules(quote, quote);
		const structure = duplicate(OfficersDashboardRules.requiredStructure);
		return validate(quote, rules, structure);
	}
}

export function runAllFillingFormRules(quote) {
	const rules = FillinFormRules.rules(quote, quote);
	const structure = duplicate(FillinFormRules.requiredStructure);
	return validate(quote, rules, structure);
}

export function runAllContactRules(quote) {
	const rules = ContactRules.rules(quote, quote);
	const structure = duplicate(ContactRules.requiredStructure);
	return validate(quote, rules, structure);
}

export function runAllBillingInformationRules(quote) {
	const rules = BillingInformationRules.rules(quote, quote);
	const structure = duplicate(BillingInformationRules.requiredStructure);
	return validate(quote, rules, structure);
}

export function validEmail(email) {
	const regex =
		/^((([a-z]|\d|[!#$%&'*+-/=?^_`{|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#$%&'*+-/=?^_`{|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i; /* eslint no-control-regex: [0] */
	return regex.test(email.trim());
}

export function runAllRules(props, quote, navigation, checkNavProducts, updateNav, serviceStatus) {
	const generalInfoData = duplicate(quote);
	generalInfoData.address = _.get(quote, 'addresses.1', _.get(quote, 'address', { fullAddress: '' }));
	generalInfoData.personEnteringRiskEmail =
		quote.personEnteringRiskEmail || localStorage.getItem('personEnteringRiskEmail') || '';
	const errors = [
		{
			url: '/quote/generalInformation',
			errors: validateNew(generalInfoData, generalInfoData, GeneralInformationRules),
		},
		{
			url: '/quote/safeguard/policyInformation',
			errors: validateNew(quote, quote, SfgPolicyInformationRules),
		},
		{
			url: '/quote/safeguard/locations',
			errors: runDashboardAndAllRulesNew(quote, quote, SfgLocationDashboardRules, runAllLocationRules, serviceStatus),
		},
		{
			url: '/quote/safeguard/coverages',
			errors: runAllSfgPolicyCoveragesRules(quote),
		},
		{
			url: '/quote/safeguard/priorCarrier',
			errors: runAllSafeguardPriorCarriersRules(quote),
		},
		{
			url: '/quote/safeguard/losses',
			errors: runAllSfgLossRules(quote),
		},
		{
			url: '/quote/workcomp/classInformation',
			errors: runAllWorkCompRules(quote),
		},
		{
			url: '/quote/workcomp/priorCarrier',
			errors: runAllWorkCompPriorCarriersRules(quote),
		},
		{
			url: '/quote/workcomp/losses',
			errors: runAllWcpLossRules(quote),
		},
		{
			url: '/quote/cap/symbolsLimits',
			errors: runAllCommercialAutoSymbolRules(quote),
		},
		{
			url: '/quote/cap/stateCoverages',
			errors: runAllCommercialAutoStateCoverageRules(quote),
		},
		{
			url: '/quote/cap/drivers',
			errors: runDashboardAndAllRules(quote, quote, DriverDashboardRules, runAllDriverRules),
		},
		{
			url: '/quote/cap/vehicles',
			errors: runDashboardAndAllRules(quote, quote, VehicleDashboardRules, runAllVehicleRules),
		},
		{
			url: '/quote/cap/priorCarrier',
			errors: runAllCommercialAutoPriorCarrierRules(quote),
		},
		{
			url: '/quote/cap/losses',
			errors: runAllCapLossRules(quote),
		},
		{
			url: '/quote/cup/policyInformation',
			errors: runAllCommercialUmbrellaRules(quote),
		},
		{
			url: '/quote/cup/underlyingPolicies',
			errors: runAllCommercialUmbrellaUnderlyingPoliciesRules(quote),
		},
		{
			url: '/quote/cup/priorCarrier',
			errors: runAllCommercialUmbrellaPriorCarrierRules(quote),
		},
		{
			url: '/quote/cup/losses',
			errors: runAllCupLossRules(quote),
		},
		{ url: '/quote/modifiers', errors: runAllModifierRules(quote) },
		{
			url: '/quote/issue/policyQuestions',
			errors: runAllPolicyQuestionRules(quote),
		},
		{
			url: '/quote/issue/additionalInterests',
			errors: runAllAdditionalInterestRules(quote),
		},
		{
			url: '/quote/issue/officers',
			errors: runAllOfficersRules(quote),
		},
		{
			url: '/quote/issue/fillinForms',
			errors: runAllFillingFormRules(quote),
		},
		{
			url: '/quote/issue/additionalQuestions',
			errors: validateNew(quote, quote, AdditionalQuestionsRules),
		},
		{ url: '/quote/issue/contact', errors: runAllContactRules(quote) },
		// '/quote/issue/billingInformation': {
		//   errors: runAllBillingInformationRules(quote),
		// },
		{ url: '/quote/rate', errors: [] },
	];
	const currentPageIndex = props ? errors.findIndex((e) => e.url === _.get(props, 'location.pathname', -1)) : -1;
	let navigateToPageUrl = undefined;
	let firstErrorPageIndex = undefined;
	// If we aren't on a page needing validation skip the logic
	if (currentPageIndex === -1) {
		return true;
	}
	const initNav = _.cloneDeep(navigation);
	let isCurrentError = false;
	navigation.navItems.forEach((navItem, index) => {
		let pageIndex = undefined;
		let errorsItem;
		let childError = false;
		if (!navItem.visible) {
			navItem.valid = true;
		} else if (!isCurrentError) {
			// check children rules
			const { children } = navItem;
			if (children) {
				children.forEach((childNavItem) => {
					if (!isCurrentError) {
						errorsItem = errors.find((e) => e.url === childNavItem.url);
						pageIndex = errors.findIndex((e) => e.url === childNavItem.url);
						if (errorsItem && !isBlank(errorsItem.errors)) {
							childNavItem.valid = false;
							isCurrentError = true;
							childError = true;
							// Capture the first page with an error on it to determine if we passed validation for navigation
							if (!firstErrorPageIndex) {
								firstErrorPageIndex = pageIndex;
							}
							// Get the page to navigate to if we are past it.
							if (!navigateToPageUrl && currentPageIndex > errors.findIndex((e) => e.url === childNavItem.url)) {
								navigateToPageUrl = childNavItem.url;
							}
						} else {
							childNavItem.valid = true;
						}
					} else {
						childNavItem.valid = false;
						childError = true;
					}
				});
			}
			errorsItem = errors.find((e) => e.url === navItem.url);
			pageIndex = errors.findIndex((e) => e.url === navItem.url);
			if ((errorsItem && !isBlank(errorsItem.errors)) || childError) {
				navItem.valid = false;
				isCurrentError = true;
				// Capture the first page with an error on it to determine if we passed validation for navigation
				if (!firstErrorPageIndex) {
					firstErrorPageIndex = pageIndex;
				}
				// Get the page to navigate to if we are past it.
				if (!navigateToPageUrl && currentPageIndex > errors.findIndex((e) => e.url === navItem.url)) {
					navigateToPageUrl = navItem.url;
				}
			} else {
				navItem.valid = true;
			}
		} else {
			// If there is an error on a previous page, invalidate all forward pages
			navItem.valid = false;
		}
	});

	if (props.location.pathname !== '/quote/rate' && !props.location.pathname.includes('/quote/issue')) {
		navigation.navItems = navigation.navItems.map((navItem) => {
			if (navItem.url.includes('issue')) {
				navItem.visible = false;
			}
			return navItem;
		});
	}
	checkNavProducts(getSet(quote.products), props, true);
	if (!_.isEqual(initNav, navigation)) {
		updateNav(navigation);
	}

	// If there is no error or the first error is beyond the current page, we passed validation for navigation
	const passedValidation =
		firstErrorPageIndex === undefined || (firstErrorPageIndex !== 0 && firstErrorPageIndex > currentPageIndex);
	//If there is a error and it is before the current page, navigate to it
	if (firstErrorPageIndex !== undefined && firstErrorPageIndex < currentPageIndex && navigateToPageUrl && props) {
		if (props.location.pathname === '/quote/rate') {
			if (navigateToPageUrl.includes('issue')) {
				let canAdvance = true;
				quote.products.forEach((product) => {
					if (!_.isNumber(quote.rates[product])) {
						canAdvance = false;
					}
				});

				if (!canAdvance) {
					navigateToPageUrl = props.location.pathname;
				}
			}
		}

		if (navigateToPageUrl.includes('issue') && !props.location.pathname.includes('issue')) {
			navigateToPageUrl = '/quote/issue/policyQuestions';
		}

		props.history.push(navigateToPageUrl);
	}
	return passedValidation;
}
