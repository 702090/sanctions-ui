import _ from 'lodash';
import callClue from 'services/clueService';
import { duplicate, getSet } from 'utils/ObjectFunctions';
import { runAllRules } from './Validation';

export function getProductsToCall(context, quote) {
	let productsToCall = duplicate(quote.products);
	quote.products.forEach((product) => {
		if (product === 'cap') {
			productsToCall = productsToCall.filter((prod) => prod != 'cap');
			setReorderRule(context, quote, product);
		}
	});

	return productsToCall;
}

export function setReorderRule(context, quote, product, props) {
	// TODO: simplify this.
	const clueOrderRequired = getSet(_.get(quote, 'clueOrderRequired', []));
	clueOrderRequired.add(product);
	_.set(quote, 'clueOrderRequired', clueOrderRequired);
	context.updateQuoteState(quote);
	runAllRules(
		props,
		context.quote,
		context.navigation,
		context.checkNavProducts,
		context.updateNav,
		context.serviceStatus,
	);
}

export async function dashboardClueCall(context, props, product) {
	context.serviceStatus.clue = true;
	await callClue(context.quote, [product]);
	const clueOrderRequired = getSet(_.get(context.quote, 'clueOrderRequired', []));
	clueOrderRequired.delete(product);
	_.set(context.quote, 'clueOrderRequired', clueOrderRequired);
	context.updateQuote(context.quote, props);
	context.serviceStatus.clue = false;
}
