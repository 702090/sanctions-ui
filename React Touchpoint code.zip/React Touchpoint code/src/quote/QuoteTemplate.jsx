import { parseJwt } from '@columbiainsurance/functions-js';
import DriverDashboard from 'commercialAuto/drivers/DriverDashboard';
import CapLossesDashboard from 'commercialAuto/losses/CapLossesDashboard';
import CapPriorCarrier from 'commercialAuto/priorCarrier/CapPriorCarrierForm';
import StateCoveragesForm from 'commercialAuto/stateCoverages/StateCoveragesForm';
import SymbolsLimitsForm from 'commercialAuto/symbolsLimits/SymbolsLimitsForm';
import VehicleDashboard from 'commercialAuto/vehicles/VehicleDashboard';
import CupLossesDashboard from 'commercialUmbrella/losses/CupLossesDashboard';
import CupPolicyInformationForm from 'commercialUmbrella/policyInformation/CupPolicyInformationForm';
import CupPriorCarrier from 'commercialUmbrella/priorCarrier/CupPriorCarrierForm';
import UnderlyingPoliciesForm from 'commercialUmbrella/underlyingPolicies/UnderlyingPoliciesForm';
import ProgressBar from 'components/shared/navigation/ProgressBar';
import { Stepper } from 'components/shared/navigation/Stepper';
import ProcessingBanner from 'components/shared/wait/ProcessingBanner';
import { Spinner } from 'components/shared/wait/Spinner';
import QuoteContext from 'context/quoteContext';
import GeneralInformation from 'generalInformation/GeneralInformationForm';
import AdditionalForms from 'issue/additionalForms/AdditionalForms';
import AdditionalInterestDashboard from 'issue/additionalInterest/AdditionalInterestDashboard';
import AdditionalQuestionsForm from 'issue/additionalQuestions/AdditionalQuestionsForm';
import BillingInformation from 'issue/billingInformation/BillingInformationForm';
import CardPayment from 'issue/billingInformation/CardPayment';
import CardPaymentDecline from 'issue/billingInformation/CardPaymentDecline';
import Contact from 'issue/contact/ContactForm';
import FillinForms from 'issue/fillinForms/FillinForms';
import OfficersDashboard from 'issue/officers/OfficersDashboard';
import PolicyQuestions from 'issue/policyQuestions/PolicyQuestionsForm';
import SubmissionProcess from 'issue/SubmissionProcess';
import { Submitted } from 'issue/Submitted';
import Summary from 'issue/summary/Summary';
import _ from 'lodash';
import Modifiers from 'modifiers/ModifiersForm';
import Rate from 'rate/RateForm';
import React, { useContext, useEffect } from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';
import { toast } from 'react-toastify';
import SafeguardLocationDashboard from 'safeguard/locationDashboard/SfgLocationDashboard';
import SafeguardLosses from 'safeguard/losses/SfgLossesDashboard';
import SafeguardCoveragesForm from 'safeguard/policyCoverages/SfgPolicyCoveragesForm';
import Safeguard from 'safeguard/policyInformation/SfgPolicyInformationForm';
import SafeguardPriorCarrier from 'safeguard/priorCarrier/SfgPriorCarrierForm';
import { getAgentToken } from 'services/agentService';
import { getQuote } from 'services/quoteService';
import Sidebar from 'sidebar/Sidebar';
import { isEmployee } from 'utils/BusinessFunctions';
import WcpLosses from 'workcomp/losses/WcpLossesDashboard';
import WcpPolicyInformationForm from 'workcomp/policyInformation/WcpPolicyInformationForm';
import WcpPriorCarrier from 'workcomp/priorCarrier/WcpPriorCarrierForm';

const QuoteForm = (props) => {
	const context = useContext(QuoteContext);
	useEffect(() => {
		async function load() {
			let agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));
			// If they are changing to a quote under a different agent, reload the agent info
			if (
				isEmployee() &&
				agent.agentSubpro !== props.match.params.agentSubpro &&
				props.match.params.agentSubpro &&
				props.match.params.agentSubpro !== ''
			) {
				agent = await getAgentToken(props.match.params.agentSubpro, agent.userId);
				agent = parseJwt(agent);
				sessionStorage.setItem('agentJSONObject', JSON.stringify(agent));
				props.onChange(agent);
			}
			if (props.match.path === '/quote/load/:agentSubpro/:id') {
				try {
					const quote = await getQuote(props.match.params.agentSubpro, props.match.params.id);

					quote.products = _.get(quote, 'products', ['sfg']);

					context.updateQuoteState(quote, props);
					// Set the context quote manually so it's available in the following conditionals in this method
					context.quote = quote;
					props.history.replace('/quote/generalInformation');
				} catch (err) {
					console.error(err);
					toast.error('The requested quote could not be found.');
					props.history.replace('/');
				}
			}
			if (context.quote.id === undefined && props.location.pathname !== '/quote') {
				props.history.replace('/');
			}

			if (context.quote.id === undefined) {
				_.set(context.quote, 'agentSubpro', `${agent.number}-${agent.subpro}`);
			}
		}
		load();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	const submitted =
		_.endsWith(props.location.pathname, 'submitted') || props.location.pathname === '/quote/issue/progress';
	return (
		<React.Fragment>
			{!submitted && (
				<div id='progressColumn'>
					<div height='40px'>&nbsp;</div>
					<ProgressBar pages={context.navigation.navItems} lastValidPageIndex={0} {...props} />
				</div>
			)}
			<div id='quoteContainer' className={submitted ? 'submitted' : ''}>
				<div id='contentColumn' className={submitted ? 'submitted' : ''}>
					<Stepper pages={context.navigation.navItems} {...props} />
					<Route
						render={({ location }) => (
							<Switch location={location}>
								<Route path='/quote/load/:id' render={() => <Spinner label='Loading Quote...' />} />
								<Route path='/quote/generalInformation' component={GeneralInformation} />
								<Route path='/quote/safeguard/policyInformation' component={Safeguard} />
								<Route path='/quote/safeguard/locations' component={SafeguardLocationDashboard} />
								<Route path='/quote/safeguard/coverages' component={SafeguardCoveragesForm} />
								<Route path='/quote/safeguard/priorCarrier' component={SafeguardPriorCarrier} />
								<Route path='/quote/safeguard/losses' component={SafeguardLosses} />
								<Route path='/quote/workcomp/classInformation' component={WcpPolicyInformationForm} />
								<Route path='/quote/workcomp/priorCarrier' component={WcpPriorCarrier} />
								<Route path='/quote/workcomp/losses' component={WcpLosses} />
								<Route path='/quote/cap/symbolsLimits' component={SymbolsLimitsForm} />
								<Route path='/quote/cap/stateCoverages' component={StateCoveragesForm} />
								<Route path='/quote/cap/drivers' component={DriverDashboard} />
								<Route path='/quote/cap/vehicles' component={VehicleDashboard} />
								<Route path='/quote/cap/priorCarrier' component={CapPriorCarrier} />
								<Route path='/quote/cap/losses' component={CapLossesDashboard} />
								<Route path='/quote/cup/policyInformation' component={CupPolicyInformationForm} />
								<Route path='/quote/cup/underlyingPolicies' component={UnderlyingPoliciesForm} />
								<Route path='/quote/cup/priorCarrier' component={CupPriorCarrier} />
								<Route path='/quote/cup/losses' component={CupLossesDashboard} />
								<Route path='/quote/modifiers' component={Modifiers} />
								<Route path='/quote/progress' component={SubmissionProcess} />
								<Route path='/quote/rate' component={Rate} />
								<Route path='/quote/issue/officers' component={OfficersDashboard} />
								<Route path='/quote/issue/policyQuestions' component={PolicyQuestions} />
								<Route path='/quote/issue/additionalInterests' component={AdditionalInterestDashboard} />
								<Route path='/quote/issue/fillinForms' component={FillinForms} />
								<Route path='/quote/issue/additionalQuestions' component={AdditionalQuestionsForm} />
								<Route path='/quote/issue/contact' component={Contact} />
								<Route path='/quote/issue/summary' component={Summary} />
								<Route path='/quote/issue/billingInformation' component={BillingInformation} />
								<Route path='/quote/issue/additionalForms' component={AdditionalForms} />
								<Route path='/quote/issue/cardPayment' component={CardPayment} />
								<Route path='/quote/issue/cardPaymentDecline' component={CardPaymentDecline} />
								<Route path='/quote/issue/progress' component={SubmissionProcess} />
								<Route path='/quote/issue/submitted' component={Submitted} />
								<Redirect from='/quote/cap' to='/quote/cap/symbolsLimits' />
								<Redirect from='/quote/workcomp' to='/quote/workcomp/classInformation' />
								<Redirect from='/quote/cup' to='/quote/cup/policyInformation' />
								<Redirect from='/quote/issue' to='/quote/issue/policyQuestions' />
								<Redirect from='/quote/safeguard' to='/quote/safeguard/policyInformation' />
								<Redirect to='/quote/generalInformation' />
							</Switch>
						)}
					/>
				</div>
			</div>
			{!submitted && <Sidebar updateProducts={context.updateProducts} {...props} />}
			<ProcessingBanner />
		</React.Fragment>
	);
};

export default QuoteForm;
