import 'App.scss';
import ApplicationHeader from 'components/shared/ApplicationHeader';
import { Spinner } from 'components/shared/wait/Spinner';
import GlobalState from 'context/globalState';
import Dashboard from 'dashboard/Dashboard';
import ErrorTemplate from 'error/ErrorTemplate';
import SystemError from 'error/SystemError';
import { parseJwt } from '@columbiainsurance/functions-js';
import _ from 'lodash';
import Application from 'print/Application';
import queryString from 'query-string';
import QuoteTemplate from 'quote/QuoteTemplate';
import React, { Component } from 'react';
import { Redirect, Route, Switch, withRouter } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { googleAnalyticsInitialize, pageAnalytics } from 'utils/ScreenFunctions';
import ScrollToTop from './components/shared/ScrollToTop';

// Test comment to force a rebuild - again
class App extends Component {
	state = { loading: true };

	// sendPageView = () => {
	// pageAnalytics(this.props.location.pathname);
	// };

	// componentDidMount() {
	// this.sendPageView();
	// }

	// componentDidUpdate() {
	// this.sendPageView();
	// }

	constructor(props) {
		super(props);
		this.handleChange = this.handleChange.bind(this);
	}

	setSessionValues({ agentToken, cigToken, authorizationToken, authorizationRefresh }) {
		let agent = parseJwt(agentToken);

		if (agent) {
			this.setState({ agent });
			sessionStorage.setItem('agentToken', agentToken);
			sessionStorage.setItem('agentJSONObject', JSON.stringify(agent));
			this.props.history.replace('/');
		}

		if (cigToken) {
			sessionStorage.setItem('cigToken', cigToken);
		}

		if (authorizationToken) {
			sessionStorage.setItem('authorizationToken', authorizationToken);
		}

		if (authorizationRefresh) {
			sessionStorage.setItem('authorizationRefresh', authorizationRefresh);
		}
	}

	UNSAFE_componentWillMount() {
		if (this.props.location.pathname === '/') {
			const values = queryString.parse(this.props.location.search);
			this.setSessionValues(values);

			// If you are running this locally and don't have a cognito token yet go through the servlet
			if (window.location.hostname === 'localhost' && !sessionStorage.getItem('authorizationToken')) {
				window.location.href = `${process.env.REACT_APP_SERVLET_DOMAIN}/AgentPortal/ReactAppServlet?application=TouchPoint&local=true&${process.env.REACT_APP_ENVIRONMENT_NAME}=true`;
			}

			this.setState({ loading: false });

			let agent = parseJwt(sessionStorage.getItem('agentToken'));
			// Are they here for an application?
			if (values.application) {
				this.props.history.replace(
					`/application/${agent.agentSubpro === '55110-00001' ? values.as : agent.agentSubpro}/${values.application}/${
						values.product ? values.product : 'all'
					}`,
				);
			}

			// googleAnalyticsInitialize(agent);
		} else {
			this.setState({ loading: false });
		}
	}

	handleChange(agent) {
		this.setState({ agent });
	}

	render() {
		if (this.state.loading) {
			return <h2>Loading...</h2>;
		}
		return (
			<React.Fragment>
				<GlobalState>
					<ToastContainer />
					<ApplicationHeader
						agent={this.state.agent}
						className={_.startsWith(this.props.location.pathname, '/quote') ? 'quote' : null}
						imagePath={require(`images/TouchPointLogo_${process.env.REACT_APP_ENVIRONMENT_NAME}.png`)}
						pathname={this.props.location.pathname}
					/>
					<ScrollToTop />
					<Switch>
						<Route path='/load' render={(props) => <Spinner label='Loading ...' />} />
						<Route
							path='/quote/load/:agentSubpro/:id'
							render={(props) => <QuoteTemplate onChange={this.handleChange} {...props} />}
						/>
						<Route path='/quote' component={QuoteTemplate} />
						<Route path='/application/:agentSubpro/:id/:product' component={Application} />
						<Route path='/accessdenied' component={ErrorTemplate} />
						<Route path='/systemError' component={SystemError} />
						<Route path='/' exact component={Dashboard} />
						<Redirect to='/' />
					</Switch>
				</GlobalState>
			</React.Fragment>
		);
	}
}

export default withRouter(App);
