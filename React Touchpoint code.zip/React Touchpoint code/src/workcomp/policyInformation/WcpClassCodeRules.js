import ruleMessagesJson from 'data/RuleMessages';
import wcpClassesJson from 'data/WCPClassCodes';
import _ from 'lodash';
import { isBlank } from 'utils/StringFunctions';
import { getPredState } from 'utils/BusinessFunctions';

const { requiredMessageText } = ruleMessagesJson;

class WcpClassCodeRules {
	static requiredStructure = {
		classCodeId: '',
		location: '',
		annualPayroll: '',
		group_numberOfEmployees: '',
	};

	static optionalStructure = {
		fullTimeEmployees: '',
		partTimeEmployees: '',
	};

	static rules(quote, values) {
		const classCodeList = _.get(quote, 'wcp.classCodes', {});

		return {
			classCodeId: [
				[(value) => !isBlank(value), requiredMessageText],
				[
					(value) => {
						return isBlank(
							_.pickBy(classCodeList, (classCode, id) => {
								return (
									classCode.classCodeId === value &&
									classCode.id !== values.id &&
									classCode.location === values.location
								);
							}),
						);
					},
					'This class code is already added to the selected location.',
				],
			],
			location: [[(value) => !isBlank(value), requiredMessageText]],
			annualPayroll: [
				[(value) => !isBlank(value), requiredMessageText],
				[(value) => !isBlank(value) && _.toNumber(value) <= 49999999, 'Annual Payroll must not be be than $49,999,999'],
			],
			group_numberOfEmployees: [
				[
					(value) => !isBlank(values.fullTimeEmployees) || !isBlank(values.partTimeEmployees),
					'Please enter at least one full time or part time employee',
				],
			],
		};
	}

	static referrals(context, values) {
		return {
			classCodeId: [
				[
					(value) => {
						return _.get(wcpClassesJson.classCodes, `${getPredState(context.quote)}.${value}.p`, '') !== 2;
					},
					'WCC01',
				],
			],
		};
	}

	static name() {
		return 'wcpClassCode';
	}
}

export default WcpClassCodeRules;
