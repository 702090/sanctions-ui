import { getFieldDisplayArray } from 'data/FieldVisibility';
import ruleMessagesJson from 'data/RuleMessages';
import _ from 'lodash';
import { needNumberOfOfficersIncluded, needWcpRiskId } from 'utils/FieldDisplay';
import { getVisibility } from 'utils/ScreenFunctions';
import { allCharactersSame, isBlank, isBlankZ, stripMask } from 'utils/StringFunctions';

const { requiredMessageText } = ruleMessagesJson;

class WcpPolicyInformationRules {
	static requiredStructure(quote, values) {
		let employeesByLocation = {};
		_.forIn(_.get(quote, 'wcp.classCodes', {}), (classCode) => {
			const fieldId = `id${classCode.location}`;
			employeesByLocation[fieldId] = '';
		});
		let requiredStructure = {
			section_classCode: '',
			group_TX_smallDeductible: '',
			fein: '',
			wcp: {
				employersLiability: '',
				officersIncluded: '',
				numberOfOfficersIncluded: '',
				experienceMod: '',
				monthsInBusiness: '',
				previousInsurance: '',
				lostTimeClaims: '',
				numberOfLostTimeClaims: '',
				riskId: '',
				modifiers: { TX: { smallDeductible1: '', smallDeductible2: '' } },
				prefillData: {
					ncci: {
						responseCode: '',
					},
				},
				employeesByLocation,
			},
		};
		return requiredStructure;
	}

	static rules(quote, values, visibility) {
		if (values && !visibility) {
			visibility = getVisibility(getFieldDisplayArray('workcomp'), quote, values);
		}
		const classCodeList = _.get(quote, 'wcp.classCodes', {});
		let wcpRules = {
			section_classCode: [[(value) => !isBlank(classCodeList), 'At least one class code is required']],
			group_TX_smallDeductible: [
				[
					(value) =>
						!visibility['wcp.smallDeductible1'] ||
						(isBlank(_.get(values, 'wcp.modifiers.TX.smallDeductible1')) &&
							isBlank(_.get(values, 'wcp.modifiers.TX.smallDeductible2'))) ||
						(!isBlank(_.get(values, 'wcp.modifiers.TX.smallDeductible1')) &&
							!isBlank(_.get(values, 'wcp.modifiers.TX.smallDeductible2'))),
					'Both deductibles required if one is entered.',
				],
			],
			fein: [
				[(value) => !allCharactersSame(value, true), 'FEIN cannot be all the same numbers.'],
				[
					(value) => isBlank(stripMask(value)) || stripMask(value).length === 9,
					'FEIN must have 9 digits if it is entered.',
				],
				[
					(value) => isBlank(stripMask(value)) || !_.includes(['123456789', '987654321'], stripMask(value)),
					'FEIN must not be 123456789 or 987654321.',
				],
				[(value) => !(isBlank(value) && _.includes(quote.products, 'wcp')), requiredMessageText],
			],
			wcp: {
				employersLiability: [[(value) => !isBlank(value), requiredMessageText]],
				officersIncluded: [[(value) => !isBlank(value), requiredMessageText]],
				numberOfOfficersIncluded: [
					[(value) => !(isBlankZ(value) && needNumberOfOfficersIncluded(quote, values)), requiredMessageText],
					[
						(value) => !needNumberOfOfficersIncluded(quote, values) || (value > 0 && value <= 10),
						'The number of included officers must be between 1 and 10',
					],
				],
				experienceMod: [
					[
						(value) => isBlankZ(value) || (value >= 0.1 && value <= 9.99),
						'Experience Modifier must be between 0.1 and 9.99.',
					],
				],
				monthsInBusiness: [[(value) => !visibility['wcp.monthsInBusiness'] || !isBlank(value), requiredMessageText]],
				previousInsurance: [[(value) => !visibility['wcp.previousInsurance'] || !isBlank(value), requiredMessageText]],
				lostTimeClaims: [[(value) => !visibility['wcp.lostTimeClaims'] || !isBlank(value), requiredMessageText]],
				numberOfLostTimeClaims: [
					[(value) => !visibility['wcp.numberOfLostTimeClaims'] || !isBlank(value), requiredMessageText],
				],
				riskId: [[(value) => !(isBlank(value) && needWcpRiskId(quote, values)), requiredMessageText]],
				modifiers: {
					TX: {
						smallDeductible1: [
							[
								(value) => isBlank(value) || _.toNumber(_.get(quote, 'rates.wcp', '')) >= 5000,
								'Cannot add small deductible with premium less than $5,000.',
							],
						],
					},
				},
			},
		};

		let locationCount = {};
		_.forIn(classCodeList, (classCode) => {
			const formLocId = `id${classCode.location}`;
			const employeeMaxTotal = _.get(locationCount, `${formLocId}.employeeMaxTotal`, 0);
			const employeeMin =
				(_.toNumber(classCode.fullTimeEmployees) || 0) + (_.toNumber(classCode.partTimeEmployees) || 0);

			if (_.get(locationCount, `${formLocId}.minEmployees`, 0) < employeeMin) {
				_.set(locationCount, `${formLocId}.minEmployees`, employeeMin);
			}
			_.set(locationCount, `${formLocId}.employeeMaxTotal`, employeeMin + employeeMaxTotal);
		});

		_.forIn(locationCount, (location, id) => {
			_.set(wcpRules, `wcp.employeesByLocation.${id}`, [
				[(value) => !isBlank(value), requiredMessageText],
				[
					(value) =>
						(!isBlank(value) && value === location.minEmployees) || location.minEmployees !== location.employeeMaxTotal,
					`The total number of part and full time employees must equal ${location.minEmployees}`,
				],
				[
					(value) => !isBlank(value) && value >= location.minEmployees && value <= location.employeeMaxTotal,
					`The total number of part and full time employees must be between ${location.minEmployees} and ${location.employeeMaxTotal}`,
				],
			]);
		});

		return wcpRules;
	}

	static referrals(context, values) {
		return {
			wcp: {
				experienceMod: [
					[
						(value) => {
							return isBlank(value) || value <= 1;
						},
						'WCP01',
					],
				],
				prefillData: {
					ncci: {
						responseCode: [
							[
								(value) => {
									const nonreferResponses = [
										'No Current Mod Information for Risk Id',
										'No Current and Future Mods Found for RiskId',
										'No Current, Future and Historical Mods Found for RiskId',
										'No Current and Future Mods Found Matching',
										'No Records Returned for Federal Employer Identification Number',
									];
									const responseMessage = _.get(values, 'wcp.prefillData.ncci.responseMessage', '');
									const containsNonReferMessage = _.some(nonreferResponses, (nrm) => {
										return responseMessage.toUpperCase().includes(nrm.toUpperCase());
									});
									return isBlank(value) || value == '0' || containsNonReferMessage /*eqeqeq*/;
								},
								'WCP02',
							],
						],
					},
				},
			},
		};
	}
	static name() {
		return 'wcpPolicyInformation';
	}
}

export default WcpPolicyInformationRules;
