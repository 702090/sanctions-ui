import QuoteContext from 'context/quoteContext';
import React, { Component } from 'react';
import { Modal } from 'semantic-ui-react';
import { pageAnalytics } from 'utils/ScreenFunctions';
import { replaceReferrals } from 'validation/RunReferrals';
import WcpClassCodeForm from 'workcomp/policyInformation/WcpClassCodeForm';

export default class WcpClassCodeModal extends Component {
	static contextType = QuoteContext;

	constructor() {
		super();
		this.state = {
			isOpen: false,
		}; // state to control the state of popup
	}

	handleOpen = (classCodeId, classCode, callBack, location, history) => {
		this.setState({
			isOpen: true,
			classCodeId,
			classCode,
			callBack,
			location,
			history,
		});
		pageAnalytics(location.pathname + '/WcpClassCodeModal', true);
	};

	handleClose = () => {
		this.state.callBack();
		replaceReferrals(this.context);
		this.setState({ isOpen: false });
		pageAnalytics(this.state.location.pathname);
	};

	render() {
		const { isOpen, classCodeId, classCode, location, history } = this.state;
		return (
			<Modal closeIcon open={isOpen} closeOnDimmerClick={false} onClose={this.handleClose}>
				<Modal.Content>
					<WcpClassCodeForm
						id={classCodeId}
						classCode={classCode}
						handleClose={this.handleClose}
						location={location}
						history={history}
					/>
				</Modal.Content>
			</Modal>
		);
	}
}
