import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { SubmitButton } from 'components/shared/buttons/SubmitButton';
import AddressPicker from 'components/shared/form/inputs/AddressPicker';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { Select } from 'components/shared/form/Select';
import { toSortedPairList } from 'components/shared/navigation/NavigationFunctions';
import { OptionalSection } from 'components/shared/sections/OptionalSection';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import wcpClassCodesJson from 'data/WCPClassCodes';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { Component } from 'react';
import { cleanOrphanAddresses } from 'utils/BusinessFunctions';
import { toDate } from 'utils/DateFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import { cleanValues, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { v4 as uuidv4 } from 'uuid';
import { checkReferrals, validate } from 'validation/Validate';
import WcpClassCodeRules from 'workcomp/policyInformation/WcpClassCodeRules';

export default class WcpClassCodeForm extends Component {
	static contextType = QuoteContext;

	visibility = {};
	dirty = false;
	formProps;
	state = { classCodeOptions: [], locationState: '' };
	rulesOnLoad = false;

	componentDidMount() {
		// If the form is not empty, trigger validation
		runRulesOnLoad(this.formProps, this.formProps.initialValues, ['id']);
	}

	getClassCodes(stateAbbr) {
		const classCodeList = toSortedPairList(wcpClassCodesJson.classCodes[stateAbbr], 'uDesc');
		const effDte = toDate(_.get(this.context, 'quote.effectiveDate'));

		let classCodeOptions = classCodeList.reduce((codeOptions, code) => {
			const codeOption = {
				value: `${code[0]}`,
				text: `${code[1].cn} -- ${code[1].uDesc}`,
			};
			const sd = code[1].sd;
			const ed = code[1].ed;
			if (((sd && toDate(sd) <= effDte) || !sd) && ((ed && toDate(ed) >= effDte) || !ed)) {
				codeOptions.push(codeOption);
			}
			return codeOptions;
		}, []);
		return classCodeOptions;
	}

	changeClassCodeList = (locationId, setFieldValue) => {
		const locationState = _.get(this.context, `quote.addresses[${locationId}].state`, '');
		const classCodeOptions = this.getClassCodes(locationState);
		if (locationState !== this.state.locationState) {
			setFieldValue('classCodeId', '');
		}
		this.setState({
			locationState: locationState,
			classCodeOptions: classCodeOptions,
		});
	};

	updateClassCode = (classId, setFieldValue) => {
		if (classId !== '') {
			setFieldValue('classCode', wcpClassCodesJson.classCodes[this.state.locationState][classId].cn);
			setFieldValue('classCodeDescription', wcpClassCodesJson.classCodes[this.state.locationState][classId].desc);
			setFieldValue('descriptionId', wcpClassCodesJson.classCodes[this.state.locationState][classId].dId);
		} else {
			setFieldValue('classCode', '');
			setFieldValue('classCodeDescription', '');
			setFieldValue('descriptionId', '');
		}
	};

	render() {
		const { quote } = this.context;
		let { id, location, history } = this.props;

		return (
			<Formik
				render={(formikProps) => {
					this.formProps = formikProps;
					this.dirty = formikProps.dirty;
					if (id === 'NEW') {
						id = formikProps.values.id;
					}
					checkReferrals(this.context, formikProps.values, WcpClassCodeRules);
					if (!this.rulesOnLoad) {
						formikProps.validateForm(formikProps.values);
						this.rulesOnLoad = true;
					}

					return (
						<Form id='screen'>
							<AddressPicker
								name='location'
								label='Which address applies to this class code?'
								location={location}
								history={history}
								additionalOnChange={this.changeClassCodeList}
								sfgOnly
							/>
							<PageSection title='Class Code Information'>
								<Field
									name='classCodeId'
									label='Class Code'
									component={Select}
									options={this.state.classCodeOptions}
									additionalOnChange={this.updateClassCode}
									width='large'
									ignoreTouched={_.get(quote, `wcp.classCodes.${id}.classCodeId`) ? true : false}
									search
								/>
							</PageSection>
							<PageSection title='Exposure'>
								<Field
									name='annualPayroll'
									label='Annual Payroll'
									component={InputNumber}
									type='currency'
									maxLength='10'
									width='small'
								/>
							</PageSection>
							<PageSection title='Number of Employees'>
								<OptionalSection
									name='group_numberOfEmployees'
									errors={formikProps.errors}
									text='Please enter at least one full time or part time employee'
									touched={
										_.get(formikProps.touched, 'fullTimeEmployees', false) ||
										_.get(formikProps.touched, 'partTimeEmployees', false)
									}
								>
									<Field
										name='fullTimeEmployees'
										label='Number of Full Time Employees'
										component={InputNumber}
										maxLength='6'
										width='small'
									/>
									<Field
										name='partTimeEmployees'
										label='Number of Part Time Employees'
										component={InputNumber}
										maxLength='6'
										width='small'
									/>
								</OptionalSection>
							</PageSection>
							<SimpleButton content='Cancel' onClick={() => this.props.handleClose()} />
							<SubmitButton content='Save' error={Object.keys(formikProps.errors).length > 0} />
						</Form>
					);
				}}
				initialValues={{
					id: id && id !== 'NEW' ? id : uuidv4(),
					classCodeId: _.get(quote, `wcp.classCodes.${id}.classCodeId`, ''),
					location: _.get(quote, `wcp.classCodes.${id}.location`, []),
					annualPayroll: _.get(quote, `wcp.classCodes.${id}.annualPayroll`, ''),
					fullTimeEmployees: _.get(quote, `wcp.classCodes.${id}.fullTimeEmployees`, ''),
					partTimeEmployees: _.get(quote, `wcp.classCodes.${id}.partTimeEmployees`, ''),
				}}
				onSubmit={(values, formikActions) => {
					let cleaned = cleanValues(values, this.visibility);
					cleaned = cleanOrphanAddresses(quote, values) || cleaned;
					this.context.onWcpClassCodeModalSubmit(values, this.dirty || cleaned, false, this.props, WcpClassCodeRules);
					this.props.handleClose();
					formikActions.setSubmitting(false);
				}}
				validate={(values) => {
					checkReferrals(this.context, values, WcpClassCodeRules);
					const validResults = validate(
						values,
						WcpClassCodeRules.rules(quote, values, this.visibility),
						duplicate(WcpClassCodeRules.requiredStructure),
					);
					logPageErrors(validResults, this.formProps.touched, 'wcp');
					return validResults;
				}}
			/>
		);
	}
}
