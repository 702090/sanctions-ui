import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { DisplayTable } from 'components/shared/displayTable';
import { DataDisplay } from 'components/shared/form/DataDisplay';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { MaskedInput } from 'components/shared/form/inputs/MaskedInput';
import { RadioButton } from 'components/shared/form/RadioButton';
import { Select } from 'components/shared/form/Select';
import { InformationMessage } from 'components/shared/messages/InformationMessage';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { toSortedPairList } from 'components/shared/navigation/NavigationFunctions';
import { OptionalSection } from 'components/shared/sections/OptionalSection';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import ncciMapJson from 'data/NCCIMap';
import selectOptionsJson from 'data/SelectOptions';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { Component } from 'react';
import { getNCCIData } from 'services/dataPrefillService';
import { prefillUsed } from 'utils/BusinessFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import { cleanValues, getVisibility, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank, stripMask } from 'utils/StringFunctions';
import { checkReferrals, validate } from 'validation/Validate';
import WcpClassCodeModal from 'workcomp/policyInformation/WcpClassCodeModal';
import WcpPolicyInformationRules from 'workcomp/policyInformation/WcpPolicyInformationRules';

const { wcp_employersLiability, wcp_timeLostClaims, wcp_smallDeductible1_TX, wcp_smallDeductible2_TX } =
	selectOptionsJson;
const { experienceMod, modEffectiveDate, orderKey, responseCode, responseMessage, riskId } = ncciMapJson;

export default class WcpPolicyInformationForm extends Component {
	static contextType = QuoteContext;

	visibility = {};
	dirty = false;
	initialFein = '';
	feinLock = false;
	state = {
		sorting: { column: null, direction: null },
		updated: false,
		activePage: 1,
	};
	countDisplay = [];
	initialValues = {};

	constructor() {
		super();
		this.wcpClassCode = React.createRef();
	}

	UNSAFE_componentWillMount() {
		const wcpClassCodes = _.get(this.context.quote, 'wcp.classCodes', {});

		this.setState({
			wcpClassCodes,
			wcpClassCodeList: _.toPairs(wcpClassCodes),
		});
		this.initialValues = this.getInitialValues(this.context.quote);
	}

	componentDidMount() {
		const veriskFein = this.feinPrefill();
		this.feinLock = !isBlank(veriskFein);
		this.initialFein = veriskFein || this.context.quote.fein || '';
		this.formProps.setFieldValue('fein', this.initialFein, false);
		// If the form is not empty, trigger validation
		runRulesOnLoad(this.formProps, this.formProps.initialValues, ['employersLiability']);
		this.buildEmployeeCountObj(this.formProps);
	}

	UNSAFE_componentWillUpdate() {
		this.buildEmployeeCountObj(this.formProps);
	}

	getInitialValues = (quote) => {
		let valuesObject = {};
		if (quote.wcp) {
			valuesObject = {
				fein: this.initialFein || '',
				wcp: {
					...quote.wcp,
					employersLiability: _.get(quote, 'wcp.employersLiability', '100000/500000/100000'),
					officersIncluded: _.get(quote, 'wcp.officersIncluded', ''),
					numberOfOfficersIncluded: _.get(quote, 'wcp.numberOfOfficersIncluded', ''),
					experienceMod: _.get(quote, experienceMod.target, _.get(quote, 'wcp.experienceMod', 1)),
					monthsInBusiness: _.get(quote, 'wcp.monthsInBusiness', ''),
					previousInsurance: _.get(quote, 'wcp.previousInsurance', ''),
					lostTimeClaims: _.get(quote, 'wcp.lostTimeClaims', ''),
					numberOfLostTimeClaims: _.get(quote, 'wcp.numberOfLostTimeClaims', ''),
					riskId: _.get(quote, 'wcp.riskId'),
					modifiers: {
						TX: {
							smallDeductible1: _.get(quote, 'wcp.modifiers.TX.smallDeductible1', ''),
							smallDeductible2: _.get(quote, 'wcp.modifiers.TX.smallDeductible2', ''),
						},
					},
					employeesByLocation: _.get(quote, 'wcp.employeesByLocation', {}),
					prefillData: {
						ncci: {
							..._.get(quote, 'wcp.prefillData.ncci', {}),
							responseCode: _.get(quote, 'wcp.prefillData.ncci.responseCode'),
						},
						valenId: _.get(quote, 'wcp.prefillData.valenId', ''),
					},
				},
			};
		} else {
			valuesObject = {
				wcp: {
					employersLiability: '100000/500000/100000',
				},
			};
		}
		_.forIn(_.get(quote, 'wcp.classCodes', {}), (classCode) => {
			valuesObject.wcp.employeesByLocation[classCode.location] = _.get(
				quote,
				`wcp.employeesByLocation.id${classCode.location}`,
				'',
			);
		});
		return valuesObject;
	};

	feinPrefill = () => {
		const locations = _.get(this.context.quote, 'sfg.locations', {});
		const firstLocation = _.find(locations, { order: 1 });
		const veriskFein = _.get(firstLocation, 'prefillData.verisk.fein', '');
		const ncciObject = _.get(this.context, 'quote.wcp.prefillData.ncci');
		if (!isBlank(veriskFein) && (veriskFein !== this.context.quote.fein || isBlank(ncciObject))) {
			this.callNcci(veriskFein, this.context.quote, this.formProps);
		}
		return veriskFein;
	};

	handleSort = (clickedColumn, defaultDirection) => () => {
		let { column, direction } = this.state.sorting;
		let { wcpClassCodeList } = this.state;
		const { quote } = this.context;
		const wcpClassCodes = _.get(quote, 'wcp.classCodes', {});
		if (defaultDirection || column !== clickedColumn) {
			direction = defaultDirection || 'ascending';
			switch (clickedColumn) {
				case 'classCode':
					wcpClassCodeList = toSortedPairList(wcpClassCodes, 'classCode');
					break;
				case 'classCodeDescription':
					wcpClassCodeList = toSortedPairList(wcpClassCodes, 'classCodeDescription');
					break;
				case 'annualPayroll':
					wcpClassCodeList = toSortedPairList(wcpClassCodes, 'annualPayroll');
					break;
				case 'fullTimeEmployees':
					wcpClassCodeList = toSortedPairList(wcpClassCodes, 'fullTimeEmployees');
					break;
				case 'partTimeEmployees':
					wcpClassCodeList = toSortedPairList(wcpClassCodes, 'partTimeEmployees');
					break;
				default:
					wcpClassCodeList = _.toPairs(_.get(this.context.quote, 'wcp.classCodes', {}));
			}
		} else {
			wcpClassCodeList = wcpClassCodeList.reverse();
			direction = direction === 'ascending' ? 'descending' : 'ascending';
		}
		this.setState({
			wcpClassCodeList,
			sorting: {
				direction,
				column: clickedColumn,
			},
		});
	};

	handleDelete = (id, formikProps) => {
		const updatedQuote = this.context.quote;
		const newWcpClassCodes = _.pickBy(this.state.wcpClassCodes, (wcpClassCode) => wcpClassCode.id !== id);

		_.set(updatedQuote, 'wcp.classCodes', newWcpClassCodes);
		_.set(formikProps.values, 'wcp.classCodes', newWcpClassCodes);
		_.unset(updatedQuote, `referrals.classCodeId.${id}`);

		runRulesOnLoad(formikProps, formikProps.values, ['']);
		this.handleSort(this.state.sorting.column, this.state.sorting.direction || true)();

		this.context.updateQuote(updatedQuote, this.props);
		this.setState({
			wcpClassCodes: newWcpClassCodes,
			wcpClassCodeList: _.toPairs(newWcpClassCodes),
		});
	};

	callback = () => {
		this.rulesOnLoad = false;
		runRulesOnLoad(this.formProps, this.formProps.values, ['']);
		this.handleSort(this.state.sorting.column, this.state.sorting.direction || true)();
	};

	// requires the FEIN without a dash
	callNcci = async (fein, quote, properties) => {
		this.context.updateServiceStatus('ncci', true);
		const ncciPrefillData = await getNCCIData(stripMask(fein), quote.effectiveDate);
		const ncciResponse = _.get(ncciPrefillData, `${responseMessage.source}['a:string']`, '');
		const ncciResponseCode = _.get(ncciPrefillData, responseCode.source, '');
		const ncciExpMod = _.get(ncciPrefillData, experienceMod.source, '');
		const ncciOrderKey = _.get(ncciPrefillData, orderKey.source, '');
		const ncciRiskId = _.get(ncciPrefillData, riskId.source, '');
		const ncciModEffectiveDate = _.get(ncciPrefillData, modEffectiveDate.source, '');

		//* for application of values requiring quote state only
		this.setNCCIValue(ncciOrderKey, orderKey, properties);
		this.setNCCIValue(ncciModEffectiveDate, modEffectiveDate, properties);
		this.setNCCIValue(ncciResponseCode, responseCode, properties);
		this.setNCCIValue(ncciResponse, responseMessage, properties);

		//* for application of values requiring quote state and field visibility
		if (
			_.get(quote, experienceMod.target) !== ncciExpMod ||
			(!isBlank(ncciExpMod) && _.get(this.formProps, `values.${experienceMod.target}`) !== ncciExpMod)
		) {
			this.setNCCIValue(ncciExpMod, experienceMod, properties, 'wcp.experienceMod');
		}

		if (
			_.get(quote, riskId.target) !== ncciRiskId ||
			(!isBlank(ncciRiskId) && _.get(this.formProps, `values.${riskId.target}`) !== ncciRiskId)
		) {
			this.setNCCIValue(ncciRiskId, riskId, properties, 'wcp.riskId');
		}

		this.formProps.setFieldValue('wcp.prefillData.ncci.noReturnData', _.get(ncciPrefillData, 'noReturnData', false));

		this.context.updateServiceStatus('ncci', false);
	};

	setNCCIValue = (value, mapObject, properties, fieldName) => {
		properties.setFieldValue(mapObject.target, value, false);

		if (fieldName) {
			properties.setFieldValue(fieldName, value, false);
		}
	};

	getPrefillToolTips = (quote, values) => {
		const noCallVeriskMessage = 'Verisk has never been called.';
		const noCallNCCIMessage = 'NCCI has never been called.';
		const noReturnVeriskMessage = 'The Verisk call returned no data.';
		const noReturnNCCIMessage = 'The NCCI call returned no data.';
		const locationsObject = _.get(quote, 'sfg.locations', {});
		const firstLocation = _.find(locationsObject, { order: 1 });

		let prefillObject = {
			fein: noCallVeriskMessage,
			experienceMod: noCallNCCIMessage,
			riskId: noCallNCCIMessage,
		};

		if (_.has(firstLocation, 'prefillData.verisk')) {
			prefillObject.fein = _.get(firstLocation, 'prefillData.verisk.fein', noReturnVeriskMessage);
			prefillObject.fein = isBlank(prefillObject.fein) ? noReturnVeriskMessage : prefillObject.fein;
		}

		if (_.has(values, 'wcp.prefillData.ncci')) {
			prefillObject.experienceMod = _.get(values, 'wcp.prefillData.ncci.experienceMod', noReturnNCCIMessage);
			prefillObject.experienceMod = isBlank(prefillObject.experienceMod)
				? noReturnNCCIMessage
				: prefillObject.experienceMod;

			prefillObject.riskId = _.get(values, 'wcp.prefillData.ncci.riskId', noReturnNCCIMessage);
			prefillObject.riskId = isBlank(prefillObject.riskId) ? noReturnNCCIMessage : prefillObject.riskId;
		}

		return prefillObject;
	};

	buildEmployeeCountObj = (formProps) => {
		const { quote } = this.context;
		const classCodes = _.get(quote, 'wcp.classCodes', {});
		const locationValues = _.get(formProps, 'values.wcp.employeesByLocation', {});
		let locationCounts = {};

		_.forIn(classCodes, (classCode) => {
			const formFieldId = `id${classCode.location}`;
			if (!locationValues[formFieldId]) {
				locationCounts[formFieldId] = '';
			} else {
				locationCounts[formFieldId] = locationValues[formFieldId];
			}
		});

		if (Object.keys(locationValues).length !== Object.keys(locationCounts).length) {
			formProps.setFieldValue('wcp.employeesByLocation', locationCounts);
		}

		const buildDisplay = [];
		_.forIn(locationCounts, (location, id) => {
			const locUuid = id.substring(2);
			buildDisplay.push({
				order: _.get(quote, `sfg.locations.${locUuid}.order`, ''),
				name: `wcp.employeesByLocation.${id}`,
				displayText: _.get(quote, `addresses.${locUuid}.fullAddress`, ''),
			});
		});
		this.countDisplay = _.sortBy(buildDisplay, (o) => o.order);
	};

	render() {
		const { quote } = this.context;
		const additionalData = [];
		this.state.wcpClassCodeList.forEach((classCode) => {
			additionalData.push(quote.addresses[classCode[1].location] && quote.addresses[classCode[1].location].fullAddress);
		});

		return (
			<QuoteContext.Provider
				value={{
					...this.context,
					updateWcpList: this.updateWcpList,
				}}
			>
				{
					//TODO:remove provider, it is no longer needed
				}
				<Formik
					render={(formikProps) => {
						this.dirty = formikProps.dirty;
						this.formProps = formikProps;

						this.visibility = getVisibility(getFieldDisplayArray('workcomp'), this.context.quote, formikProps.values);
						cleanValues(formikProps.values, this.visibility);
						checkReferrals(this.context, formikProps.values, WcpPolicyInformationRules, this.visibility);

						const prefillToolTips = this.getPrefillToolTips(this.context.quote, _.get(formikProps, 'values', {}));
						const prefillsPresent = {
							verisk: true,
							verisk360: false,
							datacubes: false,
							ncci: true,
						};

						return (
							<Form id='screen'>
								<InformationMessage
									message='Select information on this page has been pre-filled by a third-party service.'
									fieldDisplay={prefillUsed(quote, this.formProps.values, prefillsPresent)}
								/>
								<PageSection title='Federal Employee Identification Number'>
									<Field
										name='fein'
										mask='99-9999999'
										component={this.feinLock ? DataDisplay : MaskedInput}
										additionalOnBlur={(e) => {
											if (stripMask(e.target.value).length === 9) {
												this.callNcci(e.target.value, quote, formikProps);
												formikProps.dirty = true;
											}
										}}
										width='small'
										prefillHoverMessage={prefillToolTips.fein}
									/>
								</PageSection>
								<PageSection title='Limit'>
									<Field
										name='wcp.employersLiability'
										label='Liability (Accident/Policy/Employee)'
										component={RadioButton}
										options={wcp_employersLiability}
									/>
								</PageSection>
								<PageSection title='Officers'>
									<Field
										name='wcp.officersIncluded'
										label='Are Sole Proprietors, Partners or Executive Officers Included?'
										component={RadioButton}
									/>
									<Field
										name='wcp.numberOfOfficersIncluded'
										label='Number of Included Sole Proprietors, Partners or Officers'
										component={InputNumber}
										fieldDisplay={this.visibility['wcp.numberOfOfficersIncluded']}
										width='small'
										maxLength='2'
									/>
								</PageSection>
								<PageSection title='Modifiers'>
									<Field
										name='wcp.experienceMod'
										label='Experience Mod'
										component={
											!isBlank(_.get(formikProps, `values.${experienceMod.target}`)) ? DataDisplay : InputNumber
										}
										optional={!_.has(formikProps.values, experienceMod.target)}
										maxLength='4'
										decimalScale={2}
										width='small'
										ignoreTouched
										labelPrefillHoverMessage={prefillToolTips.experienceMod}
									/>
									<Field
										name='wcp.monthsInBusiness'
										label='How many months has the applicant been in business?'
										component={InputNumber}
										maxLength='4'
										width='tiny'
										fieldDisplay={this.visibility['wcp.monthsInBusiness']}
									/>
									<Field
										name='wcp.previousInsurance'
										label='Has the applicant carried WCP insurance for the past 12 months?'
										component={RadioButton}
										fieldDisplay={this.visibility['wcp.previousInsurance']}
									/>
									<Field
										name='wcp.lostTimeClaims'
										label='Has the applicant experienced any lost-time claims in the past two years?'
										component={RadioButton}
										fieldDisplay={this.visibility['wcp.lostTimeClaims']}
									/>
									<Field
										name='wcp.numberOfLostTimeClaims'
										label='How many lost-time claims has the applicant had in the past year?'
										component={RadioButton}
										options={wcp_timeLostClaims}
										fieldDisplay={this.visibility['wcp.numberOfLostTimeClaims']}
									/>
									<Field
										name='wcp.riskId'
										label='Risk Id'
										component={!isBlank(_.get(formikProps, `values.${riskId.target}`)) ? DataDisplay : InputNumber}
										fieldDisplay={this.visibility['wcp.riskId']}
										hoverMessage="If NCCI Experience Mod applies, enter factor. If it is an interstate mod, first 2 positions should be '91'"
										width='small'
										maxLength='9'
										ignoreCommas
										labelPrefillHoverMessage={prefillToolTips.riskId}
									/>
									{this.visibility['wcp.smallDeductible1'] && (
										<React.Fragment>
											{_.get(quote, 'rates.wcp', '') === 'quoting' && (
												<Field
													name='wcpSmallDeductible'
													label='Small Deductible'
													value='The Small Deductible is not available until you rate this quote as there is a minimum premium applicable.'
													component={DataDisplay}
												/>
											)}
											{_.get(quote, 'rates.wcp', '') !== 'quoting' && (
												<OptionalSection
													name='group_TX_smallDeductible'
													errors={formikProps.errors}
													text='Both deductibles required if one is entered.'
													touched={
														_.get(formikProps.touched, 'wcp.modifiers.TX.smallDeductible1', false) ||
														_.get(formikProps.touched, 'wcp.modifiers.TX.smallDeductible2', false)
													}
												>
													<Field
														name='wcp.modifiers.TX.smallDeductible1'
														label='Small Deductible 1'
														component={Select}
														options={wcp_smallDeductible1_TX}
														width='small'
														optionalSelect
														fieldDisplay={this.visibility['wcp.smallDeductible1']}
													/>
													<Field
														name='wcp.modifiers.TX.smallDeductible2'
														label='Small Deductible 2'
														component={Select}
														options={wcp_smallDeductible2_TX}
														width='small'
														optionalSelect
														fieldDisplay={this.visibility['wcp.smallDeductible2']}
													/>
												</OptionalSection>
											)}
										</React.Fragment>
									)}
								</PageSection>
								<PageSection title='Class Code' name='section_classCode' errors={formikProps.errors}>
									<SimpleButton
										content='Add Class Code'
										className='add'
										onClick={() =>
											this.wcpClassCode.current.handleOpen(
												'NEW',
												{},
												this.callback,
												this.props.location,
												this.props.history,
											)
										}
									/>
									<br />
									{!isBlank(this.state.wcpClassCodeList) && (
										<DisplayTable
											display={this.state.wcpClassCodeList}
											handleSort={this.handleSort}
											{...this.state.sorting}
											handleDelete={(classCodeId) => {
												this.handleDelete(classCodeId, formikProps);
												formikProps.validateForm(formikProps.values);
											}}
											errors={formikProps.errors}
											callBack={this.callback}
											reference={this.wcpClassCode}
											additionalData={additionalData}
											columns={[
												{
													name: 'classCode',
													display: 'Class Code',
													truncate: 48,
												},
												{
													name: 'classCodeDescription',
													display: 'Class Description',
												},
												{
													name: 'annualPayroll',
													display: 'Annual Payroll',
													type: 'currency',
												},
												{
													name: 'fullTimeEmployees',
													display: 'Full Time Employees',
												},
												{
													name: 'partTimeEmployees',
													display: 'Part Time Employees',
												},
												{
													name: '',
												},
											]}
											location={this.props.location}
											history={this.props.history}
										/>
									)}
								</PageSection>
								{!isBlank(this.countDisplay) && (
									<PageSection title='Employees By Location'>
										<InformationMessage
											message='Please enter the total number of Full and Part-time Employees at each Location'
											fieldDisplay
										/>
										{this.countDisplay.map((loc, id) => (
											<Field key={id} name={loc.name} label={loc.displayText} component={InputNumber} width='tiny' />
										))}
									</PageSection>
								)}
								<NavigationButtons
									formikProps={formikProps}
									back
									location={this.props.location}
									history={this.props.history}
									rulesObject={WcpPolicyInformationRules}
								/>
							</Form>
						);
					}}
					initialValues={this.initialValues}
					onSubmit={(values, formikActions) => {
						if (!this.context.serviceStatus.ncci) {
							cleanValues(values, this.visibility);
							this.context.onSubmit(values, this.dirty, false, false, this.props, WcpPolicyInformationRules);
						}
					}}
					validate={(values) => {
						checkReferrals(this.context, values, WcpPolicyInformationRules, this.visibility);
						const validResults = validate(
							values,
							WcpPolicyInformationRules.rules(quote, values, this.visibility),
							duplicate(WcpPolicyInformationRules.requiredStructure(quote, values)),
						);
						logPageErrors(validResults, this.formProps.touched, 'wcp');
						return validResults;
					}}
				/>
				<WcpClassCodeModal onSubmit={this.context.onWcpClassCodeModalSubmit} ref={this.wcpClassCode} />
			</QuoteContext.Provider>
		);
	}
}
