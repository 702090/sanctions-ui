import { getFieldDisplayArray } from 'data/FieldVisibility';
import _ from 'lodash';
import { getVisibility } from 'utils/ScreenFunctions';

export default class WcpLossesDashboardRules {
	static requiredStructure = {
		wcp: { noLosses: false },
		section_losses_wcp: '',
	};

	static rules(quote, values, visibility) {
		if (!visibility) {
			visibility = getVisibility(getFieldDisplayArray('wcpLosses'), quote, values);
		}

		return {
			wcp: {
				noLosses: [
					[
						(value) => value || !visibility.noLosses,
						'Please verify there have been no losses in the past three years. If no losses, please check the box stating this to continue with this quote.',
					],
				],
			},
		};
	}

	static referrals(context, values) {
		return {
			section_losses_wcp: [
				[(value) => _.size(_.get(context, 'quote.wcp.losses', {})) < 3, 'WLH01'],
				[(value) => getTotalPaidAmount(context.quote) < 10000, 'WLH02'],
			],
		};
	}

	static name() {
		return 'wcpLossesDashboard';
	}
}

function getTotalPaidAmount(quote) {
	const losses = _.get(quote, 'wcp.losses', {});
	let totalAmountPaid = 0;

	Object.keys(losses).forEach((key) => {
		totalAmountPaid += losses[key].totalAmountPaid;
	});

	return totalAmountPaid;
}
