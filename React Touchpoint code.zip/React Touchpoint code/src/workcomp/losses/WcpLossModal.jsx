import { ModalStepper } from 'components/shared/navigation/ModalStepper';
import QuoteContext from 'context/quoteContext';
import React, { Component } from 'react';
import { Modal } from 'semantic-ui-react';
import WcpLossForm from 'workcomp/losses/WcpLossForm';
import { replaceReferrals } from 'validation/RunReferrals';
import { pageAnalytics } from 'utils/ScreenFunctions';

export class WcpLossModal extends Component {
	static contextType = QuoteContext;

	constructor() {
		super();
		this.state = {
			isOpen: false,
		}; // state to control the state of popup
	}

	handleOpen = (lossId, lossHistory, callBack, location, history) => {
		this.setState({
			isOpen: true,
			lossId,
			lossHistory,
			callBack,
			location,
			history,
		});
		pageAnalytics(location.pathname + '/WcpLossModal', true);
	};

	handleClose = () => {
		this.state.callBack();
		replaceReferrals(this.context);
		pageAnalytics(this.state.location.pathname);
		this.setState({ isOpen: false });
	};

	render() {
		const { lossId, lossHistory, location, history } = this.state;
		return (
			<Modal closeIcon open={this.state.isOpen} closeOnDimmerClick={false} onClose={this.handleClose}>
				<ModalStepper currentModal='wcpLosses' handleClose={this.handleClose} />
				<Modal.Content>
					<WcpLossForm
						id={lossId}
						lossHistory={lossHistory}
						handleClose={this.handleClose}
						location={location}
						history={history}
					/>
				</Modal.Content>
			</Modal>
		);
	}
}
