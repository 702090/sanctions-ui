import { DatePicker } from 'components/shared/form/DatePicker';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputText } from 'components/shared/form/inputs/InputText';
import { RadioButton } from 'components/shared/form/RadioButton';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { useContext, useEffect } from 'react';
import { toast } from 'react-toastify';
import http from 'services/httpService';
import { cleanValues, getVisibility, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { checkReferrals, validateNew } from 'validation/Validate';
import WcpPriorCarrierRules from 'workcomp/priorCarrier/WcpPriorCarrierRules';

const WcpPriorCarrierForm = (props) => {
	const context = useContext(QuoteContext);

	let visibility = {};
	let dirty = false;
	let formProps;

	let rulesOnLoad = false;

	useEffect(() => {
		// If the form is not empty, trigger validation

		runRulesOnLoad(
			formProps,
			formProps.initialValues,
			['priorCarrier'],
			isBlank(_.get(context, 'quote.wcp.priorCarrier', '')),
		);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	const verifyCigPolicy = (e, formikProps) => {
		const requestBody = {
			policyNumber: _.get(formikProps, 'values.wcp.priorPolicyNumber', ''),
			effectiveDate: _.get(context, 'quote.effectiveDate', ''),
		};

		http
			.post(`${process.env.REACT_APP_POLICY_VERIFICATION}?auth=${sessionStorage.getItem('cigToken')}`, requestBody)
			.then((response) => {
				const priorPolicyEffectiveDate = _.get(response, 'data.originalPolicyEffdte', '');
				const priorPolicyProduct = _.get(response, 'data.originalPolicyProduct', '');
				const cancelReason = _.get(response, 'data.cancelReason', '');
				if (!isBlank(priorPolicyEffectiveDate)) {
					_.set(formikProps, 'values.wcp.priorPolicyEffectiveDate', priorPolicyEffectiveDate);
					_.set(formikProps, 'values.wcp.priorPolicyProduct', priorPolicyProduct);
					_.set(formikProps, 'values.wcp.cancelReason', cancelReason);
					_.set(formikProps, 'values.wcp.priorPolicyCigVerified', true);
				} else {
					_.unset(formikProps, 'values.wcp.priorPolicyEffectiveDate');
					_.unset(formikProps, 'values.wcp.priorPolicyProduct');
					_.unset(formikProps, 'values.wcp.cancelReason');
					_.set(formikProps, 'values.wcp.priorPolicyCigVerified', false);
				}
				formikProps.validateForm(formikProps.values);
			})
			.catch(() => {
				toast.error('Error verifying policy.');
			});
	};

	const { quote } = context;
	return (
		<Formik
			render={(formikProps) => {
				formProps = formikProps;
				dirty = formikProps.dirty;

				visibility = getVisibility(getFieldDisplayArray('wcpPriorCarrier'), quote, formikProps.values);
				cleanValues(formikProps.values, visibility);
				checkReferrals(context, formikProps.values, WcpPriorCarrierRules, visibility);
				if (!rulesOnLoad) {
					formikProps.validateForm(formikProps.values);
					rulesOnLoad = true;
				}
				return (
					<Form id='screen'>
						<PageSection>
							<Field
								name='wcp.priorCarrier'
								label='Do you have a prior carrier?'
								component={RadioButton}
								ignoreTouched
							/>
							<Field
								name='wcp.cigPriorCarrier'
								label='Is the prior carrier with Columbia Insurance Group?'
								component={RadioButton}
								fieldDisplay={visibility['wcp.cigPriorCarrier']}
							/>
							<Field
								name='wcp.priorPolicyNumber'
								label='Prior policy number'
								component={InputText}
								fieldDisplay={visibility['wcp.priorPolicyNumber']}
								maxLength='15'
								additionalOnBlur={(e) => verifyCigPolicy(e, formikProps)}
							/>
							<Field
								name='wcp.carrierName'
								label='What is the prior carrier name?'
								component={InputText}
								fieldDisplay={visibility['wcp.carrierName']}
								maxLength='35'
							/>
							<Field
								name='wcp.expirationDate'
								label='Expiration Date'
								component={DatePicker}
								fieldDisplay={visibility['wcp.expirationDate']}
								optional
							/>
							<Field
								name='wcp.annualPremium'
								label='Annual Premium'
								component={InputNumber}
								type='currency'
								fieldDisplay={visibility['wcp.annualPremium']}
								maxLength='10'
								optional
							/>
						</PageSection>
						<NavigationButtons
							formikProps={formikProps}
							back
							location={props.location}
							history={props.history}
							rulesObject={WcpPriorCarrierRules}
						/>
					</Form>
				);
			}}
			initialValues={{
				wcp: {
					priorCarrier: _.get(quote, 'wcp.priorCarrier') || '',
					cigPriorCarrier: _.get(quote, 'wcp.cigPriorCarrier') || '',
					priorPolicyNumber: _.get(quote, 'wcp.priorPolicyNumber') || '',
					carrierName: _.get(quote, 'wcp.carrierName') || '',
					expirationDate: _.get(quote, 'wcp.expirationDate') || _.get(quote, 'effectiveDate'),
					annualPremium: _.get(quote, 'wcp.annualPremium') || '',
					cancelReason: _.get(quote, 'wcp.cancelReason') || '',
				},
			}}
			onSubmit={(values, formikActions) => {
				cleanValues(values, visibility);

				if (dirty && _.get(values, 'wcp.cigPriorCarrier') !== _.get(quote, 'wcp.cigPriorCarrier')) {
					const priorPolicyProduct = _.get(values, 'wcp.priorPolicyProduct');
					if (_.get(values, 'wcp.cigPriorCarrier') === 'Y' && priorPolicyProduct === 'WCP') {
						_.set(quote, 'wcp.san', '');
					}
				}

				return context.onSubmit(values, dirty, false, false, props, WcpPriorCarrierRules);
			}}
			validate={(values) => {
				checkReferrals(context, values, WcpPriorCarrierRules, visibility);
				const validResults = validateNew(quote, values, WcpPriorCarrierRules, visibility);
				logPageErrors(validResults, formProps.touched, 'wcp');
				return validResults;
			}}
		/>
	);
};

export default WcpPriorCarrierForm;
