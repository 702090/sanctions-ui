import { getFieldDisplayArray } from 'data/FieldVisibility';
import _ from 'lodash';
import { isValidDate } from 'utils/DateFunctions';
import { getVisibility } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';

class WcpPriorCarrierRules {
	static requiredStructure = {
		wcp: {
			priorCarrier: '',
			cigPriorCarrier: '',
			priorPolicyNumber: '',
			carrierName: '',
		},
	};

	static optionalStructure = {
		wcp: {
			expirationDate: '',
			annualPremium: '',
		},
	};

	static rules(quote, values, visibility) {
		if (values && !visibility) {
			visibility = getVisibility(getFieldDisplayArray('wcpPriorCarrier'), quote, values);
		}

		// Rules won't apply if this is a new venture
		if (_.get(quote, 'newVenture') === 'Y') {
			return {};
		}

		return {
			wcp: {
				priorCarrier: [[(value) => !isBlank(value), 'Prior Carrier is required.']],
				cigPriorCarrier: [
					[(value) => !isBlank(value) || !visibility['wcp.cigPriorCarrier'], 'CIG Prior Carrier is required.'],
				],
				priorPolicyNumber: [
					[(value) => !isBlank(value) || !visibility['wcp.priorPolicyNumber'], 'Prior Policy Number is required.'],
					[
						(value) => _.get(values, 'wcp.priorPolicyCigVerified', true) || !visibility['wcp.priorPolicyNumber'],
						'The prior policy number you entered is not a valid Columbia policy number.  Please provide a valid number or remove Prior Insurance Coverage.',
					],
				],
				carrierName: [[(value) => !isBlank(value) || !visibility['wcp.carrierName'], 'Carrier Name is required.']],
				expirationDate: [[(value) => isBlank(value) || isValidDate(value), 'You must enter a valid date.']],
			},
		};
	}

	static referrals(context, values, visibility) {
		return {
			wcp: {
				priorCarrier: [[(value) => value !== 'N', 'WPI01']],
				priorPolicyNumber: [
					[
						(value) => !_.includes(['N1', 'N2', 'N3', 'N4', '02', '05', '06'], _.get(values, 'wcp.cancelReason', '')),
						'WPI02',
					],
				],
			},
		};
	}

	static name() {
		return 'wcpPriorCarrier';
	}
}

export default WcpPriorCarrierRules;
