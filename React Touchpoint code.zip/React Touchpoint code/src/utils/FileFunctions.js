import fileDownload from 'js-file-download';
import _ from 'lodash';
import { toast } from 'react-toastify';
import { deleteAttachment, getAttachment, saveAttachment } from 'services/attachmentService';
import { duplicate } from 'utils/ObjectFunctions';
import { isBlank } from 'utils/StringFunctions';
import { v4 as uuidv4 } from 'uuid';

function fileToBase64(file) {
	return new Promise((resolve) => {
		const reader = new FileReader();
		// Read file content on file loaded event
		reader.onload = function (event) {
			resolve(event.target.result);
		};

		// Convert data to base64
		reader.readAsDataURL(file);
	});
}

export async function uploadFile(event, currentContext, storePath, additionalInfo = {}) {
	const file = event.target.files[0];
	const quoteCopy = duplicate(currentContext.quote);

	const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));
	const attachments = _.get(quoteCopy, !storePath ? 'attachments' : `${storePath}.attachments`, {});
	const id = uuidv4();
	const fileName = file.name;

	// Only allow files that are < 2MB to be uploaded
	if (file.size > 2097152) {
		toast.error('The File you are trying to upload is too large. There is a 2MB limit.');
		return false;
	} else {
		try {
			const base64EncodedData = await fileToBase64(file);
			const attachmentData = {
				s3Bucket: process.env.REACT_APP_DOCUMENT_BUCKET,
				fileName: `${agent.agentSubpro}_${quoteCopy.quoteNumber}_${id}_${fileName}`,
				fileData: base64EncodedData,
				mimeType: file.type,
			};
			const response = await saveAttachment(attachmentData);
			if (!isBlank(response)) {
				attachments[id] = {
					name: fileName,
					mimeType: file.type,
				};

				storePath
					? _.set(quoteCopy, storePath, { attachments, ...additionalInfo })
					: (quoteCopy.attachments = attachments);
				await currentContext.updateQuote(quoteCopy);
				return true;
			}
		} catch (error) {
			toast.error('Your attachment could not be uploaded.');
			console.error('Error uploading attachment', error);
			return false;
		}
	}
}

export async function deleteFile(id, currentContext, storePath = 'attachments') {
	const quoteCopy = duplicate(currentContext.quote);
	const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));

	const fileName = _.get(quoteCopy, `${storePath}.${id}.name`, '');

	const attachmentData = {
		s3Bucket: process.env.REACT_APP_DOCUMENT_BUCKET,
		fileName: `${agent.agentSubpro}_${quoteCopy.quoteNumber}_${id}_${fileName}`,
	};

	const newAttachments = _.pickBy(_.get(quoteCopy, storePath, {}), (attachment, attachmentId) => attachmentId !== id);

	try {
		await deleteAttachment(attachmentData);
		_.set(quoteCopy, storePath, newAttachments);
		await currentContext.updateQuote(quoteCopy);
	} catch (error) {
		toast.error('Your attachment could not deleted.');
		console.error('Error deleting attachment', error);
	}
}

export async function downloadFile(id, currentContext, storePath) {
	if (!storePath) {
		storePath = 'attachments';
	}

	const quote = currentContext.quote;

	const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));
	const fileName = _.get(quote, `${storePath}.${id}.name`, '');

	const attachmentData = {
		s3Bucket: process.env.REACT_APP_DOCUMENT_BUCKET,
		fileName: `${agent.agentSubpro}_${quote.quoteNumber}_${id}_${fileName}`,
	};

	try {
		const response = await getAttachment(attachmentData);
		const file = new Blob([new Uint8Array(response.Body.data)], { type: response.ContentType });
		await fileDownload(file, fileName);
	} catch (error) {
		toast.error('Unable to open file');
		console.error('Error downloading attachment', error);
	}
}
