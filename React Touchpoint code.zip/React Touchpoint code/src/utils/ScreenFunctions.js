/* eslint-disable import/no-named-as-default-member */
import buildingQuestionsJson from 'data/BuildingQuestions';
import d3QuestionMapJson from 'data/DatacubesQuestionMapping';
import _ from 'lodash';
import ReactGA from 'react-ga';
import { duplicate } from 'utils/ObjectFunctions';
import { isBlank } from 'utils/StringFunctions';

const { questions } = buildingQuestionsJson;
const { d3questions } = d3QuestionMapJson;

/**
 * Takes all of the dynamically visible fields for a form and decides to show or hide them.
 * @param {Object} fields The dynamically visible fields and the function that determines their visibility
 * in the format: {fieldName:functionToRun,}.
 * @param {Object} quote The entire current quote from the state.
 * @param {Objects} values The Formik values of the current form.
 * @return {Object} The object containing the results of each field's functionToRun in the format: {fieldName:boolean}
 */
export function getVisibility(fields, quote, values) {
	const visibility = {};
	const cache = {};

	fields.forEach((field) => {
		const cachedValue = cache[field.cacheName];
		if (cachedValue === undefined) {
			const result = field.method(quote, values);
			cache[field.cacheName] = result;
			visibility[field.name] = result;
		} else {
			visibility[field.name] = cachedValue;
		}
	});
	return visibility;
}
/**
 * Takes the dynamically visible fields for a form and clears the 'hidden' fields' values
 * @param {Object} values The Formik values of the current form.
 * @param {Object } visibility The object containing the results of each field's functionToRun in the
 * format: {fieldName:boolean}
 */
export function cleanValues(values, visibility) {
	let cleaned = false;
	Object.keys(visibility).forEach((name) => {
		if (!visibility[name]) {
			_.set(values, name, '');
			cleaned = true;
		}
	});

	return cleaned;
}

export function cleanModifiers(values) {
	let cleaned = false;
	_.forIn(_.get(values, 'sfg.modifiers', {}), (stateList, st) => {
		if (_.get(values, `sfg.modifiers.${st}.scheduleModifier`, '') === 1) {
			_.unset(values, `sfg.modifiers.${st}.scheduleModifier`);
			cleaned = true;
		}
	});
	_.forIn(_.get(values, 'wcp.modifiers', {}), (stateList, st) => {
		if (_.get(values, `wcp.modifiers.${st}.scheduleModifier`, '') === 1) {
			_.unset(values, `wcp.modifiers.${st}.scheduleModifier`);
			cleaned = true;
		}
	});
	_.forIn(_.get(values, 'cap.modifiers', {}), (stateList, st) => {
		if (_.get(values, `cap.modifiers.${st}.scheduleModifier`, '') === 1) {
			_.unset(values, `cap.modifiers.${st}.scheduleModifier`);
			cleaned = true;
		}
	});

	return cleaned;
}

/**
 * Takes a Google Places object and breaks out the individual address components
 * @param {Object} places The address object returned from Google Places
 * @return {Object} The formatted address object
 */
export function parseAddress(places, name, setFieldValue) {
	const address = {};
	const addressComponents = _.get(places, 'gmaps.address_components');

	if (addressComponents) {
		addressComponents.forEach((component) => {
			address.streetNumber = _.includes(component.types, 'street_number') ? component.short_name : address.streetNumber;
			address.streetName = _.includes(component.types, 'route') ? component.short_name : address.streetName;
			address.unit = _.includes(component.types, 'subpremise') ? component.short_name : address.unit;
			address.city = _.includes(component.types, 'locality') ? component.short_name : address.city;
			address.county = _.includes(component.types, 'administrative_area_level_2')
				? component.short_name
				: address.county;
			address.state = _.includes(component.types, 'administrative_area_level_1') ? component.short_name : address.state;
			address.zip = _.includes(component.types, 'postal_code') ? component.short_name : address.zip;

			address.validationFailedMessage = '';
			address.latitude = '';
			address.longitude = '';
			address.validated = true;
		});
		address.fullAddress = places.gmaps.formatted_address;
	} else {
		address.fullAddress = places;
		address.streetNumber = '';
		address.streetName = '';
		address.unit = '';
		address.city = '';
		address.county = '';
		address.state = '';
		address.zip = '';
		address.validationFailedMessage = '';
		address.latitude = '';
		address.longitude = '';
		address.kentuckyTax = '';
		address.validated = false;
	}

	setFieldValue(name, address, false);
	return address;
}

export function cleanReferrals(referrals, id) {
	_.forIn(referrals, (referral, fieldName) => {
		if (_.isObject(referral)) {
			if (fieldName === id) {
				_.unset(referrals, id);
			}
			cleanReferrals(referral, id);
		} else if (fieldName === id) {
			_.unset(referrals, id);
		}
	});
}
export function buildReferralMessage(referral) {
	let target = '';
	if (referral.length > 9) {
		// referral on a building question
		target = `Location ${referral.slice(5, 7)}, Building ${referral.slice(7, 9)}: `;
	} else if (referral.length > 7) {
		target = `Location ${referral.slice(5, 7)}, Building ${referral.slice(7, 9)}: `;
	} else if (referral.length > 5) {
		target = `Location ${referral.slice(5, 7)}: `;
	}
	return target;
}

export function base64toBlob(base64) {
	const binary_string = atob(base64);
	const len = binary_string.length;
	const bytes = new Uint8Array(len);
	for (let i = 0; i < len; i++) {
		bytes[i] = binary_string.charCodeAt(i);
	}

	const blob = new Blob([bytes.buffer], {
		type: 'application/pdf',
	});
	return blob;
}

export function saveOrOpen(blob, fileName) {
	if (navigator && navigator.msSaveOrOpenBlob) {
		navigator.msSaveOrOpenBlob(blob, fileName);
	} else {
		window.open(URL.createObjectURL(blob), fileName);
	}
}

export function runRulesOnLoad(formProps, initialValues, fieldsToSkip, firstTime, referrals) {
	const iv = duplicate(initialValues);
	let needValidation = false;

	if (!firstTime) {
		fieldsToSkip.forEach((field) => {
			_.unset(iv, field);
		});
		_.values(iv).some((x) => {
			if (_.isObject(x)) {
				needValidation = runRulesOnLoad(formProps, x, fieldsToSkip, firstTime, referrals);
			} else if (_.isArray(x)) {
				// If field is an array ---- convert to object then call runRulesOnLoad
			} else {
				needValidation = !isBlank(x);
			}
			return needValidation;
		});

		referrals && formProps.setTouched(referrals);
	}

	if (needValidation) {
		formProps.validateForm().then((validation) => formProps.setTouched(validation));
	}
}

export function buildReferral(question, qid, referralCode) {
	return [
		[
			(value) => {
				let thisOption;
				if (question.qy === 'D') {
					question.o.forEach((option) => {
						// loop over possible options for this question and get the selected option
						if (option.value === value || (option.value === -1 && option.r === 'F')) {
							thisOption = option;
						}
					});
				}
				const number = value;
				let ok = true;
				if (thisOption && thisOption.r === 'F') {
					switch (question.qy) {
						case 'D':
							ok = false;
							break;
						case 'P':
							if (number > 100) {
								ok = false;
							}
						// Fall through
						case 'I':
							if (number < 0) {
								ok = false;
							} else if (!(thisOption.mn === 0 && thisOption.mx === 0)) {
								if (thisOption.mx < thisOption.mn && thisOption.mx === 0) {
									// and up condition
									if (thisOption.mn > number) {
										ok = false;
									}
								} else if (thisOption.mn < thisOption.mx) {
									if (thisOption.mn > number || thisOption.mx < number) {
										ok = false;
									}
								} else {
									// ranges are not set up correctly, so reject
									ok = false;
								}
							}
							break;
						default: // T and S do not need testing
					}
				}
				return ok;
			},
			referralCode,
		],
	];
}

export function mergeFieldStructure(rulesObject, values) {
	let requiredStructure = {};
	let optionalStructure = {};

	if (rulesObject) {
		if (typeof rulesObject.requiredStructure === 'function') {
			requiredStructure = rulesObject.requiredStructure(values, values) || {};
		} else {
			requiredStructure = rulesObject.requiredStructure || {};
		}

		optionalStructure = rulesObject.optionalStructure || {};

		const fields = _.merge(requiredStructure, optionalStructure);

		return fields;
	}
}

export function googleAnalyticsInitialize(agent) {
	// ReactGA.initialize(process.env.REACT_APP_GOOGLE_ANALYTICS, {
	// 	gaOptions: {
	// 		userId: agent && agent.userId,
	// 		siteSpeedSampleRate: 100,
	// 	},
	// });
}

export function pageAnalytics(page, modal) {
	// ReactGA.set({ page });
	// ReactGA.pageview(page);
}

export function pageEvent(category, action, label) {
	// ReactGA.event({
	// 	category: category,
	// 	action: action,
	// 	label: label.toString(),
	// });
}

export function logPageErrors(validResults, touched, product) {
	_.forIn(validResults, (error, fieldName) => {
		let foundError = logPageErrorsR(error, touched, fieldName, product);
		if (foundError && _.get(touched, foundError, false)) {
			pageEvent('ValidationError', error, foundError);
		}
	});
}

function logPageErrorsR(errorObject, touched, fieldHistory, product) {
	if (_.isString(errorObject)) {
		return fieldHistory;
	}

	_.forIn(errorObject, (error, fieldName) => {
		let foundError = logPageErrorsR(error, touched, fieldHistory + '.' + fieldName, product);
		if (foundError && _.get(touched, foundError, false)) {
			pageEvent('ValidationError', error, foundError);
		}
	});
}

export function getDatacubesQuestionValue(qId, location) {
	let questionValue;
	if (d3questions[qId]) {
		const d3Answers = _.get(location, 'prefillData.datacubes.questions', {});
		const d3Keys = _.get(d3questions, `${qId}`, []);

		for (let i = 0; i < d3Keys.length; i++) {
			let d3Response = _.get(d3Answers, `${d3Keys[i]}`);
			if (d3Response === true) {
				questionValue = 'Yes';
				break;
			} else if (d3Response === false) {
				questionValue = 'No';
			}
		}

		if (typeof questionValue !== 'undefined') {
			const answerArray = _.get(questions[qId], 'o', [{}]);
			questionValue = _.find(answerArray, { text: questionValue }).value;
		}
	}
	return questionValue;
}
