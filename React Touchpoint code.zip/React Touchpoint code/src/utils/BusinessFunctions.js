import { toSortedPairList } from 'components/shared/navigation/NavigationFunctions';
import bopClassCodesJson from 'data/BOPClassCodes';
import classCodeListsJson from 'data/ClassCodeLists';
import coveragesListJson from 'data/CoveragesList';
import productNamesJson from 'data/ProductNames';
import selectOptionsJson from 'data/SelectOptions';
import veriskPrefillMappingJson from 'data/VeriskPrefillMapping';
import { isAfter, isBefore, parseISO } from 'date-fns';
import _ from 'lodash';
import { toast } from 'react-toastify';
import { getCompanyId, getPropertyData, getVerisk360Valuation, getVeriskRoofReport } from 'services/dataPrefillService';
import { toDate } from 'utils/DateFunctions';
import {
	hasFormBP0412,
	hasFormBP0416,
	hasFormBP0447,
	hasFormBP0450,
	hasFormBP0497,
	hasFormBP1417,
	hasFormBP1418,
	hasFormBP1420,
	hasFormBP1479,
	hasFormIL375,
	needsCupTerrorismExclusion,
	needsILMineSubsidenceRejection,
	needsMOEPLIAcknowledgement,
	needsSfgTerrorismExclusion,
} from 'utils/FieldDisplay';
import { duplicate, getSet, removeEmpty } from 'utils/ObjectFunctions';
import { isBlank } from 'utils/StringFunctions';

const {
	animalClasses,
	attorneyClasses,
	condoClasses,
	contractorsErrorsAndOmissionsClasses,
	convenienceStoreClasses,
	fineDiningClasses,
	limitedCookingClasses,
	motelClasses,
	opticalHearingClasses,
	pharmacistClasses,
	residentialCleaningAllowed,
	restaurantClasses,
	vetClasses,
} = classCodeListsJson;
const { sfg_policy_autoservice, sfg_policy_churches, sfg_policy_contractors, sfg_policy_IL } = coveragesListJson;
const {
	sfg_additionalInsuredType,
	sfg_additionalInsuredType_Contractors,
	sfg_buildingCoverages,
	sfg_LocationCoverages,
	sfg_policyCoverages,
	sfg_policyCoverages_original,
} = selectOptionsJson;
const { classCodes } = bopClassCodesJson;
const { productNames } = productNamesJson;
const { roofCovering } = veriskPrefillMappingJson;

export const getFirstLocation = (quote) => {
	const locations = _.get(quote, 'sfg.locations', {});
	return _.findKey(locations, (location) => location.order === 1);
};

export const getPredState = (quote) => {
	const firstLocation = getFirstLocation(quote);
	const predState = _.get(quote, `addresses.${firstLocation}.state`);

	return predState;
};
/**
 *
 * @param {*} quote
 * @param {*} values
 */
export const getMinimumDownPayment = (quote, billingType, prod) => {
	let downPaymentMin = _.get(quote, `rates.${prod}`, 0);

	const firstLocation = getFirstLocation(quote);
	const predState = _.get(quote, `addresses.${firstLocation}.state`);

	if (_.startsWith(billingType, 'DQ4')) {
		if (predState === 'NE' || predState === 'GA') {
			downPaymentMin /= 4;
		} else {
			downPaymentMin = downPaymentMin / 4 + 5;
		}
	} else if (_.startsWith(billingType, 'E01')) {
		downPaymentMin /= 12;
	} else if (_.startsWith(billingType, 'A01') || _.startsWith(billingType, 'AAQ')) {
		downPaymentMin = 0;
	}

	return _.round(downPaymentMin, 2);
};

/**
 * Given the entire quote from the current state and any changes made by the current form,
 * determine if insured is an Individual or Corp.
 * @param {Object} quote The entire current quote from the state.
 * @param {Objects} values The Formik values of the current form.
 * @return {boolean} True if the insured is an individual, false if not.
 */
export const isIndividual = (quote, values) => {
	const businessType = (values && values.businessType) || (quote && quote.businessType) || '';
	return _.includes(['01', '02', '05'], businessType);
};

/**
 * Get the insured name from the current quote ("lastName, firstName" or "companyName")
 * @param {Object} quote The entire current quote from the state.
 * @return {string} The composite insured name for this quote
 */
export const getFullInsuredName = (quote) => {
	if (!quote.insuredName) {
		return '';
	}

	return isIndividual(quote) ? `${quote.insuredName.last}, ${quote.insuredName.first}` : quote.insuredName.company;
};

export const getFirstBuilding = (location) => _.findKey(location.buildings, (building) => building.order === 1);

export const isEmployee = () => {
	const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));
	return agent && !_.startsWith(agent.userId, 'agt');
};

export const getPremium = (quote) => {
	if (quote.rates) {
		let total = 0;
		let incomplete = false;
		_.forIn(quote.rates, (rate) => {
			if (_.isNumber(rate)) {
				total += _.toNumber(rate);
			} else {
				incomplete = true;
			}
		});
		return incomplete ? 0 : total;
	}
};

export const defaultVis = {
	'sfg.coverages.CDCR': false,
	'sfg.coverages.CDCP': false,
	'sfg.coverages.CDBG': false,
	'sfg.coverages.BICO': false,
	'sfg.coverages.CFFT': false,
	'sfg.coverages.CODO': false,
	'sfg.coverages.CDCO': false,
	'sfg.coverages.CITE': false,
	'sfg.coverages.LLCG': false,
	'sfg.coverages.CDDP': false,
	'sfg.coverages.CDEC': false,
	'sfg.coverages.CDED': false,
	'sfg.coverages.CDEB': false,
	'sfg.coverages.EMDI': false,
	'sfg.coverages.CDEP': false,
	'sfg.coverages.IDFR': false,
	'sfg.coverages.CDHR': false,
	'sfg.coverages.CDAF': false,
	'sfg.coverages.ICPO': false,
	'sfg.coverages.CDLQ': false,
	'sfg.coverages.MOTL': false,
	'sfg.coverages.PLPM': false,
	'sfg.coverages.PHOT': false,
	'sfg.coverages.CDPR': false,
	'sfg.coverages.CDSM': false,
	'sfg.coverages.TCLP': false,
	'sfg.coverages.CDVL': false,
	'sfg.coverages.VETL': false,
	'sfg.coverages.CDWS': false,
	'sfg.coverages.FDCO': false,
	'sfg.coverages.c7941': false,
	'sfg.coverages.c9000': false,
};
export const getPolicyCoverageList = (
	predState,
	currentCoverages,
	occupancyCodes,
	cCodes,
	effectiveDate,
	totalBppLimits,
) => {
	// CDEP = AL
	// AR
	// GA
	// IL
	// IA
	// KS
	// KY
	// MS
	// MO
	// NE
	// NM
	// NC
	// OK
	// SC
	// TN
	// TX
	const vis = { ...defaultVis };
	const newCoverageOptions = getNewCoverageOptions(
		currentCoverages,
		predState,
		occupancyCodes,
		cCodes,
		effectiveDate,
		totalBppLimits,
	);
	currentCoverages.forEach((covgCode) => {
		vis[`sfg.coverages.${covgCode}`] = true;
	});
	return { vis, newCoverageOptions };
};

/**
 * This builds the list of coverages to show in the dropdown.
 * @param {*} currentCoverages  The set of current selected coverage codes
 * @param {*} predState The predominant state of the policy (first location state)
 */
function getNewCoverageOptions(currentCoverages, predState, occupancyCodes, cCodes, effectiveDate, totalBppLimits) {
	const quoteCurrentCoverages = [...currentCoverages];
	const availablePolicyCoverages = isAfter(parseISO(effectiveDate), parseISO('2020-05-01'))
		? sfg_policyCoverages
		: sfg_policyCoverages_original;
	return availablePolicyCoverages.filter(
		(coverage) =>
			!currentCoverages.has(coverage.value) &&
			checkCoverages(
				coverage,
				cCodes,
				occupancyCodes,
				predState,
				quoteCurrentCoverages,
				totalBppLimits,
				[],
				effectiveDate,
			),
	);
}

export const distillBuildings = (locations, locationId) => {
	const occupancyCodes = new Set();
	const cCodes = new Set();
	let buildingCoverages = new Set();
	let additionalInsuredTypes = new Set();
	let totalBppLimits = 0;
	if (!isBlank(locations)) {
		_.forIn(locations, (location, id) => {
			if ((locationId && locationId === id) || !locationId) {
				const { buildings } = location;
				if (!isBlank(buildings)) {
					_.forIn(buildings, (building) => {
						occupancyCodes.add(building.occupancyType);
						cCodes.add(building.classCode);
						if (!isBlank(_.get(building, 'coverages.currentCoverages', []))) {
							buildingCoverages = getSet([...buildingCoverages, ..._.get(building, 'coverages.currentCoverages', [])]);
						}
						if (!isBlank(building.additionalInsuredType)) {
							additionalInsuredTypes = getSet([...additionalInsuredTypes, ...building.additionalInsuredType]);
						}
						totalBppLimits += _.toNumber(_.get(building, 'bppLimit', 0));
					});
				}
			}
		});
	}
	return {
		occupancyCodes,
		classCodes: cCodes,
		buildingCoverages,
		additionalInsuredTypes,
		totalBppLimits,
	};
};

export const distillLocations = (quote) => {
	const locations = _.get(quote, 'sfg.locations');
	const addresses = _.get(quote, 'addresses');
	let totalSales = 0;
	const states = new Set();
	const wcpLocations = new Set();
	const wcpStates = new Set();
	const capStates = new Set();
	if (!isBlank(locations)) {
		_.forIn(locations, (location, id) => {
			totalSales += location.grossSales;
			states.add(addresses[id].state);
		});
	}
	if (_.includes(quote.products, 'wcp')) {
		const classes = _.get(quote, 'wcp.classCodes', {});
		_.forIn(classes, (classCode) => {
			wcpLocations.add(classCode.location);
			if (!isBlank(classCode) && classCode.location && addresses[classCode.location]) {
				wcpStates.add(addresses[classCode.location].state);
			}
		});
	}

	if (_.includes(quote.products, 'cap')) {
		const coverageStates = _.get(quote, 'cap.coverages', {});
		_.forIn(coverageStates, (st) => {
			if (!isBlank(st.address) && st.address && addresses[st.address]) {
				capStates.add(addresses[st.address].state);
			}
		});
	}

	return {
		totalSales,
		states: [...states],
		wcpLocations: [...wcpLocations],
		wcpStates: [...wcpStates],
		capStates: [...capStates],
	};
};

export const addressExists = (addresses, fullAddress) => {
	let addressId = false;
	_.forIn(addresses, (address, id) => {
		if (address.fullAddress === fullAddress) {
			addressId = id;
		}
	});

	return addressId;
};

export const cleanOrphanAddresses = (q, values) => {
	const quote = _.merge(duplicate(q), values);
	const addresses = _.get(quote, 'addresses', {});
	const sfgLocations = _.get(quote, 'sfg.locations', {});
	let capCoverageLocations = [];
	let wcpClassCodeLocations = new Set([]);

	_.forIn(_.get(quote, 'cap.coverages', {}), (state) => {
		if (state.address) {
			capCoverageLocations.push(state.address);
		}
	});

	if (values.garagingLocation) {
		capCoverageLocations.push(values.garagingLocation);
	}
	_.forIn(_.get(quote, 'cap.vehicles', {}), (vehicle) => {
		if (vehicle.garagingLocation) {
			capCoverageLocations.push(vehicle.garagingLocation);
		}
	});

	_.forIn(_.get(quote, 'wcp.classCodes', {}), (classCode) => {
		wcpClassCodeLocations.add(_.get(classCode, 'location', ''));
	});

	let cleaned = false;
	_.forIn(addresses, (address, id) => {
		if (id !== '1') {
			const sfgMatch = _.pickBy(sfgLocations, (a, aId) => {
				return id === aId;
			});

			if (
				isBlank(sfgMatch) &&
				!_.includes(capCoverageLocations, id) &&
				!_.includes([...wcpClassCodeLocations], id) &&
				id !== _.get(quote, 'cap.registrationAddress', '')
			) {
				_.unset(q, `addresses.${id}`);
				cleaned = true;
			}
		}
	});
	return cleaned;
};

export const getLocationAddresses = (addresses, addNewOption, sfgLocations, sfgOnly) => {
	let addressList = [];
	const distinctAddresses = new Set();

	_.forIn(addresses, (address, id) => {
		if (id != 1) {
			if (sfgLocations) {
				_.forIn(sfgLocations, (location, locId) => {
					if (id === locId) {
						distinctAddresses.add(address.fullAddress);
						addressList.push({ value: id, text: address.fullAddress });
					}
				});
			} else {
				/* eslint eqeqeq: [0] */
				distinctAddresses.add(address.fullAddress);
				addressList.push({ value: id, text: address.fullAddress });
			}
		}
	});

	if (addresses && !distinctAddresses.has(addresses[1].fullAddress) && !sfgOnly) {
		addressList.unshift({ value: 1, text: addresses[1].fullAddress });
	}

	if (addNewOption) {
		addressList.push({ value: 'New', text: 'I need to add a new address' });
	}

	return addressList;
};

export const getAllAddresses = (addresses, state) => {
	let addressList = [];
	const distinctAddresses = new Set();

	_.forIn(addresses, (address, id) => {
		if (id != 1) {
			/* eslint eqeqeq: [0] */
			if (!state || state === address.state) {
				distinctAddresses.add(address.fullAddress);
				addressList.push({ value: id, text: address.fullAddress });
			}
		}
	});

	if (addresses && !distinctAddresses.has(addresses[1].fullAddress) && (!state || state === addresses[1].state)) {
		addressList.unshift({ value: 1, text: addresses[1].fullAddress });
	}

	return addressList;
};

export const getBuildingList = (quote, filter) => {
	const buildingList = [];
	const locations = toSortedPairList(_.get(quote, 'sfg.locations', {}));
	let addBuilding = true;
	locations.forEach((locationPair) => {
		const location = locationPair[1];
		const locId = locationPair[0];
		const buildings = toSortedPairList(location.buildings);
		buildings.forEach((buildingPair) => {
			const building = buildingPair[1];
			const bldgId = buildingPair[0];
			switch (filter) {
				case 'AI':
					addBuilding = building.additionalInsureds === 'Y';
					break;
				default:
					addBuilding = true;
			}
			if (addBuilding) {
				buildingList.push({
					text: `${_.get(quote, `addresses.${locId}.fullAddress`)}, Building ${building.order}`,
					value: `${locId}_${bldgId}`,
				});
			}
		});
	});
	return buildingList;
};

export const checkCoverages = (
	coverage,
	cCodes,
	occupancyCodes,
	predState,
	currentCoverages,
	totalBppLimits,
	buildingCoverages,
	effectiveDate,
) => {
	let cvgCode = coverage;
	if (coverage.value) {
		cvgCode = coverage.value;
	}
	const classCodeArray = [...cCodes];
	return (
		// if the coverage is an IL specific coverage w/ IL as predState, or if the coverage is not an IL specific coverage
		((_.includes(sfg_policy_IL, cvgCode) && predState === 'IL') || !_.includes(sfg_policy_IL, cvgCode)) &&
		// If the coverage is Employee Related Practices Liability do not display if predState is SD
		((cvgCode === 'CDEP' &&
			!(predState === 'SD' && isBefore(parseISO(effectiveDate), parseISO('2022-03-01'))) &&
			_.intersection(classCodeArray, attorneyClasses).length === 0) ||
			cvgCode !== 'CDEP') &&
		// if the coverage is an IL specific coverage w/ IL as predState, or if the coverage is not an IL specific coverage
		((_.includes(sfg_policy_churches, cvgCode) && cCodes.has('41650')) || !_.includes(sfg_policy_churches, cvgCode)) &&
		// if the coverage is UM/UIM, and this policy has at least one auto Service building, and be in IL or AR,  or not UM/UIM coverage
		((cvgCode === 'CDUM' &&
			_.includes(['IL', 'AR'], predState) &&
			(occupancyCodes.has('A') || _.intersection(['HIRE', 'NOWN'], currentCoverages).length > 0)) ||
			cvgCode !== 'CDUM') &&
		// if the coverage is Mini-Warehouse coverage, and this policy has at least one Mini-Warehouse building, or not Mini-Warehouse coverage
		((cvgCode === 'LLCG' && cCodes.has('09411')) || cvgCode !== 'LLCG') &&
		// if the coverage is a Funeral Directors coverage, and this policy has at least one Funeral Directors building, or not Funeral Directors coverage
		((cvgCode === 'CDFD' && cCodes.has('71865')) || cvgCode !== 'CDFD') &&
		// if the coverage is Photography coverage, and this policy has at least one photographer building, or not Photography coverage
		((cvgCode === 'PHOT' && cCodes.has('71899')) || cvgCode !== 'PHOT') &&
		// if the coverage is Printers E&O coverage, and this policy has at least one printer building, or not Printers E&O coverage
		((cvgCode === 'CDPN' && cCodes.has('71912')) || cvgCode !== 'CDPN') &&
		// if the coverage is Barbershop coverage, and this policy has at least one Barbershop building, or not Barbershop coverage
		((cvgCode === 'CDBB' && cCodes.has('71332')) || cvgCode !== 'CDBB') &&
		// if the coverage is Beauticians coverage, and this policy has at least one Beauticians building, or not Beauticians coverage
		((cvgCode === 'CDBS' && cCodes.has('71952')) || cvgCode !== 'CDBS') &&
		// if the coverage is Condo coverage, and this policy has at least one Condo building, or not Condo coverage,  and CAN'T be an Arkansas policy
		((cvgCode === 'CODO' && _.intersection(classCodeArray, condoClasses).length > 0 && predState !== 'AR') ||
			cvgCode !== 'CODO') &&
		((cvgCode === 'CDCO' && _.intersection(classCodeArray, contractorsErrorsAndOmissionsClasses).length > 0) ||
			cvgCode !== 'CDCO') &&
		// if the coverage is attorney coverage, and this policy has at least one attorney building, or not attorney coverage
		((cvgCode === 'CDPA' && _.intersection(classCodeArray, attorneyClasses).length > 0) || cvgCode !== 'CDPA') &&
		// if the coverage is Inland Marine Animal Floater coverage, and this policy has at least one animal related building, or not Inland Marine Animal Floater coverage
		((cvgCode === 'CDAF' && _.intersection(classCodeArray, animalClasses).length > 0) || cvgCode !== 'CDAF') &&
		// if the coverage is Motel coverage, and this policy has at least one motel building, or not motel coverage
		((cvgCode === 'MOTL' && _.intersection(classCodeArray, motelClasses).length > 0) || cvgCode !== 'MOTL') &&
		// if the coverage is Optical & Hearing Aid coverage, and this policy has at least one building dealing with hearing optical, or not a Optical & Hearing Aid coverage
		((cvgCode === 'CDOH' && _.intersection(classCodeArray, opticalHearingClasses).length > 0) || cvgCode !== 'CDOH') &&
		// if the coverage is Pharmacists coverage, and this policy has at least one building dealing with Pharmacists, or not Pharmacists coverage
		((cvgCode === 'PLPM' && _.intersection(classCodeArray, pharmacistClasses).length > 0) || cvgCode !== 'PLPM') &&
		// if the coverage is Vet coverage, and this policy has at least one building dealing with Vets, or not Vet coverage
		((cvgCode === 'VETL' && _.intersection(classCodeArray, vetClasses).length > 0) || cvgCode !== 'VETL') &&
		// // if the coverage is Liquor Liability coverage, and this policy has no buildings dealing with casual or fine dining, or not Liquor Liability coverage
		// ((cvgCode === 'CDLQ' &&
		// 	!_.intersection(classCodeArray, casualDiningClasses).length > 0) ||
		// 	cvgCode !== 'CDLQ') &&
		// if the coverage is a contractor's coverage, and this policy has at least one contractor building, or not a contractor coverage
		((_.includes(sfg_policy_contractors, cvgCode) && occupancyCodes.has('10')) ||
			!_.includes(sfg_policy_contractors, cvgCode)) &&
		// if the coverage is a Auto Service coverage, and this policy has at least one Auto Service building, or not a Auto Service coverage
		((_.includes(sfg_policy_autoservice, cvgCode) && occupancyCodes.has('A')) ||
			!_.includes(sfg_policy_autoservice, cvgCode)) &&
		// if the coverage is a Senior Citizens Condo D&O coverage, and this policy has at least one apartment building, or not a Senior Citizens Condo D&O coverage
		((cvgCode === 'CDSC' && occupancyCodes.has('1')) || cvgCode !== 'CDSC') &&
		// if the coverage is Interruption of Computer Operations Coverage, and this policy has at least one building with a bppLimit, or not Interruption of Computer Operations Coverage
		((cvgCode === 'ICPO' && totalBppLimits > 0) || cvgCode !== 'ICPO') &&
		// if the coverage is Electronic Data Coverage, and this policy has at least one building with a bppLimit, or not Electronic Data Coverage
		((cvgCode === 'ELDT' && totalBppLimits > 0) || cvgCode !== 'ELDT') &&
		// This coverage was completely removed
		cvgCode !== 'AGGL'
	);
};

export const defaultVisBuilding = {
	'coverages.AR': false,
	'coverages.AI': false,
	'coverages.APEN': false,
	'coverages.BXXP': false,
	'coverages.CL': false,
	'coverages.FD': false,
	'coverages.MS': false,
	'coverages.OLAW': false,
	'coverages.SN': false,
	'coverages.FL': false,
	'coverages.US': false,
	'coverages.VCNT': false,
	'coverages.RSEN': false,
	'coverages.OPRP': false,
	'coverages.RCLN': false,
	'coverages.DEBR': false,
	'coverages.VP': false,
	'coverages.GRNU': false,
	'coverages.HLMT': false,
	'coverages.SPAP': false,
	'coverages.CDLR': false,
	'coverages.CDDL': false,
	'coverages.CDNO': false,
	'coverages.CDGC': false,
	'coverages.CDGK': false,
	'coverages.MN': false,
};
export const getBuildingCoverageList = (currentCoverages, building, addressState) => {
	const vis = { ...defaultVisBuilding };
	const newCoverageOptions = getNewBuildingCoverageOptions(currentCoverages, building, addressState);
	currentCoverages.forEach((covgCode) => {
		vis[`coverages.${covgCode}`] = true;
	});
	return { vis, newCoverageOptions };
};

function getNewBuildingCoverageOptions(currentCoverages, building, addressState) {
	return sfg_buildingCoverages.filter(
		(coverage) =>
			!currentCoverages.has(coverage.value) &&
			coverage.value !== 'VCNT' &&
			checkBuildingCoverages(coverage, building, addressState),
	);
}

export const checkBuildingCoverages = (coverage, building, addressState) => {
	let cvgCode = coverage;
	if (coverage.value) {
		cvgCode = coverage.value;
	}

	return (
		// must have a building limit to add Debris Removal Coverage
		((cvgCode === 'DEBR' && building.buildingLimit > 0) || cvgCode !== 'DEBR') &&
		// must have a building limit to add OLAW
		((cvgCode === 'OLAW' && building.buildingLimit > 0) || cvgCode !== 'OLAW') &&
		// must have a building limit and be an IL policy to add MN
		((cvgCode === 'MN' && building.buildingLimit > 0 && addressState === 'IL') || cvgCode !== 'MN') &&
		//
		((cvgCode === 'RCLN' && _.includes(residentialCleaningAllowed, building.classCode)) || cvgCode !== 'RCLN') &&
		//
		((cvgCode === 'RSEN' && _.includes(restaurantClasses, building.classCode)) || cvgCode !== 'RSEN') &&
		//
		((cvgCode === 'APEN' && building.occupancyType === '1') || cvgCode !== 'APEN') &&
		//
		((cvgCode === 'HLMT' && building.bppLimit > 0) || cvgCode !== 'HLMT') &&
		((cvgCode === 'CDGC' && building.classCode === '44071') || cvgCode !== 'CDGC') &&
		((cvgCode === 'SPAP' && building.bppLimit > 0) || cvgCode !== 'SPAP')
	);
};

export const defaultLocVis = {};
export const getLocCovgList = (currentCoverages, classCodeArray, occupancyCodes, buildingCoverages) => {
	const vis = { ...defaultLocVis };
	const newCoverageOptions = getNewLocCovgOptions(currentCoverages, classCodeArray, occupancyCodes, buildingCoverages);

	currentCoverages.forEach((covgCode) => {
		vis[`coverages.${covgCode}`] = true;
	});
	return { vis, newCoverageOptions };
};

/**
 * This builds the list of coverages to show in the dropdown.
 * @param {*} currentCoverages  The set of current selected coverage codes
 * @param {*} predState The predominant state of the policy (first location state)
 */
function getNewLocCovgOptions(currentCoverages, classCodeArray, occupancyCodes, buildingCoverages) {
	return sfg_LocationCoverages.filter(
		(coverage) =>
			!currentCoverages.has(coverage.value) &&
			checkLocCovgs(coverage, classCodeArray, occupancyCodes, buildingCoverages),
	);
}

export const checkLocCovgs = (coverage, classCodeArray, occupancyCodes, buildingCoverages) => {
	let cvgCode = coverage;
	if (coverage.value) {
		cvgCode = coverage.value;
	}
	return (
		// if the coverage is a Auto Service Premier, and this policy has at least one Auto Service building, or not a Auto Service Premier
		((cvgCode === 'CDAS' && occupancyCodes.has('A')) || cvgCode !== 'CDAS') &&
		// if the coverage is a contractor's coverage, and this policy has at least one contractor building, or not a contractor coverage
		((cvgCode === 'CDCT' && occupancyCodes.has('10')) || cvgCode !== 'CDCT') &&
		// if the coverage is a Restaurant premier, and this policy has at least one Restaurant building, or not a Restaurant Premier
		((cvgCode === 'CDPX' &&
			(((occupancyCodes.has('8') || occupancyCodes.has('9')) &&
				_.intersection(classCodeArray, fineDiningClasses).length === 0) ||
				_.intersection(classCodeArray, convenienceStoreClasses).length > 0)) ||
			cvgCode !== 'CDPX') &&
		// if the coverage is Fine Arts - Restaurant, and this policy has at least one Restaurant building, or not Fine Arts - Restaurant
		((cvgCode === 'RSFA' && (occupancyCodes.has('8') || occupancyCodes.has('9')) && buildingCoverages.has('RSEN')) ||
			cvgCode !== 'RSFA') &&
		// if the coverage is a RSLL, and this policy has at least one Restaurant building, or not RSLL
		((cvgCode === 'RSLL' && (occupancyCodes.has('8') || occupancyCodes.has('9')) && buildingCoverages.has('RSEN')) ||
			cvgCode !== 'RSLL') &&
		// if the coverage is a APLL, and this policy has at least one Apartment building, or not APLL
		((cvgCode === 'APLL' && (occupancyCodes.has('1') || occupancyCodes.has('7')) && buildingCoverages.has('APEN')) ||
			cvgCode !== 'APLL') &&
		// if the coverage is Fine Arts, and this policy has at least one Apartment/Apartment-Condo building, or not Fine Arts
		((cvgCode === 'APFA' && (occupancyCodes.has('1') || occupancyCodes.has('7')) && buildingCoverages.has('APEN')) ||
			cvgCode !== 'APFA') &&
		// if the coverage is not a restaurant, contractor or auto
		((cvgCode === 'CDPE' &&
			_.intersection([...occupancyCodes], ['1', '2', '4', '5', '6', '7']).length > 0 &&
			_.intersection(classCodeArray, convenienceStoreClasses).length === 0) ||
			cvgCode !== 'CDPE') &&
		// if the coverage is a Fine Dining premier, and this policy has at least one fine dining building, or not a Fine Dining premier
		((cvgCode === 'CDPF' && _.intersection(classCodeArray, fineDiningClasses).length > 0) || cvgCode !== 'CDPF')
	);
};

export const buildingHasQuestions = (locationId, building, quote, state) => {
	let questionsRequired = false;
	if (locationId && building) {
		if (!state) {
			state = _.get(quote, `addresses.${locationId}.state`);
		}

		const classId = building.classId ? building.classId.replace('\\', '\\\\') : '';

		// Need to replace the single slash with a doubel slash because of how browsers work
		const classQuestions = _.get(classCodes, `${state}['${classId}'].questions`, []);

		questionsRequired = classQuestions.length > 0;
	}

	return questionsRequired;
};

export const cleanBuildingInterests = ({ currentContext, props }) => {
	const { quote, updateQuote } = currentContext;
	let quoteUpdateNeeded = false;
	const locations = _.get(quote, 'sfg.locations', {});
	_.forIn(locations, (loc, locId) => {
		const buildings = _.get(loc, 'buildings', {});
		_.forIn(buildings, (building, bldgId) => {
			const currentAi = _.get(building, 'additionalInsuredType');

			if (currentAi) {
				const allowedAi = _.map(
					building.occupancyType === '10' ? sfg_additionalInsuredType_Contractors : sfg_additionalInsuredType,
					'value',
				);
				const aiCodesToRemove = _.difference(currentAi, allowedAi);
				if (!isBlank(aiCodesToRemove)) {
					quoteUpdateNeeded = true;
					_.set(
						quote,
						`sfg.locations.${locId}.buildings.${bldgId}.additionalInsuredType`,
						_.pull(currentAi, ...aiCodesToRemove),
					);
					cleanAdditionalInterests({ quote, propertyId: locId, bldgId });
				}
			}
		});
	});
	if (quoteUpdateNeeded) {
		updateQuote(quote, props);
	}
};

export const cleanAdditionalInterests = ({ quote, propertyId, bldgId, deleteBuilding }) => {
	const additionalInterests = _.get(quote, 'additionalInterests', {});
	const validBuildings = getAdditionalInterestTypes(quote);
	const validForms = [];
	_.forIn(validBuildings, (option) => {
		validForms.push(option.text);
	});

	_.forIn(additionalInterests, (additionalInterest, id) => {
		//safeguard cleaning
		if (bldgId && additionalInterest.sfgInterestType) {
			const { interestBuilding } = additionalInterest;
			const aiTypeKey = _.find(
				sfg_additionalInsuredType_Contractors,
				(ai) => additionalInterest.sfgInterestDescription === ai.text,
			).value;

			//Skip if Ai was originally entered as blank
			if (!isBlank(interestBuilding)) {
				//removing the building association if its being deleted or if the form is no longer on the building
				if (
					interestBuilding &&
					interestBuilding.indexOf(`${propertyId}_${bldgId}`) >= 0 &&
					(deleteBuilding ||
						!_.includes(
							_.get(quote, `sfg.locations.${propertyId}.buildings.${bldgId}.additionalInsuredType`, []),
							aiTypeKey,
						))
				) {
					interestBuilding.splice(interestBuilding.indexOf(`${propertyId}_${bldgId}`), 1);
					//clear the AI form if this building was the only attached building
					if (isBlank(interestBuilding)) {
						//_.unset(additionalInterests, id);
						_.set(additionalInterests, `${id}.sfgInterestDescription`, '');
						_.set(additionalInterests, `${id}.sfgInterestType`, '');
					}
				}
			}
			//clear the AI sfgDescription if the form has been removed from all buildings
			if (!_.includes(validForms, additionalInterest.sfgInterestDescription)) {
				//_.unset(additionalInterests, id);
				_.set(additionalInterests, `${id}.sfgInterestDescription`, '');
				_.set(additionalInterests, `${id}.sfgInterestType`, '');
			}
		}

		//CAP AI cleaning
		if (!bldgId && additionalInterest.capInterestType) {
			const { interestVehicle } = additionalInterest;

			if (interestVehicle && interestVehicle.indexOf(`${propertyId}`) >= 0) {
				//unassociate the vehicle
				interestVehicle.splice(interestVehicle.indexOf(`${propertyId}`), 1);
				//clear the AI cap interest type if this vehicle was the only attached vehicle
				if (isBlank(interestVehicle)) {
					//_.unset(additionalInterests, id);
					_.set(additionalInterests, `${id}.capInterestType`, '');
				}
			}
		}

		//Delete an AI if it is not associated to a CAP vehicle or SFG form
		if (isBlank(additionalInterest.sfgInterestType) && isBlank(additionalInterest.capInterestType)) {
			_.unset(additionalInterests, id);
		}
	});
	//}
};

export const displayQuoteNumber = (quote, prefix) => {
	const quoteNumber = _.get(quote, 'quoteNumber');
	return quoteNumber ? `${prefix}QT${_.padStart(quoteNumber, 10, '0')}` : '';
};

export const displayPolicyNumber = (quote, prefix) => {
	const firstLocation = getFirstLocation(quote);
	const predState = _.get(quote, `addresses.${firstLocation}.state`);

	const policyNumber = _.get(quote, 'policyNumber');
	return policyNumber ? `${prefix}${predState}${_.padStart(policyNumber, 10, '0')}` : '';
};

export const getAdditionalInterestTypes = (quote) => {
	let additionalInterestTypeList = [];
	const uniqueAdditionalInterestTypeList = [];
	const locations = _.get(quote, 'sfg.locations', {});

	if (!isBlank(locations)) {
		_.forIn(locations, (location) => {
			const { buildings } = location;
			if (!isBlank(buildings)) {
				_.forIn(buildings, (building) => {
					const aiList =
						building.occupancyType === '10' ? sfg_additionalInsuredType_Contractors : sfg_additionalInsuredType;
					if (!isBlank(building.additionalInsuredType)) {
						_.forEach(building.additionalInsuredType, (value, key) => {
							if (!_.includes(uniqueAdditionalInterestTypeList, building.additionalInsuredType[key])) {
								uniqueAdditionalInterestTypeList.push(building.additionalInsuredType[key]);
								const aiFound = _.find(aiList, (a) => building.additionalInsuredType[key] === a.value);

								if (aiFound) {
									const mapValue = aiFound.text;
									additionalInterestTypeList.push({
										value: mapValue,
										text: mapValue,
										key: building.additionalInsuredType[key],
									});
								}
							}
						});
					}
				});
			}
		});
	}
	additionalInterestTypeList = _.sortBy(additionalInterestTypeList);
	return additionalInterestTypeList;
};

export const getFullName = (name) => {
	return `${name.lastName ? name.lastName : ''}${name.firstName ? ', ' + name.firstName : ''}${
		name.middleInitial ? ' ' + name.middleInitial : ''
	}`;
};

export const formatNumberWithCommas = (x) => {
	return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
};

export const getQuoteAddress = (addresses, id) => {
	if (addresses) {
		return _.get(addresses[id], 'fullAddress', '');
	} else {
		return '';
	}
};

export const licenseExists = (quote, licenseNo, thisId) => {
	let match = false;
	let drivers = _.get(quote, 'cap.drivers', {});
	_.forIn(drivers, (driver, id) => {
		if (id !== thisId) {
			match = match || driver.licenseNumber.toUpperCase() === licenseNo.toUpperCase();
		}
	});
	return match;
};

export const setRetrievedUnderlyingPolicyData = (returnData, quote, updateQuote, props) => {
	_.set(quote, 'cup.retrievedUnderlyingPolicies', returnData.underlyingPolicies);

	// merge the data by product
	if (!_.includes(quote.products, 'cap')) {
		_.unset(quote, 'cup.underlyingPolicies.cap');

		returnData.underlyingPolicies.cap && _.set(quote, 'cup.underlyingPolicies.cap', returnData.underlyingPolicies.cap);
	}
	if (!_.includes(quote.products, 'wcp')) {
		returnData.underlyingPolicies.wcp && _.set(quote, 'cup.underlyingPolicies.wcp', returnData.underlyingPolicies.wcp);
	}

	updateQuote(quote, props);
};

export const addEpliForm = (quote) => {
	return getPredState(quote) === 'MO' && _.get(quote, 'sfg.coverages.CDEP', '') !== '';
};

export const calculateCDLQ = (values) => {
	let output = {};
	if (_.get(values, 'sfg.locations')) {
		_.forIn(values.sfg.locations, (location, locationId) => {
			let has50 = false;
			let has35 = false;
			let has30 = false;
			const cdlqExposure = _.get(values, 'sfg.coverages.CDLQ.exposure');

			if (location.buildings) {
				_.forIn(location.buildings, (building, buildingId) => {
					if (building.occupancyType === '9' || _.includes(limitedCookingClasses, building.classCode)) {
						// fast food, caps at .35
						if (0.35 * location.grossSales < cdlqExposure) {
							has35 = true;
						}
					} else if (building.occupancyType === '8' && building.classCode !== '09431') {
						// fine dining, caps at .5
						if (0.5 * location.grossSales < cdlqExposure) {
							has50 = true;
						}
					} else if (building.occupancyType === '8' && building.classCode === '09431') {
						if (0.3 * location.grossSales < cdlqExposure) {
							has30 = true;
						}
					}
				});

				if (has30) {
					// fine dining (w/ 30% booze sales), caps at .3
					output[locationId] = 'SPC07';
				} else if (has35) {
					output[locationId] = 'SPC05';
				} else if (has50) {
					output[locationId] = 'SPC06';
				}
			}
		});
	}
	return output;
};

export const checkAddressUsed = (quote, deletingLocId) => {
	let addressUsed = false;

	if (_.has(quote, 'cap') && !addressUsed) {
		if (_.get(quote, 'cap.registrationAddress') === deletingLocId) {
			addressUsed = true;
		}
		if (_.has(quote, 'cap.coverages') && !addressUsed) {
			_.forIn(_.get(quote, 'cap.coverages'), (state) => {
				if (state.address === deletingLocId) {
					addressUsed = true;
				}
			});
		}
		if (_.has(quote, 'cap.vehicles') && !addressUsed) {
			_.forIn(_.get(quote, 'cap.vehicles'), (vehicle) => {
				if (vehicle.garagingAddress === deletingLocId) {
					addressUsed = true;
				}
			});
		}
	}
	return addressUsed;
};

export const cleanWorkCompClassCodes = (quote, deletingLocId) => {
	_.forIn(_.get(quote, 'wcp.classCodes'), (classCode) => {
		if (classCode.location === deletingLocId) {
			_.unset(quote, `wcp.classCodes.${classCode.id}`);
		}
	});
};

const getVeriskData = async (mailingAddress, insuredName) => {
	const veriskObject = {};
	const companyObject = await getCompanyId('verisk', mailingAddress, insuredName);
	const { companyId: uniqueId, buildingPrefillOnly } = companyObject;
	if (!isBlank(uniqueId)) {
		veriskObject.uniqueId = uniqueId;
		veriskObject.buildingPrefillOnly = buildingPrefillOnly;
		const veriskPropertyData = await getPropertyData('verisk', uniqueId);
		const ms1 = _.get(veriskPropertyData, 'Ms1', {});
		const ms2 = _.get(veriskPropertyData, 'Ms2', {});
		const ms3 = _.get(veriskPropertyData, 'Ms3', {});
		const ms4 = _.get(veriskPropertyData, 'Ms4', {});

		const { Code: naicCode, Description: naic } = _.get(ms1, 'BusinessNaicsCodes[0]', '');
		const { Code: sicCode, Description: sic } = _.get(ms1, 'BusinessSicCodes[0]', '');
		const fein = _.get(ms4, 'FeinNumber', '');

		// veriskObject.naicCode = naicCode;
		// veriskObject.naic = naic;
		// veriskObject.sicCode = sicCode;
		// veriskObject.sic = sic;
		veriskObject.fein = !isBlank(fein) ? fein.slice(0, 2) + '-' + fein.slice(2) : '';

		if (!buildingPrefillOnly) {
			veriskObject.accountingContact = ms2.ContactName;
			veriskObject.grossSales = !isBlank(ms1.SalesVolume) ? _.toNumber(_.replace(ms1.SalesVolume, /\D/g, '')) : '';
			veriskObject.businessDescription = ms2.BusinessDescription;
		}

		let sprinklerValue;
		if (!_.isBoolean(ms3.Sprinklered)) {
			sprinklerValue = '';
		} else if (ms3.Sprinklered) {
			sprinklerValue = 'Y';
		} else {
			sprinklerValue = 'N';
		}
		let protectionClassValue = _.toString(_.get(ms4, 'Ppc.Ppc', ''));
		const premiseRange = _.split(ms4.PremiseFloorArea, '-');

		// Building Attributes
		veriskObject.roofType = roofCovering[ms4.RoofCovering];
		veriskObject.constructionYear = ms1.YearBuilt;
		veriskObject.effectiveYearBuilt = ms4.EffectiveYearBuilt;
		veriskObject.constructionType = !isBlank(_.get(ms1, 'BuildingFireConstructionCode.Code', ''))
			? _.padStart(ms1.BuildingFireConstructionCode.Code, 2, '0')
			: '';
		veriskObject.squareFootage = !isBlank(ms1.SquareFootage) ? _.toNumber(_.replace(ms1.SquareFootage, /\D/g, '')) : '';
		veriskObject.premiseFloorAreaText = ms4.PremiseFloorArea;
		veriskObject.premiseMin = _.replace(premiseRange[0], /\D/g, '');
		veriskObject.premiseMax = _.replace(premiseRange[1], /\D/g, '');
		veriskObject.numberOfStories = ms1.Stories;
		veriskObject.sprinkler = sprinklerValue;
		veriskObject.roofYear = ms4.RoofCoverage;
		veriskObject.yearStarted = ms2.YearStarted;
		veriskObject.protectionClass =
			protectionClassValue.length === 1 ? _.padStart(protectionClassValue, 2, '0') : protectionClassValue;
	} else {
		veriskObject.noReturnData = true;
	}
	return veriskObject;
};

const getDatacubesData = async (mailingAddress, insuredName, dba) => {
	const datacubesObject = {};
	if (!isBlank(dba)) {
		insuredName = dba;
	}
	const companyObject = await getCompanyId('datacubes', mailingAddress, insuredName);
	const companyId = companyObject.companyId;
	const errorMessage = companyObject.errorMessage;

	if (!isBlank(companyId)) {
		datacubesObject.companyId = companyId;
		datacubesObject.search_relevance_score = companyObject.relevanceScore;
		datacubesObject.best_matched_fields_from_query = companyObject.bestMatchFields;
		datacubesObject.errorMessage = errorMessage;
		if (isBlank(errorMessage)) {
			const datacubesPropertyData = await getPropertyData('datacubes', companyId);

			datacubesObject.questions = _.get(datacubesPropertyData, 'd3PreFill.company', '');

			if (!isBlank(datacubesObject.questions)) {
				_.set(datacubesObject, 'questions.CIG_business_open_after_12am', isOpenLate(datacubesObject));
			}
		}
	} else {
		datacubesObject.noReturnData = true;
	}
	return datacubesObject;
};

// return true, false, or unknown
const isOpenLate = (d3Object) => {
	const hours = _.get(d3Object, 'questions.hours_of_operation', '');
	let ofTheJedi;

	if (!isBlank(hours) && typeof hours === 'object') {
		ofTheJedi = _.some(hours, (value) => {
			value = value.trim();
			// o -> open; c -> close
			const regex = /((\d{1,2})[:]\d{2}\s?(AM|PM)?)\s[-–]\s((\d{1,2})[:](\d{2})\s?(AM|PM)?)/i;

			if (regex.test(value)) {
				const regexArray = regex.exec(value);

				const oFull = regexArray[1];
				const oHour = parseInt(regexArray[2], 10);
				const oMeridies = regexArray[3];
				const cFull = regexArray[4];
				const cHour = parseInt(regexArray[5], 10);
				const cMinute = parseInt(regexArray[6], 10);
				const cMeridies = regexArray[7];

				// Assumption: lack of meridies values is 12 hours, not 24 hours
				// Open 24 hours without explicitly stating "Open 24 Hours"
				if (oFull === cFull && oMeridies && cMeridies) {
					return true;
				}

				// Assumption: Second number is always in the future and hour difference never exceeds 24
				if (oMeridies === 'AM' && cMeridies === 'AM') {
					if (oHour === 12 || oHour === 1 || cHour < oHour) {
						return true;
					} else {
						return false;
					}
				}

				if (oMeridies === 'PM' && cMeridies === 'PM') {
					if (cHour === 12 || cHour < oHour) {
						return true;
					} else {
						return false;
					}
				}

				if (oMeridies === 'AM' && cMeridies === 'PM') {
					if (oHour === 12 || oHour === 1) {
						return true;
					} else {
						return false;
					}
				}

				if (oMeridies === 'PM' && cMeridies === 'AM') {
					if (cHour === 12 && cMinute === 0) {
						return false;
					} else {
						return true;
					}
				}

				return false;
			} else if (value === 'Open 24 hours') {
				return true;
			} else if (value === 'Closed') {
				return false;
			}

			return false;
		});
	} else {
		ofTheJedi = 'Unknown';
	}

	return ofTheJedi;
};

export const getSTPData = async (currentContext, mailingAddress, formikProps) => {
	const insuredName = getFullInsuredName(currentContext.quote);
	const dba = _.get(currentContext, 'quote.insuredName.dba', '');

	currentContext.updateServiceStatus('stpPrefill', true);
	await Promise.all([getVeriskData(mailingAddress, insuredName), getDatacubesData(mailingAddress, insuredName, dba)])
		.then((values) => {
			_.set(formikProps, 'values.prefillData.verisk', values[0]);
			_.set(formikProps, 'values.prefillData.datacubes', values[1]);
		})
		.catch((err) => {
			console.error(err);
		});
	currentContext.updateServiceStatus('stpPrefill', false);
};

export const fillinFormsRequired = (quote) => {
	const buildings = distillBuildings(_.get(quote, 'sfg.locations', {}));
	const sfgCurrentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());

	return (
		hasFormBP0412(quote) ||
		hasFormBP0416(quote, buildings) ||
		hasFormBP0447(quote, buildings) ||
		hasFormBP0450(quote, buildings) ||
		hasFormBP0497(quote, sfgCurrentCoverages) ||
		hasFormBP1417(quote, buildings) ||
		hasFormBP1418(quote, sfgCurrentCoverages) ||
		hasFormBP1420(quote, sfgCurrentCoverages) ||
		hasFormBP1479(quote, buildings) ||
		hasFormIL375(quote, sfgCurrentCoverages)
	);
};
export const additionalFormsRequired = (quote) => {
	return (
		needsILMineSubsidenceRejection(quote) ||
		needsSfgTerrorismExclusion(quote) ||
		needsCupTerrorismExclusion(quote) ||
		needsMOEPLIAcknowledgement(quote)
	);
};

export const getVerisk360Data = (quoteState, locationId, buildingObject, buildingId) => {
	const requestBody = building360RequestBody(quoteState, locationId, buildingObject, buildingId);
	return getVerisk360Valuation(requestBody);
};

export const prefillUsed = (quote, values, prefillsPresent, locationId, buildingId) => {
	const { verisk, verisk360, datacubes, ncci } = prefillsPresent;
	const locationObject = _.get(quote, `sfg.locations.${locationId}`);
	const buildingObject = _.get(locationObject, `buildings.${buildingId}`);

	if (
		verisk &&
		(!isBlank(_.get(values, 'prefillData.verisk', '')) || !isBlank(_.get(locationObject, 'prefillData.verisk', '')))
	) {
		return true;
	}

	if (
		verisk360 &&
		(!isBlank(_.get(values, 'prefillData.verisk360.valuationId', '')) ||
			!isBlank(_.get(buildingObject, 'prefillData.verisk360.valuationId', '')))
	) {
		return true;
	}

	if (
		datacubes &&
		(!isBlank(_.get(values, 'prefillData.datacubes', '')) ||
			!isBlank(_.get(locationObject, 'prefillData.datacubes', ''))) &&
		_.toNumber(_.get(locationObject, 'prefillData.datacubes.search_relevance_score', '10')) >= 8
	) {
		return true;
	}

	if (
		ncci &&
		(_.get(values, 'wcp.prefillData.ncci.responseCode', '3') === '0' ||
			_.get(quote, 'wcp.prefillData.ncci.responseCode', '3') === '0')
	) {
		return true;
	}

	return false;
};

const building360RequestBody = (quoteInfo, locationId, buildingObject, buildingId) => {
	const roofMaterials = {
		Metal: {
			primary: 'RMP',
			auxillary: 'MTLC',
		},
		Tile: {
			primary: 'TIL',
			auxillary: 'TILG',
		},
		'Wood Shake': {
			primary: 'W',
			auxillary: 'W',
		},
		Other: {
			primary: 'COMP',
			auxillary: 'COMP',
		},
	};

	let auxConstructionType;
	let auxExterior;
	switch (buildingObject.constructionType) {
		case '01':
			auxConstructionType = 'WF'; // Wood Framed
			auxExterior = 'WBB'; // Siding - Board and Batten
			break;
		case '02':
		case '03': // Non-Combustible
		case '04':
			auxConstructionType = 'M'; // Masonry
			auxExterior = 'NB'; // None - Bare Masonry Block
			break;
		case '05':
		case '06':
			auxConstructionType = 'MP'; // Pre-Eng. Metal
			auxExterior = 'NMP'; // None - Pre-Eng. Metal Building
			break;
		default:
			break;
	}

	let auxiliaryObject = {};
	const uniqueid = `${quoteInfo.id}_${locationId}_${buildingId}`;
	const yearbuilt = _.get(buildingObject, 'constructionYear', toDate().getFullYear());

	// elements are named as such for direct use in Verisk360 API call
	switch (buildingObject.ancillaryDescription) {
		case 'Pool House':
			auxiliaryObject.PH = {
				uniqueid,
				pht: auxConstructionType,
				phewf: auxExterior,
				rc: _.get(roofMaterials, buildingObject.roofType + '.auxillary', ''),
				sf: buildingObject.squareFootage,
				yearbuilt,
			};
			break;
		case 'Fencing':
			auxiliaryObject.FEN = {
				uniqueid,
				fent: 'WP',
				l: 15, //TODO: Temporary
				h: 6,
				yearbuilt,
			};
			break;
		case 'Landscaping Wall':
			auxiliaryObject.LWL = {
				uniqueid,
				lwlt: 'BL',
				l: 15, //TODO: Temporary
				lwlh: 4,
				yearbuilt,
			};
			break;
		case 'Gazebos':
			auxiliaryObject.GZ = {
				uniqueid,
				gzt: 'R',
				m: 'TP',
				gzs: 'M',
				rt: 'SR',
				yearbuilt,
			};
			break;
		case 'Storage Sheds':
			auxiliaryObject.SS = {
				uniqueid,
				sst: 'W',
				sss: 8,
				flm: 'W',
				yearbuilt,
			};
			break;
		case 'Storm Shelter': // Above grade, Below Grade, or Both
			auxiliaryObject.SSA = {
				uniqueid,
				ssat: 'C',
				sf: buildingObject.squareFootage,
				yearbuilt,
			};
			break;
		case 'Carport':
			auxiliaryObject.CAR = {
				uniqueid,
				cart: 'AL',
				cars: 2,
				carp: 'S',
				carrc: _.get(roofMaterials, buildingObject.roofType + '.auxillary', ''),
				yearbuilt,
			};
			break;
		case 'Outdoor Inground Pool':
			auxiliaryObject.OP = {
				uniqueid,
				sf: buildingObject.squareFootage,
				opt: 'POLT',
				yearbuilt,
			};
			break;
		default:
	}

	const insuredName = quoteInfo.insuredName;
	const companyAddress = quoteInfo.addresses['1'];
	const propertyAddress = quoteInfo.addresses[locationId];
	const stateObject = _.get(classCodes, `${propertyAddress.state}`);
	const useCode = _.get(stateObject[buildingObject.classId], 'u', '').trim();
	const bldgEffectiveAge = Math.min(toDate().getFullYear() - yearbuilt, 50);

	const requestBody = {
		owner: {
			name: getFullInsuredName(quoteInfo),
			dba: insuredName.dba,
			street: !isBlank(companyAddress.streetNumber)
				? companyAddress.streetNumber + ' ' + companyAddress.streetName
				: companyAddress.streetName,
			city: companyAddress.city,
			state: companyAddress.state,
			country: 'USA',
			zipcode: companyAddress.zip,
			policynumber: quoteInfo.quoteNumber,
		},
		property: {
			name: getFullInsuredName(quoteInfo),
			street: propertyAddress.streetNumber + ' ' + propertyAddress.streetName,
			city: propertyAddress.city,
			state: propertyAddress.state,
			country: 'USA',
			zipcode: propertyAddress.zip,
			prometrixid: _.get(quoteInfo, `sfg.locations[${locationId}].prefillData.verisk.prometrixId`, ''),
		},
		underwritingInfo: {
			coveragetype: buildingObject.buildingValuation === '1' ? 'RC' : 'ACV',
			coverageamount: buildingObject.buildingLimit,
			coinsurance: buildingObject.buildingValuation === '1' ? 100 : 100 - bldgEffectiveAge,
		},
		occupancy: {
			otype: 'PRIMARY',
			use: buildingObject.ancillaryBuilding !== 'Y' ? useCode : 'AUX',
			sqft: buildingObject.squareFootage,
			yearbuilt,
			numstories: buildingObject.numberOfStories,
			isoconstructionclass: _.toInteger(buildingObject.constructionType),
		},
		features: {
			sprinkler: {
				type: 'FIRES',
				value: buildingObject.sprinkler === 'Y' ? '100' : '0',
			},
		},
	};

	// CIG Defaults based on classcode
	switch (buildingObject.classCode) {
		case '10072':
		case '10073':
		case '18616':
			requestBody.exteriorWallFinish = {
				type: 'RMP',
				value: 100,
			};
			requestBody.interiorPartitionWall = {
				type: 'NCW',
				value: 100,
			};
			_.set(requestBody, 'features.serviceBays', { type: 'SBAY', value: 6 });
			break;
		case '10367': // Automatic Car Wash
			_.set(requestBody, 'features.washStation', { type: 'CW5', value: 1 });
			break;
		case '10368': // Self Service Car Wash
			_.set(requestBody, 'features.washStation', { type: 'CWS', value: 5 });
			break;
		case '10072':
			requestBody.exteriorWallFinish = {
				type: 'RMP',
				value: 100,
			};
			_.set(requestBody, 'features.serviceBays', { type: 'SBAY', value: 6 });
			break;
		case '10073':
		case '18616':
			requestBody.exteriorWallFinish = {
				type: 'RMP',
				value: 100,
			};
			requestBody.interiorPartitionWall = {
				type: 'NCW',
				value: 100,
			};
			_.set(requestBody, 'features.serviceBays', { type: 'SBAY', value: 6 });
			break;
		default:
			break;
	}

	if (buildingObject.ancillaryBuilding !== 'Y') {
		if (buildingObject.roofType !== 'Metal') {
			requestBody.roofMaterial = {
				type: _.get(roofMaterials, buildingObject.roofType + '.primary', ''),
				value: 100,
			};
		} else {
			if (buildingObject.constructionType === '03') {
				requestBody.exteriorWallFinish = {
					type: 'RMP',
					value: 100,
				};
				requestBody.roofMaterial = {
					type: 'RMP',
					value: 100,
				};
			}
		}
		if (Date.parse(_.get(quoteInfo, 'transactionData.createdDate')) > Date.parse('2020-09-18T00:00:00.000Z')) {
			requestBody.acv = {
				basis: 'MLOP',
				effectiveage: bldgEffectiveAge,
			};
		} else {
			requestBody.acv = {
				basis: 'MLOP',
				percentage: 20,
			};
		}
	} else {
		requestBody.auxiliaryStructures = auxiliaryObject;
	}

	return removeEmpty(requestBody);
};

export const call360Valuation = async (currentContext, quote, locationId, building, buildingId, props) => {
	currentContext.updateServiceStatus('verisk360', true);
	await getVerisk360Data(quote, locationId, building, buildingId)
		.then((returnData) => {
			let veriskObject = {};

			if (returnData.MatchType === 'Error') {
				veriskObject.errorMessage = _.get(returnData, 'ErrorMessage', '');
			} else {
				if (building.ancillaryBuilding === 'Y') {
					if (Date.parse(_.get(quote, 'transactionData.createdDate')) > Date.parse('2020-09-18T00:00:00.000Z')) {
						const yearbuilt = _.get(building, 'constructionYear', toDate().getFullYear());
						const bldgEffectiveAge = Math.min(toDate().getFullYear() - yearbuilt, 50);
						const multiplier = 1 - bldgEffectiveAge / 100;
						veriskObject.ACV = (Number(_.get(returnData, 'calculatedValue', '0')) * multiplier).toString(10);
					} else {
						veriskObject.ACV = (Number(_.get(returnData, 'calculatedValue', '0')) * 0.8).toString(10);
					}
				} else {
					veriskObject.ACV = _.get(returnData, 'report.ACTUAL_CASH_VALUE.calculatedValue', '');
				}
				veriskObject.calculatedValue = _.get(returnData, 'calculatedValue', '');
				veriskObject.valuationId = _.get(returnData, 'report.valuationId', '');
				veriskObject.noReturnData = _.get(returnData, 'noReturnData');
			}

			_.set(quote, `sfg.locations.${locationId}.buildings.${buildingId}.prefillData.verisk360`, veriskObject);

			currentContext.updateQuote(quote, props);
			currentContext.updateServiceStatus('verisk360', false);
		})
		.catch((err) => {
			toast.error('The call to Verisk 360 could not be completed as dialed.');
			_.set(quote, `sfg.locations.${locationId}.buildings.${buildingId}.prefillData.verisk360.noReturnData`, true);
			currentContext.updateServiceStatus('verisk360', false);
			console.error(err);
		});
};

export const roofQuestionsRequired = (quote) => {
	const locations = _.get(quote, 'sfg.locations', {});
	return _.some(locations, (loc) => _.includes([1, 2], _.toNumber(_.get(loc, 'veriskRoofReport.Roof.RoofCondition'))));
};

export const getLowRoofScoreLocationIDs = (quote) => {
	const locations = _.get(quote, 'sfg.locations', {});
	return _.keys(
		_.pickBy(locations, (loc) => _.includes([1, 2], _.toNumber(_.get(loc, 'veriskRoofReport.Roof.RoofCondition')))),
	);
};

export const callRoofReportAPI = async (sessionID, address, quote, locationId) => {
	let roofReportAddressStructure = {};

	roofReportAddressStructure = {
		StreetAddress1: address.streetNumber + ' ' + address.streetName,
		City: address.city,
		State: address.state,
		Zip: address.zip.substr(0, 5),
	};

	const requestBody = {
		Parameters: {
			Address: roofReportAddressStructure,
		},
		authToken: sessionStorage.getItem('cigToken'),
		sessionID: sessionID,
	};

	return await getVeriskRoofReport(requestBody)
		.then((returnData) => {
			return returnData;
		})
		.catch((err) => {
			toast.error('Error calling Verisk Roof Report service.');
			if (locationId) {
				_.set(
					quote,
					`sfg.locations.${locationId}.prefillData.veriskRoofReport.ErrorMessage`,
					'Error retrieving Verisk roof report.',
				);
			}
			console.error(err);
		});
};

export const getProdIcon = (prod, size) => {
	let faName;
	switch (prod) {
		case 'sfg':
			faName = 'far fa-shield-alt';
			break;
		case 'cap':
			faName = 'fas fa-truck-pickup';
			break;
		case 'wcp':
			faName = 'fas fa-user-hard-hat';
			break;
		case 'cup':
			faName = 'fas fa-umbrella';
		default:
			break;
	}

	return <i className={faName + (size ? ' ' + size : '')} alt={productNames[prod]} title={productNames[prod]} />;
};

export const coverageRollOffMessages = ({ quoteCurrentCoverages, currentCoverages, navAction }) => {
	let coverageRemovalMessages = [];
	const removedCoverages = _.without(quoteCurrentCoverages, ...currentCoverages);
	const navText = navAction ? navAction : 'Next';
	_.forEach(removedCoverages, (cov) => {
		const covrgObj = _.find(
			[...sfg_policyCoverages_original, ...sfg_LocationCoverages, ...sfg_buildingCoverages],
			['value', cov],
		);
		if (covrgObj) {
			coverageRemovalMessages.push(
				`${covrgObj.text} has been removed. Please click ${navText} to continue this quote without the coverage.`,
			);
		}
	});
	return coverageRemovalMessages;
};

export const findFirstPDDeductible = (quote) => {
	let firstPDDeductibleLocation = -1;
	let firstPDDeductibleBuilding = -1;
	let locOrder = -1;

	const locations = _.get(quote, 'sfg.locations', {});
	_.forIn(locations, (location, locId) => {
		let bldgOrder = -1;
		_.forIn(_.get(location, 'buildings', {}), (building, bldgId) => {
			if (
				_.includes(['A', '10'], _.get(building, 'occupancyType')) &&
				(location.order <= locOrder || locOrder === -1)
			) {
				locOrder = location.order;
				if (building.order <= bldgOrder || bldgOrder === -1) {
					bldgOrder = building.order;
					firstPDDeductibleLocation = locId;
					firstPDDeductibleBuilding = bldgId;
				}
			}
		});
	});
	return { firstPDDeductibleLocation, firstPDDeductibleBuilding };
};

export const shouldUpdatePDDeductible = ({ values, quote, bldgId }) => {
	const { firstPDDeductibleBuilding } = findFirstPDDeductible(quote);
	return (
		(firstPDDeductibleBuilding === -1 || bldgId === firstPDDeductibleBuilding) &&
		_.includes(['10', 'A'], values.occupancyType)
	);
};

export const newAddressVerisk360 = ({ context, quote, locId, existingBuildings, props }) => {
	context.updateServiceStatus('runningRequiredServices', true);
	_.forIn(existingBuildings, (bldg, bldgId) => {
		if (!isBlank(_.get(bldg, 'prefillData.verisk360'))) {
			call360Valuation(context, quote, locId, bldg, bldgId, props);
		}
	});
	context.updateServiceStatus('runningRequiredServices', false);
};
