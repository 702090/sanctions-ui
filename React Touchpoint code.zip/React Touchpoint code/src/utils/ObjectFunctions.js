import _ from 'lodash';

export function getSet(dataObject = []) {
	if (_.isArray(dataObject)) {
		return new Set(dataObject);
	}
	if (_.isSet(dataObject)) {
		return dataObject;
	}
	if (_.isObject(dataObject)) {
		return new Set(Object.values(dataObject));
	}
	return new Set();
}

export function duplicate(obj) {
	return _.cloneDeep(obj);
}

export function toSortedPairList(object, sortCriteria) {
	const screenList = _.toPairs(object);
	if (!sortCriteria) {
		return _.sortBy(screenList, [
			(screen) => {
				return screen[1].order;
			},
		]);
	}
	return _.sortBy(screenList, [
		(screen) => {
			return _.get(screen[1], sortCriteria);
		},
	]);
}

export const handleDrop = (dest, src, name, caller) => {
	const newObjects = {};
	toSortedPairList(_.get(caller.context.quote, name)).forEach((objPair) => {
		let obj = objPair[1];
		if (obj.order === src) {
			obj.order = dest;
		} else {
			if (dest > src) {
				//drag down
				if (obj.order > src && obj.order <= dest) {
					obj.order--;
				}
			} else {
				//drag up
				if (obj.order < src && obj.order >= dest) {
					obj.order++;
				}
			}
		}
		newObjects[objPair[0]] = obj;
	});

	caller.setState({ force: !caller.state.force });
	_.set(caller.context.quote, name, newObjects);
	caller.dirty = true;
};

export const removeEmpty = (obj) => {
	const o = JSON.parse(JSON.stringify(obj)); // Clone source object.

	Object.keys(o).forEach((key) => {
		if (o[key] && typeof o[key] === 'object') {
			// Recurse.
			o[key] = removeEmpty(o[key]);
		} else if (o[key] === undefined || o[key] === null || o[key] === '') {
			// Delete undefined and null.
			delete o[key];
		}
	});
	return o; // Return new object.
};
