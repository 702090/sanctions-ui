import _ from 'lodash';

/**
 * Takes a string and removes '_' and '-' from string.
 * @param {string} input The value that needs the mask removed.
 * @return {string} The input with the mask removed.
 */
export function stripMask(input) {
	return input.replace(/[_-]/g, '');
}

/**
 * Decides if a string is made up of all the same character.
 * @param {string} input The string to check.
 * @param {boolean} strip Masked flag to determine if a mask needs to be removed.
 * @return {boolean} True if all characters are the same, false if there is at least 1 different character.
 */
export function allCharactersSame(input, stripMasked) {
	if (stripMasked) {
		input = stripMask(input);
	}
	if (input.length === 0) return false;
	return input.split('').every((char) => char === input[0]);
}

export function isBlank(input) {
	if (_.isEmpty(input)) {
		if (_.isNumber(input)) {
			return _.toNumber(input) === 0;
		}
		return true;
	}
	if (_.isString(input)) {
		input = input.trim();
		return input.length === 0;
	}
	return false;
}

export function isBlankZ(input) {
	if (_.isEmpty(input)) {
		if (_.isNumber(input)) {
			return false;
		}
		return true;
	}
	if (_.isString(input)) {
		input = input.trim();
		return input.length === 0;
	}
	return false;
}

export function isBlankR(input) {
	if (_.isObject(input)) {
		let total = true;
		_.forIn(input, (attribute, name) => {
			total = total && isBlankR(attribute);
		});
		return total;
	}
	if (_.isEmpty(input)) {
		if (_.isNumber(input)) {
			return _.toNumber(input) === 0;
		}
		return true;
	}
	if (_.isString(input)) {
		input = input.trim();
		return input.length === 0;
	}
	return false;
}

export function isBlankO(input) {
	if (_.isEmpty(input)) {
		if (_.isNumber(input)) {
			return _.toNumber(input) === 0;
		}
		return true;
	}
	if (_.isString(input)) {
		input = input.trim();
		return input.length === 0;
	}
	return false;
}

export function getClaimStatus(input) {
	switch (input) {
		case 'O':
			return 'Open';
		case 'CP':
			return 'Closed With Payment';
		case 'CN':
			return 'Closed No Payment';
		case 'RO':
			return 'Re-opened';
		default:
			return undefined;
	}
}

/**
 *
 * @param {*} passedInput either event or string value to clean
 * @returns {string} value with non-allowed characters removed
 * @summary Use when you don't want to directly set field value on form
 */
export function cleanInput(passedInput) {
	const allowedCharsRegex = /[^\w\s\.&'!é,@-]/g;
	if (typeof passedInput === 'string') {
		return passedInput.replace(allowedCharsRegex, '');
	}

	if (_.get(passedInput, 'target')) {
		let string = _.get(passedInput, 'target.value', '');
		return string.replace(allowedCharsRegex, '');
	}

	return passedInput;
}

/**
 *
 * @param {event} event event passed from form
 * @param {function} setFieldValue formik setFieldValue function
 * @param {string} name name of form field to be set
 * @summary use for input components to directly set form value after cleanse
 */
export function cleanSpecialCharacters(event, setFieldValue, name) {
	const cleanedValue = cleanInput(_.get(event, 'target.value', ''));
	setFieldValue(name, cleanedValue);
}
