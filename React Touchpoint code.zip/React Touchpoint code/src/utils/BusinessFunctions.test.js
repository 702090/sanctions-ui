import { findFirstPDDeductible } from './BusinessFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import _ from 'lodash';

describe('firstPDDeductibleBuilding', () => {
	const fakeQuote = {
		sfg: {
			locations: {
				'6e079781-21c1-4072-873e-c022bbfee34c': {
					buildings: {
						'77c56284-28ec-4f34-88ac-6610298ea562': {
							occupancyType: '8',
							order: 1,
						},
						'93574b09-66c1-4729-b9e5-fc893cfd3626': {
							occupancyType: '1',
							order: 3,
						},
						'7146bd17-14f0-4a1d-9589-99d1b4449063': {
							occupancyType: '8',
							order: 5,
						},
						'97c10433-b9f2-4846-b9d2-9abe70fda313': {
							occupancyType: '7',
							order: 2,
						},
						'217679ee-a6e8-4589-a0cd-f1d04bad6457': {
							occupancyType: '5',
							order: 4,
						},
						'142fd40a-9f45-4b86-b035-706965788f9f': {
							occupancyType: '8',
							order: 6,
						},
						'033c8add-982e-401b-8cdf-2e8d98a28ab9': {
							occupancyType: '8',
							order: 7,
						},
					},
					order: 1,
				},
				'29c8345e-5db4-4405-b139-a87beb947028': {
					buildings: {
						'dfd69775-64e4-4844-9612-0f51c4d8d165': {
							occupancyType: '8',
							order: 1,
						},
						'6f67d7a1-de5e-489e-93c2-14d425f09be4': {
							occupancyType: '8',
							order: 2,
						},
						'ef2f4bee-7d83-4a18-9400-7c3aedf60416': {
							occupancyType: '8',
							order: 3,
						},
						'1263107e-28fb-43a3-8db9-cd69462f0d30': {
							occupancyType: '8',
							order: 5,
						},
						'd9834118-f78f-4daa-a57e-2dc6eb4add14': {
							occupancyType: '8',
							order: 4,
						},
						'4b14b4e7-d3c9-4825-b16f-0d5366e8661f': {
							occupancyType: '8',
							order: 6,
						},
						'3e2120e6-3afc-41a1-a911-1e4ced6f3c45': {
							occupancyType: '8',
							order: 7,
						},
					},
					order: 2,
				},
				'88c71483-d17c-411f-9a6d-d2fc8c420085': {
					buildings: {
						'53d1d702-deb0-4949-a145-5fb247ceecf4': {
							occupancyType: '4',
							order: 1,
						},
						'6ac33d8a-f59e-4f37-a71e-5997bc573aa3': {
							occupancyType: '4',
							order: 3,
						},
						'8f8ec1b9-c6e7-4a76-be57-231eb642548f': {
							occupancyType: '4',
							order: 2,
						},
					},
					order: 4,
				},
				'52a9f3f7-757b-4f7c-bfae-ed7b7e59582f': {
					buildings: {
						'ae2d6664-a248-4546-9570-7353e5ee0faa': {
							occupancyType: '8',
							order: 1,
						},
						'f974ccec-32e1-41e2-b8f8-5dff8f9dde4f': {
							occupancyType: '8',
							order: 2,
						},
						'cc4e8b64-f8fd-4d6c-99ab-943d40f12dbf': {
							occupancyType: '8',
							order: 3,
						},
						'ecf53d62-aa99-489d-8b2a-2cf44f2ee0c2': {
							occupancyType: '8',
							order: 4,
						},
					},
					order: 3,
				},
				'f4251080-b7d0-4a46-abac-d78ce32a2a2f': {
					order: 5,
				},
				'e1ccc340-889c-4eaa-87af-8532c2fda9eb': {
					buildings: {
						'b9d36d72-28ac-4658-962f-f63108e22f00': {
							occupancyType: '8',
							order: 1,
						},
					},
					order: 6,
				},
			},
		},
	};

	test('Location 4, Building 3', () => {
		const manipulated = duplicate(fakeQuote);
		_.set(
			manipulated,
			'sfg.locations[88c71483-d17c-411f-9a6d-d2fc8c420085].buildings[6ac33d8a-f59e-4f37-a71e-5997bc573aa3].occupancyType',
			'10',
		);
		const spectedReturn = findFirstPDDeductible(manipulated);
		expect(spectedReturn).toEqual({
			firstPDDeductibleLocation: '88c71483-d17c-411f-9a6d-d2fc8c420085',
			firstPDDeductibleBuilding: '6ac33d8a-f59e-4f37-a71e-5997bc573aa3',
		});
	});

	test('Location 1, Building 1', () => {
		const manipulated = duplicate(fakeQuote);
		_.set(
			manipulated,
			'sfg.locations[6e079781-21c1-4072-873e-c022bbfee34c].buildings[77c56284-28ec-4f34-88ac-6610298ea562].occupancyType',
			'10',
		);
		const spectedReturn = findFirstPDDeductible(manipulated);
		expect(spectedReturn).toEqual({
			firstPDDeductibleLocation: '6e079781-21c1-4072-873e-c022bbfee34c',
			firstPDDeductibleBuilding: '77c56284-28ec-4f34-88ac-6610298ea562',
		});
	});
	test('No returns', () => {
		const spectedReturn = findFirstPDDeductible(fakeQuote);
		expect(spectedReturn).toEqual({ firstPDDeductibleLocation: -1, firstPDDeductibleBuilding: -1 });
	});
	test('Location 2, Building 2 using multiple locations and buildings', () => {
		const manipulated = duplicate(fakeQuote);
		_.set(
			manipulated,
			'sfg.locations[29c8345e-5db4-4405-b139-a87beb947028].buildings[6f67d7a1-de5e-489e-93c2-14d425f09be4].occupancyType',
			'10',
		);
		_.set(
			manipulated,
			'sfg.locations[29c8345e-5db4-4405-b139-a87beb947028].buildings[ef2f4bee-7d83-4a18-9400-7c3aedf60416].occupancyType',
			'10',
		);
		_.set(
			manipulated,
			'sfg.locations[88c71483-d17c-411f-9a6d-d2fc8c420085].buildings[53d1d702-deb0-4949-a145-5fb247ceecf4].occupancyType',
			'A',
		);
		const spectedReturn = findFirstPDDeductible(manipulated);
		expect(spectedReturn).toEqual({
			firstPDDeductibleLocation: '29c8345e-5db4-4405-b139-a87beb947028',
			firstPDDeductibleBuilding: '6f67d7a1-de5e-489e-93c2-14d425f09be4',
		});
	});
});
