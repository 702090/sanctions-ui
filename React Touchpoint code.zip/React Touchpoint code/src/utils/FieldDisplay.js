import classCodeListsJson from 'data/ClassCodeLists';
import countListsJson from 'data/CountyLists';
import _ from 'lodash';
import {
	addEpliForm,
	distillBuildings,
	getFirstLocation,
	getPredState,
	isIndividual,
	shouldUpdatePDDeductible,
} from 'utils/BusinessFunctions';
import { toDate } from 'utils/DateFunctions';
import { getSet } from 'utils/ObjectFunctions';
import { isBlank, isBlankZ } from 'utils/StringFunctions';

const { ilMineSubsidenceRejection, windHail_AL_refer, windHail_GA_refer, windHail_MS_refer } = countListsJson;
const { canopyClasses, restaurantClasses } = classCodeListsJson;

/**
 * Decides if the firstName or lastName field should be displayed.
 * @param {Object} quote The entire current quote from the state.
 * @param {Objects} values The Formik values of the current form.
 * @return {boolean} True if the insured for this quote is an individual, false otherwise.
 */
export function isNotCompany(quote, values) {
	return isIndividual(quote, values);
}

/**
 * Decides if the companyName field should be displayed.
 * @param {Object} quote The entire current quote from the state.
 * @param {Objects} values The Formik values of the current form.
 * @return {boolean} True if the insured for this quote is not an individual, false otherwise.
 */
export function isCompany(quote, values) {
	return !isIndividual(quote, values);
}

export function isAddBp0412Form(quote, values) {
	return _.get(values, 'fillinForms.bp0412.addForm', '') === 'Y';
}

export function checkAdditionalInsuredType(quote, values) {
	return values.additionalInsureds === 'Y';
}

export function checkAmusementArea(quote, values) {
	return (
		(_.includes(['1', '6', '7', '8', '9'], values.occupancyType) ||
			_.includes(['69151', '69161', '69171'], values.classCode)) &&
		!_.includes(['09421', '09431', '09441', '09451'], values.classCode)
	);
}

export function checkLiabilityExposureBasis(quote, values) {
	if (values.classCode === '09411') {
		return false;
	}

	if (values.ownerOccupied === 'Y') {
		return false;
	}

	return (
		_.includes(['8', '9', '10', 'A'], values.occupancyType) ||
		_.includes(
			[
				'10072',
				'10367',
				'10368',
				'10073',
				'18616',
				'13454',
				'13453',
				'13590',
				'12361',
				'12362',
				'44071',
				'69151',
				'69161',
				'69171',
				'09361',
				'09341',
				'09331',
				'09351',
				'09361',
				'09311',
				'54136',
			],
			values.classCode,
		)
	);
}

export function checkTotalPayroll(quote, values) {
	if (checkLiabilityExposureBasis(quote, values)) {
		if (values.classCode === '99827') {
			return true;
		}
		if (
			_.includes(
				[
					'10072',
					'10367',
					'10368',
					'10073',
					'18616',
					'13454',
					'13453',
					'13590',
					'12361',
					'12362',
					'44071',
					'69151',
					'69161',
					'69171',
					'09361',
					'09341',
					'09321',
					'09331',
					'09351',
					'09311',
					'54136',
				],
				values.classCode,
			)
		) {
			return false;
		}
		return _.includes(['2', '4', '10'], values.occupancyType);
	}
	return false;
}
export function checkTotalSales(quote, values) {
	if (checkLiabilityExposureBasis(quote, values)) {
		if (values.classCode === '99827') {
			return false;
		}
		if (
			_.includes(
				[
					'10072',
					'10367',
					'10368',
					'10073',
					'18616',
					'13454',
					'13453',
					'13590',
					'12361',
					'12362',
					'44071',
					'69151',
					'69161',
					'69171',
					'09361',
					'09341',
					'09331',
					'09351',
					'09311',
					'54136',
				],
				values.classCode,
			)
		) {
			return true;
		}
		return _.includes(['8', '9', 'A'], values.occupancyType);
	}
	return false;
}

export function showEarthquake(quote, values) {
	return isNotTexas(quote, values) && values.ancillaryBuilding !== 'Y';
}

export function isEarthquake(quote, values) {
	return values.earthquakeCoverage === 'Y';
}

export function checkMasonryVeneer(quote, values) {
	return (
		values.earthquakeCoverage === 'Y' &&
		values.constructionType === '01' &&
		(!isBlank(values.eqBuildingSubLimit) || !isBlank(values.eqBPPSubLimit))
	);
}

export function isNotHomeOffice(quote, values) {
	return values.homeOffice !== 'Y';
}

export function hasBuildingLimit(quote, values) {
	return isNotHomeOffice(quote, values) && !isBlank(values.buildingLimit);
}

export function isContractorOccupancy(quote, values) {
	return values.occupancyType === '10';
}

export function hasEarthquakeAndBuildingLimit(quote, values) {
	return values.earthquakeCoverage === 'Y' && values.buildingLimit > 0;
}

export function hasEarthquakeAndBPPLimit(quote, values) {
	return values.earthquakeCoverage === 'Y' && values.bppLimit > 0;
}

export function checkNumberOfSwimmingPools(quote, values) {
	return (
		_.includes(['1', '6', '7'], values.occupancyType) ||
		_.includes(['69151', '69161', '69171', '44071'], values.classCode)
	);
}
export function checkPlayground(quote, values) {
	return (
		(_.includes(['1', '6', '7', '8', '9'], values.occupancyType) ||
			_.includes(['69151', '69161', '69171'], values.classCode)) &&
		!_.includes(['09421', '09431', '09441', '09451'], values.classCode)
	);
}

export function checkwindstormHailRoofACV(quote, values) {
	return !isBlank(quote.windHailDeductible);
}

export function checkBuildingUpdates(quote, values) {
	if (values.constructionYear > 0) {
		return (
			toDate().getFullYear() - values.constructionYear > 20 &&
			isNotHomeOffice(quote, values) &&
			!isBlank(values.buildingLimit)
		);
	}
	return false;
}

export function checkOwnerOccupied(quote, values) {
	if (
		_.includes(
			['09411', '65144', '65145', '65146', '65147', '65132', '65133', '65141', '65142', '69145'],
			values.classCode,
		) ||
		values.homeOffice === 'Y'
	) {
		return false;
	}
	return values.occupancyType !== '1';
}

export function checkIfLeasing(quote, values) {
	return values.ownerOccupied === 'Y';
}

export function hasPools(quote, values) {
	return values.numberOfSwimmingPools > 0;
}
export function tier1County(quote, values) {
	if (values && values.addressL) {
		const county = _.replace(values.addressL.county, ' County', '');
		return (
			values.addressL.state === 'TX' &&
			_.includes(
				[
					'Aransas',
					'Brazoria',
					'Calhoun',
					'Cameron',
					'Chambers',
					'Galveston',
					'Jefferson',
					'Kennedy',
					'Kleberg',
					'Matagorda',
					'Nueces',
					'Refugio',
					'San Patricio',
					'Willacy',
				],
				county,
			)
		);
	}
	return false;
}

export function notTier1County(quote, values) {
	return !tier1County(quote, values);
}

export function checkFloodCoverage(quote, values) {
	return values && values.tidalWater === 'Y';
}

export function isNotMetalRoof(quote, values) {
	return values && values.roofType !== 'Metal' && isNotHomeOffice(quote, values);
}

export function isMetalRoof(quote, values) {
	return values && values.roofType === 'Metal' && isNotHomeOffice(quote, values);
}

export function isNotTexas(quote, values) {
	return _.get(quote, `addresses.${values.locationId}.state`, '') !== 'TX';
}

export function noLosses(quote, values) {
	return _.size(_.get(quote, 'sfg.losses', {})) === 0;
}

export function noLossesCap(quote, values) {
	return _.size(_.get(quote, 'cap.losses', {})) === 0;
}

export function noLossesWcp(quote, values) {
	return _.size(_.get(quote, 'wcp.losses', {})) === 0;
}

export function noLossesCup(quote, values) {
	return _.size(_.get(quote, 'cup.losses', {})) === 0;
}

export function isFirstBuilding(quote, values) {
	// if location order is 1 AND
	// it's either the first bulding or there are no buildings (this is a new
	//    one,  thus it's first)
	return (
		_.get(quote, `sfg.locations.${values.locationId}.order`, -1) === 1 &&
		(_.get(quote, `sfg.locations.${values.locationId}.buildings`, -1) === -1 ||
			_.get(quote, `sfg.locations.${values.locationId}.buildings.${values.id}.order`, -1) === 1)
	);
}

export function displayPDFields(quote, values) {
	return shouldUpdatePDDeductible({ values, quote, bldgId: values.id });
}

export function isHasPriorCarrier(quote, values) {
	return _.get(values, 'sfg.priorCarrier') === 'Y';
}

export function isHasPriorCarrierCap(quote, values) {
	return _.get(values, 'cap.priorCarrier') === 'Y';
}

export function isHasPriorCarrierWcp(quote, values) {
	return _.get(values, 'wcp.priorCarrier') === 'Y';
}

export function isHasPriorCarrierCup(quote, values) {
	return _.get(values, 'cup.priorCarrier') === 'Y';
}

export function isPriorCig(quote, values) {
	return isHasPriorCarrier(quote, values) && _.get(values, 'sfg.cigPriorCarrier') === 'Y';
}

export function isPriorCigCap(quote, values) {
	return isHasPriorCarrierCap(quote, values) && _.get(values, 'cap.cigPriorCarrier') === 'Y';
}

export function isPriorCigWcp(quote, values) {
	return isHasPriorCarrierWcp(quote, values) && _.get(values, 'wcp.cigPriorCarrier') === 'Y';
}

export function isPriorCigCup(quote, values) {
	return isHasPriorCarrierCup(quote, values) && _.get(values, 'cup.cigPriorCarrier') === 'Y';
}

export function isPriorNotCig(quote, values) {
	return isHasPriorCarrier(quote, values) && _.get(values, 'sfg.cigPriorCarrier') === 'N';
}

export function isPriorNotCigCap(quote, values) {
	return isHasPriorCarrierCap(quote, values) && _.get(values, 'cap.cigPriorCarrier') === 'N';
}

export function isPriorNotCigWcp(quote, values) {
	return isHasPriorCarrierWcp(quote, values) && _.get(values, 'wcp.cigPriorCarrier') === 'N';
}

export function isPriorNotCigCup(quote, values) {
	return isHasPriorCarrierCup(quote, values) && _.get(values, 'cup.cigPriorCarrier') === 'N';
}

export function isNotAllContactsSame(quote, values) {
	return _.get(values, 'contacts.allContactsSame') !== 'Y';
}

export function isAccountBill(quote, values) {
	return _.includes(['E010E', 'E010M'], _.get(values, 'billing.billingType', ''));
}

export function hasCigBillingAccount(quote, values) {
	return _.get(values, 'billing.existingAccountBill') === 'Y';
}

export function noCigBillingAccount(quote, values) {
	return _.get(values, 'billing.existingAccountBill') === 'N' && isAccountBill(quote, values);
}

export function needsBillingName(quote, values) {
	return noCigBillingAccount(quote, values) && _.get(values, 'billing.billingSameAsApplicant') === 'N';
}

export function newEftAccount(quote, values) {
	return _.get(values, 'billing.billingType', '') === 'E010E' && noCigBillingAccount(quote, values);
}

export function notAgencyBill(quote, values) {
	return (
		!_.includes(['A01', 'AAQ'], _.get(values, 'billing.billingType', '')) &&
		!isBlank(_.get(values, 'billing.billingType', ''))
	);
}
export function notAgencyBillCAP(quote, values) {
	return (
		!_.includes(['A01', 'AAQ'], _.get(values, 'billing.billingType', '')) &&
		!isBlank(_.get(values, 'billing.billingType', '')) &&
		_.includes(quote.products, 'cap')
	);
}
export function notAgencyBillWCP(quote, values) {
	return (
		!_.includes(['A01', 'AAQ'], _.get(values, 'billing.billingType', '')) &&
		!isBlank(_.get(values, 'billing.billingType', '')) &&
		_.includes(quote.products, 'wcp')
	);
}
export function notAgencyBillCUP(quote, values) {
	return (
		!_.includes(['A01', 'AAQ'], _.get(values, 'billing.billingType', '')) &&
		!isBlank(_.get(values, 'billing.billingType', '')) &&
		_.includes(quote.products, 'cup')
	);
}

export function isOnlineBankPayment(quote, values) {
	return _.get(values, 'billing.downPaymentMethod') === 'ICheck';
}

export function bankAccountSame(quote, values) {
	return (
		isOnlineBankPayment(quote, values) &&
		_.get(values, 'billing.billingType', '') !== 'E010M' &&
		noCigBillingAccount(quote, values)
	);
}

export function useDifferentAccount(quote, values) {
	return (
		_.get(values, 'billing.downPaymentMethod') === 'ICheck' &&
		(_.get(values, 'billing.bankAccountSame') === 'N' ||
			hasCigBillingAccount(quote, values) ||
			_.includes(['E010M', 'D01', 'DQ4'], _.get(values, 'billing.billingType', '')))
	);
}

export function pipAllowed(quote, values) {
	const predState = getPredState(quote);
	return _.includes(['KS', 'KY', 'TX', 'AR'], predState);
}

export function additionalPipAllowed(quote, values) {
	const predState = getPredState(quote);
	return _.includes(['KS', 'KY'], predState) && !_.includes(['0', ''], _.get(values, 'cap.symbols.pip', ''));
}

export function needWcpRiskId(quote, values) {
	return _.get(values, 'wcp.experienceMod', 0) > 0 && _.get(values, 'wcp.experienceMod', 0) !== 1;
}

export function hasPredStateTx(quote, values) {
	return getPredState(quote) === 'TX';
}

export function hasUimSymbol(quote, values) {
	return !_.includes(['0', ''], _.get(quote, 'cap.symbols.umUIM', ''));
}

export function hasTowSymbol(quote, values) {
	return !_.includes(['0', ''], _.get(quote, 'cap.symbols.tow', ''));
}

export function hasNonOwnLiabilitySymbol(quote, values) {
	return _.get(quote, 'cap.symbols.liability', '') !== '7';
}

export function hasHiredPhysicalDamage(quote, values) {
	return _.get(quote, 'cap.symbols.comp', '') === '7,8' || _.get(quote, 'cap.symbols.coll', '') === '7,8';
}

export function isCorporationOrLLC(quote, values) {
	return _.includes(['03', '13'], _.get(quote, 'businessType', ''));
}

export function hasCompSymbol(quote, values) {
	return !_.includes(['', '0'], _.get(values, 'cap.symbols.comp', ''));
}

export function hasCollSymbol(quote, values) {
	return !_.includes(['', '0'], _.get(values, 'cap.symbols.coll', ''));
}

export function hasCompOrCollSymbol(quote, values) {
	return hasCompSymbol(quote, values) || hasCollSymbol(quote, values);
}

export function additionalPipSelected(quote, values) {
	return !_.includes(['0', ''], _.get(quote, 'cap.symbols.additionalPip', ''));
}

export function hasMedPaySymbol(quote, values) {
	return !_.includes(['0', ''], _.get(values, 'cap.symbols.medPay', ''));
}

export function hasOtc(quote, values) {
	return values.otcCoverage === 'Y' && !_.includes(['', '0'], _.get(quote, 'cap.symbols.comp', ''));
}

export function hasColl(quote, values) {
	return values.collCoverage === 'Y' && !_.includes(['', '0'], _.get(quote, 'cap.symbols.coll', ''));
}

export function vehicleCostNew(quote, values) {
	return hasCompOrCollSymbol(quote, values) || hasOtc(quote, values) || hasColl(quote, values);
}

export function seatingCapacity(quote, values) {
	return values.vehType === '16';
}

export function vehRadius(quote, values) {
	const vehicleType = _.toNumber(values.vehType);
	return (vehicleType >= 3 && vehicleType <= 7) || vehicleType === 16;
}

export function secondaryClassCode(quote, values) {
	const vehicleType = _.toNumber(values.vehType);
	return vehicleType >= 3 && vehicleType <= 7;
}

export function hasPrivatePassenger(quote, values) {
	return values.vehType === '1' || values.vehType === '2';
}

export function liabilitySymbol(quote, values) {
	return _.includes(['7', '7,9', '7,8,9'], _.get(quote, 'cap.symbols.liability', ''));
}

export function registeredStateCdKansas(quote, values) {
	let results = false;
	let address = _.get(quote, 'cap.registrationAddress', '');
	if (address) {
		results = quote.addresses[address].state === 'KS';
	}
	return results;
}

export function registeredStateCdSouthDakota(quote, values) {
	let results = false;
	let address = _.get(quote, 'cap.registrationAddress', '');
	if (address) {
		results = quote.addresses[address].state === 'SD';
	}
	return results;
}

export function umUimCoverageSymbol(quote, values) {
	const uninsuredSymbolsList = _.toNumber(_.get(quote, 'cap.symbols.umUIM', ''));
	return (
		(uninsuredSymbolsList >= 2 && uninsuredSymbolsList <= 4) || (uninsuredSymbolsList >= 6 && uninsuredSymbolsList <= 8)
	);
}

export function otcCollCoverageSymbol(quote, values) {
	const collSymbol = _.get(quote, 'cap.symbols.coll', '');
	return collSymbol !== '0';
}

export function officerTitleOther(quote, values) {
	return values.title === 'OTHER';
}

export function needNumberOfOfficersIncluded(quote, values) {
	return _.get(values, 'wcp.officersIncluded', '') === 'Y';
}

export function grossVehWeight(quote, values) {
	return (values.vehType === '3' || values.vehType === '4') && !isBlank(values.grossVehWeight);
}

export function needVehSize(quote, values) {
	return (values.vehType === '3' || values.vehType === '4') && isBlank(values.grossVehWeight);
}

export function showSfgDriverCount(quote, values) {
	const currentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());

	return (
		!_.includes(quote.products, 'cap') &&
		(isBlank(_.get(quote, 'cup.underlyingPolicies.cap', {})) ||
			isBlank(_.get(quote, 'cup.underlyingPolicies.cap.driverCount', {}))) &&
		(getSet(currentCoverages).has('HIRE') || getSet(currentCoverages).has('NOWN'))
	);
}

export function manualEntry(quote, values) {
	return (
		!_.includes(quote.products, 'wcp') &&
		(_.get(values, 'cup.underlyingPolicies.wcp.manual', 'N') === 'Y' ||
			_.get(quote, 'cup.retrievedUnderlyingPolicies.wcp'))
	);
}

export function hasRestaurantClassCodes(quote, values) {
	const classCodes = distillBuildings(_.get(quote, 'sfg.locations', {})).classCodes;
	return _.intersection([...classCodes], restaurantClasses).length > 0;
}

export function hasCDPC(quote, values) {
	const currentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());

	return getSet(currentCoverages).has('CDPC');
}

export function hasCDBBorCDBS(quote, values) {
	const currentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());

	return getSet(currentCoverages).has('CDBB') || getSet(currentCoverages).has('CDBS');
}

export function hasVETL(quote, values) {
	const currentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());

	return getSet(currentCoverages).has('VETL');
}

export function hasCDFD(quote, values) {
	const currentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());

	return getSet(currentCoverages).has('CDFD');
}

export function hasPLPM(quote, values) {
	const currentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());

	return getSet(currentCoverages).has('PLPM');
}

export function hasCDPN(quote, values) {
	const currentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());

	return getSet(currentCoverages).has('CDPN');
}

export function hasCODO(quote, values) {
	const currentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());

	return getSet(currentCoverages).has('CODO');
}

export function hasCDOH(quote, values) {
	const currentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());

	return getSet(currentCoverages).has('CDOH');
}

export function hasCDSC(quote, values) {
	const currentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());

	return getSet(currentCoverages).has('CDSC');
}

export function texasDefaultExpMod(quote, values) {
	const firstLocation = getFirstLocation(quote);
	return (
		_.get(quote, `addresses.${firstLocation}.state`) === 'TX' &&
		_.includes(['', '1'], _.toString(values.wcp.experienceMod))
	);
}

export function wcpTwelveMonthsOrMore(quote, values) {
	return _.toNumber(values.wcp.monthsInBusiness) >= 12 && texasDefaultExpMod(quote, values);
}

export function hadPreviousWCPCarrier(quote, values) {
	return values.wcp.previousInsurance === 'Y' && wcpTwelveMonthsOrMore(quote, values);
}

export function hasPriorLostTimeClaim(quote, values) {
	return values.wcp.lostTimeClaims === 'Y' && hadPreviousWCPCarrier(quote, values);
}

export function isNotFirstBuilding(quote, values) {
	return (
		!isBlank(_.get(quote, `sfg.locations.${values.locationId}.buildings`, {})) &&
		_.get(quote, `sfg.locations.${values.locationId}.buildings.${values.id}.order`) !== 1
	);
}

export function isAncillaryBuilding(quote, values) {
	return values.ancillaryBuilding === 'Y';
}

export function hasFormBP0412(quote) {
	return getPredState(quote) != 'MO';
}

export function hasFormBP0416(quote, buildings) {
	if (!buildings) {
		buildings = distillBuildings(_.get(quote, 'sfg.locations', {}));
	}

	return buildings.additionalInsuredTypes.has('BP0416');
}
export function hasFormBP0447(quote, buildings) {
	if (!buildings) {
		buildings = distillBuildings(_.get(quote, 'sfg.locations', {}));
	}

	return buildings.additionalInsuredTypes.has('BP0447');
}
export function hasFormBP0450(quote, buildings) {
	if (!buildings) {
		buildings = distillBuildings(_.get(quote, 'sfg.locations', {}));
	}

	return buildings.additionalInsuredTypes.has('BP0450');
}
export function hasFormBP0497(quote, currentCoverages) {
	if (!currentCoverages) {
		currentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());
	}

	return getSet(currentCoverages).has('CDWS');
}
export function hasFormBP1417(quote, buildings) {
	if (!buildings) {
		buildings = distillBuildings(_.get(quote, 'sfg.locations', {}));
	}

	return buildings.buildingCoverages.has('CDDL');
}
export function hasFormBP1418(quote, currentCoverages) {
	if (!currentCoverages) {
		currentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());
	}

	return getSet(currentCoverages).has('CDDC');
}
export function hasFormBP1420(quote, currentCoverages) {
	if (!currentCoverages) {
		currentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());
	}

	return getSet(currentCoverages).has('CDDX');
}
export function hasFormBP1479(quote, buildings) {
	if (!buildings) {
		buildings = distillBuildings(_.get(quote, 'sfg.locations', {}));
	}

	return buildings.buildingCoverages.has('SPAP');
}
export function hasFormIL375(quote, currentCoverages) {
	if (!currentCoverages) {
		currentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());
	}

	return getSet(currentCoverages).has('CDCP');
}

export function checkRoofArea(quote, values) {
	let roofAreaCounty = false;
	const address = _.get(values, 'addressL', _.get(quote, `addresses[${values.locationId}]`, ''));
	const county = _.replace(address.county, 'County', '');
	switch (address.state) {
		case 'AL':
			roofAreaCounty = _.includes(windHail_AL_refer, county);
			break;
		case 'GA':
			roofAreaCounty =
				_.includes(windHail_GA_refer, county) &&
				_.get(quote, `sfg.locations.${values.locationId}.gaWest95`, '') !== 'N';
			break;
		case 'MS':
			roofAreaCounty = _.includes(windHail_MS_refer, county);
			break;
		default:
			break;
	}
	return isNotHomeOffice(quote, values) && values.numberOfStories > 1 && roofAreaCounty;
}

export function checkGaWest95(quote, values) {
	const address = _.get(values, 'addressL', _.get(quote, `addresses[${values.locationId}]`, ''));
	return address.state === 'GA' && _.includes(windHail_GA_refer, _.replace(address.county, 'County', ''));
}

export function isHasBP1203(quote, values) {
	return _.get(values, 'sfgInterestDescription', '') === 'BP1203 – Loss Payee';
}

export function hasReferrals(quote) {
	return !isBlank(quote.referrals);
}

export function hasQuoteId(quote) {
	return !isBlank(quote.id);
}

export function newVenture(quote, values) {
	return values.newVenture === 'Y';
}

export function isHasBP1203orBP1231(quote, values) {
	return (
		_.get(values, 'sfgInterestDescription', '') === 'BP1203 – Loss Payee' ||
		_.get(values, 'sfgInterestDescription', '') === 'BP1231 – Building Owner'
	);
}

export function needsILMineSubsidenceRejection(quote, values) {
	const locations = _.get(quote, 'sfg.locations', {});

	const thing = _.some(locations, (location, key) => {
		const address = _.get(quote, `addresses.${key}`, {});

		const locationCounty = _.get(address, 'county', '');
		const isIllinois = _.get(address, 'state', '') === 'IL';
		const countyConditions = ilMineSubsidenceRejection.includes(locationCounty);

		const bldgConditions = _.some(location.buildings, (building) => {
			const hasBldgLimit = !isBlank(building.buildingLimit);
			const currentCoverages = Array.from(_.get(building, 'coverages.currentCoverages', []));
			return hasBldgLimit && !currentCoverages.includes('MN');
		});

		return isIllinois && countyConditions && bldgConditions;
	});

	return thing;
}

export function needsSfgTerrorismExclusion(quote, values) {
	return _.get(quote, 'sfg.coverages.TRSM.included', 'Y') === 'N';
}

export function needsCupTerrorismExclusion(quote, values) {
	return _.get(quote, 'cup.federalTerrorism', 'Y') === 'N';
}

export function needsMOEPLIAcknowledgement(quote, values) {
	return addEpliForm(quote);
}

export function askSubcontracting(quote, values) {
	const buildings = distillBuildings(_.get(quote, 'sfg.locations', {}));
	const notOnBuildingPage = _.get(values, 'sfg.businessType');

	// visibility on the policy page
	if (_.get(values, 'sfg.businessType') === '9' || (notOnBuildingPage && getSet(buildings.occupancyCodes).has('10'))) {
		return true;
	} else if (
		// on building page and haven't answered the question before
		_.get(values, 'occupancyType', '') === '10' &&
		isBlankZ(_.get(quote, 'sfg.percentSubcontracting', ''))
	) {
		return true;
	}
	return false;
}

export function canopyQuestion(quote, values) {
	return _.includes(canopyClasses, values.classCode) && values.ancillaryBuilding !== 'Y';
}
