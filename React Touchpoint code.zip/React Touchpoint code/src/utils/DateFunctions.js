import { differenceInDays, differenceInYears } from 'date-fns';
import _ from 'lodash';
import { isBlank } from 'utils/StringFunctions';

/**
 * Converts a date string to a Date object.
 * @param {string} dateString A date in the format MM/DD/YYYY.
 * @return {Date} A Date object of the given date string or now.
 */
export function toDate(dateString) {
	let date = new Date();
	if (dateString && !isBlank(dateString)) {
		if (_.includes(dateString, '-')) {
			date = new Date(`${dateString}T12:00:00Z`);
		} else if (_.includes(dateString, '/')) {
			date = new Date(dateString);
		} else {
			const year = dateString.substring(0, 4);
			const month = dateString.substring(4, 6);
			const day = dateString.substring(6, 8);

			date = new Date(year, month - 1, day);
		}
	}
	date = new Date(date.setHours(0, 0, 0, 0));
	return date;
}

/**
 * Converts a date string to a new Date for DayPicker current month.
 * @param {string} dateString A date in the format MM/DD/YYYY.
 * @return {Date} A Date object in the format needed for DayPicker.
 */
export function getYearMonth(dateString) {
	let date = toDate();
	if (dateString !== undefined && dateString !== '') {
		date = new Date(Date.parse(dateString));
	}
	return new Date(date.getFullYear(), date.getMonth());
}

/**
 * Converts a Date object to a date string with leading zeros where required.
 * @param {string} date The Date string to format.
 * @return {string} The date converted to a string in the format MM/DD/YYYY.
 */
export function formatDate(date, type) {
	let dateObject = toDate(date);
	return formatDateObject(dateObject, type);
}

export function formatDateObject(dateObject, type) {
	const months = [
		'January',
		'February',
		'March',
		'April',
		'May',
		'June',
		'July',
		'August',
		'September',
		'October',
		'November',
		'December',
	];
	let newDate = '';
	const month = ('0' + (dateObject.getMonth() + 1)).slice(-2);
	const day = ('0' + dateObject.getDate()).slice(-2);
	const year = dateObject.getFullYear();
	switch (type) {
		case 'iso':
			newDate = year + '-' + month + '-' + day;
			break;
		case 'text':
			let daySuffix = 'th';
			let dayInt = dateObject.getDate();
			if (dayInt % 10 === 1) {
				daySuffix = 'st';
			} else if (dayInt % 10 === 2) {
				daySuffix = 'nd';
			} else if (dayInt % 10 === 3) {
				daySuffix = 'rd';
			}
			newDate = months[dateObject.getMonth()] + ' ' + dayInt + daySuffix + ', ' + year;
			break;
		default:
			newDate = month + '/' + day + '/' + year;
	}
	return newDate;
}

/**
 * Calculates the number of days between now and a given day.
 * @param {string} dateString A date in the format MM/DD/YYYY
 * @return {number} The number of days between the date string and now. (can be + or - values)
 */
export function daysFromNow(dateString) {
	const date = toDate(dateString);

	let dfn = differenceInDays(date, toDate());
	if (dfn === '-0') {
		dfn = 0;
	}

	return parseInt(dfn);
}

export function daysFromDate(date1String, date2String) {
	const date1 = toDate(date1String);
	const date2 = toDate(date2String);

	let dfd = differenceInDays(date1, date2);
	if (dfd === '-0') {
		dfd = 0;
	}

	return parseInt(dfd);
}

export function yearsFromNow(dateString) {
	const date = toDate(dateString);
	return differenceInYears(date, toDate());
}

export function yearsFromDate(date1String, date2String) {
	const date1 = toDate(date1String);
	const date2 = toDate(date2String);
	return differenceInYears(date1, date2);
}

/**
 * Validates that the input string is a valid calendar day.
 * @param {string} dateString A date in the format MM/DD/YYYY
 * @return {boolean} True if the date is a valid one on the calendar (including leap years), and False if it is not.
 */
export function isValidDate(dateString) {
	if (_.includes(dateString, '-')) {
		dateString = formatDate(dateString);
	}
	// First check for the pattern
	if (!/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(dateString)) return false;

	// Parse the date parts to integers
	const parts = dateString.split('/');
	const day = parseInt(parts[1], 10);
	const month = parseInt(parts[0], 10);
	const year = parseInt(parts[2], 10);

	// Check the ranges of month and year
	if (year < 1000 || year > 3000 || month === 0 || month > 12) return false;

	const monthLength = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

	// Adjust for leap years
	if (year % 400 === 0 || (year % 100 !== 0 && year % 4 === 0)) {
		monthLength[1] = 29;
	}

	// Check the range of the day
	return day > 0 && day <= monthLength[month - 1];
}

export function getListOfYears() {
	const yearList = [];
	for (let i = toDate().getFullYear(); i >= 1950; i--) {
		yearList.push({ value: i, text: i });
	}
	return yearList;
}

export function getPastDate(yearsAgo) {
	const today = new Date();
	today.setFullYear(today.getFullYear() - yearsAgo);
	return formatDateObject(today);
}

export function calculateAge(birthDate, otherDate) {
	birthDate = toDate(birthDate);
	otherDate = toDate(otherDate);

	let years = otherDate.getFullYear() - birthDate.getFullYear();

	if (
		otherDate.getMonth() < birthDate.getMonth() ||
		(otherDate.getMonth() === birthDate.getMonth() && otherDate.getDate() < birthDate.getDate())
	) {
		years--;
	}

	return years;
}
