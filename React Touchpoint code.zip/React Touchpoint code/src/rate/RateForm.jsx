import { InformationMessage } from 'components/shared/messages/InformationMessage';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import Timer from 'components/shared/Timer';
import { DashLoader } from 'components/shared/wait/DashLoader';
import QuoteContext from 'context/quoteContext';
import { Form, Formik } from 'formik';
import _ from 'lodash';
import 'odometer/themes/odometer-theme-default.css';
import React, { Fragment, useContext, useEffect, useRef } from 'react';
import NumberFormat from 'react-number-format';
import { toast } from 'react-toastify';
import { Popup } from 'semantic-ui-react';
import { getProposalPdf } from 'services/applicationPDFService';
import { insurityProposal, rateQuote } from 'services/insurityService';
import { capCompanyPlacement } from 'services/ruleService';
import { displayPolicyNumber, displayQuoteNumber, getProdIcon, isEmployee } from 'utils/BusinessFunctions';
import { base64toBlob, cleanModifiers, saveOrOpen } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { checkOverrideReferrals, replaceReferrals } from 'validation/RunReferrals';

const RateForm = (props) => {
	const context = useContext(QuoteContext);
	const { quote, rate: rateState } = context;

	let initial = true;

	if (rateState) {
		rateState.hasCap = _.includes(quote.products, 'cap');
		rateState.hasWcp = _.includes(quote.products, 'wcp');
		rateState.hasCup = _.includes(quote.products, 'cup');
	}

	const timer = useRef(null);

	const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));

	const resetRating = () => {
		rateState.done = new Set();
		rateState.doneRating = false;
		rateState.errorMessages = {};
		rateState.totalRate = 0;
		rateState.hasCap = _.includes(quote.products, 'cap');
		rateState.hasWcp = _.includes(quote.products, 'wcp');
		rateState.hasCup = _.includes(quote.products, 'cup');
		rateState.status = {};
		rateState.status['sfg'] = 'r';
		rateState.status['cap'] = 'p';
		rateState.status['wcp'] = 'p';
		rateState.status['cup'] = 'p';
		rateState.sfgRate = '';
		rateState.capRate = '';
		rateState.wcpRate = '';
		rateState.cupRate = '';
		rateState.gettingProposal = false;
		rateState.prodProposals = {};

		context.updateRate(rateState);
	};

	useEffect(() => {
		if (initial) {
			if (rateState && rateState.doneRating) {
				resetRating();
				cleanModifiers(quote);
				checkOverrideReferrals(quote);

				const sfgData = {
					product: 'BOP',
					agent,
					quote,
				};

				if (localStorage.getItem('quoteId') === _.get(context, 'quote.id')) {
					rateQuote(sfgData).then(returnedRate);

					timer && timer.current && timer.current.start();
				} else {
					multiTabMessage();
				}
			}
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [quote.products]);

	const cannotIssue = () => {
		return isEmployee() && agent.agentSubpro === '55110-00001' && process.env.REACT_APP_ENVIRONMENT_NAME === 'prod';
	};

	const returnedRate = async (returnRate) => {
		console.info('returnRate', returnRate); //! DO NOT DELETE !//

		const {
			quoteId,
			san,
			insurityMessages,
			rate,
			insurityQuoteNumber,
			naic,
			naicCode,
			sic,
			sicCode,
			placementCompany,
			liabilityPremium,
			cdebPremium,
			cdlqPremium,
			biPerPerson,
			biPerAccident,
			pdPerAccident,
			lightPremiumAmount,
			lightExposureAmount,
			heavyPremiumAmount,
			heavyExposureAmount,
			extraHeavyPremiumAmount,
			extraHeavyExposureAmount,
			valenId,
			geoCodeFailed,
		} = returnRate;

		if (isBlank(returnRate)) {
			rateState.totalRate = 'error';
			rateState.done.add('sfg');
			rateState.status.sfg = 'e';
			rateState.errorMessages.sfg = [{ message: 'A system error has occured during rating.' }];
			rateState.sfgRate = 'error';
			if (rateState.hasCap) {
				rateState.done.add('cap');
				rateState.status.cap = 'e';
				rateState.errorMessages.cap = [{ message: 'A system error has occured during rating.' }];
				rateState.capRate = 'error';
			}
			if (rateState.hasWcp) {
				rateState.done.add('wcp');
				rateState.status.wcp = 'e';
				rateState.errorMessages.wcp = [{ message: 'A system error has occured during rating.' }];
				rateState.wcpRate = 'error';
			}
			if (rateState.hasCup) {
				rateState.done.add('cup');
				rateState.status.cup = 'e';
				rateState.errorMessages.cup = [{ message: 'A system error has occured during rating.' }];
				rateState.cupRate = 'error';
			}

			timer && timer.current && timer.current.stop();
			rateState.doneRating = true;
			context.updateRate(rateState);
		} else if (localStorage.getItem('quoteId') === quoteId || rate === 'error') {
			switch (returnRate.product) {
				case 'BOP':
					context.savePageValues({
						sfg: {
							san,
							insurityQuoteNumber,
							placementCompany,
							umbrellaData: {
								liabilityPremium,
								cdebPremium,
								cdlqPremium,
							},
						},
						rates: { sfg: rate },
						naic,
						naicCode,
						sic,
						sicCode,
					});
					rateState.done.add('sfg');
					rateState.status.sfg = 'd';
					_.unset(rateState, 'errorMessages.sfg');
					if (!isBlank(insurityMessages)) {
						rateState.status.sfg = 'e';
						rateState.errorMessages.sfg = insurityMessages;
						rateState.totalRate = 'error';
					} else {
						rateState.totalRate = rate + rateState.totalRate;
					}
					rateState.sfgRate = rate;

					_.set(quote, 'geoCodeFailed', _.get(returnRate, 'geoCodeFailed', false));
					replaceReferrals(context);

					if (rateState.hasCap) {
						const capCompany = await capCompanyPlacement(quote);
						_.set(quote, 'cap.company', _.get(capCompany, 'Done.Company', '02'));

						const capData = {
							product: 'CAP',
							agent,
							quote,
						};
						rateState.status.cap = 'r';
						rateQuote(capData).then(returnedRate);
					}
					if (rateState.hasWcp) {
						const wcpData = {
							product: 'WCP',
							agent,
							quote,
						};
						rateState.status.wcp = 'r';
						rateQuote(wcpData).then(returnedRate);
					}
					break;
				case 'CAP':
					context.savePageValues({
						cap: {
							san,
							placementCompany,
							umbrellaData: {
								biPerPerson,
								biPerAccident,
								pdPerAccident,
								lightPremiumAmount,
								lightExposureAmount,
								heavyPremiumAmount,
								heavyExposureAmount,
								extraHeavyPremiumAmount,
								extraHeavyExposureAmount,
							},
						},
						rates: { cap: rate },
					});
					rateState.done.add('cap');
					rateState.status.cap = 'd';
					_.unset(rateState, 'errorMessages.cap');
					if (!isBlank(insurityMessages)) {
						rateState.status.cap = 'e';
						rateState.errorMessages.cap = insurityMessages;
						rateState.totalRate = 'error';
					} else {
						rateState.totalRate = rate + rateState.totalRate;
					}
					rateState.capRate = rate;

					break;
				case 'CUP':
					context.savePageValues({
						cup: { san, placementCompany },
						rates: { cup: rate },
					});
					rateState.status.cup = 'd';
					rateState.done.add('cup');
					_.unset(rateState, 'errorMessages.cup');
					if (!isBlank(insurityMessages)) {
						rateState.status.cup = 'e';
						rateState.errorMessages.cup = insurityMessages;

						rateState.totalRate = 'error';
					} else {
						rateState.totalRate = rate + rateState.totalRate;
					}
					rateState.cupRate = rate;

					break;
				case 'WCP':
					context.savePageValues({
						wcp: { san, placementCompany, prefillData: { valenId } },
						rates: { wcp: rate },
					});
					rateState.status.wcp = 'd';
					rateState.done.add('wcp');
					_.unset(rateState, 'errorMessages.wcp');
					if (!isBlank(insurityMessages)) {
						rateState.status.wcp = 'd';
						rateState.errorMessages.wcp = insurityMessages;
						rateState.totalRate = 'error';
					} else {
						rateState.totalRate = rate + rateState.totalRate;
					}
					rateState.wcpRate = rate;

					break;
				default:
			}

			if (
				rateState.hasCup &&
				_.get(rateState, 'done', new Set()).size === _.get(quote, 'products', ['sfg']).length - 1 &&
				rateState.totalRate !== 'error'
			) {
				rateState.status.cup = 'r';
				const cupData = {
					product: 'CUP',
					agent,
					quote,
				};
				rateQuote(cupData).then(returnedRate);
			} else if (rateState.totalRate === 'error') {
				rateState.status.cup = 'b';
			}

			context.updateRate(rateState);

			if (_.get(rateState, 'done', new Set()).size === _.get(quote, 'products', ['sfg']).length) {
				timer && timer.current && timer.current.stop();

				rateState.doneRating = true;
				context.updateRate(rateState);

				// Make the issue nav item visible if there are no errors
				const nav = context.navigation;
				nav.navItems = nav.navItems.map((navItem) => {
					if (navItem.url.includes('issue')) {
						navItem.visible = !cannotIssue() && isBlank(rateState.errorMessages);
					}
					return navItem;
				});
				context.updateNav(nav);
			}
		} else {
			timer && timer.current && timer.current.stop();

			multiTabMessage();
		}
	};

	const multiTabMessage = () => {
		_.get(quote, 'products', ['sfg']).forEach((prod) => {
			rateState.errorMessages[prod] = [
				{
					code: 'QUOTE',
					message:
						'There was an error trying to rate your quote. You may have TouchPoint open in more than 1 tab. Please exit to the quote list and re-open this quote to rate.',
				},
			];

			rateState.status[prod] = 'e';
			rateState[prod + 'Rate'] = 'error';
			rateState.totalRate = 'error';
			rateState.doneRating = true;
			rateState.done.add(prod);
		});

		context.updateRate(rateState);
	};

	const proposalClicked = (type, product) => {
		if (!rateState.prodProposals[product]) {
			if (!product) {
				rateState.gettingProposal = type;
			} else {
				rateState.prodProposals[product] = true;
			}
			context.updateRate(rateState);

			// TODO: switch here to determine which proposal to go with.
			switch (type) {
				case '1':
					insurityProposal(quote, product)
						.then((returned) => {
							if (returned.data.base64) {
								const blob = base64toBlob(returned.data.base64);

								const fileName = `Proposal_${
									quote.policyNumber ? displayPolicyNumber(quote, '') : displayQuoteNumber(quote, '')
								}_${Date.now()}.pdf`;

								saveOrOpen(blob, fileName);
							}
							rateState.gettingProposal = false;
							rateState.prodProposals[product] = false;
							if (returned.data.insurityMessages) {
								rateState.errorMessages[product] = returned.data.insurityMessages;
							}
							context.updateRate(rateState);
						})
						.catch((error) => {
							toast.error('Could not retrieve Proposal.');
							console.error('Error', error);
							rateState.gettingProposal = false;
							rateState.errorMessages[product] = {
								message: 'An error has occurred generating proposal.',
							};
							context.updateRate(rateState);
						});
					break;
				case '2':
					getProposalPdf(quote).then(async (returned) => {
						const blob = base64toBlob(returned.data.base64);

						const fileName = `Proposal_${
							quote.policyNumber ? displayPolicyNumber(quote, '') : displayQuoteNumber(quote, '')
						}_${Date.now()}.pdf`;

						saveOrOpen(blob, fileName);

						rateState.gettingProposal = false;
						context.updateRate(rateState);
					});
					break;
				case '3':
					rateState.gettingProposal = false;
					context.updateRate(rateState);
					break;
				default:
					rateState.gettingProposal = false;
					context.updateRate(rateState);
					break;
			}
		}
		if (product) {
			_.remove(rateState, 'prodProposals.' + product);
		}
	};

	return (
		<Formik
			render={(formikProps) => (
				<Form id='screen'>
					<div id='rate'>
						<div id='totalRate'>
							{_.get(rateState, 'done', new Set()).size < _.get(quote, 'products', ['sfg']).length ? (
								<Fragment>
									<div id='spinningRate'>
										<DashLoader />
									</div>
								</Fragment>
							) : !isBlank(rateState.errorMessages) ? (
								<Fragment>
									<div id='errorRate'>
										<div>
											<h2>UhOh!</h2>
											<span>Something went wrong.</span>
										</div>
										<img id='surprisedRed' alt='Surprised Alien' src={require('images/surprisedAlienRed.png')} />
									</div>
								</Fragment>
							) : (
								<Fragment>
									<NumberFormat
										value={rateState.totalRate}
										displayType='text'
										thousandSeparator
										prefix='$'
										decimalScale={2}
										fixedDecimalScale
									/>
								</Fragment>
							)}
						</div>

						<div id='sfgRate' className='productRate'>
							{getProdIcon('sfg', 'big')}
							{rateState && isBlank(rateState.sfgRate) ? (
								<span className='withElipsis'>Rating</span>
							) : rateState && rateState.errorMessages.sfg ? (
								<span className='error'>Error</span>
							) : (
								<Fragment>
									<NumberFormat
										value={rateState && rateState.sfgRate}
										displayType='text'
										thousandSeparator
										prefix='$'
										decimalScale={2}
										fixedDecimalScale
									/>
									{_.get(quote, 'products', ['sfg']).length > 1 && (
										<Popup
											trigger={
												<div
													className={`getProposal ${
														rateState && _.get(rateState, 'prodProposals.sfg', false) ? 'active' : ''
													}`}
													onClick={() => {
														proposalClicked('1', 'sfg');
													}}
												>
													<i className='fal fa-download big' />
												</div>
											}
											content='View the Safeguard Proposal'
											position='bottom center'
										/>
									)}
								</Fragment>
							)}
						</div>
						{rateState && rateState.errorMessages.sfg && (
							<ul className='productError'>
								{rateState.errorMessages.sfg.map((message, i) => (
									<li key={`sfg_msg_${i}`} className='errorMessage'>
										{message.message}
										{message.code === 'QUOTE' && (
											<a href='/' className='quoteListLink'>
												<br />
												Exit to Quote List
											</a>
										)}
									</li>
								))}
							</ul>
						)}
						{rateState && rateState.hasCap && (
							<React.Fragment>
								<div id='capRate' className='productRate'>
									{getProdIcon('cap', 'big')}
									{isBlank(rateState.capRate) ? (
										<span className='withElipsis'>{rateState.status.cap === 'r' ? 'Rating' : 'Pending'}</span>
									) : rateState.errorMessages.cap ? (
										<span className='error'>Error</span>
									) : (
										<React.Fragment>
											<NumberFormat
												value={rateState.capRate}
												displayType={'text'}
												thousandSeparator={true}
												prefix={'$'}
												decimalScale={2}
												fixedDecimalScale
											/>
											<Popup
												trigger={
													<div
														className={`getProposal ${rateState.prodProposals.cap ? 'active' : ''}`}
														onClick={() => {
															proposalClicked('1', 'cap');
														}}
													>
														<i className='fal fa-download big' />
													</div>
												}
												content='View the Commercial Auto Proposal'
												position='bottom center'
											/>
										</React.Fragment>
									)}
								</div>
								{rateState.errorMessages.cap && (
									<ul className='productError'>
										{rateState.errorMessages.cap.map((message, i) => (
											<li key={`cap_msg_${i}`} className='errorMessage'>
												{message.message}
											</li>
										))}
									</ul>
								)}
							</React.Fragment>
						)}
						{rateState && rateState.hasWcp && (
							<React.Fragment>
								<div id='wcpRate' className='productRate'>
									{getProdIcon('wcp', 'big')}
									{isBlank(rateState.wcpRate) ? (
										<span className='withElipsis'>{rateState.status.wcp === 'r' ? 'Rating' : 'Pending'}</span>
									) : rateState.errorMessages.wcp ? (
										<span className='error'>Error</span>
									) : (
										<React.Fragment>
											<NumberFormat
												value={rateState.wcpRate}
												displayType={'text'}
												thousandSeparator={true}
												prefix={'$'}
												decimalScale={2}
												fixedDecimalScale
											/>
											<Popup
												trigger={
													<div
														className={`getProposal ${rateState.prodProposals.wcp ? 'active' : ''}`}
														onClick={() => {
															proposalClicked('1', 'wcp');
														}}
													>
														<i className='fal fa-download big' />
													</div>
												}
												content='View the Workers Compensation Proposal'
												position='bottom center'
											/>
										</React.Fragment>
									)}
								</div>
								{rateState.errorMessages.wcp && (
									<ul className='productError'>
										{rateState.errorMessages.wcp.map((message, i) => (
											<li key={`wcp_msg_${i}`} className='errorMessage'>
												{message.message}
											</li>
										))}
									</ul>
								)}
							</React.Fragment>
						)}
						{rateState && rateState.hasCup && (
							<React.Fragment>
								<div id='cupRate' className='productRate'>
									{getProdIcon('cup', 'big')}
									{isBlank(rateState.cupRate) ? (
										rateState.status.cup === 'b' ? (
											<span className='blocked'>Blocked by Errors</span>
										) : (
											<span className='withElipsis'>{rateState.status.cup === 'r' ? 'Rating' : 'Pending'}</span>
										)
									) : rateState.errorMessages.cup ? (
										<span className='error'>Error</span>
									) : (
										<React.Fragment>
											<NumberFormat
												value={rateState.cupRate}
												displayType={'text'}
												thousandSeparator={true}
												prefix={'$'}
												decimalScale={2}
												fixedDecimalScale
											/>
											<Popup
												trigger={
													<div
														className={`getProposal ${rateState.prodProposals.cup ? 'active' : ''}`}
														onClick={() => {
															proposalClicked('1', 'cup');
														}}
													>
														<i className='fal fa-download big' />
													</div>
												}
												content='View the Commercial Umbrella Proposal'
												position='bottom center'
											/>
										</React.Fragment>
									)}
								</div>
								{rateState.errorMessages.cup && (
									<ul className='productError'>
										{rateState.errorMessages.cup.map((message, i) => (
											<li key={`cup_msg_${i}`} className='errorMessage'>
												{message.message}
											</li>
										))}
									</ul>
								)}
							</React.Fragment>
						)}
					</div>
					<Timer ref={timer} />
					<NavigationButtons
						formikProps={formikProps}
						back
						proposalOnClick={proposalClicked}
						gettingProposal={rateState && rateState.gettingProposal}
						doneRating={rateState && rateState.doneRating}
						ratingErrors={rateState && rateState.errorMessages}
						location={props.location}
						history={props.history}
						disableNext={cannotIssue()}
					/>
					<InformationMessage
						message='You are quoting as the Demo Agency which is not permitted to issue.'
						fieldDisplay={cannotIssue()}
					/>
				</Form>
			)}
			initialValues={{}}
			onSubmit={() => {
				return context.onSubmit({}, false, false, false, props);
			}}
		/>
	);
};

export default RateForm;
