import QuoteContext from 'context/quoteContext';
import React, { Component } from 'react';
import AttachmentsForm from 'sidebar/Attachments';
import { EditProducts } from 'sidebar/EditProducts';
import Feedback from 'sidebar/Feedback';
import QuoteInformation from 'sidebar/QuoteInformation';
import { ReferralList } from 'sidebar/Referrals';
import Remarks from 'sidebar/Remarks';
import { isBlankR } from 'utils/StringFunctions';
import StpRuleResults from './StpRuleResults';
import { isEmployee } from 'utils/BusinessFunctions';

class Sidebar extends Component {
	static contextType = QuoteContext;

	state = {};

	toggleSidebar = (func) => {
		if (this.state.currentFunction === func) {
			this.setState({ currentFunction: undefined });
		} else {
			this.setState({ currentFunction: func });
		}
	};

	closeSidebar = () => {
		this.setState({ currentFunction: undefined });
	};

	render() {
		const sidebar_class = `sidebar ${this.state.currentFunction ? 'open' : ''}`;
		const { quote } = this.context;

		return (
			<React.Fragment>
				{this.state.currentFunction && <div className='sidebarCloser' onClick={this.closeSidebar} />}
				<div className={sidebar_class} data-html2canvas-ignore='true'>
					<ul>
						<li
							onClick={() => this.toggleSidebar('Referrals')}
							className={
								(this.state.currentFunction === 'Referrals' ? 'active' : '') +
								(!isBlankR(quote.referrals) ? ' attention' : '')
							}
						>
							<div>
								{this.state.currentFunction === 'Referrals' ? (
									<i className='fal fa-times-circle big' />
								) : (
									<i className='far fa-external-link-alt big' />
								)}
								Referrals
							</div>
						</li>
						<li
							onClick={() => this.toggleSidebar('Attachments')}
							className={this.state.currentFunction === 'Attachments' ? 'active' : ''}
						>
							{this.state.currentFunction === 'Attachments' ? (
								<i className='fal fa-times-circle big' />
							) : (
								<i className='fal fa-paperclip big' />
							)}
							Attachments
						</li>
						<li
							onClick={() => this.toggleSidebar('Remarks')}
							className={
								(this.state.currentFunction === 'Remarks' ? 'active' : '') +
								(!isBlankR(quote.businessDescription) ? ' attention' : '')
							}
						>
							<div>
								{this.state.currentFunction === 'Remarks' ? (
									<i className='fal fa-times-circle big' />
								) : (
									<i className='fal fa-comment-alt-lines big' />
								)}
								Remarks
							</div>
						</li>
						{isEmployee() && (
							<li
								onClick={() => this.toggleSidebar('StpRuleResults')}
								className={this.state.currentFunction === 'StpRuleResults' ? 'active' : ''}
							>
								{this.state.currentFunction === 'StpRuleResults' ? (
									<i className='fal fa-times-circle big' />
								) : (
									<i className='fad fa-ruler-triangle big' />
								)}
								STP Rule Results
							</li>
						)}
						<li
							onClick={() => this.toggleSidebar('Contact Us')}
							className={this.state.currentFunction === 'Contact Us' ? 'active' : ''}
						>
							{this.state.currentFunction === 'Contact Us' ? (
								<i className='fal fa-times-circle big' />
							) : (
								<i className='fal fa-comments' />
							)}
							Contact Us
						</li>
						<li
							onClick={() => this.toggleSidebar('TouchPoint Products')}
							className={this.state.currentFunction === 'TouchPoint Products' ? 'active' : ''}
						>
							{this.state.currentFunction === 'TouchPoint Products' ? (
								<i className='fal fa-times-circle big' />
							) : (
								<i className='fal fa-plus-square' />
							)}
							Products
						</li>
						<li
							onClick={() => this.toggleSidebar('Policy Information')}
							className={this.state.currentFunction === 'Policy Information' ? 'active' : ''}
						>
							{this.state.currentFunction === 'Policy Information' ? (
								<i className='fal fa-times-circle big' />
							) : (
								<i className='fal fa-info-circle' />
							)}
							Info
						</li>
					</ul>
					<div className='sidebarContent'>
						{this.state.currentFunction !== 'Referrals' ? <h5>{this.state.currentFunction}</h5> : null}
						{this.state.currentFunction === 'Referrals' && <ReferralList quote={quote} generateHTML />}
						{this.state.currentFunction === 'Attachments' && <AttachmentsForm />}
						{this.state.currentFunction === 'Remarks' && <Remarks quote={quote} closeSidebar={this.closeSidebar} />}
						{this.state.currentFunction === 'StpRuleResults' && (
							<StpRuleResults quote={quote} closeSidebar={this.closeSidebar} />
						)}
						{this.state.currentFunction === 'Contact Us' && <Feedback quote={quote} />}
						{this.state.currentFunction === 'TouchPoint Products' && (
							<EditProducts quote={quote} updateProducts={this.props.updateProducts} {...this.props} />
						)}
						{this.state.currentFunction === 'Policy Information' && <QuoteInformation />}
					</div>
				</div>
			</React.Fragment>
		);
	}
}

export default Sidebar;
