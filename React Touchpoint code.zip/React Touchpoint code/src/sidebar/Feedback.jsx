import { SubmitButton } from 'components/shared/buttons/SubmitButton';
import { InputText } from 'components/shared/form/inputs/InputText';
import { InputTextArea } from 'components/shared/form/inputs/InputTextArea';
import { Select } from 'components/shared/form/Select';
import selectOptionsJson from 'data/SelectOptions';
import { Field, Form, withFormik } from 'formik';
import { validEmail } from 'helper/Validation';
import html2canvas from 'html2canvas';
import React, { Component } from 'react';
import { toast } from 'react-toastify';
import http from 'services/httpService';
import { getFullInsuredName } from 'utils/BusinessFunctions';
import { pageEvent } from 'utils/ScreenFunctions';

const closeWidget = () => {};
const { contactType } = selectOptionsJson;

class FeedbackFields extends Component {
	state = {};

	render() {
		pageEvent('ContactUs', 'Click', 'Button');
		return (
			<Form>
				<Field name='contactType' label='How can we help?' component={Select} options={contactType} width='medium' />
				<Field name='feedback_person' label='Your Name:' component={InputText} width='medium' />
				<Field name='feedback_email' label='Your Contact Email' component={InputText} width='medium' />
				<Field name='feedback_text' label='Comments:' component={InputTextArea} rows={6} width='medium' />
				<SubmitButton content='Submit' disabled={this.props.isSubmitting} />
			</Form>
		);
	}
}

const Feedback = withFormik({
	enableReinitialize: true,
	mapPropsToValues: ({ quote }) => {
		return {
			contactType: '',
			feedback_person: quote.personEnteringRisk ? quote.personEnteringRisk : '',
			feedback_email: '',
			feedback_text: '',
		};
	},
	validate: (values, props) => {
		const errors = {};

		if (!values.contactType || values.contactType === '') {
			errors.contactType = 'Please select a contact type!';
		}
		if (!values.feedback_text || values.feedback_text === '') {
			errors.feedback_text = 'Please tell us how we can help!';
		}
		if (!validEmail(values.feedback_email)) {
			errors.feedback_email = 'Please provide a valid email address!';
		}

		return errors;
	},
	handleSubmit: (values, props) => {
		// Close the widget
		closeWidget();

		// Get the screenshot and send the email
		html2canvas(document.body).then((canvas) => {
			const { quote } = props.props;

			// Figure out who to send to
			const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));
			let emailTo = ['servicedesk@colinsgrp.com'];
			let ccTo = ['webdev@colinsgrp.com', 'ahargis@colinsgrp.com'];
			if (values.contactType === 'Make a Suggestion') {
				emailTo = ['touchpoint@colinsgrp.com', 'webdev@colinsgrp.com'];
				ccTo = [];
			} else if (values.contactType === 'Ask my Underwriter') {
				emailTo = [agent.underwriterEmail];
				ccTo = ['webdev@colinsgrp.com', 'tgechter@colinsgrp.com'];
			}

			// Complete the body of the email
			const emailBody = `<div style="font-family: Arial"><b>Contact received through website widget - ${
				values.contactType
			}</b><br/>&nbsp;<table><tr><td style="padding-right: 2em;font-family: Arial;font-weight: bold;">San:</td><td style="font-family: Arial">${
				quote.sfg && quote.sfg.san ? quote.sfg.san : ''
			}</td></tr><tr><td style="padding-right: 2em;font-family: Arial;font-weight: bold;">Contact Name:</td><td style="font-family: Arial">${
				values.feedback_person
			}</td></tr><tr><td style="padding-right: 2em;font-family: Arial;font-weight: bold;">Contact Email:</td><td style="font-family: Arial"><a href="mailto:${
				values.feedback_email
			}">${
				values.feedback_email
			}</a></td></tr><tr><td style="padding-right: 2em;font-family: Arial;font-weight: bold;">Comments:</td><td style="font-family: Arial">${
				values.feedback_text
			}</td></tr><tr><td style="padding-right: 2em;font-family: Arial;font-weight: bold;">Insured Name:</td><td style="font-family: Arial">${getFullInsuredName(
				quote,
			)}</td></tr><tr><td style="padding-right: 2em;font-family: Arial;font-weight: bold;">Quote ID:</td><td style="font-family: Arial">${
				quote.id
			}</td></tr><tr><td style="padding-right: 2em;font-family: Arial;font-weight: bold;">Underwriter:</td><td style="font-family: Arial">${
				agent.underwriterName
			}</td></tr><tr><td style="padding-right: 2em;font-family: Arial;font-weight: bold;">User:</td><td style="font-family: Arial">${
				agent.userId
			}</td></tr><tr><td style="padding-right: 2em;font-family: Arial;font-weight: bold;">Path:</td><td style="font-family: Arial">${
				document.location.pathname
			}</td></tr></table></div>`;

			const feedbackEmail = {
				to: emailTo.join(';'),
				cc: ccTo.join(';'),
				subject: `TouchPoint Contact - ${values.contactType}`,
				message: emailBody,
				attachments: [
					{
						s3Bucket: process.env.REACT_APP_DOCUMENT_BUCKET,
						fileName: `screen-${Date.now()}.png`,
						contentType: 'image/png',
						attachmentBase64: canvas.toDataURL(),
					},
				],
			};

			http
				.post(process.env.REACT_APP_EMAIL_PATH, feedbackEmail)
				.then((response) => {
					if (response.status === 200) {
						props.resetForm();
						toast.success('Message sent, thank you!');
					} else {
						toast.error('Message failed to send');
					}
				})
				.catch((error) => {
					toast.error('Message failed to send');
				});
		});
	},
})(FeedbackFields);

export default Feedback;
