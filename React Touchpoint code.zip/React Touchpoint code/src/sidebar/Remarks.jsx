import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { SubmitButton } from 'components/shared/buttons/SubmitButton';
import { DataDisplay } from 'components/shared/form/DataDisplay';
import { InputTextArea } from 'components/shared/form/inputs/InputTextArea';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { useContext, useEffect } from 'react';
import { isBlank } from 'utils/StringFunctions';

const Remarks = (props) => {
	const context = useContext(QuoteContext);
	const { quote } = context;
	let formProps;
	let dirty;

	useEffect(() => {
		if (isBlank(_.get(formProps, 'values.businessDescription'))) {
			_.forIn(_.get(quote, 'sfg.locations', {}), (location) => {
				if (location.order === 1) {
					formProps.setFieldValue('businessDescription', _.get(location, 'prefillData.verisk.businessDescription'));
				}
			});
		}
	}, []);

	const getPrefillToolTips = () => {
		const noCallVeriskMessage = 'Verisk has never been called.';
		const noReturnVeriskMessage = 'The Verisk call returned no data.';

		let prefillObject = {
			businessDescription: noCallVeriskMessage,
		};

		const locations = _.get(quote, 'sfg.locations', {});

		if (!isBlank(locations)) {
			const location = _.find(locations, (locationObject) => {
				return locationObject.order === 1;
			});
			if (_.has(location, 'prefillData.verisk')) {
				prefillObject.businessDescription = isBlank(location.prefillData.verisk.businessDescription)
					? noReturnVeriskMessage
					: location.prefillData.verisk.businessDescription;
			}
		}

		return prefillObject;
	};

	const prefillToolTips = getPrefillToolTips();

	return (
		<Formik
			render={(formikProps) => {
				formProps = formikProps;
				dirty = formikProps.dirty;
				return (
					<Form>
						{formikProps.values.businessDescription && (
							<PageSection title='Business Description'>
								<Field name='businessDescription' component={DataDisplay} />
							</PageSection>
						)}
						<PageSection title='Add Remark'>
							<Field
								name='remarks'
								component={InputTextArea}
								rows={20}
								width='medium'
								prefillHoverMessage={'Business Description: ' + prefillToolTips.businessDescription}
							/>
						</PageSection>
						<SubmitButton content='Save' />
						<SimpleButton
							primary
							content='Cancel'
							onClick={() => {
								this.props.closeSidebar();
							}}
						/>
					</Form>
				);
			}}
			initialValues={{
				remarks: _.get(quote, 'remarks', ''),
				businessDescription: _.get(quote, 'businessDescription'),
			}}
			onSubmit={(values, formikActions) => {
				if (dirty) {
					context.savePageValues(values);
				}
				props.closeSidebar();
			}}
			validate={(values) => {}}
		/>
	);
};

export default Remarks;
