import _ from 'lodash';
import QuoteContext from 'context/quoteContext';
import React from 'react';
import { displayQuoteNumber, isEmployee } from 'utils/BusinessFunctions';

export const QuoteInformation = () => (
	<QuoteContext.Consumer>
		{(context) => (
			<React.Fragment>
				<div id='quoteInformationList'>
					<div className='infoGroup'>
						<span className='infoItem'>Reference Number:</span>
						<span className='infoItem'>{_.get(context.quote, 'quoteNumber', '')}</span>
					</div>
					{isEmployee && (
						<div className='infoGroup'>
							<span className='infoItem'>Database ID:</span>
							<span className='infoItem'>{_.get(context.quote, 'id', 'N/A')}</span>
						</div>
					)}
					<div className='infoGroup'>
						<span className='infoItem'>Safeguard Quote Number:</span>
						<span className='infoItem'>{displayQuoteNumber(context.quote, 'BPP')}</span>
						<span className='infoItem'>Safeguard SAN:</span>
						<span className='infoItem'>{_.get(context.quote, 'sfg.san', 'Not rated yet')}</span>
					</div>
					{_.includes(context.quote.products, 'cap') && (
						<div className='infoGroup'>
							<span className='infoItem'>Commercial Auto Quote Number:</span>
							<span className='infoItem'>{displayQuoteNumber(context.quote, 'CAP')}</span>
							<span className='infoItem'>Commercial Auto SAN:</span>
							<span className='infoItem'>{_.get(context.quote, 'cap.san', 'Not rated yet')}</span>
						</div>
					)}
					{_.includes(context.quote.products, 'wcp') && (
						<div className='infoGroup'>
							<span className='infoItem'>Workers Compensation Quote Number:</span>
							<span className='infoItem'>{displayQuoteNumber(context.quote, 'WCP')}</span>
							<span className='infoItem'>Workers Compensation SAN:</span>
							<span className='infoItem'>{_.get(context.quote, 'wcp.san', 'Not rated yet')}</span>
						</div>
					)}
					{_.includes(context.quote.products, 'cup') && (
						<div className='infoGroup'>
							<span className='infoItem'>Commercial Umbrella Quote Number:</span>
							<span className='infoItem'>{displayQuoteNumber(context.quote, 'CUP')}</span>
							<span className='infoItem'>Commercial Umbrella SAN:</span>
							<span className='infoItem'>{_.get(context.quote, 'cup.san', 'Not rated yet')}</span>
						</div>
					)}
				</div>
			</React.Fragment>
		)}
	</QuoteContext.Consumer>
);

export default QuoteInformation;
