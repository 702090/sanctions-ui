import buildingQuestionsJson from 'data/BuildingQuestions';
import capQuestionJson from 'data/capPolicyQuestions';
import productNamesJson from 'data/ProductNames';
import referralMessagesJson from 'data/ReferralMessages';
import sfgQuestionsJson from 'data/sfgPolicyQuestions';
import wcpQuestionsJson from 'data/wcpPolicyQuestions';
import _ from 'lodash';
import React from 'react';
import { calculateCDLQ } from 'utils/BusinessFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import { isBlank } from 'utils/StringFunctions';
import { isUUID } from 'validator';

const { questions } = buildingQuestionsJson;
const { capQuestions } = capQuestionJson;
const { sfgQuestions } = sfgQuestionsJson;
const { wcpQuestions } = wcpQuestionsJson;
const { productNames } = productNamesJson;
const { messages } = referralMessagesJson;

export const ReferralList = ({ quote, products, generateHTML }) => {
	let prodList = [];
	if (!products) {
		prodList = ['tp', 'sfg', 'cap', 'wcp', 'cup'];
	} else {
		prodList = products;
	}
	let flattenedReferralCodes = { tp: [], sfg: [], cap: [], wcp: [], cup: [] };
	parse(quote, quote.referrals, flattenedReferralCodes, {});

	let output = [];
	if (_.get(quote, 'underwriterReferralOverride', false)) {
		output.push(<div>Referrals Approved By: {_.get(quote, 'transactionData.uroChangedBy')}</div>);
	}
	prodList.forEach((prod) => {
		if (!isBlank(flattenedReferralCodes[prod])) {
			if (generateHTML) {
				if (!products) {
					output.push(<h5 key={prod + 'ReferralHead'}>{productNames[prod]} Referrals</h5>);
				}
				output.push(getReferralHTML(flattenedReferralCodes[prod], prod, quote));
			} else {
				output = _.concat(output, getReferralMessage(flattenedReferralCodes[prod], quote));
			}
		}
	});

	if (isBlank(output) && generateHTML) {
		output.push(<h5 key='ReferralHead'>There are no referrals.</h5>);
		output.push(<i className='fad fa-thumbs-up ok huge'></i>);
	}

	return output;
};

export const getReferralMessage = (referrals, quote, html) => {
	const cdlqReferrals = calculateCDLQ(quote);
	let spc05 = [];
	let spc06 = [];
	let spc07 = [];

	_.forIn(cdlqReferrals, (val, id) => {
		switch (val) {
			case 'SPC05':
				spc05.push(
					// <React.Fragment key={`spc05${id}`}>
					' Location ' + _.get(quote, `sfg.locations.${id}.order`),
					// </React.Fragment>,
				);
				break;
			case 'SPC06':
				spc06.push(
					// <React.Fragment key={`spc05${id}`}>
					' Location ' + _.get(quote, `sfg.locations.${id}.order`),
					// </React.Fragment>,
				);
				break;
			case 'SPC07':
				spc07.push(
					// <React.Fragment key={`spc05${id}`}>
					' Location ' + _.get(quote, `sfg.locations.${id}.order`),
					// </React.Fragment>,
				);
				break;

			default:
				break;
		}
	});

	const messageList = _.sortBy(referrals, ['idLabel', 'subIdLabel']).map((referral) => {
		let messageText = '';
		let referralTarget;
		if (referral.idLabel) {
			referralTarget = referral.idLabel + (referral.subIdLabel ? ', ' + referral.subIdLabel : '');
		}

		if (referral.qText) {
			messageText += referral.qText;
		} else {
			messageText += messages[referral.referral];
		}

		switch (referral.referral) {
			case 'SPC05':
				messageText += ' for: ' + spc05;
				break;
			case 'SPC06':
				messageText += ' for: ' + spc06;
				break;
			case 'SPC07':
				messageText += ' for: ' + spc07;
				break;
			default:
				break;
		}

		if (html) {
			return {
				referralTarget,
				messageText,
				key:
					(referral.id ? referral.id : '') +
					(referral.subId ? referral.subId : '') +
					(referral.qNum ? referral.qNum : '') +
					referral.referral,
			};
		} else {
			return {
				key: referral.referral,
				message: (referralTarget ? referralTarget + ': ' : '') + messageText,
			};
		}
	});

	return messageList;
};

const getReferralHTML = (referrals, type, quote) => {
	const referralMessages = getReferralMessage(referrals, quote, true);

	return (
		<ul key={type + 'Referrals'}>
			{referralMessages.map((referral) => {
				return (
					<li key={referral.key}>
						{referral.referralTarget && <span className='referralTarget'>{referral.referralTarget}</span>}
						{referral.messageText}
					</li>
				);
			})}
		</ul>
	);
};

function parse(quote, referrals, output, refObj) {
	_.forIn(referrals, (referral, fieldName) => {
		if (isUUID(fieldName)) {
			if (refObj.id) {
				refObj.subId = fieldName;
			} else {
				refObj.id = fieldName;
			}
		}
		if (_.startsWith(fieldName, 'q') && !isNaN(_.toNumber(fieldName.substring(1)))) {
			refObj.qNum = fieldName;
		}
		if (_.isArray(referral)) {
			//add to list
			let refObjCopy = {};
			referral.forEach((refCode) => {
				refObjCopy = duplicate(refObj);
				refObjCopy.referral = refCode;
				updateObj(quote, refCode, refObjCopy);
				output[getProd(refCode)].push(refObjCopy);
			});
		} else {
			if (!isBlank(referral)) {
				//recurse
				parse(quote, referral, output, refObj);
			}
		}
		if (refObj.subId) {
			_.unset(refObj, 'subId');
		} else {
			if (refObj.id) {
				_.unset(refObj, 'id');
			} else {
				refObj = {};
			}
		}
	});
}

function getProd(refCode) {
	switch (refCode.substring(0, 1)) {
		case 'T':
			return 'tp';
		case 'S':
			return 'sfg';
		case 'C':
			return 'cap';
		case 'W':
			return 'wcp';
		case 'U':
			return 'cup';
		default:
	}
}
function updateObj(quote, refCode, refObj) {
	let id = '';
	let subId = '';
	switch (refCode.substring(0, 3)) {
		case 'SBQ':
			refObj.qText = `Please submit unbound due to the answer to the question: "${questions[refObj.qNum].qt}"`;
		// Fall through
		case 'SLB':
		case 'SBC':
			refObj.subIdLabel = 'Building ' + _.get(quote, `sfg.locations.${refObj.id}.buildings.${refObj.subId}.order`);
		// Fall through
		case 'SLL':
			refObj.idLabel = 'Location ' + _.get(quote, `sfg.locations.${refObj.id}.order`);
			break;
		case 'CVV':
			refObj.idLabel = 'Vehicle ' + (_.get(quote, `cap.vehicles.${refObj.id}.order`) + 1);
			break;
		case 'WCC':
			refObj.idLabel = 'Class Code ' + _.get(quote, `wcp.classCodes.${refObj.id}.classCode`).trim();
			break;
		case 'SPQ':
			const possibleQuestions = _.merge(duplicate(sfgQuestions), duplicate(wcpQuestions), duplicate(capQuestions));
			refObj.qText = `Please submit unbound due to the answer to the question: "${possibleQuestions[refObj.qNum].qt}"`;
			break;
		default:
	}
	return { id: id, subId: subId };
}
