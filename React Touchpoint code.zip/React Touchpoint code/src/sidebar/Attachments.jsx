import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { toSortedPairList } from 'components/shared/navigation/NavigationFunctions';
import QuoteContext from 'context/quoteContext';
import { Form, Formik } from 'formik';
import React, { Component } from 'react';
import { deleteFile, downloadFile, uploadFile } from 'utils/FileFunctions';

export default class AttachmentsForm extends Component {
	static contextType = QuoteContext;

	render() {
		const { quote } = this.context;
		return (
			<React.Fragment>
				<Formik
					render={(formikProps) => (
						<Form>
							<input type='file' id='file' className='fileInput' onChange={(e) => uploadFile(e, this.context)} />
							<label htmlFor='file'>Choose a file</label>
							<div id='attachmentList'>
								{toSortedPairList(quote.attachments, 'name').map((attachment) => (
									<div className='attachment' key={attachment[0]}>
										<span className='attachmentText' onClick={(e) => downloadFile(attachment[0], this.context)}>
											{attachment[1].name}
										</span>
										<SimpleButton
											className='delete'
											content=''
											onClick={(e) => deleteFile(attachment[0], this.context)}
											id={attachment[0]}
											icon='delete'
										/>
									</div>
								))}
							</div>
						</Form>
					)}
					initialValues={{}}
					onSubmit={() => {
						// This needs to stay here so the form doesn't submit
					}}
				/>
			</React.Fragment>
		);
	}
}
