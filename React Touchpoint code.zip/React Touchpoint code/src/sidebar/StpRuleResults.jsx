import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import QuoteContext from 'context/quoteContext';
import productNamesJson from 'data/ProductNames';
import _ from 'lodash';
import React, { useContext, useEffect } from 'react';
import { mvrRecord } from 'services/issueService';
import { saveQuote } from 'services/quoteService';
import { allowSTP } from 'services/ruleService';
import { isBlank } from 'utils/StringFunctions';

const { productNames } = productNamesJson;

const getMvrReport = async (quote, errorMessages) => {
	const mvrReport = await mvrRecord(_.get(quote, 'cap.san', ''));
	if (mvrReport.mvrRetrieved) {
		const mvrReportDrivers = mvrReport.drivers;
		const capDrivers = _.get(quote, 'cap.drivers', {});

		_.forEach(mvrReportDrivers, (driver) => {
			const qDriver = _.find(capDrivers, (quoteDriver) => {
				return quoteDriver.licenseNumber === driver.licenseNumber;
			});
			if (qDriver) {
				qDriver.mvrData = driver.mvrData;
			}
		});
	} else {
		// TODO: Something blew up and we need to notify someone
		console.error('mvrReport', mvrReport);
	}
};

function getFullName(name) {
	return `${name.first ? name.first : ''}${name.middle ? ' ' + name.middle : ''}${name.last ? ' ' + name.last : ''}`;
}

function callRules(context, props) {
	const quote = _.get(context, 'quote', {});

	allowSTP(quote)
		.then((ruleResult) => {
			quote.stpResults = ruleResult.messages;
			context.updateQuote(quote, props);
		})
		.catch((err) => {
			console.error('Error', err);
		});
}

function getMessage(quote, val) {
	let finalMessage;
	const { product, objectId, message } = val;
	switch (product) {
		case 'sfg':
			if (objectId === quote.id) {
				finalMessage = message;
			} else {
				_.forEach(_.get(quote, 'sfg.locations'), (loc, locId) => {
					if (locId === objectId) {
						finalMessage = `Location ${loc.order} - ` + message;
					}
					_.forEach(loc.buildings, (bldg, bldgId) => {
						if (bldgId === objectId) {
							finalMessage = `Location ${loc.order} Building ${bldg.order} - ` + message;
						}
					});
				});
			}

			break;

		case 'cap':
			if (objectId === quote.id) {
				finalMessage = message;
			} else {
				_.forEach(_.get(quote, 'cap.vehicles'), (vehicle, vehicleId) => {
					const vehicleNumber = vehicle.order + 1;
					if (vehicleId === objectId) {
						finalMessage = `Vehicle ${vehicleNumber} - ` + message;
					}
				});
				_.forEach(_.get(quote, 'cap.drivers'), (driver, driverId) => {
					if (driverId === objectId) {
						finalMessage = `Driver ${getFullName(driver.name)} - ` + message;
					}
				});
			}
			break;

		default:
			finalMessage = message;
			break;
	}
	return finalMessage;
}

const StpRuleResults = (props) => {
	const context = useContext(QuoteContext);
	const { quote } = context;

	let stpResults = _.get(quote, 'stpResults', []);

	useEffect(() => {
		stpResults = _.get(quote, 'stpResults', []);
	}, [_.get(quote, 'stpResults', [])]);

	let accountResults = [];
	let sfgResults = [];
	let capResults = [];
	let wcpResults = [];
	let cupResults = [];

	_.forEach(stpResults, (val, key) => {
		switch (val.product) {
			case 'sfg':
				sfgResults.push(val);
				break;
			case 'cap':
				capResults.push(val);
				break;
			case 'wcp':
				wcpResults.push(val);
				break;
			case 'cup':
				cupResults.push(val);
				break;
			default:
				accountResults.push(val);
				break;
		}
	});

	if (isBlank(accountResults)) {
		return <div>No rules have been run</div>;
	} else {
		return (
			<React.Fragment>
				<SimpleButton onClick={() => callRules(context, props)} primary content='Run Rules Again' />
				<SimpleButton
					onClick={() => {
						getMvrReport(quote, props).then((result) => {
							saveQuote(quote);
							callRules(context, props);
						});
					}}
					primary
					content='Run MVR'
				/>
				<h1>Account Wide Rules</h1>
				{accountResults.map((val, key) => (
					<div key={key} className={val.block > 0 ? 'error' : ''}>
						{val.block > 0 ? <i className='fas fa-exclamation-triangle' /> : null}
						{getMessage(quote, val)}
					</div>
				))}
				<h1>
					<i className='far fa-shield-alt' alt={productNames.sfg} title={productNames.sfg} />
					{productNames.sfg} Rules
				</h1>
				{sfgResults.map((val, key) => (
					<div key={key} className={val.block > 0 ? 'error' : ''}>
						{val.block > 0 ? <i className='fas fa-exclamation-triangle' /> : null}
						{getMessage(quote, val)}
					</div>
				))}
				{!isBlank(capResults) ? (
					<h1>
						<i className='fas fa-truck-pickup' alt={productNames.cap} title={productNames.cap} />
						{productNames.cap} Rules
					</h1>
				) : null}
				{capResults.map((val, key) => (
					<div key={key} className={val.block > 0 ? 'error' : ''}>
						{val.block > 0 ? <i className='fas fa-exclamation-triangle' /> : null}
						{getMessage(quote, val)}
					</div>
				))}
				{!isBlank(wcpResults) ? (
					<h1>
						<i className='fas fa-user-hard-hat' alt={productNames.wcp} title={productNames.wcp} />
						{productNames.wcp} Rules
					</h1>
				) : null}
				{wcpResults.map((val, key) => (
					<div key={key} className={val.block > 0 ? 'error' : ''}>
						{val.block > 0 ? <i className='fas fa-exclamation-triangle' /> : null}
						{getMessage(quote, val)}
					</div>
				))}
				{!isBlank(cupResults) ? (
					<h1>
						<i className='fas fa-umbrella' alt={productNames.cup} title={productNames.cup} />
						{productNames.cup} Rules
					</h1>
				) : null}
				{cupResults.map((val, key) => (
					<div key={key} className={val.block > 0 ? 'error' : ''}>
						{val.block > 0 ? <i className='fas fa-exclamation-triangle' /> : null}
						{getMessage(quote, val)}
					</div>
				))}
			</React.Fragment>
		);
	}
};

export default StpRuleResults;
