import { CheckMark } from 'components/shared/navigation/CheckMark';
import QuoteContext from 'context/quoteContext';
import _ from 'lodash';
import React, { useContext, useState } from 'react';
import { toast } from 'react-toastify';

export const EditProducts = (props) => {
	const context = useContext(QuoteContext);
	const { quote, rate: rateState } = context;
	const [hasCap, setHasCap] = useState(quote.products ? quote.products.includes('cap') : undefined);
	const [hasCup, setHasCup] = useState(quote.products ? quote.products.includes('cup') : undefined);
	const [hasWcp, setHasWcp] = useState(quote.products ? quote.products.includes('wcp') : undefined);
	let toastMessage = '';

	const productEditAllowed = () => {
		if (props.location.pathname === '/quote/rate') {
			toastMessage = 'Please wait for all products to finish rating before adding/removing a product';

			return _.get(rateState, 'done', new Set()).size === _.get(quote, 'products', ['sfg']).length;
		} else if (props.location.pathname.includes('issue')) {
			toastMessage =
				'You cannot add or remove a product while in the issuing process. Please navigate away from the Issue section if you wish to add or remove a product.';
			return false;
		} else {
			return true;
		}
	};
	return (
		<div id='productSelect' className={`${props.newQuote ? '' : 'editProducts'}`}>
			<div id='productSelectSFG' className='active'>
				<i className='far fa-shield-alt' />
				<span>Safeguard</span>
				<div className='navIcon'>
					<CheckMark />
				</div>
			</div>
			<div
				id='productSelectCAP'
				className={hasCap ? 'active' : ''}
				onClick={() => {
					if (productEditAllowed()) {
						setHasCap(!hasCap);
						context.updateProducts('cap', !hasCap, props, props.newQuote, context);
					} else {
						toast.info(toastMessage);
					}
				}}
			>
				<i className='fas fa-truck-pickup' />
				<span>Commercial Auto</span>
				{hasCap && (
					<div className='navIcon'>
						<CheckMark />
					</div>
				)}
			</div>
			<div
				id='productSelectWCP'
				className={hasWcp ? 'active' : ''}
				onClick={() => {
					if (productEditAllowed()) {
						setHasWcp(!hasWcp);
						context.updateProducts('wcp', !hasWcp, props, props.newQuote, context);
					} else {
						toast.info(toastMessage);
					}
				}}
			>
				<i className='fas fa-user-hard-hat' />
				<span>Workers Compensation</span>
				{hasWcp && (
					<div className='navIcon'>
						<CheckMark />
					</div>
				)}
			</div>
			<div
				id='productSelectCUP'
				className={hasCup ? 'active' : ''}
				onClick={() => {
					if (productEditAllowed()) {
						setHasCup(!hasCup);
						context.updateProducts('cup', !hasCup, props, props.newQuote, context);
					} else {
						toast.info(toastMessage);
					}
				}}
			>
				<i className='fas fa-umbrella' />
				<span>Commercial Umbrella</span>
				{hasCup && (
					<div className='navIcon'>
						<CheckMark />
					</div>
				)}
			</div>
		</div>
	);
};

export default EditProducts;
