import { render } from '@testing-library/react';
import App from 'App';
import { BrowserRouter } from 'react-router-dom';

let assignMock = jest.fn();

delete window.location;
window.location = { assign: assignMock };

afterEach(() => {
	assignMock.mockClear();
});
it('renders without crashing', () => {
	sessionStorage.setItem('authorizationToken', 'abc');
	sessionStorage.setItem('authorizationRefresh', 'def');
	sessionStorage.setItem('cigToken', 'xyz');
	sessionStorage.setItem(
		'agentJSONObject',
		'{"writingStates":["AL","AR","GA","IL","IA","KS","KY","MS","MO","NE","OK","SD","TN","TX"],"appUnderwriterEmail":"MBROWNING@COLINSGRP.COM","isAllowBillableDownpayment":true,"city":"Columbia","territoryManagerEmail":"kwilliams@colinsgrp.com                                   ","underwriterAssistantPhoneNumber":"","isAllowAgencyBill":true,"branch":"01","underwriterEmail":"AHARGIS@COLINSGRP.COM","underwriterPhoneNumber":"573-777-4054","number":"55110","territoryManagerPhoneNumber":"","pinnacleAgent":"","street":"PO Box 618","agentSubpro":"55110-00001","state":"MO","email":"","zip":"65205","underwriterAssistantName":"Zellia Harris","appUnderwriterNumber":"98","appUnderwriterName":"Test Underwriter","underwriterAssistantEmail":"ZHARRIS@COLINSGRP.COM","userId":"vndbadepwar","token":"2eff6af5-aa1a-4d4e-afd5-ede446b69d85","isHasSweepAccount":true,"subpro":"00001","underwriterNumber":"99","territoryManagerNumber":"011","phone":"573-474-6193","underwriterName":"Annette Hargis","appUnderwriterPhoneNumber":"573-777-4051  ","name":"The Demo Agency 55110-1","territoryManagerName":"Kenya Williams","iss":"Columbia","exp":1668770738}',
	);
	sessionStorage.setItem(
		'agentToken',
		'eyJhbGciOiJIUzI1NiJ9.eyJ3cml0aW5nU3RhdGVzIjpbIkFMIiwiQVIiLCJHQSIsIklMIiwiSUEiLCJLUyIsIktZIiwiTVMiLCJNTyIsIk5FIiwiT0siLCJTRCIsIlROIiwiVFgiXSwiYXBwVW5kZXJ3cml0ZXJFbWFpbCI6Ik1CUk9XTklOR0BDT0xJTlNHUlAuQ09NIiwiaXNBbGxvd0JpbGxhYmxlRG93bnBheW1lbnQiOnRydWUsImNpdHkiOiJDb2x1bWJpYSIsInRlcnJpdG9yeU1hbmFnZXJFbWFpbCI6Imt3aWxsaWFtc0Bjb2xpbnNncnAuY29tICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAiLCJ1bmRlcndyaXRlckFzc2lzdGFudFBob25lTnVtYmVyIjoiIiwiaXNBbGxvd0FnZW5jeUJpbGwiOnRydWUsImJyYW5jaCI6IjAxIiwidW5kZXJ3cml0ZXJFbWFpbCI6IkFIQVJHSVNAQ09MSU5TR1JQLkNPTSIsInVuZGVyd3JpdGVyUGhvbmVOdW1iZXIiOiI1NzMtNzc3LTQwNTQiLCJudW1iZXIiOiI1NTExMCIsInRlcnJpdG9yeU1hbmFnZXJQaG9uZU51bWJlciI6IiIsInBpbm5hY2xlQWdlbnQiOiIiLCJzdHJlZXQiOiJQTyBCb3ggNjE4IiwiYWdlbnRTdWJwcm8iOiI1NTExMC0wMDAwMSIsInN0YXRlIjoiTU8iLCJlbWFpbCI6IiIsInppcCI6IjY1MjA1IiwidW5kZXJ3cml0ZXJBc3Npc3RhbnROYW1lIjoiWmVsbGlhIEhhcnJpcyIsImFwcFVuZGVyd3JpdGVyTnVtYmVyIjoiOTgiLCJhcHBVbmRlcndyaXRlck5hbWUiOiJUZXN0IFVuZGVyd3JpdGVyIiwidW5kZXJ3cml0ZXJBc3Npc3RhbnRFbWFpbCI6IlpIQVJSSVNAQ09MSU5TR1JQLkNPTSIsInVzZXJJZCI6InZuZGJhZGVwd2FyIiwidG9rZW4iOiIyZWZmNmFmNS1hYTFhLTRkNGUtYWZkNS1lZGU0NDZiNjlkODUiLCJpc0hhc1N3ZWVwQWNjb3VudCI6dHJ1ZSwic3VicHJvIjoiMDAwMDEiLCJ1bmRlcndyaXRlck51bWJlciI6Ijk5IiwidGVycml0b3J5TWFuYWdlck51bWJlciI6IjAxMSIsInBob25lIjoiNTczLTQ3NC02MTkzIiwidW5kZXJ3cml0ZXJOYW1lIjoiQW5uZXR0ZSBIYXJnaXMiLCJhcHBVbmRlcndyaXRlclBob25lTnVtYmVyIjoiNTczLTc3Ny00MDUxICAiLCJuYW1lIjoiVGhlIERlbW8gQWdlbmN5IDU1MTEwLTEiLCJ0ZXJyaXRvcnlNYW5hZ2VyTmFtZSI6IktlbnlhIFdpbGxpYW1zIiwiaXNzIjoiQ29sdW1iaWEiLCJleHAiOjE2Njg3NzA3Mzh9.4hO92VhGjSfV_rs0C4NYz448mwKPuprK6P1D5IdE4Xc',
	);
	render(
		<BrowserRouter>
			<App />
		</BrowserRouter>,
	);
});
