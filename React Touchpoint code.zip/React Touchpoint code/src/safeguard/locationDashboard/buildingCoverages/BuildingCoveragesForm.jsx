import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { Select } from 'components/shared/form/Select';
import { InformationMessage } from 'components/shared/messages/InformationMessage';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import classCodeListsJson from 'data/ClassCodeLists';
import selectOptionsJson from 'data/SelectOptions';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { Component } from 'react';
import { toast } from 'react-toastify';
import {
	ARmap,
	BXXPmap,
	CDGCmap,
	CDGKmap,
	CLmap,
	DEBRmap,
	FDmap,
	FLmap,
	HLMTmap,
	MSmap,
	OLAWmap,
	OPRPmap,
	RSENmap,
	SFGBuildingCoverage,
	SNmap,
	SPAPmap,
	USmap,
	VCNTmap,
	VPmap,
} from 'safeguard/locationDashboard/buildingCoverages/BuildingCoverages.jsx';
import BuildingCoveragesRules from 'safeguard/locationDashboard/buildingCoverages/BuildingCoveragesRules';
import { ModalNavButtons } from 'safeguard/locationDashboard/components/ModalNavButtons';
import { checkBuildingCoverages, coverageRollOffMessages, getBuildingCoverageList } from 'utils/BusinessFunctions';
import { getSet, duplicate } from 'utils/ObjectFunctions';
import { cleanValues, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { checkReferrals, validate } from 'validation/Validate';

let visibility = {};
let fieldVisibility = {
	'coverages.RSEN.higherSpoilageLimit': false,
};
const defaultCoverages = [];
const { sfg_buildingCoverages } = selectOptionsJson;
const { residentialCleaningAllowed } = classCodeListsJson;

export default class SafeguardBuildingCoveragesForm extends Component {
	static contextType = QuoteContext;

	dirty = false;

	state = {
		currentCoverages: new Set(),
		deletedCoverages: new Set(),
		newCoverageOptions: [],
		cov2: false,
		cov3: false,
		usLim1: false,
		usLim2: false,
		usLim3: false,
	};

	addressState = '';

	rulesOnLoad = false;

	coveragesWithoutFields = getSet(['APEN', 'CDLR', 'CDDL', 'MN', 'CDNO', 'RCLN']);

	coverageRollOffMessage = [];
	formRollOff = true;

	// add auto roll-ons
	rollOnDefaultCoverages(currentCoverages, classCode, deletedCoverages) {
		let validClassCode = '44071';
		if (classCode === validClassCode && !deletedCoverages.has('CDGC')) {
			currentCoverages.add('CDGC');
		}

		validClassCode = _.includes(residentialCleaningAllowed, classCode);
		if (validClassCode && !deletedCoverages.has('RCLN')) {
			currentCoverages.add('RCLN');
		}
		return currentCoverages;
	}

	UNSAFE_componentWillMount() {
		if (isBlank(this.state.newCoverageOptions)) {
			this.initializeBuilding(this.props.locationId, this.props.buildingId, this.props.building);
		}
		if (!this.props.newBuilding) {
			this.initializeBuilding(this.props.locationId, this.props.buildingId, this.props.building);
		}
	}

	componentDidMount() {
		// If the form is not empty, trigger validation
		runRulesOnLoad(this.formProps, this.formProps.initialValues, ['']);
	}

	componentWillUnmount() {
		visibility = {};
	}

	initializeBuilding = (locationId, buildingId, building) => {
		this.addressState = _.get(this.context, `quote.addresses.${locationId}.state`);
		const coverages = _.get(building, 'coverages', {});
		let quoteCurrentCoverages = _.get(coverages, 'currentCoverages', defaultCoverages);
		if (quoteCurrentCoverages instanceof Set) {
			quoteCurrentCoverages = [...quoteCurrentCoverages];
		} else if (quoteCurrentCoverages instanceof Object) {
			quoteCurrentCoverages = Object.values(quoteCurrentCoverages);
		}

		let currentCoverages = getSet(
			quoteCurrentCoverages.filter((coverage) =>
				checkBuildingCoverages(coverage, this.props.building, this.addressState),
			),
		);

		this.coverageRollOffMessage = coverageRollOffMessages({
			quoteCurrentCoverages,
			currentCoverages,
			navAction: 'Done',
		});

		let deletedCoverages = getSet(_.get(building, 'coverages.deletedCoverages', new Set()));

		_.set(
			this.context,
			`quote.sfg.locations.${this.props.locationId}.buildings.${this.props.buildingId}.coverages.deletedCoverages`,
			deletedCoverages,
		);

		const { newCoverageOptions, vis } = getBuildingCoverageList(currentCoverages, building, this.addressState);
		visibility = vis;
		this.updateFieldVisibilityRSEN(_.get(coverages, 'RSEN.spoilageLimit', 10000));
		this.updateFieldVisibilityUS();

		currentCoverages = this.rollOnDefaultCoverages(currentCoverages, building.classCode, deletedCoverages);

		_.set(
			this.context,
			`quote.sfg.locations.${this.props.locationId}.buildings.${this.props.buildingId}.coverages.currentCoverages`,
			currentCoverages,
		);

		this.setState({
			currentCoverages,
			newCoverageOptions,
			usLim1: !coverages || !coverages.US ? false : !isBlank(coverages.US.buildingLimit),
			usLim2: !coverages || !coverages.US ? false : !isBlank(coverages.US.bppLimit),
			usLim3: !coverages || !coverages.US ? false : !isBlank(coverages.US.limit),
			deletedCoverages,
		});
	};

	updateFieldVisibilityRSEN = (val) => {
		fieldVisibility = {
			...fieldVisibility,
			'coverages.RSEN.higherSpoilageLimit': false,
		};
		if (val > 10000) {
			fieldVisibility['coverages.RSEN.higherSpoilageLimit'] = true;
		}
	};

	updateFieldVisibilityUS = (val, name) => {
		this.setState({ [name]: !isBlank(val) });
	};

	setOLAWValues = (setFieldValue, coverages, testType) => {
		const cov2Blank = isBlank(coverages.OLAW.coverage2);
		const cov3Blank = isBlank(coverages.OLAW.coverage3);

		switch (testType) {
			case 'cov2':
				if (cov2Blank && cov3Blank) {
					setFieldValue('coverages.OLAW.coverage1', 'Y', false);
					setFieldValue('coverages.OLAW.coverageCombined', '', false);
				}
				break;
			default:
				break;
		}
	};

	removeCoverage = (coverageId, setFieldValue, hideToast) => {
		const { currentCoverages } = this.state;
		currentCoverages.delete(coverageId);
		const { deletedCoverages } = this.state;
		deletedCoverages.add(coverageId);

		setFieldValue('coverages.currentCoverages', currentCoverages, false);
		const { newCoverageOptions, vis } = getBuildingCoverageList(
			currentCoverages,
			this.props.building,
			this.addressState,
		);
		visibility = vis;

		this.setState({ currentCoverages, newCoverageOptions, deletedCoverages });

		if (!hideToast) {
			toast.success(`${_.find(sfg_buildingCoverages, (c) => coverageId === c.value).text} Removed!`);
		}
	};

	render() {
		const { locationId, newLocation, buildingId, newBuilding, building, callBack } = this.props;

		fieldVisibility['coverages.US.directDamage'] = this.state.usLim1 || this.state.usLim2;
		fieldVisibility['coverages.US.timeElement'] = this.state.usLim3;

		const { quote } = this.context;

		const coverages = _.get(building, 'coverages', {});

		return (
			<Formik
				render={(formikProps) => {
					this.formProps = formikProps;
					this.dirty = formikProps.dirty;
					cleanValues(formikProps.values, fieldVisibility);
					if (!this.rulesOnLoad) {
						formikProps.validateForm(formikProps.values);
						this.rulesOnLoad = true;
					}
					if (!isBlank(formikProps.values)) {
						checkReferrals(this.context, formikProps.values, BuildingCoveragesRules);
					}
					if (!isBlank(this.coverageRollOffMessage) && this.formRollOff) {
						formikProps.setFieldValue('coverages.currentCoverages', this.state.currentCoverages, false);
						this.formRollOff = false;
					}

					return (
						<Form id='screen'>
							{!isBlank(this.coverageRollOffMessage) &&
								this.coverageRollOffMessage.map((message) => (
									<InformationMessage key={message} message={message} fieldDisplay />
								))}
							<PageSection className='addCoverage'>
								<Field
									name='sfgBuildingCoverages'
									label='Add New Coverage'
									component={Select}
									options={this.state.newCoverageOptions}
									search
								/>
								<SimpleButton
									content='Add Coverage'
									primary
									onClick={() => {
										const data = formikProps.values.sfgBuildingCoverages || '';
										if (!isBlank(data)) {
											const { currentCoverages } = this.state;
											const newCoverageOptions = _.filter(
												this.state.newCoverageOptions,
												(coverage) => data !== coverage.value,
											);
											currentCoverages.add(data);
											_.set(formikProps, 'values.coverages.currentCoverages', currentCoverages);
											visibility[`coverages.${data}`] = true;
											if (this.coveragesWithoutFields.has(data)) {
												toast.success(`${_.find(sfg_buildingCoverages, (c) => data === c.value).text} Added!`);
											}
											this.setState({
												currentCoverages,
												newCoverageOptions,
												newCoverage: this.coveragesWithoutFields.has(data) ? '' : data,
											});
											formikProps.validateForm(formikProps.values);
											formikProps.values.sfgBuildingCoverages = '';
										}
									}}
								/>
							</PageSection>
							{sfg_buildingCoverages.map((coverage) => {
								let updateFields = () => {};
								if (coverage.value === 'RSEN') {
									updateFields = this.updateFieldVisibilityRSEN;
								}
								if (coverage.value === 'US') {
									updateFields = this.updateFieldVisibilityUS;
								}
								return (
									<SFGBuildingCoverage
										key={coverage.value}
										coverage={coverage}
										isAdded={this.state.currentCoverages.has(coverage.value)}
										setOLAWValues={this.setOLAWValues}
										removeCoverage={(coverageId, hideToast) =>
											this.removeCoverage(coverageId, formikProps.setFieldValue, hideToast)
										}
										visibility={fieldVisibility}
										updateFields={updateFields}
										locationId={locationId}
										buildingId={this.props.buildingId}
										coverages={coverages}
										isNewCoverage={this.state.newCoverage === coverage.value}
										formikProps={formikProps}
										resetNewCoverage={() => this.setState({ newCoverage: '' })}
										{...this.props}
									/>
								);
							})}
							<ModalNavButtons
								currentModal='safeguardBuildingCoverages'
								onClose={this.props.handleClose}
								locationId={locationId}
								newLocation={newLocation}
								buildingId={buildingId}
								newBuilding={newBuilding}
								building={_.merge(building, formikProps.values)}
								formikProps={formikProps}
								saveValues={() => this.context.onBldgCovgModalSubmit(formikProps.values, this.dirty, this.props)}
								callBack={callBack}
							/>
						</Form>
					);
				}}
				initialValues={{
					locationId,
					id: this.props.buildingId,
					coverages: {
						currentCoverages:
							coverages && coverages.currentCoverages
								? getSet(coverages.currentCoverages)
								: getSet(this.state.currentCoverages),
						deletedCoverages:
							coverages && coverages.deletedCoverages ? coverages.deletedCoverages : this.state.deletedCoverages,
						AR: ARmap(coverages),
						FL: FLmap(coverages),
						BXXP: BXXPmap(coverages),
						CL: CLmap(coverages),
						DEBR: DEBRmap(coverages),
						CDGK: CDGKmap(coverages),
						CDGC: CDGCmap(coverages),
						HLMT: HLMTmap(coverages),
						MS: MSmap(coverages),
						OLAW: OLAWmap(coverages),
						OPRP: OPRPmap(coverages),
						SN: SNmap(coverages),
						RSEN: RSENmap(coverages),
						SPAP: SPAPmap(coverages),
						FD: FDmap(coverages),
						US: USmap(coverages),
						VCNT: VCNTmap(coverages),
						VP: VPmap(coverages),
					},
				}}
				onSubmit={(values, formikActions) => {
					//* Visibility is blanking any nested fields and causing issues. We don't appear to be using it but will have to adjust if we do
					//* We are only using fieldVisibility
					cleanValues(values, fieldVisibility);
					this.context.onBldgCovgModalSubmit(values, this.dirty, this.props);
					formikActions.setSubmitting(false);
					this.props.handleClose();
				}}
				validate={(values) => {
					checkReferrals(this.context, values, BuildingCoveragesRules);
					const validResults = validate(
						values,
						BuildingCoveragesRules.rules(quote, values, fieldVisibility),
						duplicate(BuildingCoveragesRules.requiredStructure),
					);
					logPageErrors(validResults, this.formProps.touched, 'sfg');
					return validResults;
				}}
			/>
		);
	}
}
