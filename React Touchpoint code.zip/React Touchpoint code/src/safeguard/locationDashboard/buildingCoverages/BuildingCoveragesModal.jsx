import { ModalStepper } from 'components/shared/navigation/ModalStepper';
import QuoteContext from 'context/quoteContext';
import _ from 'lodash';
import React, { Component } from 'react';
import SafeguardBuildingCoveragesForm from 'safeguard/locationDashboard/buildingCoverages/BuildingCoveragesForm';
import { Modal } from 'semantic-ui-react';
import { pageAnalytics } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { replaceReferrals } from 'validation/RunReferrals';

export default class BuildingCoveragesModal extends Component {
	static contextType = QuoteContext;

	constructor() {
		super();
		this.state = {
			isOpen: false,
		}; // state to control the state of popup
		this.form = React.createRef();
	}

	handleOpen = (callBack, locationId, newLocation, buildingId, newBuilding, building) => {
		if (isBlank(buildingId)) {
			_.forIn(_.get(this.context, `quote.sfg.locations.${locationId}.buildings`, {}), (value, key) => {
				buildingId = key;
				building = value;
			});
		}
		this.setState({
			isOpen: true,
			callBack,
			locationId,
			newLocation,
			buildingId,
			newBuilding,
			building,
		});
		pageAnalytics(this.props.location.pathname + '/BuildingCoveragesModal', true);
	};

	handleClose = () => {
		this.setState({ isOpen: false });
		replaceReferrals(this.context);
		this.state.callBack();
		pageAnalytics(this.props.location.pathname);
	};

	render() {
		const { callBack, locationId, newLocation, buildingId, newBuilding, building } = this.state;
		return (
			<Modal
				closeIcon
				open={this.state.isOpen}
				closeOnDimmerClick={false}
				onClose={this.handleClose}
				className='banded'
			>
				<div id='colorBlock' className='bldg' />
				<ModalStepper
					currentModal='safeguardBuildingCoverages'
					handleClose={this.handleClose}
					locationId={locationId}
					newLocation={newLocation}
					buildingId={buildingId}
					newBuilding={newBuilding}
					building={building}
				/>
				<Modal.Content>
					<SafeguardBuildingCoveragesForm
						buildingId={buildingId}
						locationId={locationId}
						newLocation={newLocation}
						building={building}
						newBuilding={newBuilding}
						handleClose={this.handleClose}
						callBack={callBack}
						{...this.props}
					/>
				</Modal.Content>
			</Modal>
		);
	}
}
