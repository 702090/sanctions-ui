import { RemoveCoverageButton } from 'components/shared/buttons/RemoveCoverageButton';
import { DatePicker } from 'components/shared/form/DatePicker';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputText } from 'components/shared/form/inputs/InputText';
import { RadioButton } from 'components/shared/form/RadioButton';
import { Select } from 'components/shared/form/Select';
import { OptionalSection } from 'components/shared/sections/OptionalSection';
import { PageSection } from 'components/shared/sections/PageSection';
import selectOptionsJson from 'data/SelectOptions';
import { Field } from 'formik';
import _ from 'lodash';
import QuoteContext from 'context/quoteContext';
import React from 'react';
import { toast } from 'react-toastify';
import { isBlank } from 'utils/StringFunctions';

const {
	sfg_CDGC_limit,
	sfg_CDGK_classCode,
	sfg_CDGK_collDeductible,
	sfg_CDGK_collLimit,
	sfg_CDGK_compDeductible,
	sfg_CDGK_compLimit,
	sfg_CDGK_ratingBasis,
	sfg_FD_classCode,
	sfg_FD_coverageType,
	sfg_MS_occupancyType,
	sfg_RSEN_coverageType,
	sfg_RSEN_spoilageClass,
	sfg_US_overheadLinesDirectDamage,
	sfg_US_overheadLinesTimeElement,
	sfg_US_utilitySource,
} = selectOptionsJson;

function pickCoverage(
	coverage,
	predState,
	visibility,
	updateFields,
	coverages,
	setOLAWValues,
	setFieldValue,
	errors,
	touched,
	values,
) {
	let isOlAWCoverage2Disabled = false;
	let isOlAWCoverage3Disabled = false;
	let isOlAWCombinedDisabled = false;

	// determine which fields in OLAW will allow input
	// set fields based on props.coverage selection
	if (coverage.value === 'OLAW') {
		isOlAWCombinedDisabled = !isBlank(values.coverages.OLAW.coverage2) || !isBlank(values.coverages.OLAW.coverage3);
		isOlAWCoverage2Disabled = !isBlank(values.coverages.OLAW.combinedCoverage);
		isOlAWCoverage3Disabled = isOlAWCoverage2Disabled;
	}
	// ! Removed AI - Additional Insured props.coverage - not currently displayed
	// ! Removed GRNU - Green Updgrade by request

	switch (coverage.value) {
		// field options
		// limit - ibLimit
		// not showing up map behind scenes ?
		// OccTyp - ibOccType
		// RateNo - ibRateNo
		// OccClass - ibOccClass
		// ClassCode - ibClassCode
		// ClassDesc - ibClassDesc
		case 'AR':
			return (
				<div className='flexFields'>
					<Field
						name='coverages.AR.limit'
						label='Limit'
						width='small'
						component={InputNumber}
						type='currency'
						maxLength='13'
					/>
				</div>
			);
		// occupancyClass -  ibOccClass removed from page
		// damageToPremises - ibMisc18Info
		// broadenedDamage - ibMisc19Info
		// not displayed
		// class code - ibClassCode
		// class description - ibClassDesc
		// Occupancy Type -ibOccType
		// Rate No - ibRateNo
		case 'FL':
			return (
				<div className='flexFields'>
					<Field
						name='coverages.FL.damageToPremises'
						label='Damage to Premises Rented to You'
						width='small'
						component={InputNumber}
						type='currency'
					/>
				</div>
			);
		// limit - ibLimit
		// not displayed
		// secondaryProperty - ibMisc1Ind
		// Occupancy Type -ibOccType
		// Rate No - ibRateNo
		case 'BXXP':
			return (
				<div className='flexFields'>
					<Field
						name='coverages.BXXP.limit'
						label='Business Income from Dependent Property'
						width='small'
						component={InputNumber}
						type='currency'
						maxLength='7'
					/>
				</div>
			);
		// limit - ibLimit
		// limit2 - ibLimit2
		case 'CL':
			return (
				<div className='flexFields'>
					<OptionalSection
						name='group_CL_limits'
						errors={errors}
						touched={_.get(touched, 'coverages.CL.limit', false) || _.get(touched, 'coverages.CL.limit2', false)}
					>
						<Field
							name='coverages.CL.limit'
							label='Condo Assoc Loss Assessment Limit'
							width='small'
							component={InputNumber}
							type='currency'
							optional
							maxLength='9'
						/>
						<Field
							name='coverages.CL.limit2'
							label='Misc. Real Property Limit'
							width='small'
							component={InputNumber}
							type='currency'
							optional
							maxLength='9'
						/>
					</OptionalSection>
				</div>
			);
		// limit - ibLimit
		case 'DEBR':
			return (
				<div className='flexFields'>
					<Field
						name='coverages.DEBR.limit'
						label='Limit'
						width='small'
						component={InputNumber}
						type='currency'
						maxLength='11'
					/>
				</div>
			);
		// classCode - ibClassCode
		// compDeductibe - ibDedAmt
		// collDeductible - ibDedAmt3
		// compLimit - ibLimit
		// collLimit - iblimit3
		// ratingBasis - ibMisc1
		case 'CDGK':
			return (
				<div className='flexFields'>
					<Field
						name='coverages.CDGK.classCode'
						label='Class Code'
						width='small'
						component={RadioButton}
						options={sfg_CDGK_classCode}
					/>
					<Field
						name='coverages.CDGK.ratingBasis'
						label='Rating Basis'
						width='small'
						component={RadioButton}
						options={sfg_CDGK_ratingBasis}
					/>
					<Field
						name='coverages.CDGK.compLimit'
						label='Comprehensive Limit'
						width='small'
						component={Select}
						options={sfg_CDGK_compLimit}
					/>
					<Field
						name='coverages.CDGK.compDeductible'
						label='Comprehensive Deductible'
						width='small'
						component={RadioButton}
						options={sfg_CDGK_compDeductible}
					/>
					<Field
						name='coverages.CDGK.collLimit'
						label='Collision Limit'
						width='small'
						component={Select}
						options={sfg_CDGK_collLimit}
					/>
					<Field
						name='coverages.CDGK.collDeductible'
						label='Collision Deductible'
						width='small'
						component={RadioButton}
						options={sfg_CDGK_collDeductible}
					/>
				</div>
			);
		// limit - ibLimit
		case 'CDGC':
			return (
				<div className='flexFields'>
					<Field
						name='coverages.CDGC.limit'
						label='Occurrence Limit'
						width='small'
						component={RadioButton}
						options={sfg_CDGC_limit}
					/>
				</div>
			);
		// description - ibClassDesc40
		// limit2 - ibLimit2
		// limit3 - ibLimit3
		case 'HLMT':
			return (
				<div className='flexFields'>
					<Field
						name='coverages.HLMT.description'
						label='Description of Property'
						width='small'
						component={InputText}
					/>
					<OptionalSection
						name='group_HLMT_limits'
						errors={errors}
						touched={
							_.get(touched, 'coverages.HLMT.fursLimit', false) ||
							_.get(touched, 'coverages.HLMT.jewelryLimit', false) ||
							_.get(touched, 'coverages.HLMT.patternsLimit', false)
						}
					>
						<Field
							name='coverages.HLMT.fursLimit'
							label='Furs, etc. Sub-limit'
							width='small'
							component={InputNumber}
							type='currency'
							optional
							maxLength='11'
						/>
						<Field
							name='coverages.HLMT.jewelryLimit'
							label='Jewelry, etc. Sub-limit'
							width='small'
							component={InputNumber}
							type='currency'
							optional
							maxLength='11'
						/>
						<Field
							name='coverages.HLMT.patternsLimit'
							label='Patterns, etc. Sub-limit'
							width='small'
							component={InputNumber}
							type='currency'
							optional
							maxLength='11'
						/>
					</OptionalSection>
				</div>
			);
		// limit - ibLimit
		// insideLimit - ibLimit2
		// outsideLimit - ibLimit3
		// occupancyType - ibOccType
		case 'MS':
			return (
				<div className='flexFields'>
					<Field
						name='coverages.MS.occupancyType'
						label='Occupancy Type'
						width='small'
						component={RadioButton}
						options={sfg_MS_occupancyType}
					/>
					<OptionalSection
						name='group_MS_limits'
						errors={errors}
						touched={
							_.get(touched, 'coverages.MS.insideLimit', false) || _.get(touched, 'coverages.MS.outsideLimit', false)
						}
					>
						<Field
							name='coverages.MS.insideLimit'
							label='Inside Limit'
							width='small'
							component={InputNumber}
							type='currency'
							optional
							maxLength='7'
						/>
						<Field
							name='coverages.MS.outsideLimit'
							label='Outside Limit'
							width='small'
							component={InputNumber}
							type='currency'
							optional
							maxLength='7'
						/>
					</OptionalSection>
				</div>
			);
		// coverage1 - ibMisc6
		// coverage2 - iblimit2
		// coverage3 - ibLimit3
		// combinedCoverage - ibLimit4
		// businessIncome - ibMisc15Info
		// waitingPeriod - ibMisc19Info (now hardcoded to 0 in mapping)
		case 'OLAW':
			return (
				<div className='flexFields'>
					<Field
						name='coverages.OLAW.coverage1'
						label='Coverage 1 - Undamaged Bldg Cov'
						width='small'
						component={RadioButton}
						optional
					/>
					<Field
						name='coverages.OLAW.businessIncome'
						label='Business Income and Extra Expenses'
						width='small'
						component={RadioButton}
						optional
					/>
					<Field
						name='coverages.OLAW.coverage2'
						label='Coverage 2 - Demolition Cost Coverage'
						width='small'
						component={InputNumber}
						type='currency'
						optional
						additionalOnChange={() => setOLAWValues(setFieldValue, coverages, 'cov2')}
						maxLength='13'
						disabled={isOlAWCoverage2Disabled}
					/>
					<Field
						name='coverages.OLAW.coverage3'
						label='Coverage 3 - Increased Cost of Construction Coverage'
						width='small'
						component={InputNumber}
						optional
						type='currency'
						hoverMessage='Enter the total limit for Increased Cost of Construction Coverage including the $10,000 that is automatically included in the Coverage'
						maxLength='13'
						disabled={isOlAWCoverage3Disabled}
					/>
					<Field
						name='coverages.OLAW.combinedCoverage'
						label='Coverage 2 & 3 Combined'
						width='small'
						component={InputNumber}
						type='currency'
						optional
						maxLength='13'
						disabled={isOlAWCombinedDisabled}
						// fieldDisplay={visibility['coverages.OLAW.combinedCoverage']}
					/>
				</div>
			);
		// limit - ibLimit
		// not displayed
		// class code - ibClassCode
		// class description - ibClassDesc
		// Occupancy Type -ibOccType
		// Rate No - ibRateNo
		case 'OPRP':
			return (
				<div className='flexFields'>
					<Field
						name='coverages.OPRP.limit'
						label='Limit'
						width='small'
						component={InputNumber}
						type='currency'
						maxLength='11'
					/>
				</div>
			);
		// limit - ibLimit
		case 'SN':
			return (
				<div className='flexFields'>
					<Field
						name='coverages.SN.limit'
						label='Limit'
						width='small'
						component={InputNumber}
						type='currency'
						maxLength='11'
					/>
				</div>
			);
		// foodContaminationLimit - ibLimit
		// addtlAdvertisingExpense - ibLimit2
		// spoilageLimit - ibLimit3
		// classCode - ibClassCode
		// coverageType - ibType1
		// maintenanceAgreement - ibMisc1
		case 'RSEN':
			return (
				<div className='flexFields'>
					<Field
						name='coverages.RSEN.foodContaminationLimit'
						label='Food Contamination'
						width='small'
						component={InputNumber}
						type='currency'
						maxLength='17'
					/>
					<Field
						name='coverages.RSEN.addtlAdvertisingExpense'
						label='Additional Advertising Expense'
						width='small'
						component={InputNumber}
						type='currency'
						maxLength='17'
					/>
					<Field
						name='coverages.RSEN.spoilageLimit'
						label='Spoilage Limit'
						width='small'
						component={InputNumber}
						type='currency'
						maxLength='17'
						additionalOnChange={updateFields}
					/>
					<Field
						name='coverages.RSEN.spoilageClass'
						label='Spoilage Class'
						width='small'
						component={Select}
						options={sfg_RSEN_spoilageClass}
						fieldDisplay={visibility['coverages.RSEN.higherSpoilageLimit']}
					/>
					<Field
						name='coverages.RSEN.coverageType'
						label='Coverage Type'
						width='small'
						component={RadioButton}
						options={sfg_RSEN_coverageType}
						fieldDisplay={visibility['coverages.RSEN.higherSpoilageLimit']}
					/>
					<Field
						name='coverages.RSEN.maintenanceAgreement'
						label='Maintenance Agreement'
						width='small'
						component={RadioButton}
						fieldDisplay={visibility['coverages.RSEN.higherSpoilageLimit']}
					/>
				</div>
			);
		// limit - ibLimit
		case 'SPAP':
			return (
				<div className='flexFields'>
					<Field
						name='coverages.SPAP.limit'
						label='Limit'
						width='small'
						component={InputNumber}
						type='currency'
						maxLength='11'
					/>
				</div>
			);
		// classCode - ibClassCode
		//  deductibleAmount - ibDedAmt
		// coverageType - ibType1
		// maintenanceAgreement - ibMisc1
		// limit - ibLimit
		// description - ibClassDesc40
		case 'FD':
			// TODO Add spoilage PDF link for class code
			return (
				<div className='flexFields'>
					<Field
						name='coverages.FD.classCode'
						label='Class Code'
						width='small'
						component={Select}
						options={sfg_FD_classCode}
					/>
					<Field
						name='coverages.FD.deductibleAmount'
						label='Deductible Amount'
						width='tiny'
						component={InputNumber}
						type='currency'
						disabled
					/>
					<Field
						name='coverages.FD.coverageType'
						label='Coverage Type'
						width='small'
						component={RadioButton}
						options={sfg_FD_coverageType}
					/>
					<Field
						name='coverages.FD.maintenanceAgreement'
						label='Maintenance Agreement'
						width='small'
						component={RadioButton}
					/>
					<Field
						name='coverages.FD.limit'
						label='Limit'
						width='small'
						component={InputNumber}
						type='currency'
						maxLength='6'
					/>
					<Field
						name='coverages.FD.description'
						label='Description'
						width='small'
						component={InputText}
						optional
						maxLength='25'
					/>
				</div>
			);
		// buildingLimit - ibLimit
		// bppLimit - ibLimit3
		// powerSupplyDirectDamage - ibMisc1
		// waterSupplyDirectDamage - ibMisc2
		// communicationsDirectDamage - ibMisc3
		// overheadLinesDirectDamage - ibMisc4
		// utilitySource - ibType1
		// coverageType - ibType2
		// limit - ibLimit2
		// powerSupplyTimeElement - ibMisc5
		// waterSupplyTimeElement - ibMisc6
		// communicationsTimeElement - ibMisc7
		// overheadLinesTimeElement - ibMisc8
		// wasteWaterRemoval -ibMisc9
		case 'US':
			return (
				<React.Fragment>
					<PageSection title='Direct Damage' className='smallSection'>
						<div className='flexFields'>
							<OptionalSection
								name='group_US_limits'
								errors={errors}
								touched={
									_.get(touched, 'coverages.US.buildingLimit', false) || _.get(touched, 'coverages.US.bppLimit', false)
								}
							>
								<Field
									name='coverages.US.buildingLimit'
									label='Building Limit'
									width='small'
									component={InputNumber}
									type='currency'
									maxLength='9'
									optional
									additionalOnChange={(e) => updateFields(e, 'usLim1')}
								/>
								<Field
									name='coverages.US.bppLimit'
									label='BPP Limit'
									width='small'
									component={InputNumber}
									type='currency'
									maxLength='9'
									optional
									additionalOnChange={(e) => updateFields(e, 'usLim2')}
								/>
							</OptionalSection>
							<Field
								name='coverages.US.powerSupplyDirectDamage'
								label='Power Supply'
								width='small'
								component={RadioButton}
								maxLength='9'
								fieldDisplay={visibility['coverages.US.directDamage']}
							/>
							<Field
								name='coverages.US.waterSupplyDirectDamage'
								label='Water Supply'
								width='small'
								component={RadioButton}
								fieldDisplay={visibility['coverages.US.directDamage']}
							/>
							<Field
								name='coverages.US.communicationsDirectDamage'
								label='Communications'
								width='small'
								component={RadioButton}
								fieldDisplay={visibility['coverages.US.directDamage']}
							/>
							<Field
								name='coverages.US.overheadLinesDirectDamage'
								label='Overhead Lines'
								width='small'
								component={RadioButton}
								options={sfg_US_overheadLinesDirectDamage}
								optional
								fieldDisplay={visibility['coverages.US.directDamage']}
							/>
							<Field
								name='coverages.US.utilitySource'
								label='Utility Source'
								width='small'
								component={RadioButton}
								options={sfg_US_utilitySource}
								fieldDisplay={visibility['coverages.US.directDamage']}
							/>
							{/* <Field
              name='coverages.US.coverageType'
              label='Coverage Type'
              width='small'
              component={RadioButton}
              options={sfg_US_Coverage_Type}
              optional={true}
            /> */}
						</div>
					</PageSection>
					<PageSection title='Time Element' className='smallSection'>
						<div className='flexFields'>
							<Field
								name='coverages.US.limit'
								label='Limit'
								width='small'
								component={InputNumber}
								type='currency'
								maxLength='9'
								optional
								additionalOnChange={(e) => updateFields(e, 'usLim3')}
								className='inline'
							/>
							<Field
								name='coverages.US.powerSupplyTimeElement'
								label='Power Supply'
								width='small'
								component={RadioButton}
								fieldDisplay={visibility['coverages.US.timeElement']}
								className='inline'
							/>
							<Field
								name='coverages.US.waterSupplyTimeElement'
								label='Water Supply'
								width='small'
								component={RadioButton}
								fieldDisplay={visibility['coverages.US.timeElement']}
								className='inline'
							/>
							<Field
								name='coverages.US.communicationsTimeElement'
								label='Communications'
								width='small'
								component={RadioButton}
								fieldDisplay={visibility['coverages.US.timeElement']}
								className='inline'
							/>
							<Field
								name='coverages.US.overheadLinesTimeElement'
								label='Overhead Lines'
								width='small'
								component={RadioButton}
								options={sfg_US_overheadLinesTimeElement}
								optional
								fieldDisplay={visibility['coverages.US.timeElement']}
								className='inline'
							/>
							<Field
								name='coverages.US.wasteWaterRemoval'
								label='Wastewater Removal'
								width='small'
								component={RadioButton}
								fieldDisplay={visibility['coverages.US.timeElement']}
								className='inline'
							/>
						</div>
					</PageSection>
				</React.Fragment>
			);
		// dateFrom - ibVacancyFromDt
		// dateTo - ibVacancyToDt
		case 'VCNT':
			return (
				<div className='flexFields'>
					<Field name='coverages.VCNT.dateFrom' label='Date From' width='small' component={DatePicker} />
					<Field name='coverages.VCNT.dateTo' label='Date To' width='small' component={DatePicker} />
				</div>
			);
		// limit - ibLimit
		// not displayed
		// Occupancy Type -ibOccType
		// Rate No - ibRateNo
		case 'VP':
			return (
				<div className='flexFields'>
					<Field
						name='coverages.VP.limit'
						label='Limit'
						width='small'
						maxLength='11'
						component={InputNumber}
						type='currency'
					/>
				</div>
			);
		// no field options
		case 'APEN':
		case 'CDLR':
		case 'CDDL':
		case 'MN':
		case 'CDNO':
		case 'RCLN':
			return <React.Fragment>Added to policy.</React.Fragment>;
		default:
			return null;
	}
}

export const SFGBuildingCoverage = (props) => {
	const { touched, errors, setFormikState, setFieldValue } = props.formikProps;
	if (props.isAdded) {
		const coverageErrors = _.get(errors, `coverages.${props.coverage.value}`, {});
		const groupErrors = _.findKey(errors, (error, key) => _.startsWith(key, `group_${props.coverage.value}`));
		return (
			<QuoteContext.Consumer>
				{(context) => (
					<PageSection
						title={props.coverage.text}
						className='coverageSection'
						name={`section_${props.coverage.value}`}
						errors={errors}
						locationId={props.locationId}
						buildingId={props.buildingId}
						isNewCoverage={props.isNewCoverage}
						cancelAction={() => {
							props.resetNewCoverage();
							props.removeCoverage(props.coverage.value, true);
							props.formikProps.validateForm(props.formikProps.values);
						}}
						saveAction={() => {
							if (isBlank(coverageErrors) && isBlank(groupErrors)) {
								toast.success(`${props.coverage.text} Added!`);
								props.resetNewCoverage();
							} else {
								_.forIn(coverageErrors, (fieldError, fieldName) =>
									_.set(touched, `coverages.${props.coverage.value}.${fieldName}`, true),
								);
								setFormikState({ focusCoverage: props.coverage.value }); // this forces re-render
							}
							props.formikProps.validateForm(props.formikProps.values);
							context.onBldgCovgModalSubmit(props.formikProps.values, props.formikProps.dirty, props);
						}}
					>
						<RemoveCoverageButton
							onClick={(event) => {
								props.removeCoverage(props.coverage.value);
							}}
						/>
						<div className='coverageFields'>
							{pickCoverage(
								props.coverage,
								props.predState,
								props.visibility,
								props.updateFields,
								props.coverages,
								props.setOLAWValues,
								setFieldValue,
								errors,
								props.formikProps.touched,
								props.formikProps.values,
							)}
						</div>
					</PageSection>
				)}
			</QuoteContext.Consumer>
		);
	}
	return null;
};

// map coverages here

export const ARmap = (coverages) => ({
	limit: _.get(coverages, 'AR.limit', ''),
});

export const FLmap = (coverages) => ({
	damageToPremises: _.get(coverages, 'FL.damageToPremises', ''),
	broadenedDamage: _.get(coverages, 'FL.broadenedDamage', ''),
});

export const BXXPmap = (coverages) => ({
	limit: _.get(coverages, 'BXXP.limit', ''),
});

export const CLmap = (coverages) => ({
	limit: _.get(coverages, 'CL.limit', ''),
	limit2: _.get(coverages, 'CL.limit2', ''),
});

export const DEBRmap = (coverages) => ({
	limit: _.get(coverages, 'DEBR.limit', ''),
});

export const CDGKmap = (coverages) => ({
	classCode: _.get(coverages, 'CDGK.classCode', ''),
	ratingBasis: _.get(coverages, 'CDGK.ratingBasis', ''),
	compDeductible: _.get(coverages, 'CDGK.compDeductible', ''),
	compLimit: _.get(coverages, 'CDGK.compLimit', ''),
	collLimit: _.get(coverages, 'CDGK.collLimit', ''),
	collDeductible: _.get(coverages, 'CDGK.collDeductible', ''),
});

export const CDGCmap = (coverages) => ({
	limit: _.get(coverages, 'CDGC.limit', ''),
});

export const HLMTmap = (coverages) => ({
	description: _.get(coverages, 'HLMT.description', ''),
	fursLimit: _.get(coverages, 'HLMT.fursLimit', ''),
	jewelryLimit: _.get(coverages, 'HLMT.jewelryLimit', ''),
	patternsLimit: _.get(coverages, 'HLMT.patternsLimit', ''),
});

export const MSmap = (coverages) => ({
	occupancyType: _.get(coverages, 'MS.occupancyType', ''),
	insideLimit: _.get(coverages, 'MS.insideLimit', ''),
	outsideLimit: _.get(coverages, 'MS.outsideLimit', ''),
});

export const OLAWmap = (coverages) => ({
	coverage1: _.get(coverages, 'OLAW.coverage1', ''),
	coverage2: _.get(coverages, 'OLAW.coverage2', ''),
	coverage3: _.get(coverages, 'OLAW.coverage3', ''),
	combinedCoverage: _.get(coverages, 'OLAW.combinedCoverage', ''),
	businessIncome: _.get(coverages, 'OLAW.businessIncome', ''),
});

export const OPRPmap = (coverages) => ({
	limit: _.get(coverages, 'OPRP.limit', ''),
});

export const SNmap = (coverages) => ({
	limit: _.get(coverages, 'SN.limit', ''),
});

export const RSENmap = (coverages) => ({
	foodContaminationLimit: _.get(coverages, 'RSEN.foodContaminationLimit', '10000'),
	addtlAdvertisingExpense: _.get(coverages, 'RSEN.addtlAdvertisingExpense', '3000'),
	spoilageLimit: _.get(coverages, 'RSEN.spoilageLimit', '10000'),

	spoilageClass: _.get(coverages, 'RSEN.spoilageClass', ''),
	coverageType: _.get(coverages, 'RSEN.coverageType', ''),
	maintenanceAgreement: _.get(coverages, 'RSEN.maintenanceAgreement', ''),
});

export const SPAPmap = (coverages) => ({
	limit: _.get(coverages, 'SPAP.limit', ''),
});

export const FDmap = (coverages) => ({
	classCode: _.get(coverages, 'FD.classCode', ''),
	deductibleAmount: _.get(coverages, 'FD.deductibleAmount', '500'),
	coverageType: _.get(coverages, 'FD.coverageType', ''),
	maintenanceAgreement: _.get(coverages, 'FD.maintenanceAgreement', ''),
	limit: _.get(coverages, 'FD.limit', ''),
	description: _.get(coverages, 'FD.description', ''),
});

export const USmap = (coverages) => ({
	buildingLimit: _.get(coverages, 'US.buildingLimit', ''),
	bppLimit: _.get(coverages, 'US.bppLimit', ''),
	powerSupplyDirectDamage: _.get(coverages, 'US.powerSupplyDirectDamage', ''),
	waterSupplyDirectDamage: _.get(coverages, 'US.waterSupplyDirectDamage', ''),
	communicationsDirectDamage: _.get(coverages, 'US.communicationsDirectDamage', ''),
	overheadLinesDirectDamage: _.get(coverages, 'US.overheadLinesDirectDamage', ''),
	utilitySource: _.get(coverages, 'US.utilitySource', ''),
	coverageType: _.get(coverages, 'US.coverageType', ''),
	limit: _.get(coverages, 'US.limit', ''),
	powerSupplyTimeElement: _.get(coverages, 'US.powerSupplyTimeElement', ''),
	waterSupplyTimeElement: _.get(coverages, 'US.waterSupplyTimeElement', ''),
	communicationsTimeElement: _.get(coverages, 'US.communicationsTimeElement', ''),
	overheadLinesTimeElement: _.get(coverages, 'US.overheadLinesTimeElement', ''),
	wasteWaterRemoval: _.get(coverages, 'US.wasteWaterRemoval', ''),
});

export const VCNTmap = (coverages) => ({
	dateFrom: _.get(coverages, 'VCNT.dateFrom', ''),
	dateTo: _.get(coverages, 'VCNT.dateTo', ''),
});

export const VPmap = (coverages) => ({
	limit: _.get(coverages, 'VP.limit', ''),
});
