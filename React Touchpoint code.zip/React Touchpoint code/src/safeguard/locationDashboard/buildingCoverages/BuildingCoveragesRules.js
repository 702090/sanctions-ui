import { requiredQuestionMessage } from 'data/FieldVisibility';
import _ from 'lodash';
import { daysFromDate, formatDateObject, isValidDate, toDate } from 'utils/DateFunctions';
import { getSet } from 'utils/ObjectFunctions';
import { isBlank, isBlankZ } from 'utils/StringFunctions';

export default class BuildingCoveragesRules {
	static requiredStructure = {
		section_CDLR: '',
		section_OLAW: '',
		section_RSEN: '',
		section_FD: '',
		section_VCNT: '',
		section_SPAP: '',
		group_US_limits: '',
		group_FL_damage: '',
		group_CL_limits: '',
		group_HLMT_limits: '',
		group_MS_limits: '',
		coverages: {
			AR: {
				limit: '',
			},
			FL: {
				damageToPremises: '',
			},
			BXXP: {
				limit: '',
			},
			CL: {
				limit: '',
			},
			DEBR: {
				limit: '',
			},
			CDGK: {
				classCode: '',
				ratingBasis: '',
				compLimit: '',
				compDeductible: '',
				collLimit: '',
				collDeductible: '',
				extraTesting: '',
			},
			CDGC: {
				limit: '',
			},
			HLMT: {
				description: '',
				fursLimit: 0,
				jewelryLimit: 0,
				patternsLimit: 0,
			},
			OLAW: {
				coverage1: '',
				coverage2: '',
				coverage3: '',
				combinedCoverage: '',
				businessIncome: '',
			},
			MS: {
				occupancyType: '',
				insideLimit: '',
				outsideLimit: '',
			},
			OPRP: {
				limit: '',
			},
			SN: {
				limit: '',
			},
			RSEN: {
				foodContaminationLimit: '',
				addtlAdvertisingExpense: '',
				spoilageLimit: '',
				spoilageClass: '',
				coverageType: '',
				maintenanceAgreement: '',
			},
			SPAP: {
				limit: '',
			},
			FD: {
				classCode: '',
				coverageType: '',
				maintenanceAgreement: '',
				limit: '',
			},
			VP: {
				limit: '',
			},
			VCNT: {
				dateFrom: '',
				dateTo: '',
			},
			US: {
				buildingLimit: '',
				bppLimit: '',
				powerSupplyDirectDamage: '',
				waterSupplyDirectDamage: '',
				communicationsDirectDamage: '',
				overheadLinesDirectDamage: '',
				utilitySource: '',
				coverageType: '',
				limit: '',
				powerSupplyTimeElement: '',
				waterSupplyTimeElement: '',
				communicationsTimeElement: '',
				overheadLinesTimeElement: '',
				wasteWaterRemoval: '',
			},
		},
	};

	//TODO when CAP added - If policy doesn't have CAP in quote and is auto risk (occtyp A) must have Hired or Non Owned coverage (HIRE,NOWN) not sure if both or just one. Double check

	static rules(quote, values, visibility) {
		//use values for current page validation
		//use quote for external page validation

		//spected was sometimes dying if quote.sfg.coverages.currentCoverages was not passing as a set
		let sfgCoverages = _.get(values, 'sfg.coverages.currentCoverages', new Set([]));

		if (!(sfgCoverages instanceof Set)) {
			sfgCoverages = getSet(sfgCoverages);
		}

		let eitherUSLimitSet = false;

		if (values.coverages.currentCoverages.has('US')) {
			eitherUSLimitSet = !isBlank(values.coverages.US.buildingLimit) || !isBlank(values.coverages.US.bppLimit);
		}

		let expdte = toDate(quote.effectiveDate);
		expdte.setFullYear(expdte.getFullYear() + 1);
		expdte = formatDateObject(expdte);

		const currentBppLimit = _.toNumber(
			_.get(quote, `sfg.locations.${values.locationId}.buildings.${values.id}.bppLimit`, 0),
		);

		return {
			section_OLAW: [
				[
					(value) =>
						!values.coverages.currentCoverages.has('OLAW') ||
						!isBlank(values.coverages.OLAW.coverage1) ||
						!isBlank(values.coverages.OLAW.coverage2) ||
						!isBlank(values.coverages.OLAW.coverage3) ||
						!isBlank(values.coverages.OLAW.combinedCoverage),
					'You have to select a coverage',
				],
				[
					(value) =>
						!values.coverages.currentCoverages.has('OLAW') ||
						values.coverages.OLAW.coverage1 !== 'N' ||
						values.coverages.OLAW.businessIncome !== 'N',
					'Please select either Coverage 1-Undamaged Building Coverage or Business Income and Extra Expenses or remove this coverage from the quote.',
				],
			],
			section_RSEN: [
				[
					(value) => !(values.coverages.currentCoverages.has('RSEN') && values.coverages.currentCoverages.has('FD')),
					'Risk cannot have both Restaurant Enhancement Endorsement and Spoilage Coverage.',
				],
				[
					(value) => !(values.coverages.currentCoverages.has('RSEN') && sfgCoverages.has('FDCO')),
					'Risk cannot have both building level Restaurant Enhancement Endorsement and policy level Food Contamination coverage.',
				],
			],
			section_FD: [
				[
					(value) => !(values.coverages.currentCoverages.has('FD') && values.coverages.currentCoverages.has('RSEN')),
					'Risk cannot have both Restaurant Enhancement Endorsement and Spoilage Coverage.',
				],
			],
			section_SPAP: [
				[
					(value) =>
						!values.coverages.currentCoverages.has('SPAP') ||
						(values.coverages.currentCoverages.has('SPAP') && currentBppLimit > 0),
					'Specified BPP Temp Away from Premises Coverage is not available if there is no Business Personal Property.  Please either remove this coverage or add a Business Personal Property Limit.',
				],
			],
			group_US_limits: [
				[
					(value) => !values.coverages.currentCoverages.has('US') || eitherUSLimitSet,
					'You must supply either a building limit or a BPP Limit',
				],
			],
			group_CL_limits: [
				[
					(value) =>
						!values.coverages.currentCoverages.has('CL') ||
						!(isBlank(values.coverages.CL.limit) && isBlank(values.coverages.CL.limit2)),
					'At least one limit is required',
				],
			],
			group_HLMT_limits: [
				[
					(value) =>
						!values.coverages.currentCoverages.has('HLMT') ||
						!(
							isBlank(values.coverages.HLMT.fursLimit) &&
							isBlank(values.coverages.HLMT.jewelryLimit) &&
							isBlank(values.coverages.HLMT.patternsLimit)
						),
					'At least one Sub-limit is required.',
				],
			],
			group_MS_limits: [
				[
					(value) =>
						!values.coverages.currentCoverages.has('MS') ||
						!(isBlank(values.coverages.MS.insideLimit) && isBlank(values.coverages.MS.outsideLimit)),
					'At least one limit is required',
				],
			],
			coverages: {
				AR: {
					limit: [
						[(value) => !values.coverages.currentCoverages.has('AR') || !isBlank(value), requiredQuestionMessage],
						[
							(value) => !values.coverages.currentCoverages.has('AR') || _.toNumber(value) > 10000,
							'Limit must be greater than $10,000',
						],
					],
				}, //AR
				FL: {
					damageToPremises: [
						[
							(value) =>
								!values.coverages.currentCoverages.has('FL') ||
								isBlank(value) ||
								(_.toNumber(value) > 0 && _.toNumber(value) <= 950000),
							'Damage To Premises must be greater than 0 and less than or equal $950,000',
						],
						[(value) => !values.coverages.currentCoverages.has('FL') || !isBlank(value), requiredQuestionMessage],
					],
				}, //FL
				BXXP: {
					limit: [
						[(value) => !values.coverages.currentCoverages.has('BXXP') || !isBlank(value), requiredQuestionMessage],
						[
							(value) =>
								!values.coverages.currentCoverages.has('BXXP') ||
								(_.toNumber(value) >= 5000 && _.toNumber(value) < 1000000),
							'Limit must be greater than or equal to $5000 and less than $1,000,000',
						],
					],
				},
				CL: {
					limit: [
						[
							(value) =>
								!values.coverages.currentCoverages.has('CL') ||
								_.toNumber(value) === 1000 ||
								_.toNumber(value) % 5000 === 0 ||
								isBlank(value),
							'Limit must $1,000 or in increments of $5,000',
						],
					],
				},
				DEBR: {
					limit: [
						[(value) => !values.coverages.currentCoverages.has('DEBR') || !isBlank(value), requiredQuestionMessage],
						[
							(value) => !values.coverages.currentCoverages.has('DEBR') || _.toNumber(value) > 25000,
							'Limit must be greater than $25000',
						],
					],
				},
				CDGK: {
					classCode: [
						[(value) => !values.coverages.currentCoverages.has('CDGK') || !isBlank(value), requiredQuestionMessage],
					],
					ratingBasis: [
						[(value) => !values.coverages.currentCoverages.has('CDGK') || !isBlank(value), requiredQuestionMessage],
					],
					compLimit: [
						[(value) => !values.coverages.currentCoverages.has('CDGK') || !isBlank(value), requiredQuestionMessage],
						[
							(value) =>
								!values.coverages.currentCoverages.has('CDGK') ||
								isBlank(value) ||
								isBlank(values.coverages.CDGK.collLimit) ||
								value === values.coverages.CDGK.collLimit,
							'The comp/coll limits must be the same',
						],
					],
					compDeductible: [
						[(value) => !values.coverages.currentCoverages.has('CDGK') || !isBlank(value), requiredQuestionMessage],
					],
					collLimit: [
						[(value) => !values.coverages.currentCoverages.has('CDGK') || !isBlank(value), requiredQuestionMessage],
						[
							(value) =>
								!values.coverages.currentCoverages.has('CDGK') ||
								isBlank(value) ||
								isBlank(values.coverages.CDGK.compLimit) ||
								value === values.coverages.CDGK.compLimit,
							'The comp/coll limits must be the same',
						],
					],
					collDeductible: [
						[(value) => !values.coverages.currentCoverages.has('CDGK') || !isBlank(value), requiredQuestionMessage],
					],
				},
				CDGC: {
					limit: [
						[(value) => !values.coverages.currentCoverages.has('CDGC') || !isBlank(value), requiredQuestionMessage],
					],
				},
				HLMT: {
					description: [
						[(value) => !values.coverages.currentCoverages.has('HLMT') || !isBlank(value), requiredQuestionMessage],
					],
					fursLimit: [
						[
							(value) =>
								!values.coverages.currentCoverages.has('HLMT') ||
								isBlank(value) ||
								value <= quote.sfg.locations[values.locationId].buildings[values.id].bppLimit,
							'Furs Limit cannot exceed the Business Personal Property Limit entered for the building.',
						],
						[
							(value) => !values.coverages.currentCoverages.has('HLMT') || isBlank(value) || _.toNumber(value) > 2500,
							'Limit must be greater than $2,500',
						],
					],
					jewelryLimit: [
						[
							(value) =>
								!values.coverages.currentCoverages.has('HLMT') ||
								isBlank(value) ||
								value <= quote.sfg.locations[values.locationId].buildings[values.id].bppLimit,
							'Jewelry Limit cannot exceed the Business Personal Property Limit entered for the building.',
						],
						[
							(value) => !values.coverages.currentCoverages.has('HLMT') || isBlank(value) || _.toNumber(value) > 2500,
							'Limit must be greater than $2,500',
						],
					],
					patternsLimit: [
						[
							(value) =>
								!values.coverages.currentCoverages.has('HLMT') ||
								isBlank(value) ||
								value <= quote.sfg.locations[values.locationId].buildings[values.id].bppLimit,
							'Patterns Limit cannot exceed the Business Personal Property Limit entered for the building.',
						],
						[
							(value) => !values.coverages.currentCoverages.has('HLMT') || isBlank(value) || _.toNumber(value) > 2500,
							'Limit must be greater than $2,500',
						],
					],
				},
				MS: {
					occupancyType: [
						[(value) => !values.coverages.currentCoverages.has('MS') || !isBlank(value), requiredQuestionMessage],
					],
				},

				OLAW: {
					coverage1: [
						[
							(value) =>
								!values.coverages.currentCoverages.has('OLAW') ||
								value === 'Y' ||
								isBlank(values.coverages.OLAW.coverage2),
							'Coverage 1 must be Yes if Coverage 2 is selected',
						],
					],

					coverage2: [
						[
							(value) =>
								!values.coverages.currentCoverages.has('OLAW') ||
								isBlank(value) ||
								values.coverages.OLAW.coverage1 === 'Y' ||
								!isBlank(values.coverages.OLAW.coverage3),
							'Coverage 2 can not be a solo coverage, you must also set Coverage 1 to Yes or provide a value for Coverage 3',
						],
					],

					coverage3: [
						[
							(value) => !values.coverages.currentCoverages.has('OLAW') || isBlank(value) || _.toNumber(value) > 10000,
							'The limit must be greater than $10,000.',
						],
					],
					businessIncome: [
						[
							(value) =>
								!(
									values.coverages.currentCoverages.has('OLAW') &&
									value === 'Y' &&
									values.coverages.OLAW.coverage1 === 'N' &&
									isBlank(values.coverages.OLAW.coverage2) &&
									isBlank(values.coverages.OLAW.coverage3) &&
									isBlank(values.coverages.OLAW.combinedCoverage)
								),
							'Please enter at least one limit for this coverage or remove this coverage from the quote.',
						],
					],
					combinedCoverage: [
						[
							(value) => !values.coverages.currentCoverages.has('OLAW') || isBlankZ(value) || _.toNumber(value) > 0,
							'Limit must be greater than $0',
						],
						[
							(value) =>
								!values.coverages.currentCoverages.has('OLAW') ||
								isBlank(value) ||
								values.coverages.OLAW.coverage1 === 'Y',
							'Coverage 2 & 3 Combined must be paired with Coverage 1.  Please set Coverage 1 to Yes.',
						],
					],
				},
				OPRP: {
					limit: [
						[(value) => !values.coverages.currentCoverages.has('OPRP') || !isBlank(value), requiredQuestionMessage],
						[
							(value) => !values.coverages.currentCoverages.has('OPRP') || _.toNumber(value) > 2500,
							'Limit must be greater than $2,500',
						],
					],
				},
				SN: {
					limit: [
						[(value) => !values.coverages.currentCoverages.has('SN') || !isBlank(value), requiredQuestionMessage],
					],
				},
				RSEN: {
					// Food Containment
					// Additional Advertising Expense
					// Spoilage Limit
					foodContaminationLimit: [
						[(value) => !values.coverages.currentCoverages.has('RSEN') || !isBlank(value), requiredQuestionMessage],
						[
							(value) => !values.coverages.currentCoverages.has('RSEN') || _.toNumber(value) >= 10000,
							'Limit must be greater or equal to $10,000',
						],
					],
					addtlAdvertisingExpense: [
						[(value) => !values.coverages.currentCoverages.has('RSEN') || !isBlank(value), requiredQuestionMessage],
						[
							(value) => !values.coverages.currentCoverages.has('RSEN') || _.toNumber(value) >= 3000,
							'Limit must be greater or equal to $3,000',
						],
					],
					spoilageLimit: [
						[(value) => !values.coverages.currentCoverages.has('RSEN') || !isBlank(value), requiredQuestionMessage],
						[
							(value) => !values.coverages.currentCoverages.has('RSEN') || _.toNumber(value) >= 10000,
							'Limit must be greater or equal to $10,000',
						],
					],
					spoilageClass: [
						[
							(value) =>
								!values.coverages.currentCoverages.has('RSEN') ||
								_.toNumber(values.coverages.RSEN.spoilageLimit) < 10001 ||
								!isBlank(value),
							'You must answer Spoilage Class if Spoilage Limit > $10,000',
						],
					],
					coverageType: [
						[
							(value) =>
								!values.coverages.currentCoverages.has('RSEN') ||
								_.toNumber(values.coverages.RSEN.spoilageLimit) < 10001 ||
								!isBlank(value),
							'You must answer Coverage Type if Spoilage Limit > $10,000',
						],
					],
					maintenanceAgreement: [
						[
							(value) =>
								!values.coverages.currentCoverages.has('RSEN') ||
								_.toNumber(values.coverages.RSEN.spoilageLimit) < 10001 ||
								!isBlank(value),
							'You must answer Maintenance Agreement if Spoilage Limit > $10,000',
						],
					],
				},
				SPAP: {
					limit: [
						[(value) => !values.coverages.currentCoverages.has('SPAP') || !isBlank(value), requiredQuestionMessage],
					],
				},
				FD: {
					classCode: [
						[(value) => !values.coverages.currentCoverages.has('FD') || !isBlank(value), requiredQuestionMessage],
					],
					coverageType: [
						[(value) => !values.coverages.currentCoverages.has('FD') || !isBlank(value), requiredQuestionMessage],
					],
					maintenanceAgreement: [
						[(value) => !values.coverages.currentCoverages.has('FD') || !isBlank(value), requiredQuestionMessage],
					],
					limit: [
						[(value) => !values.coverages.currentCoverages.has('FD') || !isBlank(value), requiredQuestionMessage],
						[
							(value) => !values.coverages.currentCoverages.has('FD') || _.toNumber(value) <= 50000,
							'Limit must be less than or equal to $50,000',
						],
					],
				},
				VP: {
					limit: [
						[(value) => !values.coverages.currentCoverages.has('VP') || !isBlank(value), requiredQuestionMessage],
						[
							(value) => !values.coverages.currentCoverages.has('VP') || _.toNumber(value) > 10000,
							'Limit must be greater than $10,000',
						],
					],
				},
				VCNT: {
					//dateFrom
					//dateTo
					// no rules
					dateFrom: [
						[
							(value) => !values.coverages.currentCoverages.has('VCNT') || isValidDate(value),
							'You must enter a valid date.',
						],
						[
							(value) => !values.coverages.currentCoverages.has('VCNT') || !isBlank(value),
							'From date must be populated to get a rate.',
						],
						[
							(value) =>
								!values.coverages.currentCoverages.has('VCNT') ||
								isBlank(value) ||
								daysFromDate(value, quote.effectiveDate) >= 0,
							"From date can not predate this quote's effective date.",
						],
						[
							(value) =>
								!values.coverages.currentCoverages.has('VCNT') || isBlank(value) || daysFromDate(value, expdte) <= 0,
							"From date can not postdate this quote's expiration date.",
						],
					],
					dateTo: [
						[
							(value) => !values.coverages.currentCoverages.has('VCNT') || isValidDate(value),
							'You must enter a valid date.',
						],
						[
							(value) => !values.coverages.currentCoverages.has('VCNT') || !isBlank(value),
							'To date must be populated to get a rate.',
						],
						[
							(value) =>
								!values.coverages.currentCoverages.has('VCNT') ||
								isBlank(value) ||
								daysFromDate(value, quote.effectiveDate) >= 0,
							"To date can not predate this quote's effective date.",
						],
						[
							(value) =>
								!values.coverages.currentCoverages.has('VCNT') || isBlank(value) || daysFromDate(value, expdte) <= 0,
							"To date can not postdate this quote's expiration date.",
						],
						[
							(value) =>
								!values.coverages.currentCoverages.has('VCNT') ||
								daysFromDate(value, values.coverages.VCNT.dateFrom) >= 0,
							'To date can not predate the from date.',
						],
					],
				},
				US: {
					// buildingLimit
					// bppLimit
					// powerSupplyDirectDamage
					// waterSupplyDirectDamage
					// communicationsDirectDamage
					// overheadLinesDirectDamage
					// utilitySource
					// coverageType
					// limit
					// powerSupplyTimeElement
					// waterSupplyTimeElement
					// communicationsTimeElement
					// overheadLinesTimeElement
					// wasteWaterRemoval
					//
					// If direct damage building limit or bpp limit greater than 0 then
					//		Power Supply,Water Supply,Communications and utility source
					//		fields within Direct Damage subsection required
					//
					// If time element limit greater than 0 Power Supply,Water Supply,
					//		Communications, Wastewater Removal under time element
					//		subsection required
					buildingLimit: [
						[
							(value) => !(values.coverages.currentCoverages.has('US') && values.coverages.US.buildingLimit === 0),
							'Please remove the $0 building limit and leave this field blank if no building coverage is requested.',
						],
					],
					bppLimit: [
						[
							(value) => !(values.coverages.currentCoverages.has('US') && values.coverages.US.bppLimit === 0),
							'Please remove the $0 limit and leave this field blank if no BPP coverage is requested.',
						],
					],
					limit: [
						[
							(value) => !(values.coverages.currentCoverages.has('US') && values.coverages.US.limit === 0),
							'Please remove the $0 time element limit and leave this field blank if no coverage is requested.',
						],
					],
					powerSupplyDirectDamage: [
						[
							(value) => !values.coverages.currentCoverages.has('US') || !eitherUSLimitSet || !isBlank(value),
							'An entry for Power Supply is required if Building or BPP Limits are supplied',
						],
					],
					waterSupplyDirectDamage: [
						[
							(value) => !values.coverages.currentCoverages.has('US') || !eitherUSLimitSet || !isBlank(value),
							'An entry for Water Supply is required if Building or BPP Limits are supplied',
						],
					],
					communicationsDirectDamage: [
						[
							(value) => !values.coverages.currentCoverages.has('US') || !eitherUSLimitSet || !isBlank(value),
							'An entry for Communications is required if Building or BPP Limits are supplied',
						],
					],
					utilitySource: [
						[
							(value) => !values.coverages.currentCoverages.has('US') || !eitherUSLimitSet || !isBlank(value),
							'An entry for Utility Source is required if Building or BPP Limits are supplied',
						],
					],
					powerSupplyTimeElement: [
						[
							(value) =>
								!values.coverages.currentCoverages.has('US') || isBlank(values.coverages.US.limit) || !isBlank(value),
							'An entry for Power Supply is required if Building or BPP Limits are supplied',
						],
					],
					waterSupplyTimeElement: [
						[
							(value) =>
								!values.coverages.currentCoverages.has('US') || isBlank(values.coverages.US.limit) || !isBlank(value),
							'An entry for Water Supply is required if Building or BPP Limits are supplied',
						],
					],
					communicationsTimeElement: [
						[
							(value) =>
								!values.coverages.currentCoverages.has('US') || isBlank(values.coverages.US.limit) || !isBlank(value),
							'An entry for Communications is required if Building or BPP Limits are supplied',
						],
					],
					wasteWaterRemoval: [
						[
							(value) =>
								!values.coverages.currentCoverages.has('US') || isBlank(values.coverages.US.limit) || !isBlank(value),
							'An entry for Wastewater Removal is required if Building or BPP Limits are supplied',
						],
					],
				},
			}, //coverages
		}; //return
	}

	static referrals(context, values, visibility) {
		const coverages = getSet(_.get(values, 'coverages.currentCoverages'));
		return {
			section_CDLR: [[(value) => !coverages.has('CDLR'), 'SBC03']],
			section_VCNT: [[(value) => !coverages.has('VCNT'), 'SBC04']],
			coverages: {
				BXXP: {
					limit: [[(value) => !coverages.has('BXXP') || value < 50000, 'SBC01']],
				},
				FD: {
					maintenanceAgreement: [
						[(value) => !coverages.has('FD') || values.coverages.FD.maintenanceAgreement !== 'N', 'SBC02'],
					],
				},
			},
		};
	}
	static name() {
		return 'sfgBuildingCoverages';
	}
}
