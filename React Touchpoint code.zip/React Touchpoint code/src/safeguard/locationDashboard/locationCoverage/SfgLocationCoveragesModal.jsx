import { ModalStepper } from 'components/shared/navigation/ModalStepper';
import QuoteContext from 'context/quoteContext';
import React, { Component } from 'react';
import SafeguardLocationCoveragesForm from 'safeguard/locationDashboard/locationCoverage/SfgLocationCoveragesForm';
import { Modal } from 'semantic-ui-react';
import { pageAnalytics } from 'utils/ScreenFunctions';
import { replaceReferrals } from 'validation/RunReferrals';

export default class LocationCoveragesModal extends Component {
	static contextType = QuoteContext;

	constructor() {
		super();
		this.state = {
			isOpen: false,
		}; // state to control the state of popup
	}

	handleOpen = (callBack, locationId, newLocation, buildingId, newBuilding, building) => {
		this.setState({
			isOpen: true,
			locationId,
			newLocation,
			buildingId,
			newBuilding,
			building,
			callBack,
		});
		pageAnalytics(this.props.location.pathname + '/SfgLocationCoveragesModal', true);
	};

	handleClose = () => {
		this.state.callBack();
		replaceReferrals(this.context);
		pageAnalytics(this.props.location.pathname);
		this.setState({ isOpen: false });
	};

	render() {
		const { locationId, newLocation, buildingId, newBuilding, building, callBack } = this.state;
		return (
			<Modal
				closeIcon
				open={this.state.isOpen}
				closeOnDimmerClick={false}
				onClose={this.handleClose}
				className='banded'
			>
				<div id='colorBlock' className='loc' />
				<ModalStepper
					currentModal='safeguardLocationCoverages'
					handleClose={this.handleClose}
					locationId={locationId}
					newLocation={newLocation}
					buildingId={buildingId}
					newBuilding={newBuilding}
					building={building}
				/>
				<Modal.Content>
					<SafeguardLocationCoveragesForm
						locationId={locationId}
						handleClose={this.handleClose}
						newLocation={newLocation}
						buildingId={buildingId}
						building={building}
						newBuilding={newBuilding}
						callBack={callBack}
						{...this.props}
					/>
				</Modal.Content>
			</Modal>
		);
	}
}
