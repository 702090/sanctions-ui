import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { Select } from 'components/shared/form/Select';
import { InformationMessage } from 'components/shared/messages/InformationMessage';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import coveragesListJson from 'data/CoveragesList';
import selectOptionsJson from 'data/SelectOptions';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { Component } from 'react';
import { toast } from 'react-toastify';
import { ModalNavButtons } from 'safeguard/locationDashboard/components/ModalNavButtons';
import SfgLocationCoverageRules from 'safeguard/locationDashboard/locationCoverage/SfgLocationCoverageRules';
import {
	APLLmap,
	CDWTmap,
	FDSCmap,
	RSLLmap,
	SFGLocCoverage,
} from 'safeguard/locationDashboard/locationCoverage/SfgLocationCoverages';
import { checkLocCovgs, coverageRollOffMessages, distillBuildings, getLocCovgList } from 'utils/BusinessFunctions';
import { getSet } from 'utils/ObjectFunctions';
import { cleanValues, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { validate } from 'validation/Validate';

let visibility = {};
const defaultCoverages = [];
const { sfg_LocationCoverages } = selectOptionsJson;

export default class SafeguardLocationCoveragesFields extends Component {
	static contextType = QuoteContext;

	fieldVisibility = {};

	dirty = false;
	state = { protectionClassOptions: [] };
	location = {};
	rulesOnLoad = false;
	coveragesWithoutFields = getSet(['APFA', 'RSFA', 'CDAS', 'CDCT', 'CDPF', 'CDPX', 'CDPE']);
	coverageRollOffMessage = [];

	UNSAFE_componentWillMount() {
		const { occupancyCodes, classCodes, buildingCoverages } = distillBuildings(
			_.get(this.context, 'quote.sfg.locations'),
			this.props.locationId,
		);

		this.location = _.get(this.context, `quote.sfg.locations.${this.props.locationId}`, {});

		let quoteCurrentCoverages = _.get(this.location, 'coverages.currentCoverages', defaultCoverages);
		if (quoteCurrentCoverages instanceof Set) {
			quoteCurrentCoverages = [...quoteCurrentCoverages];
		} else if (quoteCurrentCoverages instanceof Object) {
			quoteCurrentCoverages = Object.values(quoteCurrentCoverages);
		}

		let deletedCoverages = getSet(_.get(this.location, 'coverages.deletedCoverages', new Set()));

		const currentCoverages = getSet(
			quoteCurrentCoverages.filter(
				(coverage) =>
					checkLocCovgs(coverage, [...classCodes], occupancyCodes, buildingCoverages) &&
					!deletedCoverages.has(coverage),
			),
		);

		this.coverageRollOffMessage = coverageRollOffMessages({
			quoteCurrentCoverages,
			currentCoverages,
			navAction: 'Done',
		});

		coveragesListJson.sfg_location_premier.forEach((covgCd) => {
			if (checkLocCovgs(covgCd, [...classCodes], occupancyCodes, buildingCoverages) && !deletedCoverages.has(covgCd)) {
				currentCoverages.add(covgCd);
			}
		});

		_.set(this.context, `quote.sfg.locations.${this.props.locationId}.coverages.currentCoverages`, currentCoverages);

		const { newCoverageOptions, vis } = getLocCovgList(
			currentCoverages,
			[...classCodes],
			occupancyCodes,
			buildingCoverages,
		);
		visibility = vis;

		this.updateFieldVisibilityLL('APLL', _.get(this.location, 'coverages.APLL.compDeductible', ''));

		this.updateFieldVisibilityLL('RSLL', _.get(this.location, 'coverages.RSLL.compDeductible', ''));

		this.setState({
			currentCoverages,
			newCoverageOptions,
			occupancyCodes,
			classCodes,
			deletedCoverages,
			buildingCoverages,
		});
	}

	componentDidMount() {
		// If the form is not empty, trigger validation
		runRulesOnLoad(this.formProps, this.formProps.initialValues, ['']);
	}

	updateFieldVisibilityLL = (covgCode, compVal) => {
		this.fieldVisibility = _.merge(this.fieldVisibility, {
			[`coverages.${covgCode}.collDeductible`]: false,
		});

		if (compVal === '2500') {
			this.fieldVisibility[`coverages.${covgCode}.collDeductible`] = true;
		}
	};

	removeCoverage = (coverageId, formikProps, hideToast) => {
		const { currentCoverages } = this.state;
		currentCoverages.delete(coverageId);
		const { deletedCoverages } = this.state;
		deletedCoverages.add(coverageId);

		_.set(formikProps, 'values.coverages.currentCoverages', currentCoverages);
		_.set(formikProps, 'values.coverages.deletedCoverages', deletedCoverages);

		const { newCoverageOptions, vis } = getLocCovgList(
			currentCoverages,
			[...this.state.classCodes],
			this.state.occupancyCodes,
			this.state.buildingCoverages,
		);
		visibility = vis;
		this.setState({ currentCoverages, newCoverageOptions, deletedCoverages });
		if (!hideToast) {
			toast.success(`${_.find(sfg_LocationCoverages, (c) => coverageId === c.value).text} Removed!`);
		}

		this.context.onLocCovgModalSubmit(formikProps.values, true, this.props);
	};

	render() {
		const { quote } = this.context;
		const { newLocation, locationId, callBack } = this.props;
		const coverages = _.get(quote, `sfg.locations.${locationId}.coverages`);

		return (
			<Formik
				render={(formikProps) => {
					this.formProps = formikProps;

					this.dirty = formikProps.dirty;
					cleanValues(formikProps.values, visibility);
					if (!this.rulesOnLoad) {
						formikProps.validateForm(formikProps.values);
						this.rulesOnLoad = true;
					}
					return (
						<Form id='screen'>
							{!isBlank(this.coverageRollOffMessage) &&
								this.coverageRollOffMessage.map((message) => (
									<InformationMessage key={message} message={message} fieldDisplay />
								))}
							<PageSection className='addCoverage'>
								<Field
									name='LocationCoverages'
									label='Add New Coverage'
									component={Select}
									options={this.state.newCoverageOptions}
								/>
								<SimpleButton
									content='Add Coverage'
									primary
									onClick={() => {
										const data = formikProps.values.LocationCoverages || '';
										if (!isBlank(data)) {
											const { currentCoverages, deletedCoverages } = this.state;
											const newCoverageOptions = _.filter(
												this.state.newCoverageOptions,
												(coverage) => data !== coverage.value,
											);
											currentCoverages.add(data);
											deletedCoverages.delete(data);
											_.set(formikProps, 'values.coverages.currentCoverages', currentCoverages);
											_.set(formikProps, 'values.coverages.deletedCoverages', deletedCoverages);
											visibility[`coverages.${data}`] = true;
											if (this.coveragesWithoutFields.has(data)) {
												toast.success(`${_.find(sfg_LocationCoverages, (c) => data === c.value).text} Added!`);
											}
											this.setState({
												currentCoverages,
												newCoverageOptions,
												newCoverage: this.coveragesWithoutFields.has(data) ? '' : data,
											});
											formikProps.validateForm(formikProps.values);
											formikProps.values.LocationCoverages = '';
										}
									}}
								/>
							</PageSection>
							{sfg_LocationCoverages.map((coverage) => {
								let updateFields = () => {};
								if (_.includes(['APLL', 'RSLL'], coverage.value)) {
									updateFields = this.updateFieldVisibilityLL(
										coverage.value,
										_.get(formikProps.values, `coverages.${coverage.value}.compDeductible`, ''),
									);
								}
								return (
									<SFGLocCoverage
										key={coverage.value}
										coverage={coverage}
										isAdded={this.state.currentCoverages.has(coverage.value)}
										removeCoverage={(coverageId, hideToast) => this.removeCoverage(coverageId, formikProps, hideToast)}
										visibility={this.fieldVisibility}
										updateFields={updateFields}
										isNewCoverage={this.state.newCoverage === coverage.value}
										formikProps={formikProps}
										resetNewCoverage={() => this.setState({ newCoverage: '' })}
										{...this.props}
									/>
								);
							})}
							<ModalNavButtons
								currentModal='safeguardLocationCoverages'
								onClose={this.props.handleClose}
								locationId={locationId}
								newLocation={newLocation}
								buildingId=''
								newBuilding={newLocation}
								building={{}}
								formikProps={formikProps}
								saveValues={() => this.context.onLocCovgModalSubmit(formikProps.values, this.dirty, this.props)}
								callBack={callBack}
							/>
						</Form>
					);
				}}
				initialValues={{
					id: this.props.locationId,
					coverages: {
						currentCoverages:
							coverages && coverages.currentCoverages ? coverages.currentCoverages : this.state.currentCoverages,
						deletedCoverages:
							coverages && coverages.deletedCoverages ? coverages.deletedCoverages : this.state.deletedCoverages,
						FDSC: FDSCmap(coverages),
						RSLL: RSLLmap(coverages),
						APLL: APLLmap(coverages),
						CDWT: CDWTmap(coverages),
					},
				}}
				onSubmit={(values, formikActions) => {
					cleanValues(values, visibility);
					this.context.onLocCovgModalSubmit(values, this.dirty, this.props);
					formikActions.setSubmitting(false);
					this.props.handleClose();
				}}
				validate={(values) => {
					const validResults = validate(
						values,
						SfgLocationCoverageRules.rules(quote, values, this.fieldVisibility),
						SfgLocationCoverageRules.requiredStructure,
					);
					logPageErrors(validResults, this.formProps.touched, 'sfg');
					return validResults;
				}}
			/>
		);
	}
}
