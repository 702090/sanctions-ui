import { RemoveCoverageButton } from 'components/shared/buttons/RemoveCoverageButton';
import { EndorsementLink } from 'components/EndorsementLink';
import { RadioButton } from 'components/shared/form/RadioButton';
import { Select } from 'components/shared/form/Select';
import { PageSection } from 'components/shared/sections/PageSection';
import coveragesListJson from 'data/CoveragesList';
import selectOptionsJson from 'data/SelectOptions';
import { Field } from 'formik';
import _ from 'lodash';
import QuoteContext from 'context/quoteContext';
import React from 'react';
import { toast } from 'react-toastify';
import { isBlank } from 'utils/StringFunctions';

const {
	sfg_APLL_comp_deductible,
	sfg_APLL_coll_deductible,
	sfg_APLL_limit,
	sfg_CDWT_limit,
	sfg_FDSC_limit,
	sfg_RSLL_comp_deductible,
	sfg_RSLL_coll_deductible,
	sfg_RSLL_limit,
} = selectOptionsJson;
const { sfg_URLs } = coveragesListJson;

function pickCoverage(coverage, visibility, updateFields) {
	switch (coverage.value) {
		case 'FDSC':
			// limit - covg1Lmt
			return (
				<Field
					name='coverages.FDSC.limit'
					label='Limit'
					component={RadioButton}
					options={sfg_FDSC_limit}
					width='tiny'
				/>
			);
		case 'RSLL':
			// limit - covg1Lmt
			// deductible - ded2amt
			return (
				<React.Fragment>
					<Field name='coverages.RSLL.limit' label='Limit' component={Select} options={sfg_RSLL_limit} width='tiny' />
					<Field
						name='coverages.RSLL.compDeductible'
						label='Comprehensive Deductible Maximum'
						component={RadioButton}
						options={sfg_RSLL_comp_deductible}
						width='tiny'
					/>
					<Field
						name='coverages.RSLL.collDeductible'
						label='Collision Deductible Maximum'
						component={RadioButton}
						options={sfg_RSLL_coll_deductible}
						width='tiny'
						fieldDisplay={visibility['coverages.RSLL.collDeductible']}
					/>
				</React.Fragment>
			);
		case 'APLL':
			// limit - covg1Lmt
			// deductible - ded2amt
			return (
				<React.Fragment>
					<Field name='coverages.APLL.limit' label='Limit' component={Select} options={sfg_APLL_limit} width='tiny' />
					<Field
						name='coverages.APLL.compDeductible'
						label='Comprehensive Deductible Maximum'
						component={RadioButton}
						options={sfg_APLL_comp_deductible}
						width='tiny'
					/>
					<Field
						name='coverages.APLL.collDeductible'
						label='Collision Deductible Maximum'
						component={RadioButton}
						options={sfg_APLL_coll_deductible}
						width='tiny'
						fieldDisplay={visibility['coverages.APLL.collDeductible']}
					/>
				</React.Fragment>
			);
		case 'CDWT':
			// limit - covg1Lmt
			return (
				<Field
					name='coverages.CDWT.limit'
					label='Property Limit'
					component={RadioButton}
					options={sfg_CDWT_limit}
					width='tiny'
				/>
			);
		case 'APFA':
		case 'RSFA':
		case 'CDAS':
		case 'CDCT':
		case 'CDPF':
		case 'CDPX':
		case 'CDPE':
			return <React.Fragment>Added to policy.</React.Fragment>;
		default:
			return null;
	}
}

export const SFGLocCoverage = ({
	coverage,
	isAdded,
	removeCoverage,
	visibility,
	updateFields,
	isNewCoverage,
	formikProps,
	resetNewCoverage,
	...props
}) => {
	const { touched, errors, setFormikState } = formikProps;
	let urlSummary = '';
	let urlPDF = '';

	if (sfg_URLs[coverage.value]) {
		urlSummary = sfg_URLs[coverage.value][0].urlSum;
		urlPDF = sfg_URLs[coverage.value][0].urlPDF;
	}

	if (isAdded) {
		const coverageErrors = _.get(errors, `coverages.${coverage.value}`, {});
		const groupErrors = _.findKey(errors, (error, key) => _.startsWith(key, `group_${coverage.value}`));
		return (
			<QuoteContext.Consumer>
				{(context) => (
					<PageSection
						title={coverage.text}
						className='coverageSection'
						name={`section_${coverage.value}`}
						errors={errors}
						isNewCoverage={isNewCoverage}
						cancelAction={() => {
							resetNewCoverage();
							removeCoverage(coverage.value, true);
							formikProps.validateForm(formikProps.values);
						}}
						saveAction={() => {
							if (isBlank(coverageErrors) && isBlank(groupErrors)) {
								toast.success(`${coverage.text} Added!`);
								resetNewCoverage();
							} else {
								_.forIn(coverageErrors, (fieldError, fieldName) => {
									_.set(touched, `coverages.${coverage.value}.${fieldName}`, true);
								});
								setFormikState({ focusCoverage: coverage.value }); // this forces re-render
							}
							formikProps.validateForm(formikProps.values);
							context.onLocCovgModalSubmit(formikProps.values, formikProps.dirty, props);
						}}
					>
						{!isBlank(urlSummary) ? <EndorsementLink summary={urlSummary} pdf={urlPDF} /> : ''}

						<RemoveCoverageButton
							onClick={(event) => {
								removeCoverage(coverage.value);
							}}
						/>
						<div className='coverageFields'>{pickCoverage(coverage, visibility, updateFields)}</div>
					</PageSection>
				)}
			</QuoteContext.Consumer>
		);
	}
	return null;
};

export const FDSCmap = (coverages) => ({
	limit: _.get(coverages, 'FDSC.limit', ''),
});
export const RSLLmap = (coverages) => ({
	limit: _.get(coverages, 'RSLL.limit', ''),
	compDeductible: _.get(coverages, 'RSLL.compDeductible', ''),
	collDeductible: _.get(coverages, 'RSLL.collDeductible', ''),
});
export const APLLmap = (coverages) => ({
	limit: _.get(coverages, 'APLL.limit', ''),
	compDeductible: _.get(coverages, 'APLL.compDeductible', ''),
	collDeductible: _.get(coverages, 'APLL.collDeductible', ''),
});

export const CDWTmap = (coverages) => ({
	limit: _.get(coverages, 'CDWT.limit', ''),
});
