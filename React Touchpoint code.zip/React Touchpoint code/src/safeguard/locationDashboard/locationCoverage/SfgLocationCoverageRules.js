import { getFieldDisplayArray, requiredQuestionMessage } from 'data/FieldVisibility';
import { getVisibility } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { distillBuildings } from 'utils/BusinessFunctions';
import _ from 'lodash';

export default class SfgLocationCoverageRules {
	static requiredStructure = {
		section_RSLL: '',
		section_APLL: '',
		coverages: {
			FDSC: { limit: '' },
			RSLL: { limit: '', compDeductible: '', collDeductible: '' },
			APLL: { limit: '', compDeductible: '', collDeductible: '' },
			CDWT: { limit: '' },
		},
	};

	static rules(quote, values, visibility, dashboardCallId) {
		// TODO: re-visit this posibility
		// verifySet(quote.sfg.coverages.currentCoverages);
		// verifySet(values.coverages.currentCoverages);
		if (values && !visibility) {
			visibility = getVisibility(getFieldDisplayArray('safeguardLocation'), quote, values);
		}
		const locationId = values.id ? values.id : dashboardCallId;
		const { buildingCoverages } = distillBuildings(_.get(quote, 'sfg.locations', {}), locationId);

		return {
			section_RSLL: [
				[
					(value) => buildingCoverages.has('RSEN') || (values && !values.coverages.currentCoverages.has('RSLL')),
					'This coverage requires at least one building at this location to have Restaurant Enhancement Endorsement Coverage',
				],
			],
			section_APLL: [
				[
					(value) => buildingCoverages.has('APEN') || (values && !values.coverages.currentCoverages.has('APLL')),
					'This coverage requires at least one building at this location to have Apartment Enhancement Endorsement Coverage',
				],
			],
			coverages: {
				FDSC: {
					limit: [
						[
							(value) => (values && !values.coverages.currentCoverages.has('FDSC')) || !isBlank(value),
							requiredQuestionMessage,
						],
					],
				},
				RSLL: {
					limit: [
						[
							(value) => (values && !values.coverages.currentCoverages.has('RSLL')) || !isBlank(value),
							requiredQuestionMessage,
						],
					],
					compDeductible: [
						[
							(value) => (values && !values.coverages.currentCoverages.has('RSLL')) || !isBlank(value),
							requiredQuestionMessage,
						],
					],
					collDeductible: [
						[
							(value) =>
								(values && !values.coverages.currentCoverages.has('RSLL')) ||
								!(isBlank(value) && _.get(values, 'coverages.RSLL.compDeductible', '') === '2500'),
							requiredQuestionMessage,
						],
					],
				},
				APLL: {
					limit: [
						[
							(value) => (values && !values.coverages.currentCoverages.has('APLL')) || !isBlank(value),
							requiredQuestionMessage,
						],
					],
					compDeductible: [
						[
							(value) => (values && !values.coverages.currentCoverages.has('APLL')) || !isBlank(value),
							requiredQuestionMessage,
						],
					],
					collDeductible: [
						[
							(value) =>
								(values && !values.coverages.currentCoverages.has('APLL')) ||
								!(isBlank(value) && _.get(values, 'coverages.APLL.compDeductible', '') === '2500'),
							requiredQuestionMessage,
						],
					],
				},
				CDWT: {
					limit: [
						[
							(value) => (values && !values.coverages.currentCoverages.has('CDWT')) || !isBlank(value),
							requiredQuestionMessage,
						],
					],
				},
			},
		};
	}

	static referrals(context, values) {
		return {};
	}

	static name() {
		return 'sfgLocationCoverages';
	}
}
