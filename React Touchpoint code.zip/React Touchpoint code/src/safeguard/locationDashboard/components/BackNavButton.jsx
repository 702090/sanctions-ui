import React from 'react';
import { SimpleButton } from 'components/shared/buttons/SimpleButton';

export const BackNavButton = ({ mRef, data }) => {
	const onClick = () => {
		data.saveValues();
		data.onClose();
		mRef.current.handleOpen(
			data.callBack,
			data.locationId,
			data.newLocation,
			data.buildingId,
			data.newBuilding,
			data.building,
		);
	};
	return (
		<React.Fragment>
			<div id='navigateleft' className='navigate'>
				<i className='far fa-chevron-square-left' onClick={onClick} />
			</div>
			<SimpleButton content='Back' id='Back' primary onClick={onClick} />
		</React.Fragment>
	);
};
