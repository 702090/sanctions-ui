import _ from 'lodash';
import React, { Component } from 'react';
import { isBlank } from 'utils/StringFunctions';

export class BuildingSection extends Component {
	render() {
		const { buildingId, locationId, order, onClick, copyBuilding, deleteBuilding, mode, errors } = this.props;
		const errorCount = _.size(errors);
		let icon = '';
		let action = () => {};
		switch (mode) {
			case 'copy':
				icon = <i className='fal fa-copy big mode' />;
				action = copyBuilding;
				break;
			case 'delete':
				icon = <i className='fal fa-times big mode' />;
				action = deleteBuilding;
				break;
			default:
		}
		return (
			<div className={`building buildingButton ${mode} ${!isBlank(errors) ? 'error' : ''}`} onClick={onClick}>
				{errors ? (
					<div className='buildingError'>
						{errorCount} Error
						{errorCount > 1 ? 's' : ''}
						<i className='fas fa-exclamation-triangle large' />
					</div>
				) : (
					<i className='fas fa-building big' />
				)}

				<div className='buildingLabel'>Building&nbsp;{order}</div>
				<div
					className={`bldgOverlayIcon ${mode}`}
					onClick={(e) => {
						e.stopPropagation();
						action(locationId, buildingId);
					}}
				>
					{icon}
				</div>
			</div>
		);
	}
}
