import _ from 'lodash';
import React from 'react';
import { isBlank } from 'utils/StringFunctions';

export const LocationSection = (props) => {
	let imageUrl = '';
	let linkUrl = '';
	if (props.info) {
		imageUrl = `https://maps.googleapis.com/maps/api/staticmap?zoom=15&size=400x300&maptype=roadmap&center=${props.info}&markers=color:red|${props.info}&components=country:US&key=${process.env.REACT_APP_GOOGLE_KEY}`;
		linkUrl = `https://maps.google.com/?q=${props.info}`;
	}
	return (
		<div className={`locationSection ${props.mode} ${!isBlank(props.errors) ? 'error' : ''}`}>
			<div className='locationTrigger' onClick={props.onClick}>
				<div className='imageWrapper'>
					{props.info ? (
						<img src={imageUrl} alt={props.info} />
					) : (
						<div className='warning'>
							<p>Please enter an address for this location</p>
						</div>
					)}
					{!isBlank(props.errors) && (
						<div className='locationError'>
							<i className='fas fa-exclamation-triangle massive' />
							<span>
								{_.size(props.errors)} Error
								{_.size(props.errors) > 1 ? 's' : ''}
							</span>
						</div>
					)}
					<div className={`editHelp ${!isBlank(props.errors) ? 'error' : ''}`}>
						Click to edit location
						{/* {!isBlank(props.errors) ? (
              <Label color='red' floating>
                {_.size(props.errors)}
              </Label>
            ) : (
              ''
            )} */}
					</div>
					{props.info ? (
						<a
							href={linkUrl}
							target='_blank'
							rel='noopener noreferrer'
							className='mapIcon'
							onClick={(e) => {
								e.stopPropagation();
							}}
						>
							<i className='far fa-search' />
							&nbsp; View Map
						</a>
					) : (
						''
					)}
					<div
						className={`locOverlayIcon ${props.mode}`}
						onClick={(e) => {
							e.stopPropagation();
							props.deleteLocation(props.locationId);
						}}
					>
						<i className='fal fa-times massive' />
					</div>
				</div>
				<div>{props.info}</div>
			</div>
			{props.info ? props.children : ''}
		</div>
	);
};
