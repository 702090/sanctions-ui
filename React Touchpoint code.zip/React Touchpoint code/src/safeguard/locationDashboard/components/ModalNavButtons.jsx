import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import QuoteContext from 'context/quoteContext';
import _ from 'lodash';
import React from 'react';
import { BackNavButton } from 'safeguard/locationDashboard/components/BackNavButton';
import { DoneNavButton } from 'safeguard/locationDashboard/components/DoneNavButton';
import { NextNavButton } from 'safeguard/locationDashboard/components/NextNavButton';
import { buildingHasQuestions } from 'utils/BusinessFunctions';

export const ModalNavButtons = ({
	currentModal,
	onClose,
	locationId,
	newLocation,
	buildingId,
	newBuilding,
	building,
	saveValues,
	address,
	callBack,
	formikProps,
	prefillData,
	disableNext,
	datatestId,
}) => {
	const data = {
		locationId,
		newLocation,
		buildingId,
		newBuilding,
		building,
		saveValues,
		onClose,
		errors: formikProps.errors,
		address,
		callBack,
		submit: formikProps.submitForm,
		prefillData,
		disableNext,
		datatestId,
	};
	return (
		<QuoteContext.Consumer>
			{(context) => {
				const quote = _.get(context, 'quote', {});

				let state;
				if (address) {
					state = address.state;
				} else {
					state = _.get(quote, `addresses.${locationId}.state`);
				}
				let buttons = '';

				const hasQuestions = buildingHasQuestions(locationId, building, quote, state);
				switch (currentModal) {
					case 'safeguardLocation':
						buttons = <NextNavButton data={data} mRef={newLocation ? context.refBuilding : context.refLocCoverages} />;
						break;
					case 'safeguardLocationCoverages':
						buttons = (
							<React.Fragment>
								<BackNavButton data={data} mRef={newLocation ? context.refBldgCoverages : context.refLocation} />
								<DoneNavButton data={data} />
							</React.Fragment>
						);
						break;
					case 'safeguardBuilding':
						buttons = (
							<React.Fragment>
								{newLocation && <BackNavButton data={data} mRef={context.refLocation} />}
								<NextNavButton data={data} mRef={hasQuestions ? context.refBldgQuestions : context.refBldgCoverages} />
							</React.Fragment>
						);
						break;
					case 'safeguardBuildingQuestions':
						buttons = (
							<React.Fragment>
								<BackNavButton data={data} mRef={context.refBuilding} />
								<NextNavButton data={data} mRef={context.refBldgCoverages} />
							</React.Fragment>
						);
						break;
					case 'safeguardBuildingCoverages':
						buttons = (
							<React.Fragment>
								<BackNavButton data={data} mRef={hasQuestions ? context.refBldgQuestions : context.refBuilding} />
								{newLocation ? (
									<NextNavButton data={data} mRef={context.refLocCoverages} />
								) : (
									<DoneNavButton data={data} />
								)}
							</React.Fragment>
						);
						break;
					default:
						break;
				}
				return (
					<div id='navigationButtons'>
						<SimpleButton
							onClick={() => {
								formikProps.resetForm();
								onClose();
							}}
							content='Cancel'
							type='button'
						/>
						<div id='navigateleft' className='navigate cancel'>
							<i className='far fa-chevron-square-left' onClick={onClose} />
						</div>
						{buttons}
					</div>
				);
			}}
		</QuoteContext.Consumer>
	);
};
