import React from 'react';
import { isBlank } from 'utils/StringFunctions';
import { SubmitButton } from 'components/shared/buttons/SubmitButton';

export const NextNavButton = ({ mRef, data }) => {
	const onClick = () => {
		if (isBlank(data.errors)) {
			mRef.current.handleOpen(
				data.callBack,
				data.locationId,
				data.newLocation,
				data.buildingId,
				data.newBuilding,
				data.building,
				data.address,
				data.prefillData,
			);
		}
	};
	return (
		<React.Fragment>
			<SubmitButton
				content='Next'
				onClick={() => {
					if (isBlank(data.errors)) {
						onClick();
					}
				}}
				className={!isBlank(data.errors) ? 'error' : ''}
				disabled={data.disableNext}
				datatestId={data.datatestId}
			/>
			<div id='navigateRight' className='navigate'>
				<i
					className='far fa-chevron-square-right'
					onClick={() => {
						data.submit();
						onClick();
					}}
				/>
			</div>
		</React.Fragment>
	);
};
