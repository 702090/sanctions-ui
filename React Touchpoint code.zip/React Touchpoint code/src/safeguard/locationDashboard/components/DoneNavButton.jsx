import { SubmitButton } from 'components/shared/buttons/SubmitButton';
import React from 'react';
import { isBlank } from 'utils/StringFunctions';

export const DoneNavButton = ({ data }) => (
	<React.Fragment>
		<SubmitButton content='Done' className={!isBlank(data.errors) ? 'error' : ''} onClick={data.callBack} />
		<div id='navigateRight' className='navigate'>
			<i className='far fa-chevron-square-right' onClick={data.submit} />
		</div>
	</React.Fragment>
);
