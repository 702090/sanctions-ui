import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { callGeocode, callKentuckyTax } from 'components/shared/form/inputs/Addresses';
import { InputAddress } from 'components/shared/form/inputs/InputAddress';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { Loading } from 'components/shared/form/Loading';
import { RadioButton } from 'components/shared/form/RadioButton';
import { Select } from 'components/shared/form/Select';
import { InformationMessage } from 'components/shared/messages/InformationMessage';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import selectOptionsJson from 'data/SelectOptions';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { useContext, useEffect, useState } from 'react';
import { ModalNavButtons } from 'safeguard/locationDashboard/components/ModalNavButtons';
import SfgLocationRules from 'safeguard/locationDashboard/location/SfgLocationRules';
import { getCounties, getProtectionClassCodes } from 'services/insurityService';
import { getSTPData, prefillUsed } from 'utils/BusinessFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import { cleanValues, getVisibility, logPageErrors, parseAddress, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { v4 as uuidv4 } from 'uuid';
import { checkReferrals, validateNew } from 'validation/Validate';

const SafeguardLocationForm = (props) => {
	const context = useContext(QuoteContext);
	let formProps;
	const { quote } = context;
	let { id, newLocation, callBack } = props;
	const { sfg_propertyDeductible, sfg_windHail } = selectOptionsJson;

	const [protectionClassOptions, setProtectionClassOptions] = useState([]);
	const [loadingProtectionClassOptions, setLoadingProtectionClassOptions] = useState(false);
	const [loadingCountyOptions, setLoadingCountyOptions] = useState(false);
	const [countyOptions, setCountyOptions] = useState([]);

	useEffect(() => {
		// Run validation after all elements have been added to the form
		Promise.all([protectionClassOnChange(address, true), countyOnChange(address, true)]).then(() => {
			// If the form is not empty, trigger validation
			runRulesOnLoad(formProps, formProps.initialValues, ['id']);
		});
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	useEffect(() => {
		// Update prefill fields after verisk retrieval
		if (!isBlank(_.get(formProps, 'values.prefillData.verisk', {}))) {
			if (isBlank(_.get(formProps, 'values.grossSales', ''))) {
				formProps.setFieldValue('grossSales', _.get(formProps, 'values.prefillData.verisk.grossSales', ''));
			}
			if (isBlank(_.get(formProps, 'values.protectionClass', ''))) {
				const veriskProtectionClass = _.get(formProps, 'values.prefillData.verisk.protectionClass', '');
				let protectionClassValues = [];
				_.forIn(protectionClassOptions, (option) => {
					const splitClassString = _.split(_.toString(option.value), '|');
					if (splitClassString[1] === veriskProtectionClass) {
						protectionClassValues.push(option);
					}
				});
				// not prefilling if more than one of the same protection class value
				if (protectionClassValues.length === 1) {
					formProps.setFieldValue('protectionClass', protectionClassValues[0].value);
				}
			}
		}
		dirty = true;
	}, [context.serviceStatus.stpPrefill]);

	let dirty = false;

	let rulesOnLoad = false;
	let visibility = {};

	const location = _.get(context, `quote.sfg.locations.${props.id}`, {});
	const address = _.get(context, `quote.addresses.${props.id}`, {});

	const protectionClassOnChange = async (addressL, loadingProtectionClassOpts) => {
		if (addressL) {
			setLoadingProtectionClassOptions(loadingProtectionClassOpts);
			getProtectionClassCodes(
				addressL.city,
				addressL.state,
				addressL.zip,
				new Date(context.quote.effectiveDate).getTime(),
			).then((classOptions) => {
				if (classOptions.length === 1) {
					formProps.setFieldValue('protectionClass', classOptions[0].value);
					formProps.setFieldTouched('protectionClass', true, false);
				}
				setProtectionClassOptions(classOptions);
				setLoadingProtectionClassOptions(false);
			});
		}
	};

	const countyOnChange = async (addressL, loadingCountyOps) => {
		if (addressL) {
			setLoadingCountyOptions(loadingCountyOps);
			getCounties(
				addressL.city,
				addressL.state,
				addressL.zip,
				addressL.county,
				new Date(context.quote.effectiveDate).getTime(),
			).then((countyOpts) => {
				if (countyOpts.length === 1) {
					addressL.county = countyOpts[0].text;
					formProps.setFieldValue('addressL.county', countyOpts[0].value, false);
					formProps.setFieldTouched('addressL.county', true, false);
				}

				visibility = getVisibility(getFieldDisplayArray('safeguardLocation'), quote, formProps.values);

				formProps.setFieldValue('windIndicator', visibility.tidalWater ? '2' : '', true);

				setCountyOptions(countyOpts);
				setLoadingCountyOptions(false);
			});
		}
	};

	const getPrefillToolTips = (quoteObject, formValues) => {
		const noCallVeriskMessage = 'Verisk has never been called.';
		const noReturnVeriskMessage = 'The Verisk call returned no data.';
		const locationObject = _.get(quote, `sfg.locations.${formValues.id}`, {});

		let prefillObject = {
			grossSales: noCallVeriskMessage,
			protectionClass: noCallVeriskMessage,
			naicCode: noCallVeriskMessage,
			naic: noCallVeriskMessage,
			sicCode: noCallVeriskMessage,
			sic: noCallVeriskMessage,
			yearStarted: noCallVeriskMessage,
		};

		if (_.has(locationObject, 'prefillData.verisk') || _.has(formValues, 'prefillData.verisk')) {
			//* Gross Sales
			prefillObject.grossSales = _.get(
				locationObject,
				'prefillData.verisk.grossSales',
				_.get(formValues, 'prefillData.verisk.grossSales', noReturnVeriskMessage),
			);
			prefillObject.grossSales = isBlank(prefillObject.grossSales) ? noReturnVeriskMessage : prefillObject.grossSales;

			//* Protection Class
			prefillObject.protectionClass = _.get(
				locationObject,
				'prefillData.verisk.protectionClass',
				_.get(formValues, 'prefillData.verisk.protectionClass', noReturnVeriskMessage),
			);
			prefillObject.protectionClass = isBlank(prefillObject.protectionClass)
				? noReturnVeriskMessage
				: prefillObject.protectionClass;

			//* Non-Field Prefill - Misc
			//* NAIC Description
			prefillObject.naic = _.get(
				locationObject,
				'prefillData.verisk.naic',
				_.get(formValues, 'prefillData.verisk.naic', noReturnVeriskMessage),
			);
			prefillObject.naic = isBlank(prefillObject.naic) ? noReturnVeriskMessage : prefillObject.naic;

			//* NAIC Code
			prefillObject.naicCode = _.get(
				locationObject,
				'prefillData.verisk.naicCode',
				_.get(formValues, 'prefillData.verisk.naicCode', noReturnVeriskMessage),
			);
			prefillObject.naicCode = isBlank(prefillObject.naicCode) ? noReturnVeriskMessage : prefillObject.naicCode;

			//* SIC Description
			prefillObject.sic = _.get(
				locationObject,
				'prefillData.verisk.sic',
				_.get(formValues, 'prefillData.verisk.sic', noReturnVeriskMessage),
			);
			prefillObject.sic = isBlank(prefillObject.sic) ? noReturnVeriskMessage : prefillObject.sic;

			//* SIC Code
			prefillObject.sicCode = _.get(
				locationObject,
				'prefillData.verisk.sicCode',
				_.get(formValues, 'prefillData.verisk.sicCode', noReturnVeriskMessage),
			);
			prefillObject.sicCode = isBlank(prefillObject.sicCode) ? noReturnVeriskMessage : prefillObject.sicCode;

			//* Year Started
			prefillObject.yearStarted = _.get(
				locationObject,
				'prefillData.verisk.yearStarted',
				_.get(formValues, 'prefillData.verisk.yearStarted', noReturnVeriskMessage),
			);
			prefillObject.yearStarted = isBlank(prefillObject.yearStarted)
				? noReturnVeriskMessage
				: prefillObject.yearStarted;

			prefillObject.misc =
				'NAIC Code: ' +
				prefillObject.naicCode +
				'\nNAIC Description: ' +
				prefillObject.naic +
				'\nSIC Code: ' +
				prefillObject.sicCode +
				'\nSIC Description: ' +
				prefillObject.sic +
				'\nYear Business was started: ' +
				prefillObject.yearStarted;
		}

		return prefillObject;
	};

	return (
		<Formik
			render={(formikProps) => {
				formProps = formikProps;
				dirty = dirty || formikProps.dirty;
				if (id === 'NEW') {
					id = formikProps.values.id;
				}
				visibility = getVisibility(getFieldDisplayArray('safeguardLocation'), quote, formikProps.values);
				cleanValues(formikProps.values, visibility);

				checkReferrals(context, formikProps.values, SfgLocationRules, visibility);

				if (!rulesOnLoad) {
					formikProps.validateForm(formikProps.values);
					rulesOnLoad = true;
				}

				const prefillToolTips = getPrefillToolTips(quote, formikProps.values);
				const prefillsPresent = {
					verisk: true,
					verisk360: false,
					datacubes: false,
					ncci: false,
				};

				return (
					<Form id='screen'>
						<InformationMessage
							message='Select information on this page has been pre-filled by a third-party service.'
							fieldDisplay={prefillUsed(quote, formProps.values, prefillsPresent, id)}
						/>
						<PageSection title='Address Information' miscPrefillToolTips={prefillToolTips.misc}>
							<SimpleButton
								onClick={() => {
									const mailingAddress = duplicate(_.get(quote, 'addresses[1]'));
									formikProps.setFieldValue('addressL', mailingAddress);
									callGeocode('addressL', mailingAddress, formikProps.setFieldValue);
									protectionClassOnChange(mailingAddress, true);
									countyOnChange(mailingAddress, true);
									if (mailingAddress.state === 'KY') {
										callKentuckyTax('addressL', mailingAddress, formikProps.setFieldValue);
									}
									getSTPData(context, mailingAddress, formikProps);
								}}
								primary
								content='Address Same As Mailing'
							/>
							<Field
								name='addressL.fullAddress'
								label='Address'
								component={InputAddress}
								className='geo'
								addressName='addressL'
								additionalOnChange={parseAddress}
								getProtectionClassCodes={protectionClassOnChange}
								getCounties={countyOnChange}
								formikProps={formikProps}
								geocode
							/>
							{loadingCountyOptions && <Field name='addressL.county' label='County' component={Loading} />}
							{!isBlank(countyOptions) && (
								<Field name='addressL.county' label='County' component={RadioButton} options={countyOptions} />
							)}
							<Field
								name='gaWest95'
								label='Is the property located west of I-95?'
								component={RadioButton}
								fieldDisplay={visibility.gaWest95}
							/>
							<InformationMessage
								fieldDisplay={false && visibility.island}
								message='Wind will be excluded on this policy due to the county.'
							/>
							{(loadingProtectionClassOptions || context.serviceStatus.stpPrefill) && (
								<Field name='protectionClass' label='Protection Class' component={Loading} />
							)}
							{!isBlank(protectionClassOptions) && !context.serviceStatus.stpPrefill && (
								<Field
									name='protectionClass'
									label='Protection Class'
									component={RadioButton}
									options={protectionClassOptions}
									labelPrefillHoverMessage={prefillToolTips.protectionClass}
								/>
							)}
						</PageSection>
						<PageSection title='General Location Information'>
							<Field
								name='propertyDeductibleAmount'
								label='Property Deductible Amount'
								component={RadioButton}
								options={sfg_propertyDeductible}
							/>
							<Field
								name='windHailDeductible'
								label='Wind Hail Deductible'
								component={Select}
								options={sfg_windHail}
								fieldDisplay={visibility.windHailDeductible}
							/>
							<Field
								name='island'
								label='Is this location on an island?'
								component={RadioButton}
								fieldDisplay={visibility.island}
							/>
							<Field
								name='tidalWater'
								label='Is the distance from this location to the tidal water less than 5 miles?'
								component={RadioButton}
								fieldDisplay={visibility.tidalWater}
							/>
							<Field
								name='floodCoverage'
								label='Is there flood coverage in place?  '
								component={RadioButton}
								fieldDisplay={visibility.floodCoverage}
							/>
							<Field
								name='separateWind'
								label='Does the insured have separate wind coverage in place through TWIA or another carrier?'
								component={RadioButton}
								fieldDisplay={visibility.separateWind}
							/>
							{context.serviceStatus.stpPrefill ? (
								<Field label='Loading Prefill Data' component={Loading} />
							) : (
								<Field
									name='grossSales'
									label='Gross Sales'
									component={InputNumber}
									type='currency'
									prefillHoverMessage={prefillToolTips.grossSales}
								/>
							)}
						</PageSection>
						<ModalNavButtons
							currentModal='safeguardLocation'
							onClose={props.handleClose}
							locationId={id}
							datatestId='locationPopupNext'
							newLocation={newLocation}
							buildingId={newLocation ? 'NEW' : ''}
							newBuilding={newLocation}
							building={{}}
							address={formikProps.values.addressL}
							formikProps={formikProps}
							saveValues={() => {
								// TODO:rename this function
								context.onModalSubmit(formikProps.values, dirty, props);
							}}
							callBack={callBack}
							prefillData={formikProps.values.prefillData}
							disableNext={context.serviceStatus.stpPrefill}
						/>
					</Form>
				);
			}}
			initialValues={{
				addressL: address && !isBlank(address) ? address : { fullAddress: '', county: '' },
				id: id && id !== 'NEW' ? id : uuidv4(),
				propertyDeductibleAmount: location.propertyDeductibleAmount || '',
				protectionClass: location.protectionClass || '',
				windHailDeductible: location.windHailDeductible || '',
				gaWest95: location.gaWest95 || '',
				island: location.island || '',
				tidalWater: location.tidalWater || '',
				floodCoverage: location.floodCoverage || '',
				separateWind: location.separateWind || '',
				grossSales: location.grossSales || '',
				windIndicator: location.windIndicator || '',
				prefillData: location.prefillData || {},
				veriskRoofReport: location.veriskRoofReport || '',
			}}
			onSubmit={(values, formikActions) => {
				if (dirty && visibility.tidalWater && isBlank(values.windIndicator)) {
					values.windIndicator = '2';
				}

				if (!context.serviceStatus.addressValidation) {
					cleanValues(values, visibility);
					context.onModalSubmit(values, dirty, props);
					formikActions.setSubmitting(false);
					props.handleClose();
				}
			}}
			validate={(values) => {
				checkReferrals(context, values, SfgLocationRules, visibility);
				const validResults = validateNew(quote, values, SfgLocationRules, visibility, context.serviceStatus);
				logPageErrors(validResults, formProps.touched, 'sfg');
				return validResults;
			}}
		/>
	);
};

export default SafeguardLocationForm;
