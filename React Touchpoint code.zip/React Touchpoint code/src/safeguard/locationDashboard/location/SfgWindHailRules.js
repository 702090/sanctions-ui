import countyListsJson from 'data/CountyLists';
import rulesValuesJson from 'data/RulesValues';
import messageJson from 'data/WindHailMessages';
import _ from 'lodash';
import { isBlank } from 'utils/StringFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import selectOptionsJson from 'data/SelectOptions';
import { notTier1County } from 'utils/FieldDisplay';

const { windHail_AL_refer, windHail_GA_refer, windHail_MS_refer, windHail_TX_mandatory } = countyListsJson;
const { sfg_roofAreaWindHailDeductibles } = rulesValuesJson;
const { sfg_windHail } = selectOptionsJson;

export function windHailCheck(addresses, values, quote, locationId, buildings) {
	let totalLimits = 0;
	let modifiedBuildingTotal = 0;
	let returnMessage = '';
	let buildingsToTest = [];
	let totalRoofArea = 0;
	const state = _.get(values, 'addressL.state', _.get(quote, `addresses[${locationId}].state`, ''));
	const county = _.replace(
		_.get(values, 'addressL.county', _.get(quote, `addresses[${locationId}].county`, '')),
		'County',
		'',
	);
	const minimumRequiredState = _.includes(['NM', 'OK', 'TX'], state);

	if (!isBlank(buildings)) {
		_.forIn(buildings, (building) => {
			const bldgLimit = building.buildingLimit ? _.toNumber(building.buildingLimit) : 0;
			const bppLimit = building.bppLimit ? _.toNumber(building.bppLimit) : 0;
			if (minimumRequiredState) {
				const numStories = isBlank(building.numberOfStories) ? 1 : _.toNumber(_.get(building, 'numberOfStories', 1));
				modifiedBuildingTotal += bldgLimit / numStories;
			}
			totalLimits = totalLimits + bldgLimit + bppLimit;
			totalRoofArea =
				totalRoofArea +
				(isBlank(_.get(building, 'roofArea', '')) ? _.get(building, 'squareFootage', 0) : _.get(building, 'roofArea'));
		});
	}

	// Run required rules, then bucket rules, then state/county rules
	switch (_.toNumber(values.propertyDeductibleAmount)) {
		case 1000:
			if (minimumRequiredState && notTier1County(quote, values) && modifiedBuildingTotal >= 250000) {
				returnMessage = windHailMinimumByPercent(values, totalLimits);
			}

			if (isBlank(returnMessage)) {
				if (
					totalLimits <= 20000 &&
					_.includes(['1', '2', '5', '1000', '25000', '50000', '75000', '100000'], values.windHailDeductible)
				) {
					returnMessage = messageJson.propDed1000msg1;
				}
				if (
					_.inRange(totalLimits, 20001, 50001) &&
					_.includes(['1', '2', '1000', '50000', '75000', '100000'], values.windHailDeductible)
				) {
					returnMessage = messageJson.propDed1000msg2;
				}
				if (totalLimits > 50000 && values.windHailDeductible === '1000') {
					returnMessage = messageJson.propDed1000msg3;
				}
			}
			break;
		case 2500:
			if (minimumRequiredState && notTier1County(quote, values) && modifiedBuildingTotal >= 500000) {
				returnMessage = windHailMinimumByPercent(values, totalLimits);
			}
			if (isBlank(returnMessage)) {
				if (
					totalLimits <= 50000 &&
					_.includes(['1', '2', '5', '1000', '2500', '50000', '75000', '100000'], values.windHailDeductible)
				) {
					returnMessage = messageJson.propDed2500msg1;
				}
				if (
					_.inRange(totalLimits, 50001, 125001) &&
					_.includes(['1', '2', '1000', '2500'], values.windHailDeductible)
				) {
					returnMessage = messageJson.propDed2500msg2;
				}
				if (_.inRange(totalLimits, 125001, 250001) && _.includes(['1', '1000', '2500'], values.windHailDeductible)) {
					returnMessage = messageJson.propDed2500msg3;
				}
				if (totalLimits > 250001 && _.includes(['1000', '2500'], values.windHailDeductible)) {
					returnMessage = messageJson.propDed2500msg4;
				}
			}
			break;
		case 5000:
			if (minimumRequiredState && notTier1County(quote, values) && modifiedBuildingTotal >= 750000) {
				returnMessage = windHailMinimumByPercent(values, totalLimits);
			}
			if (isBlank(returnMessage)) {
				if (
					totalLimits <= 100000 &&
					_.includes(['1', '2', '5', '1000', '2500', '5000', '50000', '75000', '100000'], values.windHailDeductible)
				) {
					returnMessage = messageJson.propDed5000msg1;
				}
				if (
					_.inRange(totalLimits, 100001, 250001) &&
					_.includes(['1', '2', '1000', '2500', '5000'], values.windHailDeductible)
				) {
					returnMessage = messageJson.propDed5000msg2;
				}
				if (
					_.inRange(totalLimits, 250001, 500001) &&
					_.includes(['1', '1000', '2500', '5000'], values.windHailDeductible)
				) {
					returnMessage = messageJson.propDed5000msg3;
				}
				if (totalLimits > 500000 && _.includes(['1000', '2500', '5000'], values.windHailDeductible)) {
					returnMessage = messageJson.propDed5000msg4;
				}
			}
			break;
		case 7500:
			if (minimumRequiredState && notTier1County(quote, values) && modifiedBuildingTotal >= 1000000) {
				returnMessage = windHailMinimumByPercent(values, totalLimits);
			}
			if (isBlank(returnMessage)) {
				if (
					totalLimits <= 150000 &&
					_.includes(
						['1', '2', '5', '1000', '2500', '5000', '7500', '50000', '75000', '100000'],
						values.windHailDeductible,
					)
				) {
					returnMessage = messageJson.propDed7500msg1;
				}
				if (
					_.inRange(totalLimits, 150001, 375001) &&
					_.includes(['1', '2', '1000', '2500', '5000', '7500'], values.windHailDeductible)
				) {
					returnMessage = messageJson.propDed7500msg2;
				}
				if (
					_.inRange(totalLimits, 375001, 750001) &&
					_.includes(['1', '1000', '2500', '5000', '7500'], values.windHailDeductible)
				) {
					returnMessage = messageJson.propDed7500msg3;
				}
				if (totalLimits > 750000 && _.includes(['1000', '2500', '5000', '7500'], values.windHailDeductible)) {
					returnMessage = messageJson.propDed7500msg4;
				}
			}
			break;
		case 10000:
			if (minimumRequiredState && notTier1County(quote, values) && modifiedBuildingTotal >= 1000000) {
				returnMessage = windHailMinimumByPercent(values, totalLimits);
			}
			if (isBlank(returnMessage)) {
				if (
					totalLimits <= 200000 &&
					_.includes(
						['1', '2', '5', '1000', '2500', '5000', '7500', '10000', '50000', '75000', '100000'],
						values.windHailDeductible,
					)
				) {
					returnMessage = messageJson.propDed10000msg1;
				}
				if (
					_.inRange(totalLimits, 200001, 500001) &&
					_.includes(['1', '2', '1000', '2500', '5000', '7500', '10000'], values.windHailDeductible)
				) {
					returnMessage = messageJson.propDed10000msg2;
				}
				if (
					_.inRange(totalLimits, 500001, 1000001) &&
					_.includes(['1', '1000', '2500', '5000', '7500', '10000'], values.windHailDeductible)
				) {
					returnMessage = messageJson.propDed10000msg3;
				}
				if (totalLimits > 1000000 && _.includes(['1000', '2500', '5000', '7500', '10000'], values.windHailDeductible)) {
					returnMessage = messageJson.propDed10000msg4;
				}
			}
			break;
		default:
			returnMessage = '';
	}

	if (!isBlank(returnMessage)) {
		buildingsToTest.push([() => false, returnMessage]);
	}

	// Run State rules only if primary rules passed
	if (isBlank(returnMessage)) {
		switch (state) {
			case 'AL':
				if (_.includes(windHail_AL_refer, county)) {
					checkCounty(values, buildingsToTest, totalRoofArea, totalLimits, county);
				}
				break;
			case 'GA':
				if (_.includes(windHail_GA_refer, county)) {
					checkCounty(values, buildingsToTest, totalRoofArea, totalLimits, county);
				}
				break;
			case 'MS':
				if (_.includes(windHail_MS_refer, county)) {
					checkCounty(values, buildingsToTest, totalRoofArea, totalLimits, county);
				}
				break;
			case 'TX':
				texasRules(values, buildingsToTest, totalLimits, county);
				break;
			default:
				break;
		}
	}
	return buildingsToTest;
}

function checkCounty(values, buildingsToTest, totalRoofArea, totalLimits, county) {
	if (isBlank(values.windHailDeductible)) {
		buildingsToTest.push([
			() => false,
			_.replace(messageJson.countyRequired, 'XX', _.get(values, 'addressL.county', '')),
		]);
	} else if (values.gaWest95 === 'N') {
		// Base messages on whether these percentages are allowed. If they are less than the property deductible stick to non-state specific rules
		if (!_.includes(['2', '5'], values.windHailDeductible)) {
			const twoPercentAllowed = (totalLimits * 2) / 100 >= values.propertyDeductibleAmount;
			const fivePercentAllowed = (totalLimits * 5) / 100 >= values.propertyDeductibleAmount;
			if (twoPercentAllowed) {
				buildingsToTest.push([() => false, messageJson.eastOf95LowPercent]);
			} else if (fivePercentAllowed && values.windHailDeductible !== '5') {
				buildingsToTest.push([() => false, messageJson.eastOf95HighPercent]);
			}
		}
	} else {
		roofAreaRules(values, buildingsToTest, totalRoofArea, totalLimits);
	}
}

function roofAreaRules(values, buildingsToTest, totalRoofArea, totalLimits) {
	let currentDeductible = _.get(values, 'windHailDeductible', 0);
	if (currentDeductible <= 5) {
		currentDeductible = totalLimits * (currentDeductible / 100);
	}
	if (totalRoofArea > 100000 && values.windHailDeductible > 5) {
		buildingsToTest.push([
			() => false,
			'Due to the total roof area of all buildings the deductible must be a percentage',
		]);
	} else {
		const amountRequired = _.find(
			sfg_roofAreaWindHailDeductibles,
			(area) => totalRoofArea >= area.min && totalRoofArea <= area.max,
		);
		if (currentDeductible < amountRequired.deductAmount) {
			buildingsToTest.push([() => false, messageJson.roofAreaMsg + amountRequired.deductDisplay]);
		}
	}
}

function texasRules(values, buildingsToTest, totalLimits, county) {
	let texasWindHailSatisfied = true;
	const requiredTexasLimit = totalLimits * 0.02;

	if (_.includes(windHail_TX_mandatory, county) && !_.includes(['2', '5'], values.windHailDeductible)) {
		if (isBlank(values.windHailDeductible) || values.windHailDeductible === '1') {
			texasWindHailSatisfied = false;
		}
		if (requiredTexasLimit > _.toNumber(values.windHailDeductible)) {
			texasWindHailSatisfied = false;
		}
		if (!texasWindHailSatisfied) {
			buildingsToTest.push([
				() => false,
				requiredTexasLimit < 100000
					? `This location needs at least a 2% wind/hail deductible or a flat wind/hail deductible that is greater than ${requiredTexasLimit}`
					: 'This location needs at least a 2% wind/hail deductible',
			]);
		}
	}
}

function windHailMinimumByPercent(values, totalLimits) {
	let windHailMinimumMessage = '';
	const minimum = totalLimits * 0.01;
	const flatValueCheck = duplicate(sfg_windHail);
	const flatDollarValue = flatValueCheck.reduce((prev, curr) => {
		return curr.value > 5 && prev.value < minimum && curr.value > minimum ? curr : prev;
	});
	const currentWindHailDeductible = _.toNumber(_.get(values, 'windHailDeductible', 0));
	if (flatDollarValue.value > currentWindHailDeductible && !_.includes([1, 2, 5], currentWindHailDeductible)) {
		windHailMinimumMessage = `Based on the total limits a minimum of ${flatDollarValue.text} or 1% deductible is required`;
	}
	return windHailMinimumMessage;
}
