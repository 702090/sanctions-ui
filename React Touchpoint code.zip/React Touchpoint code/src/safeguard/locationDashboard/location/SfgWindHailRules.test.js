import { windHailCheck } from './SfgWindHailRules';

describe('Wind/Hail Rules', () => {
	describe('Oklahoma location with wind/hail not required, 1,000 property deductible', () => {
		//	$1,000 for the Property Deductible amount
		//	Building – one story with $240,000 building limit and $20,000 BPP limit
		//	Wind Hail is not required (modified building value is $240,000)

		const values = {
			propertyDeductibleAmount: '1000',
			addressL: {
				state: 'OK',
				county: 'Not Relevant',
			},
		};
		const buildings = {
			bldg1: {
				bppLimit: 20000,
				order: 1,
				numberOfStories: 1,
				buildingLimit: 240000,
			},
		};

		test('1 - Wind Hail Deductible is Undefined, Property deductible 1,000, wind/hail not required', () => {
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
		test('2 - Wind Hail Deductible is $1,000, Property deductible 1,000 and per previous rules not allowed, wind/hail not required', () => {
			values.windHailDeductible = '1000';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining([
					'Based on the total building limits the wind/hail deductible cannot be equal to $1,000.',
				]),
			);
		});
	});

	describe('Texas location with wind/hail required, 1,000 property deductible', () => {
		// $1,000 for the Property Deductible amount
		// Building – two story with $700,000 building limit and $150,000 BPP limit
		// Wind Hail is required
		// (all limits added together is 850,000 so 1% is $8,500 and the next highest flat deductible is $10,000)

		const values = {
			propertyDeductibleAmount: '1000',
			addressL: {
				state: 'TX',
				county: 'Not Relevant',
			},
			windHailDeductible: '',
		};
		const buildings = {
			bldg1: {
				bppLimit: 150000,
				order: 1,
				numberOfStories: 2,
				buildingLimit: 700000,
			},
		};

		test('3 - Wind Hail Deductible is blank, Property deductible 1,000, wind/hail required', () => {
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining(['Based on the total limits a minimum of $10,000 or 1% deductible is required']),
			);
		});
		test('4 - Wind Hail Deductible is 1%, Property deductible 1,000, wind/hail required', () => {
			values.windHailDeductible = '1';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
	});

	describe('New Mexico location with wind/hail required, 2,500 property deductible', () => {
		// $2,500 for the Property Deductible amount
		//	Building 1 – two story with $400,000 building limit and $100,000 BPP limit
		//	Building 2 – one story with $200,000 building limit and $50,000 BPP limit
		//	Building 3 – one story with $100,000 building limit and $20,000 BPP limit
		//	Wind Hail is required (modified building value is $500,000)
		// All limits added together equal 870,000 so 1% is $8,700 and the next highest flat deductible is $10,000

		const values = {
			propertyDeductibleAmount: '2500',
			addressL: {
				state: 'NM',
				county: 'Not Relevant',
			},
			windHailDeductible: '0',
		};
		const buildings = {
			bldg1: {
				bppLimit: 100000,
				order: 1,
				numberOfStories: 2,
				buildingLimit: 400000,
			},
			bldg2: {
				bppLimit: 50000,
				order: 2,
				numberOfStories: 1,
				buildingLimit: 200000,
			},
			bldg3: {
				bppLimit: 20000,
				order: 3,
				numberOfStories: 1,
				buildingLimit: 100000,
			},
		};

		test('5 - Wind Hail Deductible is none, Property deductible 2,500, wind/hail required', () => {
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining(['Based on the total limits a minimum of $10,000 or 1% deductible is required']),
			);
		});
		test('6 - Wind Hail Deductible is 10000, Property deductible 2,500, wind/hail required', () => {
			values.windHailDeductible = '10000';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
	});

	describe('Oklahoma location with wind/hail not required, 2,500 property deductible', () => {
		// $2,500 for the Property Deductible amount
		// Building – one story with $400,000 building limit and $50,000 BPP limit
		//	Wind Hail is not required (modified building value is $400,000)
		const values = {
			propertyDeductibleAmount: '2500',
			addressL: {
				state: 'OK',
				county: 'Not Relevant',
			},
			windHailDeductible: '0',
		};
		const buildings = {
			bldg1: {
				bppLimit: 50000,
				order: 1,
				numberOfStories: 1,
				buildingLimit: 400000,
			},
		};

		test('7 - Wind Hail Deductible is Undefined, Property deductible 2,500, wind/hail not required', () => {
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
		test('8 - Wind Hail Deductible is an acceptable amount, Property deductible 2,500, wind/hail not required', () => {
			values.windHailDeductible = '5000';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
		test('9 - Wind Hail Deductible is $2,500, Property deductible 2,500 and per previous rules not allowed, wind/hail not required', () => {
			values.windHailDeductible = '2500';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining([
					'Based on the total building limits the wind/hail deductible cannot be equal to $1,000 or $2,500.',
				]),
			);
		});
	});

	describe('Texas location with wind/hail not required, 5,000 property deductible', () => {
		// $5,000 for the Property Deductible amount
		// Building 1 – one story with $500,000 BPP limit
		// Wind Hail is not required (no building limit for tenant occupied)

		const values = {
			propertyDeductibleAmount: '5000',
			addressL: {
				state: 'TX',
				county: 'Not Relevant',
			},
			windHailDeductible: '0',
		};
		const buildings = {
			bldg1: {
				bppLimit: 500000,
				order: 1,
			},
		};

		test('10 - Wind Hail Deductible is none, Property deductible 5,000, bpp only, wind/hail not required', () => {
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
		test('11 - Wind Hail Deductible is 7500, Property deductible 5,000, bpp only, wind/hail not required and selected amount greater than minimum allowed', () => {
			values.windHailDeductible = '7500';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
		test('12 - Wind Hail Deductible is 5000, Property deductible 5,000, bpp only, wind/hail not required but per previous rules this is too low', () => {
			values.windHailDeductible = '2500';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining([
					'Based on total building limits the wind/hail deductible cannot be 1%, or a flat deductible less than $7,500.',
				]),
			);
		});
	});

	describe('New Mexico location with wind/hail required, 5,000 property deductible', () => {
		// $5,000 for the Property Deductible amount
		// Building 1 – two story, $1,000,000 building limit and $90,000 BPP limit
		// Building 2 – one story, $1,500,000 building limit and $100,000 BPP limit
		// Building 3 – one story, $1,000,000 building limit and $120,000 BPP limit
		// Wind Hail is required (modified building value is $3,000,000)
		// All limits added together equal 3,810,000 so 1% is $38,100 and the next highest flat deductible is $50,000
		// Error message “Based on the total limits a minimum of $50,000 or 1% deductible is required.”
		const values = {
			propertyDeductibleAmount: '5000',
			addressL: {
				state: 'NM',
				county: 'Not Relevant',
			},
			windHailDeductible: '0',
		};
		const buildings = {
			bldg1: {
				bppLimit: 90000,
				order: 1,
				numberOfStories: 2,
				buildingLimit: 1000000,
			},
			bldg2: {
				bppLimit: 100000,
				order: 2,
				numberOfStories: 1,
				buildingLimit: 1500000,
			},
			bldg3: {
				bppLimit: 120000,
				order: 3,
				numberOfStories: 1,
				buildingLimit: 1000000,
			},
		};

		test('13 - Wind Hail Deductible is none, Property deductible 5,000, wind/hail required', () => {
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining(['Based on the total limits a minimum of $50,000 or 1% deductible is required']),
			);
		});
		test('14 - Wind Hail Deductible is none, Property deductible 5,000, wind/hail required, minimum fixed amount selected', () => {
			values.windHailDeductible = '50000';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
		test('15 - Wind Hail Deductible is none, Property deductible 5,000, wind/hail required, less than the minimum is selected', () => {
			values.windHailDeductible = '25000';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining(['Based on the total limits a minimum of $50,000 or 1% deductible is required']),
			);
		});
	});

	describe('Oklahoma location with wind/hail required, 7,500 property deductible', () => {
		// $7,500 for the Property Deductible amount
		// Building 1 – one story with $700,000 building limit and $100,000 BPP limit
		// Building 1 – Building 2 – two story with 750,000 building limit and $50,000 BPP limit
		// Wind Hail is required (modified building value is 1,075,000)
		// All limits added together equal 1,600,000 so 1% is $16,000 and the next highest flat deductible is $25,000
		const values = {
			propertyDeductibleAmount: '7500',
			addressL: {
				state: 'OK',
				county: 'Not Relevant',
			},
			windHailDeductible: '0',
		};
		const buildings = {
			bldg1: {
				bppLimit: 100000,
				order: 1,
				numberOfStories: 1,
				buildingLimit: 700000,
			},
			bldg2: {
				bppLimit: 50000,
				order: 2,
				numberOfStories: 2,
				buildingLimit: 750000,
			},
		};

		test('16 - Wind Hail Deductible is none, Property deductible 7,500, wind/hail required', () => {
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining(['Based on the total limits a minimum of $25,000 or 1% deductible is required']),
			);
		});
		test('17 - Wind Hail Deductible is none, Property deductible 7,500, wind/hail required, minimum fixed amount selected', () => {
			values.windHailDeductible = '25000';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
		test('18 - Wind Hail Deductible is none, Property deductible 7,500, wind/hail required, less than the minimum is selected', () => {
			values.windHailDeductible = '2500';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining(['Based on the total limits a minimum of $25,000 or 1% deductible is required']),
			);
		});
	});

	describe('Texas location with wind/hail not required, 7,500 property deductible', () => {
		// $7,500 for the Property Deductible amount
		// Building 1 – one story with $500,000 building limit and $100,000 BPP limit
		// Building 2 – two story with $750,000 building limit and $50,000 BPP limit
		// Wind Hail is not required (modified building value is 875,000)
		const values = {
			propertyDeductibleAmount: '7500',
			addressL: {
				state: 'TX',
				county: 'Not Relevant',
			},
			windHailDeductible: '0',
		};
		const buildings = {
			bldg1: {
				bppLimit: 100000,
				order: 1,
				numberOfStories: 1,
				buildingLimit: 500000,
			},
			bldg2: {
				bppLimit: 50000,
				order: 1,
				numberOfStories: 2,
				buildingLimit: 750000,
			},
		};

		test('19 - Wind Hail Deductible is Undefined, Property deductible 7,500, wind/hail not required', () => {
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
		test('20 - Wind Hail Deductible is an acceptable amount, Property deductible 7,500, wind/hail not required', () => {
			values.windHailDeductible = '10000';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
		test('21 - Wind Hail Deductible is $7,500, Property deductible 7,500 and per previous rules not allowed, wind/hail not required', () => {
			values.windHailDeductible = '7500';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining([
					'Based on total building limits the wind/hail deductible must be a percentage or a flat deductible greater than or equal to $10,000.',
				]),
			);
		});
	});

	describe('New Mexico location with wind/hail required, 10,000 property deductible', () => {
		// $10,000 for the Property Deductible amountt
		// Building – one story with $2,500,000 building limit and $700,000 BPP limit
		// Wind Hail is required (modified building value of $2,500,000)
		// All limits added together is 3,200,000 so 1% is $32,000 and the next highest flat deductible is $50,000
		const values = {
			propertyDeductibleAmount: '10000',
			addressL: {
				state: 'NM',
				county: 'Not Relevant',
			},
			windHailDeductible: '',
		};
		const buildings = {
			bldg1: {
				bppLimit: 700000,
				order: 1,
				numberOfStories: 1,
				buildingLimit: 2500000,
			},
		};

		test('22 - Wind Hail Deductible is blank, Property deductible 10,000, wind/hail required', () => {
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining(['Based on the total limits a minimum of $50,000 or 1% deductible is required']),
			);
		});
		test('23 - Wind Hail Deductible is none, Property deductible 10,000, wind/hail required, minimum fixed amount selected', () => {
			values.windHailDeductible = '50000';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
		test('24 - Wind Hail Deductible is none, Property deductible 10,000, wind/hail required, less than the minimum is selected', () => {
			values.windHailDeductible = '25000';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining(['Based on the total limits a minimum of $50,000 or 1% deductible is required']),
			);
		});
	});

	describe('Oklahoma location with wind/hail not required, 10,000 property deductible', () => {
		// $10,000 for the Property Deductible amount
		// Building 1 – one story with $900,000 building limit and $700,000 BPP limit
		// Wind Hail is not required (modified building value of $900,000)
		const values = {
			propertyDeductibleAmount: '10000',
			addressL: {
				state: 'OK',
				county: 'Not Relevant',
			},
			windHailDeductible: '0',
		};
		const buildings = {
			bldg1: {
				bppLimit: 700000,
				order: 1,
				numberOfStories: 1,
				buildingLimit: 900000,
			},
		};

		test('25 - Wind Hail Deductible is Undefined, Property deductible 10,000, wind/hail not required', () => {
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
		test('26 - Wind Hail Deductible is an acceptable amount, Property deductible 10,000, wind/hail not required', () => {
			values.windHailDeductible = '25000';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
		test('27 - Wind Hail Deductible is $10,000, Property deductible 10,000 and per previous rules not allowed, wind/hail not required', () => {
			values.windHailDeductible = '10000';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining([
					'Based on total building limits the wind/hail deductible must be a percentage or a flat deductible greater than or equal to $25,000.',
				]),
			);
		});
	});

	describe('Missouri location without new wind/hail implemented', () => {
		// $1,000 for Property Deductible amount
		// Building – one story with $400,000 building limit and $100,000 BPP limit
		// Wind Hail is not required (Missouri is not done yet)
		const values = {
			propertyDeductibleAmount: '1000',
			addressL: {
				state: 'MO',
				county: 'Not Relevant',
			},
			windHailDeductible: '',
		};
		const buildings = {
			bldg1: {
				bppLimit: 100000,
				order: 1,
				numberOfStories: 1,
				buildingLimit: 400000,
			},
		};

		test('28 - Wind Hail Deductible is blank, Property deductible 1,000, wind/hail not required', () => {
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
		test('29 - Wind Hail Deductible is selected, Property deductible 1,000, wind/hail not required, error for previous bucket rules', () => {
			values.windHailDeductible = '1000';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining([
					'Based on the total building limits the wind/hail deductible cannot be equal to $1,000.',
				]),
			);
		});
	});
});

describe('Georgia Wind/Hail Rules for special counties', () => {
	describe('Properties East of 95 with wind/hail required', () => {
		const values = {
			propertyDeductibleAmount: '1000',
			addressL: {
				state: 'GA',
				county: 'Chatham',
			},
			gaWest95: 'N',
		};
		const buildings = {
			bldg1: {
				bppLimit: 20000,
				order: 1,
				numberOfStories: 1,
				buildingLimit: 240000,
				roofArea: 100000,
			},
		};

		const smallBuildings = {
			bldg1: {
				bppLimit: 10000,
				order: 1,
				numberOfStories: 1,
				roofArea: 4100,
			},
		};

		test('30 - Properties east of 95 require 2% wind/hail, wind hail is blank', () => {
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining(['Risks located in Chatham county require a wind/hail deductible']),
			);
		});
		test('31 - Properties east of 95 require 2% wind/hail, wind hail is too low', () => {
			values.windHailDeductible = '1';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining([
					'Due to the total roof area of all buildings the wind/hail deductible must be a percentage greater than or equal to 2%. Please choose a different amount.',
				]),
			);
		});
		test('32 - Properties east of 95 require 2% wind/hail, and correct wind/hail is selected', () => {
			values.windHailDeductible = '2';
			const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
			expect(spectedReturn).toEqual([]);
		});
		test('33 - Properties east of 95 with total modified limit less than $50,000, ignore percentage and use flat deductible rule', () => {
			values.windHailDeductible = '1000';
			const spectedReturn = windHailCheck({}, values, {}, '1', smallBuildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining([
					'Based on total building limits the wind/hail deductible must be a flat deductible between $2,500 and $10,000.',
				]),
			);
		});
		test('34 - Properties east of 95 with total modified limit less than $50,000, accept flat eligible deductibles between prop ded and max total limit', () => {
			values.windHailDeductible = '2500';
			const spectedReturn = windHailCheck({}, values, {}, '1', smallBuildings);
			expect(spectedReturn).toEqual([]);
		});
		test('35 - Properties east of 95 with total modified limit exactly $50,000, do not use GA East specific rules because percent is not greater than property deductible', () => {
			values.windHailDeductible = '1000';
			smallBuildings.bppLimit = 50000;
			const spectedReturn = windHailCheck({}, values, {}, '1', smallBuildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining([
					'Based on total building limits the wind/hail deductible must be a flat deductible between $2,500 and $10,000.',
				]),
			);
		});
		test('36 - Properties east of 95 with total modified limit exactly $50,000, do not use GA East specific rules because percent is not greater than property deductible', () => {
			values.windHailDeductible = '2500';
			smallBuildings.bppLimit = 50000;
			const spectedReturn = windHailCheck({}, values, {}, '1', smallBuildings);
			expect(spectedReturn).toEqual([]);
		});
		test('37 - Properties east of 95 with total modified limit exactly $50,000, error on percentage', () => {
			values.windHailDeductible = '2';
			smallBuildings.bppLimit = 50000;
			const spectedReturn = windHailCheck({}, values, {}, '1', smallBuildings);
			expect(spectedReturn[0]).toEqual(
				expect.arrayContaining([
					'Based on total building limits the wind/hail deductible must be a flat deductible between $2,500 and $10,000.',
				]),
			);
		});
	});
});

describe('Texas special rules', () => {
	// TODO build these out when there's more time
	const values = {
		propertyDeductibleAmount: '1000',
		addressL: {
			state: 'TX',
			county: 'Goliad',
		},
	};
	const buildings = {
		bldg1: {
			bppLimit: 20000,
			order: 1,
			numberOfStories: 1,
			buildingLimit: 150000,
		},
	};

	test('38 - Wind Hail is blank but required in this county', () => {
		const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
		expect(spectedReturn[0]).toEqual(
			expect.arrayContaining([
				'This location needs at least a 2% wind/hail deductible or a flat wind/hail deductible that is greater than 3400',
			]),
		);
	});
	test('39 - Wind hail required by county and minimum met', () => {
		values.windHailDeductible = '2';
		const spectedReturn = windHailCheck({}, values, {}, '1', buildings);
		expect(spectedReturn).toEqual([]);
	});
});
