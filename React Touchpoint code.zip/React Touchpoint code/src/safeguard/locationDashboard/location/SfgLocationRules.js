import classCodeListsJson from 'data/ClassCodeLists';
import countyListsJson from 'data/CountyLists';
import { getFieldDisplayArray, requiredQuestionMessage } from 'data/FieldVisibility';
import _ from 'lodash';
import { getVisibility } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { windHailCheck } from './SfgWindHailRules';

export default class SfgLocationRules {
	static requiredStructure = {
		addressL: { fullAddress: '', county: '' },
		propertyDeductibleAmount: '',
		protectionClass: '',
		grossSales: '',
		island: '',
		separateWind: '',
		floodCoverage: '',
		tidalWater: '',
		gaWest95: '',
		windHailDeductible: '',
	};

	static optionalStructure = {};

	static rules(quote, values, visibility, serviceStatus, dashboardCallId) {
		if (!visibility) {
			visibility = getVisibility(getFieldDisplayArray('safeguardLocation'), quote, values);
		}
		const { ineligibleClasses } = classCodeListsJson;
		const { windHail_AL_error, windHail_MS_error } = countyListsJson;

		const locationId = values.id ? values.id : dashboardCallId;

		const buildings = _.get(quote, `sfg.locations.${locationId}.buildings`, '');

		const zipFive = _.get(values, 'addressL.zip', '').substring(0, 5);
		const locState = _.toUpper(_.get(values, 'addressL.state', ''));
		const cleanedCounty = _.replace(_.get(values, 'addressL.county', ''), ' County', '');
		const windAllowedByCounty = !(
			(locState === 'AL' &&
				_.includes(
					windHail_AL_error,
					cleanedCounty, // TODO: may want to do this in the data load from Google
				)) ||
			(locState === 'MS' &&
				_.includes(
					windHail_MS_error,
					cleanedCounty, // TODO: may want to do this in the data load from Google
				))
		);

		const windAllowedByCity = !(
			locState === 'GA' &&
			_.includes(
				['Jekyll Island', 'St Simons Island', 'St Simons Is', 'Saint Simons Island', 'Sea Island', 'Tybee Island'],
				_.get(values, 'addressL.city', ''),
			)
		);

		let buildingsToTest = [];
		if (!isBlank(buildings) && windAllowedByCounty && windAllowedByCity) {
			buildingsToTest = windHailCheck(quote.addresses, values, quote, locationId, buildings);
		}
		const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));

		return {
			addressL: {
				fullAddress: [
					[(value) => !isBlank(value), 'Address is required.'],
					[
						(value) => serviceStatus.addressValidation || _.get(values, 'addressL.zip', '') !== '00000',
						'This address must include a valid zipcode.',
					],
					[(value) => !_.get(values, 'addressL.poBox'), 'Po boxes are not allowed.'],
					[
						(value) => serviceStatus.addressValidation || !_.includes(ineligibleClasses, zipFive),
						`Risks located in ZIP Code ${zipFive} are not eligible for our Safeguard program.`,
					],
					[
						(value) =>
							serviceStatus.addressValidation || _.includes(agent.writingStates, _.get(values, 'addressL.state', '')),
						'We are not licensed to write business in this state, please delete this location to continue with the quote.',
					],
					[
						(value) => !isBlank(_.get(values, 'addressL.streetNumber', '')),

						'Please make sure you have entered a street address.',
					],
					[
						(value) => windAllowedByCounty,
						`Risks located in ${_.get(
							values,
							'addressL.county',
							'',
						)} are not eligible to be quoted due to increased wind or hail exposure.`,
					],
					[
						(value) => {
							return windAllowedByCity;
						},
						`Risks located in ${_.get(
							values,
							'addressL.city',
							'',
						)} are not eligible to be quoted due to increased wind or hail exposure.`,
					],
				],
				county: [[(value) => !isBlank(value), 'County is required.']],
			},
			propertyDeductibleAmount: [[(value) => !isBlank(value), 'Property Deductible Amount is required.']],
			protectionClass: [[(value) => !isBlank(value), 'Protection Class is required.']],
			windHailDeductible: [...buildingsToTest],
			grossSales: [
				[(value) => value > 0, 'Gross Sales is required.'],
				[(value) => _.isInteger(value), 'Gross Sales must be a whole number.'],
				[(value) => value <= 6000000, 'Due to sales in excess of $6M, this risk is ineligible for Safeguard.'],
			],
			island: [
				[(value) => !isBlank(value) || !visibility.island, requiredQuestionMessage],
				[(value) => value !== 'Y', 'Risks located on an island are not eligible for our Safeguard program.'],
			],
			tidalWater: [[(value) => !isBlank(value) || !visibility.tidalWater, requiredQuestionMessage]],
			floodCoverage: [
				[(value) => !isBlank(value) || !visibility.floodCoverage, requiredQuestionMessage],
				[
					(value) => value !== 'N' || values.tidalWater === 'N',
					'This risk is not eligible for our Safeguard program due to no flood coverage.',
				],
			],
			separateWind: [
				[(value) => !isBlank(value) || !visibility.separateWind, requiredQuestionMessage],
				[
					(value) => value !== 'N' || !visibility.separateWind,
					'This risk is not eligible for our Safeguard program due to no separate wind coverage.',
				],
			],
			gaWest95: [[(value) => !isBlank(value) || !visibility.gaWest95, requiredQuestionMessage]],
		};
	}
	static referrals(context, values) {
		// use values for current page validation
		// use quote for external page validation
		return {
			addressL: {
				fullAddress: [[(value) => _.get(values, 'addressL.validated', false), 'SLL02']],
			},
			protectionClass: [
				[(value) => !(value.split('|')[1] === '09'), 'SLL03'],
				[(value) => !(value.split('|')[1] === '10'), 'SLL04'],
			],
			gaWest95: [[(value) => value !== 'Y', 'SLL01']],
		};
	}
	static name() {
		return 'sfgLocation';
	}
}
