import { ModalStepper } from 'components/shared/navigation/ModalStepper';
import QuoteContext from 'context/quoteContext';
import _ from 'lodash';
import React, { Component } from 'react';
import SafeguardLocationForm from 'safeguard/locationDashboard/location/SfgLocationForm';
import { Modal, Radio } from 'semantic-ui-react';
import { getFirstBuilding } from 'utils/BusinessFunctions';
import { pageAnalytics } from 'utils/ScreenFunctions';
import { replaceReferrals } from 'validation/RunReferrals';

export default class LocationModal extends Component {
	static contextType = QuoteContext;

	constructor() {
		super();
		this.state = {
			isOpen: false,
		}; // state to control the state of popup
	}

	componentDidMount() {
		this.props.onLoad();
	}

	handleOpen = (callBack, locationId, newLocation, buildingId) => {
		this.setState({
			isOpen: true,
			locationId,
			newLocation,
			callBack,
			buildingId,
		});
		pageAnalytics(this.props.location.pathname + '/SfgLocationModal', true);
	};

	handleClose = () => {
		this.setState({ isOpen: false });
		replaceReferrals(this.context);
		pageAnalytics(this.props.location.pathname);
		this.state.callBack();
	};

	render() {
		const { newLocation, locationId, callBack } = this.state;
		let firstBuildingId;
		let building = {};
		if (locationId && !newLocation) {
			firstBuildingId = getFirstBuilding(_.get(this.context, `quote.sfg.locations.${locationId}`));
			building = _.get(
				this.context,
				`quote.sfg.locations.${locationId}.buildings.${this.state.buildingId || firstBuildingId}`,
			);
		}
		return (
			<Modal
				closeIcon
				open={this.state.isOpen}
				closeOnDimmerClick={false}
				onClose={this.handleClose}
				className='banded'
			>
				<div id='colorBlock' className='loc'>
					{!newLocation && building && (
						<React.Fragment>
							<span>Location</span>
							<Radio
								toggle
								name='locationBuildingToggle'
								onChange={(e) => {
									this.context.refBuilding.current.handleOpen(
										callBack,
										locationId,
										false,
										this.state.buildingId || firstBuildingId,
										false,
										building,
									);
									this.handleClose();
								}}
							/>
							<span>
								Building
								{building.order}
							</span>
						</React.Fragment>
					)}
				</div>
				<ModalStepper
					currentModal='safeguardLocation'
					handleClose={this.handleClose}
					locationId={locationId}
					newLocation={newLocation}
				/>
				<Modal.Content>
					<SafeguardLocationForm
						id={locationId}
						handleClose={this.handleClose}
						newLocation={newLocation}
						callBack={callBack}
						{...this.props}
					/>
				</Modal.Content>
			</Modal>
		);
	}
}
