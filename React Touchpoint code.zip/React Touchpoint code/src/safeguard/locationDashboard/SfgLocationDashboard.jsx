import { ModeButton } from 'components/shared/buttons/ModeButton';
import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import ConfirmModal from 'components/shared/modals/ConfirmModal';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { toSortedPairList } from 'components/shared/navigation/NavigationFunctions';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import productNamesJson from 'data/ProductNames';
import { Form, Formik } from 'formik';
import { runAllLocationRules, runDashboardAndAllRulesNew } from 'helper/Validation';
import _ from 'lodash';
import React, { Component } from 'react';
import BuildingModal from 'safeguard/locationDashboard/building/BuildingModal';
import BuildingCoveragesModal from 'safeguard/locationDashboard/buildingCoverages/BuildingCoveragesModal';
import BuildingQuestionsModal from 'safeguard/locationDashboard/buildingQuestions/BuildingQuestionsModal';
import { BuildingSection } from 'safeguard/locationDashboard/components/BuildingSection';
import { LocationSection } from 'safeguard/locationDashboard/components/LocationSection';
import LocationModal from 'safeguard/locationDashboard/location/SfgLocationModal';
import LocationCoveragesModal from 'safeguard/locationDashboard/locationCoverage/SfgLocationCoveragesModal';
import SfgLocationDashboardRules from 'safeguard/locationDashboard/SfgLocationDashboardRules';
import {
	checkAddressUsed,
	cleanAdditionalInterests,
	cleanWorkCompClassCodes,
	findFirstPDDeductible,
} from 'utils/BusinessFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import { cleanReferrals, logPageErrors } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { v4 as uuidv4 } from 'uuid';
import { checkReferrals, removeReferrals } from 'validation/Validate';

const { productNames } = productNamesJson;
export default class SafeguardLocationDashboard extends Component {
	static contextType = QuoteContext;

	dirty = false;

	state = { mode: 'basic', locationModalLoaded: true };

	runRules = true;

	constructor() {
		super();
		this.locationModal = React.createRef();
		this.buildingModal = React.createRef();
		this.buildingQuestionsModal = React.createRef();
		this.buildingCoveragesModal = React.createRef();
		this.locationCoveragesModal = React.createRef();
		this.confirmModal = React.createRef();
	}

	componentDidMount() {
		// If the form is not empty, trigger validation
		if (_.values(this.formProps.initialValues).some((x) => x !== undefined)) {
			this.formProps.validateForm().then((validation) => this.formProps.setTouched(validation));
		}
	}

	openCopyMode = () => {
		this.setState({ mode: 'copy' });
	};

	openDeleteMode = () => {
		this.setState({ mode: 'delete' });
	};

	closeOpenMode = () => {
		this.runRules = true;
		this.setState({ mode: 'basic' });
	};

	copyBuilding = (locId, bldgId) => {
		//TODO:run building referrals on new building
		const { quote } = this.context;
		const buildings = _.get(quote, `sfg.locations.${locId}.buildings`);
		const oldBuilding = buildings[bldgId];

		const newBuilding = duplicate(oldBuilding);
		newBuilding.id = uuidv4();
		newBuilding.order = Object.keys(buildings).length + 1;
		newBuilding.originalPrimary = false;
		_.set(newBuilding, 'questions.reviewedCorrect', '');

		_.set(quote, `sfg.locations.${locId}.buildings.${newBuilding.id}`, newBuilding);
		const { updateQuote } = this.context;

		updateQuote(quote, this.props);
	};

	deleteBuilding = (locId, bldgId) => {
		removeReferrals(this.context, locId, '', bldgId);
		const { quote, updateQuote } = this.context;
		const buildings = _.get(quote, `sfg.locations.${locId}.buildings`);
		const removedOrder = buildings[bldgId].order;

		cleanReferrals(quote.referrals, bldgId);
		cleanAdditionalInterests({ quote, propertyId: locId, bldgId, deleteBuilding: true });

		_.unset(buildings, bldgId);

		// If this was the only location with contractors - remove policy level pdDeductible
		const { firstPDDeductibleBuilding } = findFirstPDDeductible(quote);
		if (firstPDDeductibleBuilding === -1) {
			_.set(quote, 'sfg.pdDeductible', '');
			_.set(quote, 'sfg.pdDeductibleType', '');
		}

		_.forIn(buildings, (bldg, id) => {
			if (bldg.order > removedOrder) {
				bldg.order -= 1;
				if (bldg.order === 1 && _.get(quote, `sfg.locations.${locId}.buildings.${id}.ancillaryBuilding`, '') === 'Y') {
					_.set(quote, `sfg.locations.${locId}.buildings.${id}.liabilityExposureBasis`, '');
					_.set(quote, `sfg.locations.${locId}.buildings.${id}.ancillaryBuilding`, '');
					_.set(quote, `sfg.locations.${locId}.buildings.${id}.originalPrimary`, false);
				}
			}
		});

		updateQuote(quote, this.props);
	};

	deleteLocation = (locId) => {
		removeReferrals(this.context, locId);
		const { quote } = this.context;
		const { addresses } = quote;
		const locations = _.get(quote, 'sfg.locations');
		const buildings = _.get(locations, `${locId}.buildings`);
		_.forIn(buildings, (building, bldgId) => {
			cleanAdditionalInterests({ quote, propertyId: locId, bldgId, deleteBuilding: true });
		});
		const removedOrder = locations[locId].order;
		cleanReferrals(quote.referrals, locId);

		_.unset(locations, locId);

		// If this was the only location with contractors - remove policy level pdDeductible
		const { firstPDDeductibleLocation } = findFirstPDDeductible(quote);
		if (firstPDDeductibleLocation === -1) {
			_.set(quote, 'sfg.pdDeductible', '');
			_.set(quote, 'sfg.pdDeductibleType', '');
		}

		_.forIn(locations, (loc, id) => {
			if (loc.order > removedOrder) {
				loc.order -= 1;
			}
			// Reset quote level business description to first location description
			if (loc.order === 1) {
				_.set(quote, 'businessDescription', _.get(loc, 'prefillData.verisk.businessDescription', ''));
			}
		});
		if (_.has(quote, 'wcp.classCodes')) {
			cleanWorkCompClassCodes(quote, locId);
		}
		if (!checkAddressUsed(quote, locId)) {
			_.unset(addresses, locId);
		}
		const { updateQuote } = this.context;

		updateQuote(quote, this.props);
	};

	render() {
		return (
			<QuoteContext.Provider
				value={{
					...this.context,
					refBldgQuestions: this.buildingQuestionsModal,
					refBldgCoverages: this.buildingCoveragesModal,
					refLocCoverages: this.locationCoveragesModal,
					refLocation: this.locationModal,
					refBuilding: this.buildingModal,
				}}
			>
				{/* these need to stay siblings for the z-index to work */}
				<div id='modeOverlay' className={this.state.mode} onClick={this.closeOpenMode} />
				<div id='modeOverlay_NavigationButtons' className={this.state.mode} onClick={this.closeOpenMode} />
				<div id='modeOverlay_Header' className={this.state.mode}>
					{_.startCase(`${this.state.mode} mode`)}
					<p>
						{this.state.mode === 'copy'
							? 'Click on a building to create a new copy of it.'
							: 'Click on a location or a building to delete it.'}
					</p>
				</div>
				<Formik
					render={(formikProps) => {
						this.dirty = formikProps.dirty;
						this.formProps = formikProps;
						checkReferrals(this.context, formikProps.values, SfgLocationDashboardRules);
						// if (
						//   this.locationModal.current !== null &&
						//   this.state.locationModalLoaded &&
						//   isBlank(_.get(this.context, 'quote.sfg.locations', {}))
						// ) {
						//   this.locationModal.current.handleOpen(
						//     () => {
						//       formikProps.validateForm(formikProps.values);
						//       this.closeOpenMode();
						//     },
						//     'NEW',
						//     true,
						//   );
						// }
						if (this.runRules && !isBlank(_.get(this.context, 'quote.sfg.locations', {}))) {
							formikProps.validateForm(formikProps.values);
							this.runRules = false;
						}

						return (
							<Form id='screen'>
								<PageSection name='section_locations' errors={formikProps.errors}>
									<div id='dashboardButtons'>
										<SimpleButton
											className='newLocationButton'
											primary
											onClick={() =>
												this.locationModal.current.handleOpen(
													() => formikProps.validateForm(formikProps.values),
													'NEW',
													true,
												)
											}
											content='New Location'
										/>
										<div>
											<ModeButton
												openClick={this.openCopyMode}
												closeClick={this.closeOpenMode}
												mode={this.state.mode}
												type='copy'
											/>
											<ModeButton
												openClick={this.openDeleteMode}
												closeClick={this.closeOpenMode}
												mode={this.state.mode}
												type='delete'
											/>
										</div>
									</div>
									<div className='locationDashboard'>
										{toSortedPairList(_.get(this.context, 'quote.sfg.locations', {})).map((locationPair) => (
											<LocationSection
												key={locationPair[0]}
												locationId={locationPair[0]}
												onClick={() => {
													this.locationModal.current.handleOpen(
														() => formikProps.validateForm(formikProps.values),
														locationPair[0],
														false,
													);
												}}
												mode={this.state.mode}
												deleteLocation={(locId, bldgId) => {
													let deleteMessage = "Are you sure you want to delete this location and all of it's building?";
													if (_.has(this.context, 'quote.wcp.classCodes')) {
														let exists = false;
														_.forIn(this.context.quote.wcp.classCodes, (classCode) => {
															if (classCode.location === locId) {
																exists = true;
															}
														});
														if (exists) {
															deleteMessage += ` All ${productNames['wcp']} class codes associated with this address will also be deleted.`;
														}
													}
													this.confirmModal.current.handleOpen('Delete Location', deleteMessage, () =>
														this.deleteLocation(locId),
													);
												}}
												errors={formikProps.errors[locationPair[0]]}
												info={_.get(this.context, `quote.addresses.${locationPair[0]}.fullAddress`)}
											>
												<div className='buildingSection'>
													{toSortedPairList(
														_.get(this.context, `quote.sfg.locations.${locationPair[0]}.buildings`, {}),
													).map((buildingPair) => (
														<div key={buildingPair[0]} className='buildingWrapper'>
															<BuildingSection
																buildingId={buildingPair[0]}
																locationId={locationPair[0]}
																order={buildingPair[1].order}
																mode={this.state.mode}
																copyBuilding={this.copyBuilding}
																deleteBuilding={(locId, bldgId) => {
																	this.confirmModal.current.handleOpen(
																		'Delete Building',
																		'Are you sure you want to delete this building?',
																		() => this.deleteBuilding(locId, bldgId),
																	);
																}}
																errors={formikProps.errors[`${locationPair[0]}|${buildingPair[0]}`]}
																onClick={() =>
																	this.buildingModal.current.handleOpen(
																		() => formikProps.validateForm(formikProps.values),
																		locationPair[0],
																		false,
																		buildingPair[0],
																		false,
																		buildingPair[1],
																	)
																}
															/>
														</div>
													))}

													<div className='buildingWrapper'>
														<div
															className='building newBuildingButton'
															onClick={() =>
																this.buildingModal.current.handleOpen(
																	() => formikProps.validateForm(formikProps.values),
																	locationPair[0],
																	false,
																	'NEW',
																	true,
																	{},
																)
															}
														>
															<i className='fal fa-plus-circle big' />
															<div>Add Building</div>
														</div>
													</div>
												</div>
											</LocationSection>
										))}
										{isBlank(_.get(this.context, 'quote.sfg.locations', {})) && (
											<div className='displayTableInstructions'>
												<p>This is where your locations will show up once you have added one.</p>
												<p>Use the "New Location" button to add a new location.</p>
											</div>
										)}
									</div>
								</PageSection>
								<NavigationButtons
									formikProps={formikProps}
									back
									location={this.props.location}
									datatestId='locationNext'
									history={this.props.history}
									disableNext={this.context.serviceStatus.runningRequiredServices}
								/>
							</Form>
						);
					}}
					initialValues={{}}
					onSubmit={(values, formikActions) => this.context.onSubmit(values, this.dirty, false, false, this.props)}
					validate={(values) => {
						checkReferrals(this.context, values, SfgLocationDashboardRules);
						let validResults = runDashboardAndAllRulesNew(
							this.context.quote,
							values,
							SfgLocationDashboardRules,
							runAllLocationRules,
							this.context.serviceStatus,
						);
						logPageErrors(validResults, this.formProps.touched, 'sfg');
						return validResults;
					}}
				/>
				<LocationModal
					ref={this.locationModal}
					onLoad={() => this.setState({ locationModalLoaded: true })}
					location={this.props.location}
					history={this.props.history}
				/>

				<BuildingModal ref={this.buildingModal} {...this.props} />

				<BuildingQuestionsModal ref={this.buildingQuestionsModal} {...this.props} />

				<BuildingCoveragesModal ref={this.buildingCoveragesModal} {...this.props} />

				<LocationCoveragesModal ref={this.locationCoveragesModal} {...this.props} />
				<ConfirmModal ref={this.confirmModal} />
			</QuoteContext.Provider>
		);
	}
}
