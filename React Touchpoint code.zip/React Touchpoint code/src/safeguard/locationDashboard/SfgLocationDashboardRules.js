import canopyClassesJson from 'data/ClassCodeLists';
import _ from 'lodash';
import { isBlank } from 'utils/StringFunctions';

const { canopyClasses } = canopyClassesJson;

export default class SfgLocationDashboardRules {
	static requiredStructure = {
		section_locations: '',
	};

	static rules(quote) {
		// use values for current page validation
		// use quote for external page validation

		let buildingRequirementSastified = true;
		let ancillaryBuildingEntered = [];

		const locations = _.get(quote, 'sfg.locations', {});
		const addresses = _.get(quote, 'addresses');

		let subLimitTotals = {};
		let subLimitReferrals = [];
		let errorLocations = [];

		_.forIn(locations, (location, id) => {
			let canopyClass = false;
			let hasAncillary = false;
			const { buildings } = location;
			if (isBlank(buildings) && !isBlank(_.get(quote, `addresses.${id}.fullAddress`, ''))) {
				buildingRequirementSastified = false;
			}
			_.forIn(buildings, (building) => {
				if (_.includes(['AL', 'KY', 'MS', 'TN'], addresses[id].state)) {
					subLimitTotals[location.order] =
						(subLimitTotals[location.order] || 0) +
						((building.buildingLimit * (building.eqBuildingSubLimit || 0)) / 100 +
							((building.bppLimit || 0) * (building.eqBPPSubLimit || 0)) / 100);
				}
				if (
					_.includes(canopyClasses, building.classCode) &&
					building.separateCanopy === 'Y' &&
					!building.ancillaryBuilding
				) {
					canopyClass = true;
				}
				if (building.ancillaryBuilding && building.ancillaryDescription === 'Carport') {
					hasAncillary = true;
				}
			});
			if (canopyClass && !hasAncillary) {
				ancillaryBuildingEntered.push([
					() => false,
					`Location ${location.order} requires a canopy ancillary building to be entered`,
				]);
			}
		});

		_.forIn(subLimitTotals, (total, locationNumber) => {
			if (total > 10000000) {
				errorLocations.push(locationNumber);
				if (+locationNumber === Object.keys(subLimitTotals).length && errorLocations.length > 0) {
					subLimitReferrals.push([
						(value) => false,
						`Due to the building characteristics, the Earthquake maximum sublimit of $10,000,000 applies per location.
            Please either lower or remove the sublimit amount on one or more of the buildings from location(s):
            ${errorLocations.join(', ')}.`,
					]);
				}
			}
		});

		return {
			section_locations: [
				[(value) => !isBlank(locations), 'At least one location is required on this quote'],
				[(value) => buildingRequirementSastified, 'Each location must have at least one building'],
				...ancillaryBuildingEntered,
				...subLimitReferrals,
			],
		};
	}

	static referrals(context, values) {
		// use values for current page validation
		// use context for external page validation
		let texasLessorsRisk = false;
		const locations = _.get(context, 'quote.sfg.locations', {});
		const addresses = _.get(context, 'quote.addresses');

		if (!isBlank(locations)) {
			_.forIn(locations, (location, id) => {
				const { buildings } = location;
				if (!isBlank(buildings)) {
					_.forIn(buildings, (building) => {
						if (addresses[id].state === 'TX') {
							if (building.ownerOccupied === 'Y') {
								texasLessorsRisk = true;
							}
						}
					});
				}
			});
		}

		return {
			section_locations: [[(value) => !texasLessorsRisk, 'SLD01']],
		};
	}
	static name() {
		return 'sfgLocationDashboard';
	}
}
