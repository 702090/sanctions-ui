import { ModalStepper } from 'components/shared/navigation/ModalStepper';
import QuoteContext from 'context/quoteContext';
import React, { Component } from 'react';
import SafeguardBuildingForm from 'safeguard/locationDashboard/building/BuildingForm';
import { Modal, Radio } from 'semantic-ui-react';
import { pageAnalytics } from 'utils/ScreenFunctions';
import { replaceReferrals } from 'validation/RunReferrals';

export default class BuildingModal extends Component {
	static contextType = QuoteContext;

	constructor() {
		super();
		this.state = {
			isOpen: false,
			building: {},
		}; // state to control the state of popup
	}

	handleOpen = (callBack, locationId, newLocation, buildingId, newBuilding, building, address, prefillData) => {
		this.setState({
			isOpen: true,
			callBack,
			locationId,
			newLocation,
			buildingId,
			newBuilding,
			building,
			address,
			prefillData,
		});
		pageAnalytics(this.props.location.pathname + '/BuildingModal', true);
	};

	handleClose = () => {
		this.setState({ isOpen: false });
		replaceReferrals(this.context);
		this.state.callBack();
		pageAnalytics(this.props.location.pathname);
	};

	render() {
		const { newBuilding, locationId, newLocation, buildingId, building, address, callBack, prefillData } = this.state;
		return (
			<Modal
				closeIcon
				open={this.state.isOpen}
				closeOnDimmerClick={false}
				onClose={this.handleClose}
				className='banded'
			>
				<div id='colorBlock' className='bldg'>
					{!newLocation && !newBuilding && (
						<React.Fragment>
							<span>Location</span>
							<Radio
								toggle
								checked
								name='locationBuildingToggle'
								onChange={(e) => {
									this.context.refLocation.current.handleOpen(callBack, locationId, false, buildingId);
									this.handleClose();
								}}
							/>
							<span>
								Building
								{building.order}
							</span>
						</React.Fragment>
					)}
				</div>

				<ModalStepper
					currentModal='safeguardBuilding'
					handleClose={this.handleClose}
					locationId={locationId}
					newLocation={newLocation}
					buildingId={buildingId}
					newBuilding={newBuilding}
					building={building}
					prefillData={prefillData}
				/>
				<Modal.Content>
					<SafeguardBuildingForm
						id={buildingId}
						locationId={locationId}
						newLocation={newLocation}
						handleClose={this.handleClose}
						newBuilding={newBuilding}
						building={building}
						address={address}
						callBack={callBack}
						prefillData={prefillData}
						{...this.props}
					/>
				</Modal.Content>
			</Modal>
		);
	}
}
