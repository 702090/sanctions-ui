import bopClassCodesJson from 'data/BOPClassCodes';
import classCodeListsJson from 'data/ClassCodeLists';
import countyListsJson from 'data/CountyLists';
import { getFieldDisplayArray, requiredQuestionMessage } from 'data/FieldVisibility';
import joistedHazardGradesList from 'data/JoistedHazardGrades';
import rulesValues from 'data/RulesValues';
import { isBefore, parseISO } from 'date-fns';
import _ from 'lodash';
import { formatNumberWithCommas } from 'utils/BusinessFunctions';
import { toDate } from 'utils/DateFunctions';
import { getVisibility } from 'utils/ScreenFunctions';
import { isBlank, isBlankZ } from 'utils/StringFunctions';

const {
	sfg_minimumContractorsPayrollByState,
	sfg_minimumContractorsPayrollByState2_1_2022,
	sfg_mortgageeLossPayeeAdditionalInterestType,
} = rulesValues;
const { joistedHazardGrades } = joistedHazardGradesList;
const { earthquake_counties } = countyListsJson;
const { apartmentClasses, boardingHouseClasses, dwellingClasses } = classCodeListsJson;

export default class BuildingRules {
	static requiredStructure = {
		// TODO remove non-required fields from structure
		ancillaryBuilding: '',
		ancillaryDescription: '',
		occupancyType: '',
		classCode: '',
		separateCanopy: '',
		percentSubcontracting: '',
		homeOffice: '',
		numberOfMortgageesLossPayees: '',
		additionalInsureds: '',
		additionalInsuredType: [],
		ownerOccupied: '',
		playground: '',
		amusementArea: '',
		numberOfSwimmingPools: '',
		poolFenced: '',
		poolDiving: '',
		poolGates: '',
		poolRules: '',
		poolDepth: '',
		poolSafety: '',
		constructionYear: '',
		constructionType: '',
		roofYear: '',
		roofType: '',
		roofSurfaceLimitation: '',
		wiringYear: '',
		plumbingYear: '',
		primaryHeatingYear: '',
		numberOfStories: '',
		squareFootage: 0,
		roofArea: '',
		sprinkler: '',
		buildingLimit: '',
		bppLimit: '',
		buildingValuation: '',
		liabilityExposureBasis: '',
		pdDeductibleType: '',
		pdDeductible: '',
		earthquakeCoverage: '',
		eqDeductible: '',
		eqBuildingClassification: '',
		masonryVeneer: '',
		rateGrade: '',
		BP0402Number: '',
		BP0416Number: '',
		section_coverageInfo: '',
		numberOfTenants: '',
		tenant1: '',
		tenant2: '',
		tenant3: '',
		tenant4: '',
		tenant5: '',
		tenant6: '',
		tenant7: '',
		tenant8: '',
		tenant9: '',
		tenant10: '',
	};

	static optionalStructure = {
		permanentYard: '',
		windstormHailRoofACV: '',
		eqBuildingSubLimit: '',
		eqBPPSubLimit: '',
	};

	static rules(quote, values, visibility, serviceStatus) {
		// use values for current page validation
		// use quote for external page validation
		if (!values) {
			values = {};
		}
		if (!visibility) {
			visibility = getVisibility(getFieldDisplayArray('safeguardBuilding'), quote, values);
		}

		const numberOfTenants = _.get(values, 'numberOfTenants', 1);

		const quoteBuilding = _.get(quote, `sfg.locations.${values.locationId}.buildings.${values.id}`, {});
		const v360UseValue =
			values.buildingValuation === '1'
				? _.get(quoteBuilding, 'prefillData.verisk360.calculatedValue', 0)
				: _.get(quoteBuilding, 'prefillData.verisk360.ACV', 0);
		const scrubbedV360UseValue =
			typeof v360UseValue === 'string' ? Number(v360UseValue.replace(/,/gi, '')) : v360UseValue;
		const v360PrefillLimit = Math.ceil(scrubbedV360UseValue * 0.75);
		const currentYear = new Date().getFullYear();
		const veriskPrefill = _.get(quote, `sfg.locations.${values.locationId}.prefillData.verisk`, {});
		const locationState = _.get(quote, `addresses.${values.locationId}.state`, {});
		const locationCounty = _.get(quote, `addresses.${values.locationId}.county`, {});
		const premiseMin = !isBlank(veriskPrefill.premiseMin) ? _.toNumber(veriskPrefill.premiseMin) : '';
		const veriskSquareFootage = !isBlank(veriskPrefill.squareFootage) ? _.toNumber(veriskPrefill.squareFootage) : '';
		let hazardGrade = getHazardGrade(locationState, locationCounty);
		const firstBuildingBppLimit = _.get(
			_.find(_.get(quote, `sfg.locations.${values.locationId}.buildings`, {}), { order: 1 }),
			'bppLimit',
			'',
		);
		const contractorMinPayrollValueObject = isBefore(
			_.get(quote, 'effectiveDate'),
			parseISO('2022-02-01'), //,
		)
			? sfg_minimumContractorsPayrollByState
			: sfg_minimumContractorsPayrollByState2_1_2022;

		const eqBuildingSubLimitCheck = (visible, subLimit, buildingLimit, constructionType) => {
			let fireRule = false;
			let maxValue = 0;

			if (locationState === 'AR' || locationState === 'IL' || locationState === 'MO') {
				switch (hazardGrade) {
					case 10:
						maxValue = constructionType === '01' ? 500000 : 250000;
						break;
					case 9:
						maxValue = constructionType === '01' ? 750000 : 500000;
						break;
					case 8:
						maxValue = constructionType === '01' ? 1000000 : 750000;
						break;
					case 7:
						maxValue = constructionType === '01' ? 1500000 : 1000000;
						break;

					default:
						break;
				}
			}

			if (visible && maxValue > 0 && (subLimit / 100) * buildingLimit > maxValue) {
				fireRule = true;
			}

			return [(value) => !fireRule, `The sub-limit cannot exceed $${Number(maxValue).toLocaleString()}`];
		};

		return {
			classId: [[(value) => !isBlank(value), 'Class code is required.']],
			ancillaryBuilding: [[(value) => !(isBlank(value) && visibility.ancillaryBuilding), requiredQuestionMessage]],
			ancillaryDescription: [
				[(value) => !(isBlank(value) && visibility.ancillaryDescription), requiredQuestionMessage],
			],
			separateCanopy: [
				[
					(value) => !(visibility['separateCanopy'] && isBlank(value)) || values.ancillaryBuilding === 'Y',
					requiredQuestionMessage,
				],
			],
			percentSubcontracting: [
				[(value) => !visibility['percentSubcontracting'] || !isBlankZ(value), requiredQuestionMessage],
				[
					(value) => value >= 0 && value <= 10,
					'This risk is not eligible for Safeguard. Please contact your underwriter for possible placement with one of our other products.',
				],
			],
			homeOffice: [[(value) => !(isBlank(value) && visibility.homeOffice), requiredQuestionMessage]],
			numberOfMortgageesLossPayees: [
				[
					(value) =>
						!(
							value === 0 &&
							_.intersection(values.additionalInsuredType, sfg_mortgageeLossPayeeAdditionalInterestType).length > 0
						),
					'The number of mortgagees or loss payees must be greater than 0 because an additional insured type or mortgagee or loss payee was selected.',
				],
				[
					(value) => {
						return !isBlankZ(value);
					},
					requiredQuestionMessage,
				],
			],
			additionalInsureds: [
				[(value) => !isBlank(value), requiredQuestionMessage],
				[
					(value) =>
						!(
							values.numberOfMortgageesLossPayees > 0 &&
							_.intersection(values.additionalInsuredType, sfg_mortgageeLossPayeeAdditionalInterestType).length === 0
						),
					'Because the number of mortgagees/loss payees was greater than 0, a loss payee or mortgagee form must be selected below.',
				],
			],
			additionalInsuredType: [
				[(value) => !(isBlank(value) && values.additionalInsureds === 'Y'), requiredQuestionMessage],
			],
			ownerOccupied: [[(value) => !(isBlank(value) && visibility.ownerOccupied), requiredQuestionMessage]],
			numberOfTenants: [
				[
					(value) => (value > 0 && value <= 10) || !visibility.numberOfTenants,
					'Number of Tenants must be between 1 and 10.',
				],
			],
			tenant1: [[(value) => !visibility.numberOfTenants || !isBlank(value), requiredQuestionMessage]],
			tenant2: [
				[(value) => !visibility.numberOfTenants || !isBlank(value) || numberOfTenants < 2, requiredQuestionMessage],
			],
			tenant3: [
				[(value) => !visibility.numberOfTenants || !isBlank(value) || numberOfTenants < 3, requiredQuestionMessage],
			],
			tenant4: [
				[(value) => !visibility.numberOfTenants || !isBlank(value) || numberOfTenants < 4, requiredQuestionMessage],
			],
			tenant5: [
				[(value) => !visibility.numberOfTenants || !isBlank(value) || numberOfTenants < 5, requiredQuestionMessage],
			],
			tenant6: [
				[(value) => !visibility.numberOfTenants || !isBlank(value) || numberOfTenants < 6, requiredQuestionMessage],
			],
			tenant7: [
				[(value) => !visibility.numberOfTenants || !isBlank(value) || numberOfTenants < 7, requiredQuestionMessage],
			],
			tenant8: [
				[(value) => !visibility.numberOfTenants || !isBlank(value) || numberOfTenants < 8, requiredQuestionMessage],
			],
			tenant9: [
				[(value) => !visibility.numberOfTenants || !isBlank(value) || numberOfTenants < 9, requiredQuestionMessage],
			],
			tenant10: [
				[(value) => !visibility.numberOfTenants || !isBlank(value) || numberOfTenants < 10, requiredQuestionMessage],
			],
			playground: [
				[(value) => !(isBlank(value) && visibility.playground), requiredQuestionMessage],
				[
					(value) => !visibility.playground || !(_.includes(['8', '9'], values.occupancyType) && value === 'Y'),
					'This risk is not eligible for our Safeguard program due to the playground on premise.',
				],
			],
			amusementArea: [[(value) => !(isBlank(value) && visibility.amusementArea), requiredQuestionMessage]],
			numberOfSwimmingPools: [
				[(value) => !(isBlankZ(value) && visibility.numberOfSwimmingPools), requiredQuestionMessage],
			],
			poolFenced: [
				[(value) => !(isBlank(value) && visibility.poolFenced), requiredQuestionMessage],
				[
					(value) => !(value === 'N' && visibility.poolFenced),
					'This risk is not eligible for our Safeguard program due to the exposure of a swimming pool not fenced.',
				],
			],
			poolDiving: [
				[(value) => !(isBlank(value) && visibility.poolDiving), requiredQuestionMessage],
				[
					(value) => !(value === 'Y' && visibility.poolDiving),
					'This risk is not eligible for our Safeguard program due to the diving board or slide',
				],
			],
			poolGates: [
				[(value) => !(isBlank(value) && visibility.poolGates), requiredQuestionMessage],
				[
					(value) => !(value === 'N' && visibility.poolGates),
					'This risk is not eligible for our Safeguard program due to the exposure with no locked gates.',
				],
			],
			poolRules: [
				[(value) => !(isBlank(value) && visibility.poolRules), requiredQuestionMessage],
				[
					(value) => !(value === 'N' && visibility.poolRules),
					'This risk is not eligible for our Safeguard program due to pool rules not being posted.',
				],
			],
			poolDepth: [
				[(value) => !(isBlank(value) && visibility.poolDepth), requiredQuestionMessage],
				[
					(value) => !(value === 'N' && visibility.poolDepth),
					'This risk is not eligible for our Safeguard program due to pool depths not being marked.',
				],
			],
			poolSafety: [
				[(value) => !(isBlank(value) && visibility.poolSafety), requiredQuestionMessage],
				[
					(value) => !(value === 'N' && visibility.poolSafety),
					'This risk is not eligible for our Safeguard program due to no life saving devices being available.',
				],
			],
			permanentYard: [
				[
					(value) => value !== '0' || !visibility.permanentYard,
					'If there is no permanent yard coverage, please leave this field blank.',
				],
				[
					(value) => isBlank(value) || parseInt(value) >= 1 || !visibility.permanentYard,
					'Permanent yard must be greater than zero.',
				],
			],
			constructionYear: [
				[(value) => value > 0, requiredQuestionMessage],
				[
					(value) =>
						(value >= 1950 && value <= currentYear) || (values.homeOffice === 'Y' && values.occupancyType === '10'),
					'Due to the age of the building this risk does not qualify for our Safeguard program.  Please contact your underwriter to discuss other possible options.',
				],
				[
					(value) =>
						!(
							(values.homeOffice !== 'Y' &&
								toDate().getFullYear() - value > 20 &&
								(_.includes(['1', '6', '7'], values.occupancyType) ||
									_.includes(['69151', '69161', '69171'], values.classCode)) &&
								!_.includes(['60999', '60989'], values.classCode)) ||
							(value < '1950' && values.homeOffice !== 'Y' && values.occupancyType !== '10') ||
							(values.homeOffice !== 'Y' &&
								toDate().getFullYear() - value > 40 &&
								_.includes(['8', '9'], values.occupancyType))
						),
					'This risk is not eligible for our Safeguard program due to the age of the building.',
				],
			],
			constructionType: [[(value) => !isBlank(value), requiredQuestionMessage]],
			roofYear: [
				[(value) => value > 0 || !visibility.roofYear || values.ancillaryBuilding === 'Y', requiredQuestionMessage],

				[
					(value) => value >= values.constructionYear || !visibility.roofYear || values.ancillaryBuilding === 'Y',
					'Building updates cannot be older than the original construction year',
				],
			],
			roofType: [[(value) => !(isBlank(value) && visibility.roofType), requiredQuestionMessage]],
			roofSurfaceLimitation: [
				[(value) => !(isBlank(value) && visibility.roofSurfaceLimitation), requiredQuestionMessage],
			],
			wiringYear: [
				[(value) => value > 0 || !visibility.wiringYear || values.ancillaryBuilding === 'Y', requiredQuestionMessage],
				[
					(value) => value >= values.constructionYear || !visibility.wiringYear || values.ancillaryBuilding === 'Y',
					'Building updates cannot be older than the original construction year',
				],
			],
			plumbingYear: [
				[(value) => value > 0 || !visibility.plumbingYear || values.ancillaryBuilding === 'Y', requiredQuestionMessage],
				[
					(value) => value >= values.constructionYear || !visibility.plumbingYear || values.ancillaryBuilding === 'Y',
					'Building updates cannot be older than the original construction year',
				],
			],
			primaryHeatingYear: [
				[
					(value) => value > 0 || !visibility.primaryHeatingYear || values.ancillaryBuilding === 'Y',
					requiredQuestionMessage,
				],
				[
					(value) =>
						value >= values.constructionYear || !visibility.primaryHeatingYear || values.ancillaryBuilding === 'Y',
					'Building updates cannot be older than the original construction year',
				],
			],
			numberOfStories: [
				[
					(value) => isBlank(value) || _.toNumber(value) >= 1 || !visibility.numberOfStories,
					'Value must be greater than zero.',
				],
				[(value) => !(isBlank(value) && visibility.numberOfStories), requiredQuestionMessage],
				[
					(value) =>
						!(
							visibility.numberOfStories &&
							((_.includes(['69151', '69161', '69171'], values.classCode) && value > 4) ||
								(values.occupancyType === '2' && value > 6) ||
								(_.includes(['1', '6', '7'], values.occupancyType) && value > 3) ||
								(!_.includes(['69151', '69161', '69171'], values.classCode) &&
									!_.includes(['1', '2', '6', '7'], values.occupancyType) &&
									value > 2))
						),
					'This risk is not eligible for our Safeguard program due to the number of stories.',
				],
			],
			squareFootage: [
				[
					(value) => {
						return value > 0 || !visibility.squareFootage;
					},
					requiredQuestionMessage,
				],
				[
					(value) =>
						values.ancillaryBuilding === 'Y' ||
						!(
							visibility.squareFootage &&
							((values.occupancyType === '2' && value > 100000) ||
								(_.includes(['8', '9'], values.occupancyType) && value > 7500) ||
								(!_.includes(['2', '8', '9'], values.occupancyType) &&
									value > 35000 &&
									!_.includes(['69151', '69161', '69171'], values.classCode)) ||
								(_.includes(['09321', '09351', '09361'], values.classCode) && value < 3000) ||
								(_.includes(['54321', '54331', '54127'], values.classCode) && value < 4000) ||
								(_.includes(['54341', '54351'], values.classCode) && value >= 4000) ||
								(values.classCode === '54136' &&
									values.classCodeDescription !== 'CONVENIENCE FOOD-W/O GAS-NO' &&
									value >= 4000))
						),
					'This risk is not eligible for our Safeguard program due to the amount of square footage.',
				],
				[
					(value) => {
						let squareFootageRangeSatisfied = false;
						if (
							!visibility.squareFootage ||
							!values.originalPrimary ||
							values.ancillaryBuilding === 'Y' ||
							isBlank(veriskSquareFootage) ||
							isBlank(premiseMin) ||
							values.ownerOccupied !== 'N2' ||
							_.get(quote, `addresses.${values.locationId}.state`, '') === 'MS' ||
							veriskSquareFootage < premiseMin ||
							(value >= premiseMin && value <= veriskSquareFootage)
						) {
							squareFootageRangeSatisfied = true;
						}
						return squareFootageRangeSatisfied;
					},
					`The square footage for this building must be between ${formatNumberWithCommas(
						premiseMin,
					)} and ${formatNumberWithCommas(veriskSquareFootage)}`,
				],
			],
			roofArea: [
				[
					(value) => {
						return value > 0 || !visibility.roofArea;
					},
					requiredQuestionMessage,
				],
			],
			sprinkler: [
				[(value) => !(isBlank(value) && visibility.sprinkler), requiredQuestionMessage],
				[
					(value) =>
						!(_.includes(['69151', '69161', '69171'], values.classCode) && value === 'N') ||
						values.ancillaryBuilding === 'Y',
					'This risk is not eligible for our Safeguard program due to no sprinkler system.',
				],
				[
					(value) =>
						!(
							(_.includes(
								[
									'09611',
									'09671',
									'09621',
									'09631',
									'09681',
									'09641',
									'09651',
									'09691',
									'09661',
									'09001',
									'09021',
									'09031',
									'09051',
									'09071',
									'09091',
									'09111',
									'09131',
									'09151',
									'09181',
									'09191',
									'09201',
									'09221',
									'09241',
									'09251',
									'09421',
									'09451',
									'09431',
									'09441',
									'09341',
									'09361',
								],
								values.classCode,
							) ||
								(_.includes(['8', '9'], values.occupancyType) &&
									!_.includes(
										[
											'09331',
											'09161',
											'09011',
											'09041',
											'09061',
											'09081',
											'09101',
											'09121',
											'09141',
											'09171',
											'09211',
											'09231',
											'09261',
											'09351',
										],
										values.classCode,
									))) &&
							value === 'N' &&
							values.constructionType === '01'
						) || values.ancillaryBuilding === 'Y',
					'This risk does not qualify for Safeguard due to no sprinkler system.  Please contact your Underwriter.',
				],
				[
					(value) =>
						!(visibility.sprinkler && values.occupancyType === '2' && values.numberOfStories > 3 && value === 'N') ||
						values.ancillaryBuilding === 'Y',
					'This risk is not eligible for our Safeguard program due to the occupancy, number of stories and no sprinkler system.',
				],
			],
			section_coverageInfo: [
				[
					(value) =>
						!(isBlank(values.buildingLimit) && isBlank(values.bppLimit)) ||
						(isBlank(value) && (bppLimitRequired(values, visibility) || buildingLimitRequired(values))),
					'You must enter either a Building Limit or Business Personal Property Limit',
				],
			],
			buildingLimit: [
				[
					(value) => !visibility.buildingLimit || !buildingLimitRequired(values) || !isBlank(value),
					requiredQuestionMessage,
				],
				[
					(value) => !(visibility.buildingLimit && (value > 9000000 || value + values.bppLimit > 9000000)),
					'This risk is not eligible for Safeguard due to the total insured value. Please contact your Underwriter to determine eligibility on our Commercial Package Policy.',
				],
				[
					(value) =>
						serviceStatus.verisk360 || !visibility.buildingLimit || isBlank(value) || value >= v360PrefillLimit,
					`Building limit must be greater than or equal to $${Number(v360PrefillLimit).toLocaleString('en-US')}`,
				],
			],
			bppLimit: [
				[
					(value) =>
						!isBlank(value) ||
						!bppLimitRequired(values, visibility) ||
						(isBlank(value) &&
							values.ancillaryBuilding === 'Y' &&
							(isBlank(firstBuildingBppLimit) ||
								_.includes(['Pool House', 'Storage Sheds'], values.ancillaryDescription))),
					requiredQuestionMessage,
				],
				[
					(value) => !(value > 9000000),
					'This risk is not eligible for Safeguard due to the total insured value. Please contact your Underwriter to determine eligibility on our Commercial Package Policy.',
				],
			],
			buildingValuation: [
				[(value) => !visibility.buildingValuation || !isBlank(value), requiredQuestionMessage],
				[
					(value) =>
						!(
							values.buildingValuation === '2' &&
							values.roofSurfaceLimitation !== '1' &&
							values.roofSurfaceLimitation !== '3' &&
							values.roofType !== 'Metal'
						),
					'Since building valuation is Actual Cash Value, the roof surface limitation must also be Actual Cash Value.',
				],
			],
			liabilityExposureBasis: [
				[(value) => !isBlank(value) || !visibility.liabilityExposureBasis, requiredQuestionMessage],
				[
					(value) => !visibility.liabilityExposureBasis || !(values.occupancyType === '10' && value > 500000),
					'This risk is not eligible for our Safeguard program due to the total amount of payroll on a contractor risk.  Please contact your Underwriter.',
				],
				[
					(value) =>
						values.ancillaryBuilding === 'Y' ||
						!visibility.totalPayroll ||
						!(
							values.occupancyType === '10' &&
							_.toNumber(value) <
								(contractorMinPayrollValueObject[locationState] &&
									_.toNumber(contractorMinPayrollValueObject[locationState].value))
						),
					`The minimum amount of payroll should be $${
						contractorMinPayrollValueObject[locationState] ? contractorMinPayrollValueObject[locationState].text : 'N/A'
					}.`,
				],
				[
					(value) => !(visibility.totalSales && value > 6000000),
					'This risk is not eligible for our Safeguard program due to the total amount of sales.  Please contact your Underwriter.',
				],
			],
			pdDeductibleType: [
				[
					(value) => {
						// This is saved at the sfg policy level after entry on building
						const pdDeductibleTypeValue = isBlank(value) ? _.get(quote, 'sfg.pdDeductibleType') : value;
						return !(visibility['pdDeductibleType'] && isBlank(pdDeductibleTypeValue));
					},
					requiredQuestionMessage,
				],
			],
			pdDeductible: [
				[
					(value) => {
						// This is saved at the sfg policy level after entry on building
						const pdDeductibleValue = isBlank(value) ? _.get(quote, 'sfg.pdDeductible') : value;
						return !(visibility['pdDeductible'] && isBlank(pdDeductibleValue));
					},
					requiredQuestionMessage,
				],
			],
			earthquakeCoverage: [
				[(value) => !(isBlank(value) && visibility.earthquakeCoverage), requiredQuestionMessage],
				[
					(value) =>
						!(
							value === 'Y' &&
							_.includes(['KY', 'MS', 'TN'], locationState) &&
							values.constructionType !== '02' &&
							values.constructionYear >= 1980 &&
							values.buildingLimit * (values.eqBuildingSubLimit / 100) > 2000000
						),
					'Due to the building characteristics, the Earthquake maximum sublimit of $2,000,000 per building applies.  Please either lower or remove the sublimit amount requested.',
				],
				[
					(value) =>
						!(
							value === 'Y' &&
							((_.includes(['AL'], locationState) &&
								_.includes([8, 9, 10], hazardGrade) &&
								values.buildingLimit * (values.eqBuildingSubLimit / 100) +
									values.bppLimit * (values.eqBPPSubLimit / 100) >
									1000000) ||
								(_.includes(['KY', 'MS', 'TN'], locationState) &&
									(values.constructionType === '02' || values.constructionYear < 1980) &&
									values.buildingLimit * (values.eqBuildingSubLimit / 100) > 1000000))
						),
					'Due to the building characteristics, the Earthquake maximum sublimit of $1,000,000 per building applies.  Please either lower or remove the sublimit amount requested.',
				],
			],
			eqDeductible: [
				[(value) => !(isBlank(value) && visibility.eqDeductible), requiredQuestionMessage],
				[
					(value) =>
						!(
							visibility.eqDeductible &&
							value < 0.05 &&
							_.includes(['KY', 'MS', 'TN'], locationState) &&
							values.constructionType !== '02' &&
							values.constructionYear <= 1980
						),
					'The minimum Earthquake deductible for this risk is 5%',
				],
				[
					(value) =>
						!(
							visibility.eqDeductible &&
							value < 0.1 &&
							_.includes(['KY', 'MS', 'TN'], locationState) &&
							(values.constructionType === '02' || values.constructionYear < 1980)
						),
					'The minimum Earthquake deductible for this risk is 10%',
				],
				[
					(value) =>
						!(
							visibility.eqDeductible &&
							value < 0.1 &&
							_.includes(['AL', 'AR', 'IL', 'KS', 'MO', 'OK'], locationState) &&
							!(
								_.includes(_.get(earthquake_counties, `${locationState}.hazardGrade_8`), locationCounty) ||
								_.includes(_.get(earthquake_counties, `${locationState}.hazardGrade_9`), locationCounty) ||
								_.includes(_.get(earthquake_counties, `${locationState}.hazardGrade_10`), locationCounty)
							)
						),
					'The minimum Earthquake deductible for this risk is 10%',
				],
				[
					(value) =>
						!(
							visibility.eqDeductible &&
							value < 0.2 &&
							_.includes(['AL', 'AR', 'IL', 'KS', 'MO', 'OK'], locationState) &&
							(_.includes(_.get(earthquake_counties, `${locationState}.hazardGrade_8`), locationCounty) ||
								_.includes(_.get(earthquake_counties, `${locationState}.hazardGrade_9`), locationCounty) ||
								_.includes(_.get(earthquake_counties, `${locationState}.hazardGrade_10`), locationCounty))
						),
					'The minimum Earthquake deductible for this risk is 20%',
				],
			],
			eqBuildingSubLimit: [
				eqBuildingSubLimitCheck(
					visibility.eqBuildingSubLimit && visibility.earthquakeCoverage,
					_.get(values, 'eqBuildingSubLimit'),
					_.get(values, 'buildingLimit', 1),
					values.constructionType,
				),
			],
			eqBuildingClassification: [
				[(value) => !(isBlank(value) && visibility.eqBuildingClassification), requiredQuestionMessage],
			],
			masonryVeneer: [[(value) => !(isBlank(value) && visibility.masonryVeneer), requiredQuestionMessage]],
			rateGrade: [[(value) => !(isBlank(value) && visibility.rateGrade), requiredQuestionMessage]],
			BP0402Number: [
				[
					(value) => (value >= 1 && value <= 99) || !_.includes(values.additionalInsuredType, 'BP0402'),
					'You must have between 1 and 99 Managers / Lessors',
				],
			],
			BP0416Number: [
				[
					(value) => (value >= 1 && value <= 3) || !_.includes(values.additionalInsuredType, 'BP0416'),
					'You must have between 1 and 3 pieces of Leased Equipment',
				],
			],
		};
	}

	static referrals(context, values, visibility) {
		// use values for current page validation
		// use context for external page validationP
		if (!visibility) {
			visibility = getVisibility(getFieldDisplayArray('safeguardBuilding'), context.quote, values);
		}
		const thisYear = toDate().getFullYear();
		const roofAge = thisYear - values.roofYear;
		let veriskRoofYearValidates = false;

		if (!visibility.roofYear || values.ancillaryBuilding === 'Y' || values.roofType === 'Metal') {
			veriskRoofYearValidates = true;
		} else {
			switch (_.get(context.quote, `sfg.locations.${values.locationId}.prefillData.verisk.roofYear`, '')) {
				case 'New - 10 years':
					veriskRoofYearValidates = roofAge <= 10;
					break;
				case '>10 - 20 years':
					veriskRoofYearValidates = roofAge <= 20;
					break;
				case '>20 years':
					veriskRoofYearValidates = roofAge <= 21;
					break;
				default:
					veriskRoofYearValidates = true;
					break;
			}
		}

		const quoteBuilding = _.get(context.quote, `sfg.locations.${values.locationId}.buildings.${values.id}`, {});
		const v360UseValue =
			values.buildingValuation === '1'
				? _.get(quoteBuilding, 'prefillData.verisk360.calculatedValue', 0)
				: _.get(quoteBuilding, 'prefillData.verisk360.ACV', 0);
		const v360PrefillMax = Math.ceil(v360UseValue * 1.25);
		const locationState = _.get(context.quote, `addresses.${values.locationId}.state`, {});
		const locationCounty = _.get(context.quote, `addresses.${values.locationId}.county`, {});
		const hazardGrade = getHazardGrade(locationState, locationCounty);

		return {
			classId: [
				[
					(value) => {
						return _.get(bopClassCodesJson.classCodes, `${locationState}.${value}.p`, '') !== 2;
					},
					'SLB10',
				],
			],
			amusementArea: [[(value) => !visibility.amusementArea || value !== 'Y', 'SLB06']],
			roofYear: [
				[
					(value) =>
						((value >= thisYear - 20 && value <= thisYear) ||
							!visibility.roofYear ||
							values.ancillaryBuilding === 'Y' ||
							values.roofType === 'Metal') &&
						veriskRoofYearValidates,
					'SLB01',
				],
			],
			roofType: [
				[(value) => !visibility.roofType || isBlank(value) || !_.includes(['Wood Shake', 'Tile'], value), 'SLB05'],
			],
			buildingLimit: [
				[
					(value) =>
						_.get(context, 'serviceStatus.verisk360', false) ||
						!visibility.buildingLimit ||
						isBlank(value) ||
						value < v360PrefillMax ||
						isBlank(_.get(quoteBuilding, 'prefillData.verisk360.calculatedValue', '')),
					'SLB07',
				],
			],
			ownerOccupied: [[(value) => value !== 'Y', 'SLB08']],
			earthquakeCoverage: [
				[
					(value) =>
						!(
							value === 'Y' &&
							((_.includes([7, 8, 9, 10], hazardGrade) &&
								values.constructionType !== '01' &&
								values.constructionYear < 1980) ||
								(_.includes(joistedHazardGrades[locationState], hazardGrade) &&
									values.constructionType === '02' &&
									values.buildingLimit + values.bppLimit > 250000))
						),
					'SLB09',
				],
			],
		};
	}

	static name() {
		return 'sfgBuilding';
	}
}

function buildingLimitRequired(values) {
	const limitRequired =
		//For lessor liability rates off of bldg regardless of liability exposure basis
		values.ownerOccupied === 'Y' ||
		//Required for apartments
		values.occupancyType === '1' ||
		//Self storage, Condo association
		_.includes(['09411', '69145'], values.classCode) ||
		//Apartment, boarding house, dwelling classes
		_.includes([...apartmentClasses, ...boardingHouseClasses, ...dwellingClasses], values.classCode) ||
		//Select condo class codes owner occupied
		(values.ownerOccupied === 'Y' && _.includes(['60989', '60999'], values.classCode));

	return limitRequired;
}

function bppLimitRequired(values, visibility) {
	const limitRequired =
		//If non-lessor and select condo classes
		(_.includes(['N1', 'N2'], values.ownerOccupied) && _.includes(['60989', '60999'], values.classCode)) ||
		//If non-lessor and church
		(_.includes(['N1', 'N2'], values.ownerOccupied) && values.classCode === '41650') ||
		//contractors working from home
		(values.homeOffice === 'Y' && values.occupancyType === '10') ||
		//non lessor and no sales/payroll liability exposure basis
		(_.includes(['N1', 'N2'], values.ownerOccupied) && !visibility.liabilityExposureBasis);
	return limitRequired;
}

function getHazardGrade(locationState, locationCounty) {
	let hazardGrade = 6;

	if (_.includes(_.get(earthquake_counties, `${locationState}.hazardGrade_10`), locationCounty)) {
		hazardGrade = 10;
	} else if (_.includes(_.get(earthquake_counties, `${locationState}.hazardGrade_9`), locationCounty)) {
		hazardGrade = 9;
	} else if (_.includes(_.get(earthquake_counties, `${locationState}.hazardGrade_8`), locationCounty)) {
		hazardGrade = 8;
	} else if (_.includes(_.get(earthquake_counties, `${locationState}.hazardGrade_7`), locationCounty)) {
		hazardGrade = 7;
	}

	return hazardGrade;
}
