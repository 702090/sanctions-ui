import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { CheckboxGroup } from 'components/shared/form/CheckboxGroup';
import { DataDisplay } from 'components/shared/form/DataDisplay';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputText } from 'components/shared/form/inputs/InputText';
import { RadioButton } from 'components/shared/form/RadioButton';
import { Select } from 'components/shared/form/Select';
import { InformationMessage } from 'components/shared/messages/InformationMessage';
import { WarningMessage } from 'components/shared/messages/WarningMessage';
import { toSortedPairList } from 'components/shared/navigation/NavigationFunctions';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import bopClassCodesJson from 'data/BOPClassCodes';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import selectOptionsJson from 'data/SelectOptions';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { Component } from 'react';
import { toast } from 'react-toastify';
import BuildingRules from 'safeguard/locationDashboard/building/BuildingRules';
import { ModalNavButtons } from 'safeguard/locationDashboard/components/ModalNavButtons';
import { getVerisk360PDF } from 'services/dataPrefillService';
import { isEmployee, prefillUsed } from 'utils/BusinessFunctions';
import { toDate } from 'utils/DateFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import { base64toBlob, cleanValues, getVisibility, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank, isBlankZ } from 'utils/StringFunctions';
import { v4 as uuidv4 } from 'uuid';
import { checkReferrals, removeReferrals, validate } from 'validation/Validate';

const {
	sfg_additionalInsuredType,
	sfg_additionalInsuredType_Contractors,
	sfg_ancillaryType,
	sfg_buildingValuation,
	sfg_constructionType,
	sfg_eqBuildingClassification,
	sfg_eqDeductible,
	sfg_eqSubLimit,
	sfg_masonryVeneer,
	sfg_occupancyType,
	sfg_ownerOccupied,
	sfg_pdDeductible,
	sfg_pdDeductibleType,
	sfg_rateGrade,
	sfg_roofSurfaceLimitation,
	sfg_roofSurfaceLimitationMetal,
	sfg_roofType,
} = selectOptionsJson;

export default class SafeguardBuildingForm extends Component {
	static contextType = QuoteContext;
	dirty = false;
	state = { classCodeOptions: [], locationStateCode: '' };
	rulesOnLoad = false;
	visibility = {};
	veriskReturn =
		_.get(this.props, 'prefillData.verisk') ||
		_.get(this.context.quote, `sfg.locations.${this.props.locationId}.prefillData.verisk`, {});

	UNSAFE_componentWillMount() {
		const address = this.props.address || _.get(this.context, `quote.addresses.${this.props.locationId}`);
		const locationStateCode = address.state;

		const classCodeOptions = this.getClassCodes(locationStateCode);
		this.setState({ locationStateCode, classCodeOptions });
	}

	componentDidMount() {
		const ignoreFields = ['id', 'locationId', 'BP0402Number', 'BP0416Number', 'roofSurfaceLimitation'];
		const veriskPrefillFields = [
			'roofType',
			'constructionYear',
			'constructionType',
			'squareFootage',
			'numberOfStories',
			'sprinkler',
		];

		_.forIn(this.veriskReturn, (data, key) => {
			if (_.includes(veriskPrefillFields, key) && !isBlank(data)) {
				ignoreFields.push(key);
			}
		});
		if (!isBlank(this.veriskReturn.effectiveYearBuilt) && !_.includes(ignoreFields, 'constructionYear')) {
			ignoreFields.push('constructionYear');
		}
		// If the form is not empty, trigger validation
		runRulesOnLoad(this.formProps, this.formProps.initialValues, ignoreFields);
	}

	getClassCodes(locationStateCode) {
		const classCodeList = toSortedPairList(bopClassCodesJson.classCodes[locationStateCode], 'uDesc');
		const effDte = toDate(_.get(this.context, 'quote.effectiveDate'));
		let classCodeOptions = classCodeList.reduce((codeOptions, code) => {
			const codeOption = {
				value: `${code[0]}`,
				text: `${code[1].cn} -- ${code[1].uDesc}`,
			};
			const sd = code[1].sd;
			const ed = code[1].ed;
			if (((sd && toDate(sd) <= effDte) || !sd) && ((ed && toDate(ed) >= effDte) || !ed)) {
				codeOptions.push(codeOption);
			}
			return codeOptions;
		}, []);
		return classCodeOptions;
	}

	earthquakeCoverageChange = (earthquakeCoverage, setFieldValue, values, constructionType) => {
		if (earthquakeCoverage === 'Y') {
			setFieldValue('rateGrade', bopClassCodesJson.classCodes[this.state.locationStateCode][values.classId].eqrg);

			constructionType = constructionType || values.constructionType;

			if (constructionType === '01') {
				setFieldValue('eqBuildingClassification', '1C', false);
			} else if (constructionType === '02') {
				setFieldValue('eqBuildingClassification', '5B', false);
			} else if (_.includes(['03', '04', '06'], constructionType)) {
				setFieldValue('eqBuildingClassification', '4A', false);
			}
		}
	};

	ancillaryBuilding = (val) => {
		return val === 'Y';
	};

	clearValuation = async (val, contextBuilding, buildingCopy, fProps, fieldName) => {
		if (!isBlank(val) && _.has(contextBuilding, 'prefillData.verisk360')) {
			if (!_.isEqual(val, _.get(fProps, `initialValues.${fieldName}`))) {
				this.dirty = true;
				_.unset(contextBuilding, 'prefillData.verisk360');
				_.unset(buildingCopy, 'prefillData.verisk360');
				fProps.setFieldTouched('buildingLimit');
				const validResults = validate(
					fProps.values,
					BuildingRules.rules(this.context.quote, fProps.values, this.visibility, this.context.serviceStatus),
					duplicate(BuildingRules.requiredStructure),
				);
			}
		}
	};

	displayTenantFields = (numberOfTenants) => {
		let fieldsArray = [];
		for (let i = 1; i <= Math.min(numberOfTenants, 10); i++) {
			fieldsArray.push(
				<Field
					name={`tenant${i}`}
					label={`Tenant ${i} Name`}
					width='medium'
					component={InputText}
					key={`tenant${i}`}
					maxLength='60'
				/>,
			);
		}

		return fieldsArray;
	};

	updateClassCode = (classId, setFieldValue, buildingCopy) => {
		if (classId !== '') {
			if (
				classId !==
				_.get(this.context, `quote.sfg.locations.${this.props.locationId}.buildings.${this.props.id}.classId`)
			) {
				_.unset(
					this.context,
					`quote.sfg.locations.${this.props.locationId}.buildings.${this.props.id}.questions.reviewedCorrect`,
				);
				_.unset(this.props.building, 'questions.reviewedCorrect');
				_.set(buildingCopy, 'questions.reviewedCorrect', '');
			}
			setFieldValue('classCode', bopClassCodesJson.classCodes[this.state.locationStateCode][classId].cn);
			setFieldValue('classCodeDescription', bopClassCodesJson.classCodes[this.state.locationStateCode][classId].desc);
			setFieldValue('classCode4', bopClassCodesJson.classCodes[this.state.locationStateCode][classId].classCode4);
			setFieldValue('rateNo', bopClassCodesJson.classCodes[this.state.locationStateCode][classId].rateNo);
			setFieldValue('rateGroup', bopClassCodesJson.classCodes[this.state.locationStateCode][classId].rateGroup);
			setFieldValue('occupancyType', bopClassCodesJson.classCodes[this.state.locationStateCode][classId].oc);
			setFieldValue('riskLevel', bopClassCodesJson.classCodes[this.state.locationStateCode][classId].riskLevel);
			setFieldValue('rateGrade', bopClassCodesJson.classCodes[this.state.locationStateCode][classId].eqrg);
			// Remove any selected contractor specific additional interests when changing from contractor class
			const aiValues = _.get(buildingCopy, 'additionalInsuredType', []);
			if (bopClassCodesJson.classCodes[this.state.locationStateCode][classId].oc !== '10' && !isBlank(aiValues)) {
				const cleanedAiList = _.intersection(aiValues, _.map(sfg_additionalInsuredType, 'value'));
				setFieldValue('additionalInsuredType', cleanedAiList);
			}
		} else {
			setFieldValue('classCode', '');
			setFieldValue('classCodeDescription', '');
			setFieldValue('classCode4', '');
			setFieldValue('rateNo', '');
			setFieldValue('rateGroup', '');
			setFieldValue('occupancyType', '');
			setFieldValue('riskLevel', '');
			setFieldValue('rateGrade', '');
		}

		removeReferrals(this.context, this.formProps.values.locationId, 'questions', this.formProps.values.id);
	};

	getPrefillToolTips = (quote, buildingCopy, locationId) => {
		const noCallVeriskMessage = 'Verisk has never been called.';
		const noCallVerisk360Message = 'Verisk360 has never been called.';
		const noReturnVeriskMessage = 'The Verisk call returned no data.';
		const noReturnVerisk360Message = 'The Verisk360 call returned no data.';
		const locationObject = _.get(quote, `sfg.locations.${locationId}`, {});

		let prefillObject = {
			calculatedValue: noCallVerisk360Message,
			constructionYear: noCallVeriskMessage,
			effectiveYearBuilt: noCallVeriskMessage,
			roofType: noCallVeriskMessage,
			constructionType: noCallVeriskMessage,
			squareFootage: noCallVeriskMessage,
			premiseFloorArea: noCallVeriskMessage,
			numberOfStories: noCallVeriskMessage,
			sprinkler: noCallVeriskMessage,
			roofYear: noCallVeriskMessage,
		};

		if (_.has(buildingCopy, 'prefillData.verisk360')) {
			prefillObject.calculatedValue = _.get(
				buildingCopy,
				'prefillData.verisk360.calculatedValue',
				noReturnVerisk360Message,
			);
			prefillObject.calculatedValue = isBlank(prefillObject.calculatedValue)
				? noReturnVerisk360Message
				: prefillObject.calculatedValue;

			prefillObject.ACV = _.get(buildingCopy, 'prefillData.verisk360.ACV', noReturnVerisk360Message);
			prefillObject.ACV = isBlank(prefillObject.ACV) ? noReturnVerisk360Message : prefillObject.ACV;
		}

		if (_.has(locationObject, 'prefillData.verisk')) {
			//* Construction Year
			prefillObject.constructionYear = _.get(
				locationObject,
				'prefillData.verisk.constructionYear',
				noReturnVeriskMessage,
			);
			prefillObject.constructionYear = isBlank(prefillObject.constructionYear)
				? noReturnVeriskMessage
				: prefillObject.constructionYear;

			prefillObject.effectiveYearBuilt = _.get(
				locationObject,
				'prefillData.verisk.effectiveYearBuilt',
				noReturnVeriskMessage,
			);
			prefillObject.effectiveYearBuilt = isBlank(prefillObject.effectiveYearBuilt)
				? noReturnVeriskMessage
				: prefillObject.effectiveYearBuilt;

			//* Roof Type
			prefillObject.roofType = _.get(locationObject, 'prefillData.verisk.roofType', noReturnVeriskMessage);
			prefillObject.roofType = isBlank(prefillObject.roofType) ? noReturnVeriskMessage : prefillObject.roofType;

			//* Construction Type
			prefillObject.constructionType = _.get(
				locationObject,
				'prefillData.verisk.constructionType',
				noReturnVeriskMessage,
			);
			const optionObj = _.find(sfg_constructionType, ['value', prefillObject.constructionType]);
			prefillObject.constructionType = isBlank(prefillObject.constructionType)
				? noReturnVeriskMessage
				: `${prefillObject.constructionType}${optionObj ? ': ' + optionObj.text : ''}`;

			//* Square Footage
			prefillObject.squareFootage = _.get(locationObject, 'prefillData.verisk.squareFootage', noReturnVeriskMessage);
			prefillObject.squareFootage = isBlank(prefillObject.squareFootage)
				? noReturnVeriskMessage
				: prefillObject.squareFootage;

			prefillObject.premiseFloorArea = _.get(
				locationObject,
				'prefillData.verisk.premiseFloorAreaText',
				noReturnVeriskMessage,
			);
			prefillObject.premiseFloorArea = isBlank(prefillObject.premiseFloorArea)
				? noReturnVeriskMessage
				: prefillObject.premiseFloorArea;

			//* Number of Stories
			prefillObject.numberOfStories = _.get(
				locationObject,
				'prefillData.verisk.numberOfStories',
				noReturnVeriskMessage,
			);
			prefillObject.numberOfStories = isBlank(prefillObject.numberOfStories)
				? noReturnVeriskMessage
				: prefillObject.numberOfStories;

			//* Sprinkler
			prefillObject.sprinkler = _.get(locationObject, 'prefillData.verisk.sprinkler', noReturnVeriskMessage);
			prefillObject.sprinkler = isBlank(prefillObject.sprinkler) ? noReturnVeriskMessage : prefillObject.sprinkler;

			//* Roof Year
			prefillObject.roofYear = _.get(locationObject, 'prefillData.verisk.roofYear', noReturnVeriskMessage);
			prefillObject.roofYear = isBlank(prefillObject.roofYear) ? noReturnVeriskMessage : prefillObject.roofYear;
		}

		return prefillObject;
	};

	getSubLimitOptions(classification) {
		let subLimitOptions = sfg_eqSubLimit;

		if (_.includes(['3C', '4C', '4D', '5B', '5C', '5AA'], classification)) {
			subLimitOptions = subLimitOptions.filter((option) => option.value !== '5');
		}

		return subLimitOptions;
	}

	setVeriskPrefilData() {
		this.formProps.setFieldValue('numberOfStories', this.veriskReturn.numberOfStories || 0);
		this.formProps.setFieldValue('squareFootage', this.veriskReturn.squareFootage || 0);
		this.formProps.setFieldValue('sprinkler', this.veriskReturn.sprinkler || 'N');
	}

	render() {
		let { id, locationId, newLocation, building, newBuilding, callBack } = this.props;
		let buildingCopy = duplicate(building);
		const { quote } = this.context;
		const isOriginalBuilding =
			buildingCopy.originalPrimary || isBlank(_.get(quote, `sfg.locations.${locationId}.buildings`), {});
		const addressState = _.get(quote, `addresses.${locationId}.state`, '');

		return (
			<Formik
				render={(formikProps) => {
					this.formProps = formikProps;
					const ancillary = this.ancillaryBuilding(formikProps.values.ancillaryBuilding);
					let additionalInsuredTypeOptions = sfg_additionalInsuredType;
					if (formikProps.values.occupancyType === '10') {
						additionalInsuredTypeOptions = sfg_additionalInsuredType_Contractors;
					}
					this.dirty = this.dirty || formikProps.dirty;

					if (ancillary) {
						const firstBuildingClassId = _.find(_.get(quote, `sfg.locations.${locationId}.buildings`, {}), {
							order: 1,
						}).classId;
						if (firstBuildingClassId && formikProps.values.classId !== firstBuildingClassId) {
							formikProps.setFieldValue('classId', firstBuildingClassId);
							this.updateClassCode(firstBuildingClassId, formikProps.setFieldValue, buildingCopy);
						}
					}

					// Need to save these values to policy level if not previously filled in on an existing building
					if (this.visibility.pdDeductibleType && isBlank(_.get(quote, 'sfg.pdDeductible')) && !this.dirty) {
						this.dirty = true;
					}

					if (id === 'NEW') {
						id = formikProps.values.id;
					}
					this.visibility = getVisibility(getFieldDisplayArray('safeguardBuilding'), quote, formikProps.values);
					let liabilityExposureLabel = '';
					if (this.visibility.totalSales || this.visibility.totalPayroll) {
						if (this.visibility.totalSales) {
							liabilityExposureLabel = 'Sales';
						} else if (this.visibility.totalPayroll) {
							liabilityExposureLabel = 'Payroll';
						}
						/* eslint eqeqeq: [0] */
						if (ancillary && formikProps.values.liabilityExposureBasis != 1) {
							formikProps.setFieldValue('liabilityExposureBasis', 1);
						}
					}
					formikProps.values.pdDeductibleType = formikProps.values.pdDeductibleType || '1';
					formikProps.values.pdDeductible = formikProps.values.pdDeductible || '500';
					cleanValues(formikProps.values, this.visibility);
					checkReferrals(this.context, formikProps.values, BuildingRules, this.visibility);
					if (!this.rulesOnLoad) {
						formikProps.validateForm(formikProps.values);
						this.rulesOnLoad = true;
					}

					const prefillToolTips = this.getPrefillToolTips(this.context.quote, buildingCopy, locationId);

					const prefillsPresent = {
						verisk: true,
						verisk360: true,
						datacubes: false,
						ncci: false,
					};

					const valuationId = _.get(buildingCopy, 'prefillData.verisk360.valuationId', '');

					const subLimitOptions = this.getSubLimitOptions(formikProps.values.eqBuildingClassification);

					return (
						<Form id='screen'>
							<InformationMessage
								message='Select information on this page has been pre-filled by a third-party service.'
								fieldDisplay={prefillUsed(quote, this.formProps.values, prefillsPresent, locationId, buildingCopy.id)}
							/>
							<Field
								name='ancillaryBuilding'
								label='Is this building an ancillary or secondary building?'
								component={RadioButton}
								fieldDisplay={this.visibility['ancillaryBuilding']}
								additionalOnChange={(value, sfv) => {
									this.clearValuation(value, building, buildingCopy, formikProps, 'ancillaryBuilding');
								}}
								labelHoverMessage='Buildings or structures at the location that are not part of the main building but pertain to the use of the main building.  Examples would include storage sheds and awnings.'
							/>
							<Field
								name='ancillaryDescription'
								label='Ancillary Building Description'
								component={Select}
								options={sfg_ancillaryType}
								width='small'
								fieldDisplay={this.visibility['ancillaryDescription']}
								additionalOnChange={(value, sfv) => {
									sfv('liabilityExposureBasis', 1, false);
									if (!_.includes(['Pool House', 'Storage Sheds'], value)) {
										const firstBuildingBppLimit = _.find(_.get(quote, `sfg.locations.${locationId}.buildings`, {}), {
											order: 1,
										}).bppLimit;
										sfv('bppLimit', isBlank(firstBuildingBppLimit) ? '' : 1, false);
									}
									this.clearValuation(value, building, buildingCopy, formikProps, 'ancillaryDescription');
								}}
							/>
							<PageSection title='Classification Information'>
								<Field
									name='occupancyType'
									label='Business Type'
									component={DataDisplay}
									options={sfg_occupancyType}
									disabled
									hidden={!isEmployee()}
								/>
								<Field
									name='classId'
									label='Class Code'
									component={Select}
									options={this.state.classCodeOptions}
									additionalOnChange={(value) => {
										this.updateClassCode(value, formikProps.setFieldValue, buildingCopy);
										this.clearValuation(value, building, buildingCopy, formikProps, 'classId');
									}}
									width='large'
									search
									disabled={ancillary}
								/>
								<Field
									name='separateCanopy'
									label='If the applicant is insuring the canopy is it listed as a separate building?'
									component={RadioButton}
									fieldDisplay={this.visibility['separateCanopy']}
								/>
								<Field
									name='percentSubcontracting'
									label='Percentage of Subcontracting Work'
									component={InputNumber}
									type='percent'
									width='tiny'
									fieldDisplay={this.visibility['percentSubcontracting']}
								/>
								<Field
									name='homeOffice'
									label='Does the applicant operate the business from their residence?'
									component={RadioButton}
									fieldDisplay={this.visibility['homeOffice']}
									additionalOnChange={(value) => {
										if (value === 'N') {
											this.setVeriskPrefilData();
										}
									}}
								/>
								<Field
									name='numberOfMortgageesLossPayees'
									label='Number Of Mortgagees/Loss Payees'
									component={InputNumber}
									width='tiny'
									additionalOnChange={(value, setFieldValue) => {
										if (value > 0) {
											setFieldValue('additionalInsureds', 'Y', false);
										}
									}}
								/>
								<Field
									name='additionalInsureds'
									label='Additional Interests'
									component={RadioButton}
									disabled={_.get(formikProps, 'values.numberOfMortgageesLossPayees', 0) > 0}
								/>
								<Field
									name='additionalInsuredType'
									label='Additional Interest Type'
									component={CheckboxGroup}
									options={additionalInsuredTypeOptions}
									fieldDisplay={this.visibility['additionalInsuredType']}
									additionalInfoFields={{
										BP0402: [
											{
												name: 'BP0402Number',
												label: 'Number of Managers / Lessors',
												component: InputNumber,
												width: 'tiny',
												maxLength: 2,
											},
										],
										BP0416: [
											{
												name: 'BP0416Number',
												label: 'Number Leased Equipment',
												component: InputNumber,
												width: 'tiny',
												maxLength: 2,
											},
										],
									}}
								/>
								<Field
									name='ownerOccupied'
									label='Applicant is'
									component={RadioButton}
									options={sfg_ownerOccupied}
									fieldDisplay={this.visibility.ownerOccupied}
									additionalOnChange={(value, setFieldValue) => {
										if (
											_.includes(['N1', 'Y'], value) &&
											isOriginalBuilding &&
											!isBlank(this.veriskReturn.squareFootage)
										) {
											setFieldValue('squareFootage', this.veriskReturn.squareFootage, false);
										}
									}}
								/>
								<Field
									name='numberOfTenants'
									label='How many tenants are in this building?'
									component={InputNumber}
									maxLength='2'
									width='tiny'
									fieldDisplay={this.visibility.numberOfTenants}
									optional={ancillary}
								/>
								<div className='flexFields'>
									{this.displayTenantFields(_.get(formikProps, 'values.numberOfTenants', 1))}
								</div>
							</PageSection>
							{this.visibility.playground || this.visibility.amusementArea || this.visibility.numberOfSwimmingPools ? (
								<PageSection title='Property Information'>
									<Field
										name='playground'
										label='Playground'
										component={RadioButton}
										fieldDisplay={this.visibility.playground}
									/>
									<Field
										name='amusementArea'
										label='Amusement Area'
										component={RadioButton}
										fieldDisplay={this.visibility.amusementArea}
										referrals={quote.referrals}
									/>
									<Field
										name='numberOfSwimmingPools'
										label='Number of swimming pools'
										component={InputNumber}
										fieldDisplay={this.visibility.numberOfSwimmingPools}
										width='tiny'
									/>
									<Field
										name='poolFenced'
										label='Is the swimming pool fenced'
										component={RadioButton}
										fieldDisplay={this.visibility.poolFenced && this.visibility.numberOfSwimmingPools}
									/>
									<Field
										name='poolDiving'
										label='Does the swimming pool have a diving board or slide'
										component={RadioButton}
										fieldDisplay={this.visibility.poolDiving && this.visibility.numberOfSwimmingPools}
									/>
									<Field
										name='poolGates'
										label='Are the gates locked when the pool is closed'
										component={RadioButton}
										fieldDisplay={this.visibility.poolGates && this.visibility.numberOfSwimmingPools}
									/>
									<Field
										name='poolRules'
										label='Are the pool rules posted'
										component={RadioButton}
										fieldDisplay={this.visibility.poolRules && this.visibility.numberOfSwimmingPools}
									/>
									<Field
										name='poolDepth'
										label='Are the pool depths marked'
										component={RadioButton}
										fieldDisplay={this.visibility.poolDepth && this.visibility.numberOfSwimmingPools}
									/>
									<Field
										name='poolSafety'
										label='Are there life saving devices available by the pool'
										component={RadioButton}
										fieldDisplay={this.visibility.poolSafety && this.visibility.numberOfSwimmingPools}
									/>
								</PageSection>
							) : (
								''
							)}
							<PageSection title='Building Information'>
								<Field
									name='permanentYard'
									label='Permanent Yard'
									component={InputNumber}
									optional
									maxLength='13'
									width='small'
									fieldDisplay={this.visibility.permanentYard}
								/>
								<Field
									name='constructionYear'
									label='Original Construction Year'
									component={
										(this.veriskReturn.constructionYear || this.veriskReturn.effectiveYearBuilt) &&
										formikProps.values.originalPrimary
											? DataDisplay
											: InputNumber
									}
									additionalOnBlur={(value) => {
										this.clearValuation(value, building, buildingCopy, formikProps, 'constructionYear');
									}}
									width='tiny'
									format='####'
									prefillHoverMessage={
										'ConstructionYear (ms1): ' +
										prefillToolTips.constructionYear +
										'\nEffectiveYearBuilt (ms4): ' +
										prefillToolTips.effectiveYearBuilt
									}
								/>
								<Field
									name='constructionType'
									label='Construction'
									component={
										this.veriskReturn.constructionType && formikProps.values.originalPrimary ? DataDisplay : RadioButton
									}
									additionalOnChange={(value) => {
										this.earthquakeCoverageChange(
											formikProps.values.earthquakeCoverage,
											formikProps.setFieldValue,
											formikProps.values,
											value,
										);
										this.clearValuation(value, building, buildingCopy, formikProps, 'constructionType');
									}}
									options={sfg_constructionType}
									labelPrefillHoverMessage={prefillToolTips.constructionType}
								/>
								<Field
									name='roofYear'
									label='Year Roof Updated'
									component={InputNumber}
									width='tiny'
									fieldDisplay={this.visibility.roofYear}
									referrals={quote.referrals}
									format='####'
									optional={ancillary}
									prefillHoverMessage={prefillToolTips.roofYear}
								/>
								<Field
									name='roofType'
									label='Roof Type'
									component={RadioButton}
									options={sfg_roofType}
									fieldDisplay={this.visibility.roofType}
									referrals={quote.referrals}
									labelPrefillHoverMessage={prefillToolTips.roofType}
									additionalOnChange={(value) => {
										this.clearValuation(value, building, buildingCopy, formikProps, 'roofType');
									}}
								/>
								<Field
									name='roofSurfaceLimitation'
									label='Roof Surface Limitation'
									component={RadioButton}
									options={sfg_roofSurfaceLimitationMetal}
									fieldDisplay={this.visibility.roofSurfaceLimitationMetal}
								/>
								<WarningMessage
									fieldDisplay={this.visibility.roofSurfaceLimitationMetal}
									message='The Exclusion of Cosmetic Damage form will be attached due to the metal roof.'
								/>
								<Field
									name='roofSurfaceLimitation'
									label='Roof Surface Limitation'
									component={RadioButton}
									options={sfg_roofSurfaceLimitation}
									fieldDisplay={this.visibility.roofSurfaceLimitation}
								/>
								<Field
									name='wiringYear'
									label='Year Electrical Updated'
									component={InputNumber}
									width='tiny'
									fieldDisplay={this.visibility.wiringYear}
									referrals={quote.referrals}
									format='####'
									optional={ancillary}
								/>
								<Field
									name='plumbingYear'
									label='Year Plumbing Updated'
									component={InputNumber}
									width='tiny'
									fieldDisplay={this.visibility.plumbingYear}
									referrals={quote.referrals}
									format='####'
									optional={ancillary}
								/>
								<Field
									name='primaryHeatingYear'
									label='Year Heating Updated'
									component={InputNumber}
									width='tiny'
									fieldDisplay={this.visibility.primaryHeatingYear}
									referrals={quote.referrals}
									format='####'
									optional={ancillary}
								/>
								<Field
									name='numberOfStories'
									label='Number Of Stories'
									component={
										this.veriskReturn.numberOfStories && formikProps.values.originalPrimary ? DataDisplay : InputNumber
									}
									maxLength='1'
									width='tiny'
									fieldDisplay={this.visibility.numberOfStories}
									prefillHoverMessage={prefillToolTips.numberOfStories}
									additionalOnBlur={(value) => {
										this.clearValuation(value, building, buildingCopy, formikProps, 'numberOfStories');
									}}
								/>
								<Field
									name='squareFootage'
									label='Square Footage'
									component={
										this.veriskReturn.squareFootage &&
										formikProps.values.originalPrimary &&
										_.includes(['N1', 'Y'], formikProps.values.ownerOccupied) &&
										addressState !== 'MS'
											? DataDisplay
											: InputNumber
									}
									type='sqft'
									maxLength='9'
									width='tiny'
									fieldDisplay={this.visibility.squareFootage}
									prefillHoverMessage={
										'Square Footage: ' +
										prefillToolTips.squareFootage +
										'\nPremise Area: ' +
										prefillToolTips.premiseFloorArea
									}
									additionalOnBlur={(value) => {
										this.clearValuation(value, building, buildingCopy, formikProps, 'squareFootage');
									}}
								/>
								<Field
									name='roofArea'
									label='Square Footage of Roof Area'
									component={InputNumber}
									type='sqft'
									maxLength='9'
									width='tiny'
									fieldDisplay={this.visibility.roofArea}
								/>
								<Field
									name='sprinkler'
									label='Sprinkler'
									component={
										this.veriskReturn.sprinkler && formikProps.values.originalPrimary ? DataDisplay : RadioButton
									}
									fieldDisplay={this.visibility.sprinkler}
									labelPrefillHoverMessage={prefillToolTips.sprinkler}
								/>
							</PageSection>
							<PageSection title='Coverage Information' name='section_coverageInfo' errors={formikProps.errors}>
								<div>
									<Field
										name='buildingLimit'
										label='Building Limit'
										component={InputNumber}
										type='currency'
										maxLength='13'
										fieldDisplay={this.visibility.buildingLimit}
										width='small'
										prefillHoverMessage={
											'Total Value: ' + prefillToolTips.calculatedValue + '\nActual Cash Value: ' + prefillToolTips.ACV
										}
									/>
									{isEmployee() && (
										<React.Fragment>
											<div>This report will not update until the form has been submitted.</div>
											<SimpleButton
												disabled={isBlank(valuationId)}
												positive={!isBlank(valuationId)}
												onClick={async () => {
													const pdfData = await getVerisk360PDF(valuationId);
													if (!isBlank(pdfData)) {
														window.open(URL.createObjectURL(base64toBlob(pdfData.base64)), `${valuationId} Valuation`);
													} else {
														toast.error(
															"Authorization Code likely timed out. You're gonna have to re-navigate to touchpoint in a new tab.",
														);
													}
												}}
											>
												{isBlank(valuationId) ? 'No PDF available' : `Verisk 360 Report: ${valuationId}`}
											</SimpleButton>
										</React.Fragment>
									)}
								</div>
								<Field
									name='bppLimit'
									label='Business Personal Property Limit'
									component={InputNumber}
									type='currency'
									width='small'
									disabled={
										ancillary &&
										!_.includes(['Pool House', 'Storage Sheds'], _.get(formikProps, 'values.ancillaryDescription', ''))
									}
									additionalOnChange={(value) => {
										this.earthquakeCoverageChange(
											formikProps.values.earthquakeCoverage,
											formikProps.setFieldValue,
											formikProps.values,
											formikProps.values.constructionType,
										);
									}}
								/>
								<Field
									name='buildingValuation'
									label='Building Valuation'
									component={RadioButton}
									options={sfg_buildingValuation}
									fieldDisplay={this.visibility.buildingValuation}
								/>
								<Field
									name='liabilityExposureBasis'
									label={`Total ${liabilityExposureLabel} Amount`}
									component={InputNumber}
									type='currency'
									fieldDisplay={this.visibility.totalSales || this.visibility.totalPayroll}
									width='small'
									disabled={ancillary}
								/>
								<Field
									name='windstormHailRoofACV'
									label='Windstorm/Hail Roof ACV'
									optional
									component={RadioButton}
									fieldDisplay={this.visibility.windstormHailRoofACV}
								/>
								<Field
									name='pdDeductibleType'
									label='Property Damage Liability Deductible Type'
									component={RadioButton}
									options={sfg_pdDeductibleType}
									fieldDisplay={this.visibility.pdDeductibleType}
								/>
								<Field
									name='pdDeductible'
									label='Property Damage Liability Deductible'
									component={RadioButton}
									options={sfg_pdDeductible}
									fieldDisplay={this.visibility.pdDeductible}
								/>
								<Field
									name='earthquakeCoverage'
									label='Earthquake Coverage'
									additionalOnChange={this.earthquakeCoverageChange}
									component={RadioButton}
									fieldDisplay={this.visibility.earthquakeCoverage}
								/>
								<Field
									name='eqDeductible'
									label='Deductible'
									component={Select}
									options={
										_.includes(['KY', 'MS', 'TN'], addressState, '')
											? sfg_eqDeductible
											: sfg_eqDeductible.filter(({ value }) => value !== '0.05')
									}
									fieldDisplay={this.visibility.eqDeductible && this.visibility.earthquakeCoverage}
									width='small'
								/>
								<Field
									name='eqBuildingClassification'
									label='Building Classification'
									component={Select}
									options={sfg_eqBuildingClassification}
									fieldDisplay={this.visibility.eqBuildingClassification && this.visibility.earthquakeCoverage}
									width='small'
								/>
								<Field
									name='eqBuildingSubLimit'
									label='Building Sub-limit'
									component={Select}
									optionalSelect
									options={subLimitOptions}
									fieldDisplay={this.visibility.eqBuildingSubLimit && this.visibility.earthquakeCoverage}
									width='small'
								/>
								<Field
									name='eqBPPSubLimit'
									label='BPP Sub-limit'
									component={Select}
									optionalSelect
									options={subLimitOptions}
									fieldDisplay={this.visibility.eqBPPSubLimit && this.visibility.earthquakeCoverage}
									width='small'
								/>
								<Field
									name='masonryVeneer'
									label='Masonry Veneer'
									component={RadioButton}
									options={sfg_masonryVeneer}
									fieldDisplay={this.visibility.masonryVeneer}
								/>
								<Field
									name='rateGrade'
									label='Rate Grade'
									component={RadioButton}
									options={sfg_rateGrade}
									fieldDisplay={this.visibility.rateGrade}
									disabled
								/>
							</PageSection>
							<ModalNavButtons
								currentModal='safeguardBuilding'
								onClose={this.props.handleClose}
								locationId={locationId}
								newLocation={newLocation}
								buildingId={id}
								newBuilding={newBuilding}
								building={_.merge(
									buildingCopy,
									duplicate(BuildingRules.requiredStructure),
									duplicate(BuildingRules.optionalStructure),
									formikProps.values,
								)}
								formikProps={formikProps}
								saveValues={() => {
									this.context.onBldgModalSubmit(formikProps.values, this.dirty, this.props);
								}}
								callBack={callBack}
							/>
						</Form>
					);
				}}
				initialValues={{
					id: id && id !== 'NEW' ? id : uuidv4(),
					locationId: locationId || '',
					ancillaryBuilding: buildingCopy.ancillaryBuilding || '',
					ancillaryDescription: buildingCopy.ancillaryDescription || '',
					occupancyType: buildingCopy.occupancyType || '',
					classId: buildingCopy.classId || '',
					classCode: buildingCopy.classCode || '',
					classCodeDescription: buildingCopy.classCodeDescription || '',
					separateCanopy: buildingCopy.separateCanopy || '',
					percentSubcontracting: buildingCopy.percentSubcontracting || '',
					homeOffice: buildingCopy.homeOffice || '',
					numberOfMortgageesLossPayees: !isBlankZ(buildingCopy.numberOfMortgageesLossPayees)
						? buildingCopy.numberOfMortgageesLossPayees
						: '',
					additionalInsureds: buildingCopy.additionalInsureds || '',
					additionalInsuredType: buildingCopy.additionalInsuredType || [],
					BP0402Number: buildingCopy.BP0402Number || 1,
					BP0416Number: buildingCopy.BP0416Number || 1,
					ownerOccupied: buildingCopy.ownerOccupied || '',
					tenant1: buildingCopy.tenant1 || '',
					tenant2: buildingCopy.tenant2 || '',
					tenant3: buildingCopy.tenant3 || '',
					tenant4: buildingCopy.tenant4 || '',
					tenant5: buildingCopy.tenant5 || '',
					tenant6: buildingCopy.tenant6 || '',
					tenant7: buildingCopy.tenant7 || '',
					tenant8: buildingCopy.tenant8 || '',
					tenant9: buildingCopy.tenant9 || '',
					tenant10: buildingCopy.tenant10 || '',
					numberOfTenants: buildingCopy.numberOfTenants || 1,
					playground: buildingCopy.playground || '',
					amusementArea: buildingCopy.amusementArea || '',
					numberOfSwimmingPools: !isBlankZ(buildingCopy.numberOfSwimmingPools)
						? buildingCopy.numberOfSwimmingPools
						: '',
					poolFenced: buildingCopy.poolFenced || '',
					poolDiving: buildingCopy.poolDiving || '',
					poolGates: buildingCopy.poolGates || '',
					poolRules: buildingCopy.poolRules || '',
					poolDepth: buildingCopy.poolDepth || '',
					poolSafety: buildingCopy.poolSafety || '',
					permanentYard: buildingCopy.permanentYard || '',
					constructionYear:
						isOriginalBuilding && !isBlank(this.veriskReturn.constructionYear)
							? this.veriskReturn.constructionYear
							: buildingCopy.constructionYear || (isOriginalBuilding && this.veriskReturn.effectiveYearBuilt) || '',
					constructionType:
						isOriginalBuilding && !isBlank(this.veriskReturn.constructionType)
							? this.veriskReturn.constructionType
							: buildingCopy.constructionType || '',
					roofYear: buildingCopy.roofYear || '',
					roofType: buildingCopy.roofType || (isOriginalBuilding && this.veriskReturn.roofType) || '',
					roofSurfaceLimitation: buildingCopy.roofSurfaceLimitation || 'X',
					wiringYear: buildingCopy.wiringYear || '',
					plumbingYear: buildingCopy.plumbingYear || '',
					primaryHeatingYear: buildingCopy.primaryHeatingYear || '',
					roofArea: buildingCopy.roofArea || '',
					numberOfStories:
						isOriginalBuilding && !isBlank(this.veriskReturn.numberOfStories)
							? this.veriskReturn.numberOfStories
							: buildingCopy.numberOfStories || '',
					// We will use a range rule instead of prefill when not owner occupied
					// If MS we will prefill but allow change so use building copy if previously changed
					squareFootage:
						isOriginalBuilding &&
						!isBlank(this.veriskReturn.squareFootage) &&
						_.includes(['N1', 'Y'], buildingCopy.ownerOccupied)
							? addressState === 'MS'
								? buildingCopy.squareFootage || this.veriskReturn.squareFootage || ''
								: this.veriskReturn.squareFootage
							: buildingCopy.squareFootage || '',
					sprinkler:
						isOriginalBuilding && !isBlank(this.veriskReturn.sprinkler)
							? this.veriskReturn.sprinkler
							: buildingCopy.sprinkler || '',
					buildingLimit: buildingCopy.buildingLimit || '',
					bppLimit: buildingCopy.bppLimit || '',
					buildingValuation: buildingCopy.buildingValuation || '',
					liabilityExposureBasis: buildingCopy.liabilityExposureBasis || '',
					windstormHailRoofACV: buildingCopy.windstormHailRoofACV || '',
					pdDeductibleType: quote.sfg.pdDeductibleType || '1',
					pdDeductible: quote.sfg.pdDeductible || '500',
					earthquakeCoverage: buildingCopy.earthquakeCoverage || '',
					eqDeductible: buildingCopy.eqDeductible || '',
					eqBuildingClassification: buildingCopy.eqBuildingClassification || '',
					eqBuildingSubLimit: buildingCopy.eqBuildingSubLimit || '',
					eqBPPSubLimit: buildingCopy.eqBPPSubLimit || '',
					masonryVeneer: buildingCopy.masonryVeneer || '',
					rateGrade: buildingCopy.rateGrade || '',
					originalPrimary: isOriginalBuilding,
				}}
				onSubmit={(values, formikActions) => {
					cleanValues(values, this.visibility);
					this.context.onBldgModalSubmit(values, this.dirty, this.props, this.context);
					formikActions.setSubmitting(false);
					this.props.handleClose();
				}}
				validate={(values) => {
					checkReferrals(this.context, values, BuildingRules);
					const validResults = validate(
						values,
						BuildingRules.rules(quote, values, this.visibility, this.context.serviceStatus),
						duplicate(BuildingRules.requiredStructure),
					);
					logPageErrors(validResults, this.formProps.touched, 'sfg');
					return validResults;
				}}
			/>
		);
	}
}
