import '@testing-library/jest-dom';
import { act, cleanup, fireEvent, render, screen, waitFor, getAllByRole } from '@testing-library/react';
import MockDate from 'mockdate';
import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import renderer from 'react-test-renderer';
import SafeguardLocationDashboard from '../SfgLocationDashboard';
import QuoteContext from 'context/quoteContext';
jest.mock('axios');
import axios from 'axios';
/* eslint-disable testing-library/no-unnecessary-act */

describe('SafeguardLocationDashboard data', () => {
	const runRequiredServices = jest.fn();
	const updateServiceStatus = jest.fn();
	const onSubmit = jest.fn();
	const quote = {
		quote: {
			newVenture: 'N',
			wcp: {},
			policyState: {
				errorPages: {},
				completed: [],
			},
			personEnteringRisk: 'Nate Stukenborg',
			agentSubpro: '55110-00001',
			customerNumber: '000009000055961',
			insuredName: {
				company: 'GoPo - Gourmet Popcorn',
				first: '',
				last: '',
			},
			naic: 'FULL-SERVICE RESTAURANTS',
			sfg: {
				insurityQuoteNumber: '257186',
				san: '97210801000000',
				noLosses: true,
				lossMessages: {
					'80ca56fb-d4e5-4c4a-baba-d83096936c48': {
						lexisNexisMessage: 'CLUE Report #22573150700999 ordered - No Claims Found',
					},
					'9746e9d9-bec6-4f53-970d-1ccfbc624467': {
						lexisNexisMessage: 'CLUE Report #22306006333581 ordered - No Claims Found',
					},
				},
				priorCarrier: 'Y',
				losses: {},
				coverages: {
					deletedCoverages: ['CDEP'],
					CMCD: {
						liabilityType: '2',
					},
					currentCoverages: ['CDPL', 'CDCR', 'TRSM', 'HIRE', 'NOWN'],
					AGGL: {},
					CDUM: {},
					CDMD: {
						liabilityType: '2',
					},
					ELDT: {},
					CITE: {},
					CDCR: {
						limit: '50000',
					},
					TRSM: {
						included: 'Y',
					},
				},
				umbrellaData: {
					liabilityPremium: '98',
				},
				carrierName: 'Bogus',
				medPayLimit: '5000',
				cigPriorCarrier: 'N',
				locations: {
					'86780d46-24ef-449a-b4d4-e0cba7a2beb9': {
						veriskRoofReport: {
							Roof: {
								RoofMaterial: 'membrane',
								RoofCondition: '3',
								SolarPanels: 'NO SOLAR PANEL',
								RoofShape: 'flat',
							},
							ProMetrixTaskId: 'fa8d0f76-dff0-433f-92fa-96e7f6e8b607',
							StatusCode: 200,
							ExternalTaskId: 'd15809dd-69aa-42cf-8c24-71824e236cc1',
						},
						protectionClass: '|02|COLUMBIA',
						propertyDeductibleAmount: '10000',
						prefillData: {
							datacubes: {
								search_relevance_score: 10,
								questions: {
									burglar_alarm_work: false,
									moving_truck_rental: false,
									spray_painting: false,
									lead_paint_removal: false,
									hazardous_materials_exposure: false,
									swimming_pool_on_premise: false,
									used_or_second_hand_goods_sold: false,
									business_name: 'Unknown',
									hours_of_operation: 'Unknown',
									keyword_matches: {
										word_list: 'Unknown',
										word_objects: [
											{
												word: 'Demolition',
												found: false,
											},
											{
												word: 'Manufacturing',
												found: false,
											},
											{
												word: 'Live Music',
												found: false,
											},
											{
												word: 'Wood fired oven/smoker',
												found: false,
											},
											{
												word: 'Wood-fired oven',
												found: false,
											},
											{
												word: 'Wood-fired smoker',
												found: false,
											},
											{
												word: 'Wood oven',
												found: false,
											},
											{
												word: 'Wood smoker',
												found: false,
											},
											{
												word: 'Remediation',
												found: false,
											},
											{
												word: 'Mold',
												found: false,
											},
										],
									},
									woodworking_on_premise: false,
									school_on_premise: false,
									retaining_wall_work: false,
									work_above_30ft: false,
									provide_towing_services: false,
									has_commercial_vehicle: 'Yes (Radius: Local, Business Use: Service)',
									cocktail_lounge: false,
									gaming_slots_on_premise: 'Unknown',
									payroll: 'Unknown',
									email_contact: 'Unknown',
									naics: ['624221', '624210', '624230', '624120', '624229', '624190'],
									oil_gas_work: false,
									refill_propane_tanks: false,
									naics_description: [
										'624221 - Temporary Shelters',
										'624210 - Community Food Services',
										'624230 - Emergency and Other Relief Services',
										'624120 - Services for the Elderly and Persons with Disabilities',
										'624229 - Other Community Housing Services',
										'624190 - Other Individual and Family Services',
									],
									veterinary_service_exotic_animals: false,
									hospital_construction_work: false,
									fire_alarm_work: false,
									auto_repair_services: false,
									airport_work: false,
									patrol_security: false,
									arson_flag: false,
									detective_agency: false,
									hazardous_materials: false,
									management_exp_gt_3yrs: 'Unknown',
									repackaging_relabeling: false,
									mini_storage_facility: false,
									playground_on_premise: false,
									paint_tank_bridge: false,
									open_24_hours: 'Unknown',
									powerline_work: false,
									years_in_business: 'Unknown',
									sprinkler_work: false,
									automobile_auction: false,
									website: 'Unknown',
									auto_salvage: false,
									sell_products_own_label: false,
									labor_union: false,
									email_address: 'Unknown',
									manufacturing_mixing_products: false,
									boiler_work: false,
									purchase_resale_automobiles: false,
									additional_names: ['DEPARTMENT OF SOCIAL SERVICES'],
									power_plant_work: false,
									premise_exposure: false,
									heavy_equipment_repair: false,
									exercise_facility_exists: false,
									alcohol_sales: false,
									reviews: {
										reviews: 'Unknown',
										ratings: {
											google_rating: 'Unknown',
											yelp_rating: 'Unknown',
										},
									},
									bankruptcy_flag: 'Unknown',
									computer_engineering: false,
									hazardous_materials_pressure: false,
									new_company: 'Unknown',
									links: {
										careers_link: 'Unknown',
										twitter_link: 'Unknown',
										yelp_link: 'Unknown',
										main_page_link: 'Unknown',
										facebook_link: 'Unknown',
										news_link: 'Unknown',
										linkedin_link: 'Unknown',
										contact_link: 'Unknown',
										team_link: 'Unknown',
										product_link: 'Unknown',
										about_us_link: 'Unknown',
									},
									legal_entity: 'Unknown',
									hazardous_materials_industry: false,
									equipment_lessor_renter: false,
									employment_agency: false,
									other_business_activities_on_the_premise: true,
									CIG_business_open_after_12am: 'Unknown',
									business_open_after_2am: 'Unknown',
									used_recapped_retreaded_tires_sold: false,
									phone_number: ['314-474-8533'],
									road_work: false,
									furniture_work: false,
									veterinary_service_breeding_racing: false,
									deep_fryers_used_on_premise: false,
									tax_lien_flag: 'Unknown',
									bankruptcy_details: 'Unknown',
									traffic_signal_work: false,
									paint_above_30ft: false,
									curr_construction: false,
									hospital_work: false,
									welfare_agency: 'Unknown',
									investment_services: false,
									industry_experience: 'Unknown',
									pre_qualification: {
										bankruptcy_indicator: 'Unknown',
										num_of_osha_violations: '0',
										HAZ_hauler_indicator: 'Unknown',
										lob_desc: [
											' Services for the Elderly and Persons with Disabilities',
											' Other Community Housing Services',
											' Community Food Services',
											' Emergency and Other Relief Services',
											'CHILD REL SOCIAL SVCS',
											'INDIVIDUAL AND FAMILY SERVICES',
											' Other Individual and Family Services',
											' Temporary Shelters',
										],
										product_recall_flag: false,
									},
									personal_auto: false,
									cable_underground: false,
									daycare_on_premise: false,
									barges_vessels: false,
									demolition_wreck: false,
									eifs_work: false,
									legal_name: 'Unknown',
									items_sold_on_consignment: false,
									also_known_as: 'Unknown',
									fire_restoration: false,
									cooking_facility_in_units: false,
									roof_work: false,
									naics_confidence: ['HIGH', 'HIGH', 'HIGH', 'HIGH', 'HIGH', 'HIGH'],
									heavy_equipment_used: false,
									asbestos_work: false,
									tree_trimming: false,
									provide_roadside_service: false,
									work_underground: false,
									customizing_services_offered: false,
								},
								companyId: '1460f6a9-c1ab-554d-a3f0-347a74f514fa',
								best_matched_fields_from_query: ['street_addr1', 'zip'],
							},
							verisk: {
								noReturnData: true,
							},
						},
						buildings: {
							'0be4fcce-81d5-4458-ad21-306e0d4a43da': {
								constructionType: '03',
								riskLevel: 'M',
								constructionYear: 2019,
								numberOfMortgageesLossPayees: 0,
								ownerOccupied: 'N1',
								questions: {
									q742: 54,
									reviewedCorrect: 'Y',
									q844: 258,
									q860: 290,
									q882: 335,
									q807: 185,
									q813: 196,
									q857: 285,
									q1056: 712,
									q804: 179,
								},
								additionalInsureds: 'N',
								coverages: {
									currentCoverages: [],
									deletedCoverages: [],
								},
								occupancyType: '8',
								classId: '09641CASUAL DINING BISTROS ALCOH|CD',
								squareFootage: 5000,
								rateNo: '28',
								playground: 'N',
								sprinkler: 'Y',
								amusementArea: 'N',
								order: 1,
								classCode: '09641',
								BP0402Number: 1,
								roofType: 'Other',
								roofSurfaceLimitation: 'X',
								rateGroup: '41',
								originalPrimary: true,
								numberOfStories: 1,
								buildingLimit: 1250000,
								buildingValuation: '1',
								liabilityExposureBasis: 50000,
								prefillData: {
									verisk360: {
										ACV: '1182827.40',
										valuationId: 'AB6Q-W4FK',
										calculatedValue: '1215718.17',
									},
								},
								BP0416Number: 1,
								classCodeDescription: 'CASUAL DINING BISTROS ALCOH|CD',
								earthquakeCoverage: 'N',
							},
						},
						windHailDeductible: '0',
						grossSales: 50000,
						coverages: {
							currentCoverages: ['CDPX'],
						},
						order: 1,
						undefined: false,
					},
				},
				businessType: '7',
				liabilityLimit: '1000000',
				productAggLimit: '2000000',
				expirationDate: '11/10/2022',
				percentSubcontracting: '',
			},
			transactionData: {
				modifiedDate: '2022-11-16T14:02:28.104Z',
				modifiedBy: 'vndbadepwar',
				createdDate: '2022-11-02T21:01:56.699Z',
				createdBy: 'nstukenborg',
			},
			products: ['sfg'],
			naicCode: '722511',
			blockAgentEdit: true,
			geoCodeFailed: false,
			rates: {
				sfg: 'error',
			},
			cup: {},
			id: '69fda11b-ddf2-4193-8a2a-74772e39b398',
			personEnteringRiskEmail: 'nstukenborg@colinsgrp.com',
			addresses: {
				1: {
					zip: '65251-1901',
					poBox: false,
					streetName: 'Court St',
					validated: true,
					streetNumber: '525',
					city: 'Fulton',
					fullAddress: '525 Court St Fulton MO 65251-1901',
					county: 'Callaway',
					state: 'MO',
					ruralRoute: false,
				},
				'86780d46-24ef-449a-b4d4-e0cba7a2beb9': {
					zip: '65202-2335',
					poBox: false,
					streetName: 'Whitegate Dr',
					validated: true,
					streetNumber: '2102',
					city: 'Columbia',
					latitude: '38.967345',
					county: 'Boone',
					fullAddress: '2102 Whitegate Dr Columbia MO 65202-2335',
					state: 'MO',
					longitude: '-92.306005',
					ruralRoute: false,
				},
			},
			sic: 'RESTAURANTS, DINERS, EATING PLACES',
			cap: {
				symbols: {
					liability: '7',
				},
			},
			businessType: '03',
			sicCode: '5812',
			quoteNumber: 2539,
			effectiveDate: '2022-11-16',
			address: {
				zip: '65251-1901',
				poBox: false,
				streetName: 'Court St',
				validated: true,
				streetNumber: '525',
				city: 'Fulton',
				fullAddress: '525 Court St Fulton MO 65251-1901',
				county: 'Callaway',
				state: 'MO',
				ruralRoute: false,
			},
			referrals: {
				addressL: {
					fullAddress: {
						'86acfc14-f45c-49df-828e-79edfbd6eeda': ['SLL02'],
					},
				},
			},
		},
		serviceStatus: {
			addressValidation: false,
			vinValidation: false,
			priorPolicyLookup: false,
			stpPrefill: false,
			verisk: false,
			verisk360: false,
			runningRequiredServices: false,
		},
		updateServiceStatus: updateServiceStatus,
		onSubmit: onSubmit,
	};

	let testUseEffect;
	const mockUseEffect = () => {
		testUseEffect.mockImplementationOnce(() => {});
	};
	const renderComponent = (component) => {
		return render(<BrowserRouter>{component}</BrowserRouter>);
	};
	beforeEach(async () => {
		testUseEffect = jest.spyOn(React, 'useEffect');
		mockUseEffect();
		window.sessionStorage.clear();
		axios.get.mockImplementation((url) => {
			switch (url) {
				case `${process.env.CIG_API_DOMAIN}/InsurityAPI/CountyLookup?city=Fulton&state=MO&zip=65251-1901&county=Callaway&effdte=1668556800000&auth=xyz&env=dev&logLevel=debug&user=vndbadepwar`:
					return Promise.resolve({
						data: [
							{
								text: 'Callaway',
								value: 'Callaway',
							},
						],
					});
				case `${process.env.CIG_API_DOMAIN}/InsurityAPI/ProtectionClassLookup?city=Fulton&state=MO&zip=65251-1901&effdte=1668556800000&auth=xyz&env=dev&logLevel=debug&user=vndbadepwar`:
					return Promise.resolve({
						data: [
							{
								text: 'FULTON (04)',
								value: '|04|FULTON',
							},
							{
								text: 'FULTON (4X)',
								value: '|4x|FULTON',
							},
							{
								text: 'MILLERSBURG FPSA (06)',
								value: '|06|MILLERSBURG FPSA',
							},
							{
								text: 'MILLERSBURG FPSA (6X)',
								value: '|6X|MILLERSBURG FPSA',
							},
						],
					});
				case `${process.env.REACT_APP_AWS_API_DOMAIN}/common-verisk/api/getPropertyInfo/I438973679`:
					return Promise.resolve({
						data: {
							BusinessName: 'Columbia Insurance Group Inc',
							Address: {
								StreetAddress1: '2102 WHITEGATE DR',
								City: 'COLUMBIA',
								State: 'MO',
								Zip: '65202',
								Zip4: '2335',
								County: 'BOONE',
							},
							Ms1: {
								BusinessSicCodes: [
									{
										Code: '641107',
										Description: 'Insurance-Homeowners',
										Sequence: '1',
									},
									{
										Code: '641112',
										Description: 'Insurance',
										Sequence: '2',
									},
									{
										Code: '641122',
										Description: 'Insurance-Plan Administrators',
										Sequence: '3',
									},
								],
								BusinessNaicsCodes: [
									{
										Code: 524210,
										Description: 'Insurance Agencies and Brokerages',
										Sequence: 1,
									},
									{
										Code: 524298,
										Description: 'All Other Insurance Related Activities',
										Sequence: 2,
									},
								],
								TotalEmployees: '161',
								IsEmploymentVerified: false,
								CreditScore: 866,
								BuildingFireConstructionCode: {
									Code: '2',
									Description: 'Joisted Masonry',
								},
								GpsCoordinates: {
									Latitude: 38.968067,
									Longitude: -92.306571,
								},
								OnsiteSurveyDate: '07/01/2012',
								Occupancy: {
									Code: '0702',
									Description: 'Non-Governmental Offices and Banks',
								},
								YearBuilt: 1980,
								Stories: 2,
								SquareFootage: '53,300 sq. ft',
								Ppc: '02',
							},
							Ms2: {
								BusinessDescription:
									'Columbia Insurance Group and its affiliated companies have a history that began in 1874 as a part of the growing mutual insurance movement in the Midwest. It began as the Home Mutual Insurance Company to protect homes from fire in rural Missouri. The company emphasizes growing its small and midsized commercial lines book, and it also provides the farm and personal lines market with insurance coverage. In June 2006, Columbia Insurance Group was rated A- by A.M. Best, the largest and longest established company to issue in-depth reports and financial-strength ratings about insurance organizations. Columbia Insurance Group offers products in Arkansas, Georgia, Illinois, Iowa, Kansas, Missouri, Nebraska, Oklahoma, South Dakota and Tennessee through the independent insurance agency mechanism.',
								ContactName: 'Robert Wagner',
								WorkFromHome: false,
								HoursOfOperation: [
									{
										DayOfWeek: 'Mon',
										OpenTime: '09:00',
										CloseTime: '17:00',
									},
									{
										DayOfWeek: 'Tue',
										OpenTime: '09:00',
										CloseTime: '17:00',
									},
									{
										DayOfWeek: 'Wed',
										OpenTime: '09:00',
										CloseTime: '17:00',
									},
									{
										DayOfWeek: 'Thu',
										OpenTime: '09:00',
										CloseTime: '17:00',
									},
									{
										DayOfWeek: 'Fri',
										OpenTime: '09:00',
										CloseTime: '17:00',
									},
								],
								YearStarted: '1874',
								RelativeCreditGradings: [
									{
										GroupingCriterias: [
											{
												GroupingName: 'Industry',
												GroupingCode: '52',
												GroupingValue: 'Finance and Insurance',
											},
											{
												GroupingName: 'Number of Employees',
												GroupingValue: '100 - 249',
											},
										],
										GradingValue: '1',
										IsSpecialBucket: false,
									},
									{
										GroupingCriterias: [
											{
												GroupingName: 'Number of Employees',
												GroupingValue: '100 - 249',
											},
										],
										GradingValue: '1',
										IsSpecialBucket: false,
									},
									{
										GroupingCriterias: [
											{
												GroupingName: 'Industry',
												GroupingCode: '52',
												GroupingValue: 'Finance and Insurance',
											},
										],
										GradingValue: '1',
										IsSpecialBucket: false,
									},
								],
							},
							Ms3: {
								Sprinklered: false,
								Crime: {
									MatchType: 'Address Level Match',
									CAPRiskIndex: {
										IndexValuesUpto10: {
											Current: '7',
											Past: '7',
											Forecasted: '7',
										},
										IndexValuesUpto2000: {
											Current: '258',
											Past: '243',
											Forecasted: '247',
										},
									},
									IsReportAvailable: true,
									Arson: {
										IndexValuesUpto10: {
											Current: '7',
											Past: '7',
											Forecasted: '7',
										},
										IndexValuesUpto2000: {
											Current: '253',
											Past: '238',
											Forecasted: '242',
										},
									},
									AutoTheft: {
										IndexValuesUpto10: {
											Current: '6',
											Past: '6',
											Forecasted: '7',
										},
										IndexValuesUpto2000: {
											Current: '198',
											Past: '197',
											Forecasted: '227',
										},
									},
									Robbery: {
										IndexValuesUpto10: {
											Current: '7',
											Past: '7',
											Forecasted: '7',
										},
										IndexValuesUpto2000: {
											Current: '232',
											Past: '231',
											Forecasted: '220',
										},
									},
									AggravatedAssault: {
										IndexValuesUpto10: {
											Current: '7',
											Past: '7',
											Forecasted: '7',
										},
										IndexValuesUpto2000: {
											Current: '245',
											Past: '290',
											Forecasted: '270',
										},
									},
									Burglary: {
										IndexValuesUpto10: {
											Current: '10',
											Past: '10',
											Forecasted: '10',
										},
										IndexValuesUpto2000: {
											Current: '838',
											Past: '718',
											Forecasted: '842',
										},
									},
									Homicide: {
										IndexValuesUpto10: {
											Current: '7',
											Past: '6',
											Forecasted: '7',
										},
										IndexValuesUpto2000: {
											Current: '201',
											Past: '188',
											Forecasted: '205',
										},
									},
									Rape: {
										IndexValuesUpto10: {
											Current: '8',
											Past: '7',
											Forecasted: '8',
										},
										IndexValuesUpto2000: {
											Current: '353',
											Past: '276',
											Forecasted: '352',
										},
									},
									Larceny: {
										IndexValuesUpto10: {
											Current: '9',
											Past: '8',
											Forecasted: '8',
										},
										IndexValuesUpto2000: {
											Current: '408',
											Past: '369',
											Forecasted: '380',
										},
									},
									AggregateCrimesAgainstPerson: {
										IndexValuesUpto10: {
											Current: '7',
											Past: '7',
											Forecasted: '7',
										},
										IndexValuesUpto2000: {
											Current: '250',
											Past: '260',
											Forecasted: '262',
										},
									},
									AggregateCrimesAgainstProperty: {
										IndexValuesUpto10: {
											Current: '9',
											Past: '9',
											Forecasted: '9',
										},
										IndexValuesUpto2000: {
											Current: '455',
											Past: '425',
											Forecasted: '437',
										},
									},
								},
								Bcegs: '99',
							},
							Ms4: {
								LegalName: 'Columbia Insurance Group Inc',
								LocationType: 'Headquarters',
								Payroll: '$10,000,000+',
								PremiseFloorArea: '100,000+ sq. ft',
								BusinessLinkage: 'COLUMBIA MUTUAL INSURANCE CO INC',
								BankruptcyCount: 0,
								LiensCount: 0,
								FloorData: [
									{
										FloorLevel: 1,
										SquareFootage: 18200,
										FloorType: 'FLOOR',
									},
									{
										FloorLevel: 2,
										SquareFootage: 35100,
										FloorType: 'FLOOR',
									},
								],
								Combustibility: '2',
								OnsiteSurveyDate: '07/01/2012',
								MarketValue: '2366500',
								EffectiveYearBuilt: 1980,
								RestaurantInspectionAndViolations: {
									IsDataApplicable: false,
								},
								Crime: {
									MatchType: 'Address Level Match',
									CAPRiskIndex: {
										IndexValuesUpto10: {
											Current: '7',
											Past: '7',
											Forecasted: '7',
										},
										IndexValuesUpto2000: {
											Current: '258',
											Past: '243',
											Forecasted: '247',
										},
									},
									IsReportAvailable: true,
									Arson: {
										IndexValuesUpto10: {
											Current: '7',
											Past: '7',
											Forecasted: '7',
										},
										IndexValuesUpto2000: {
											Current: '253',
											Past: '238',
											Forecasted: '242',
										},
									},
									AutoTheft: {
										IndexValuesUpto10: {
											Current: '6',
											Past: '6',
											Forecasted: '7',
										},
										IndexValuesUpto2000: {
											Current: '198',
											Past: '197',
											Forecasted: '227',
										},
									},
									Robbery: {
										IndexValuesUpto10: {
											Current: '7',
											Past: '7',
											Forecasted: '7',
										},
										IndexValuesUpto2000: {
											Current: '232',
											Past: '231',
											Forecasted: '220',
										},
									},
									AggravatedAssault: {
										IndexValuesUpto10: {
											Current: '7',
											Past: '7',
											Forecasted: '7',
										},
										IndexValuesUpto2000: {
											Current: '245',
											Past: '290',
											Forecasted: '270',
										},
									},
									Burglary: {
										IndexValuesUpto10: {
											Current: '10',
											Past: '10',
											Forecasted: '10',
										},
										IndexValuesUpto2000: {
											Current: '838',
											Past: '718',
											Forecasted: '842',
										},
									},
									Homicide: {
										IndexValuesUpto10: {
											Current: '7',
											Past: '6',
											Forecasted: '7',
										},
										IndexValuesUpto2000: {
											Current: '201',
											Past: '188',
											Forecasted: '205',
										},
									},
									Rape: {
										IndexValuesUpto10: {
											Current: '8',
											Past: '7',
											Forecasted: '8',
										},
										IndexValuesUpto2000: {
											Current: '353',
											Past: '276',
											Forecasted: '352',
										},
									},
									Larceny: {
										IndexValuesUpto10: {
											Current: '9',
											Past: '8',
											Forecasted: '8',
										},
										IndexValuesUpto2000: {
											Current: '408',
											Past: '369',
											Forecasted: '380',
										},
									},
									AggregateCrimesAgainstPerson: {
										IndexValuesUpto10: {
											Current: '7',
											Past: '7',
											Forecasted: '7',
										},
										IndexValuesUpto2000: {
											Current: '250',
											Past: '260',
											Forecasted: '262',
										},
									},
									AggregateCrimesAgainstProperty: {
										IndexValuesUpto10: {
											Current: '9',
											Past: '9',
											Forecasted: '9',
										},
										IndexValuesUpto2000: {
											Current: '455',
											Past: '425',
											Forecasted: '437',
										},
									},
								},
								Ppc: {
									Ppc: '2',
									FireProtectionArea: 'COLUMBIA',
									WaterSupplyType: 'Hydrant',
									RespondingFireStation: 'COLUMBIA FS 4',
									DriveDistanceToRespondingFireStation: '1 mile or less',
								},
								OshaInpectionsAndViolations: {
									InspectionsInLast10Years: '0',
									ViolationsInLast10Years: '0',
								},
								ManufacturingPercentOfArea: 0,
								HabitationalPercentOfArea: 0,
								RiskId: '24MO66024391',
								FeinNumber: '430926456',
								DbaName: 'COLUMBIA INSURANCE GROUP, INC.',
								SprinklerCreditValue: 'Partial credit',
								TotalSalesVolume: '$1,070,699,000',
							},
						},
					});

				case `${process.env.REACT_APP_AWS_API_DOMAIN}/common-datacubes/api/getPrefillData/1460f6a9-c1ab-554d-a3f0-347a74f514fa`:
					return Promise.resolve({
						data: {
							d3Company: {
								company_name: 'STATE OF MISSOURI',
								location_of_operation: [
									{
										zip: '65202',
										user_added: false,
										city: 'COLUMBIA',
										latitude: 38.9681,
										address_id: 'a6ebc3e3cd766c8a',
										county: 'BOONE',
										other_names: 'Unknown',
										street_addr1: '2102 WHITEGATE DR',
										street_addr2: 'Unknown',
										owned: false,
										company_name: 'STATE OF MISSOURI',
										state: 'MO',
										longitude: -92.3073,
										primary: true,
									},
									{
										zip: '65202',
										user_added: false,
										city: 'COLUMBIA',
										latitude: 38.9759,
										address_id: '0181af1d4928af79',
										county: 'BOONE',
										other_names: 'Unknown',
										street_addr1: '108 W CRAIG ST',
										street_addr2: 'Unknown',
										owned: false,
										company_name: 'STATE OF MISSOURI',
										state: 'MO',
										longitude: -92.3384,
										primary: false,
									},
									{
										zip: '65233',
										user_added: false,
										city: 'BOONVILLE',
										latitude: 38.9446,
										address_id: '3f3362c6d5264958',
										county: 'COOPER',
										other_names: 'Unknown',
										street_addr1: '1680 RADIO HILL RD',
										street_addr2: 'Unknown',
										owned: false,
										company_name: 'STATE OF MISSOURI',
										state: 'MO',
										longitude: -92.7726,
										primary: false,
									},
									{
										zip: '65251',
										user_added: false,
										city: 'FULTON',
										latitude: 38.847,
										address_id: 'a84e918f5f7137ae',
										county: 'CALLAWAY',
										other_names: 'Unknown',
										street_addr1: '600 E 5TH ST',
										street_addr2: 'Unknown',
										owned: false,
										company_name: 'STATE OF MISSOURI',
										state: 'MO',
										longitude: -91.9396,
										primary: false,
									},
									{
										zip: '65251',
										user_added: false,
										city: 'FULTON',
										latitude: 38.8472,
										address_id: 'cfdb1115bb7887ff',
										county: 'CALLAWAY',
										other_names: 'Unknown',
										street_addr1: '505 E 5TH ST',
										street_addr2: 'Unknown',
										owned: false,
										company_name: 'STATE OF MISSOURI',
										state: 'MO',
										longitude: -91.94,
										primary: false,
									},
									{
										zip: '65202',
										user_added: false,
										city: 'COLUMBIA',
										latitude: 38.9711,
										address_id: 'e0c923a71a853532',
										county: 'BOONE',
										other_names: 'Unknown',
										street_addr1: '1500 VANDIVER DR',
										street_addr2: 'STE 100',
										owned: false,
										company_name: 'STATE OF MISSOURI',
										state: 'MO',
										longitude: -92.3161,
										primary: false,
									},
								],
								officers: 'Unknown',
								description_of_operation: 'Unknown',
								status: 'ACTIVE',
								annual_sales: 'Unknown',
								coverage: 'Unknown',
								zip: '65202',
								public_private_indicator: 'Unknown',
								ceo_last_name: 'Unknown',
								ceo_first_name: 'Unknown',
								website: 'Unknown',
								ein: 'Unknown',
								naics: ['624221', '624210', '624230', '624120', '624229', '624190'],
								company_id: '1460f6a9-c1ab-554d-a3f0-347a74f514fa',
								naics_description: [
									'624221 - Temporary Shelters',
									'624210 - Community Food Services',
									'624230 - Emergency and Other Relief Services',
									'624120 - Services for the Elderly and Persons with Disabilities',
									'624229 - Other Community Housing Services',
									'624190 - Other Individual and Family Services',
								],
								established_year: 'Unknown',
								type_of_org: 'Unknown',
								number_of_employee: 'Unknown',
								site_employee: 'Unknown',
								street_addr1: '2102 WHITEGATE DR',
								street_addr2: 'Unknown',
								city: 'COLUMBIA',
								state: 'MO',
								sic: ['8322'],
								number_of_officer: 0,
								number_of_agent: 0,
								primary_contact: 'Unknown',
								other_contact: 'Unknown',
								agents: 'Unknown',
								sic_description: ['CHILD REL SOCIAL SVCS', 'INDIVIDUAL AND FAMILY SERVICES'],
								financial_info: {
									year_started: 'Unknown',
									website: 'Unknown',
									sic_codes: ['8322'],
									site_employees: 'Unknown',
									num_of_employee: 'Unknown',
									site_status: 'ACTIVE',
									bankruptcy_indicator: 'Unknown',
									company_name: 'STATE OF MISSOURI',
									annual_sales: 'Unknown',
									credit_score_class: 'Unknown',
									tax_liens_indicator: 'Unknown',
									payroll: 'Unknown',
									paydex_score: 'Unknown',
									industry_paydex_score: 'Unknown',
									number_of_suits: 'Unknown',
									number_of_liens: 'Unknown',
									number_of_judgements: 'Unknown',
									net_worth: 'Unknown',
									subsidiary_indicator: 'Unknown',
									fss: 'Unknown',
									slow_payments: 'Unknown',
									past_due_payments: 'Unknown',
									lob_desc: ['CHILD REL SOCIAL SVCS', 'INDIVIDUAL AND FAMILY SERVICES'],
								},
								email_address: 'Unknown',
								phone_num: ['314-474-8533'],
								am_best_rating: 'Unknown',
								wc_rating: 'Unknown',
								sic_mapped: [
									{
										code: '8322',
										description: 'INDIVIDUAL AND FAMILY SERVICES',
									},
									{
										code: '8322',
										description: 'CHILD REL SOCIAL SVCS',
									},
								],
								display_name: 'STATE OF MISSOURI',
							},
							d3Risk360: {
								permits: 'Unknown',
								inspections: 'Unknown',
								events: 'Unknown',
								primary_property_risk: {
									general: {
										company_name: 'STATE OF MISSOURI',
										company_id: '1460f6a9-c1ab-554d-a3f0-347a74f514fa',
										ein: 'Unknown',
										street_addr1: '2102 WHITEGATE DR',
										street_addr2: 'Unknown',
										city: 'COLUMBIA',
										state: 'MO',
										zip: '65202',
										county: 'BOONE',
										latitude: 38.9681,
										longitude: -92.3073,
										address_id: 'a6ebc3e3cd766c8a',
									},
									other_tenants: [
										{
											naics_description: [
												'541211 - Offices of Certified Public Accountants',
												'561613 - Armored Car Services',
											],
											zip: '65202',
											website: 'Unknown',
											address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
											city: 'COLUMBIA',
											latitude: 38.9681,
											street_addr1: '2102 WHITEGATE DR',
											ein: 'Unknown',
											street_addr2: 'Unknown',
											sic: ['7381'],
											company_name: 'FRED S BURRESS COMPANY INC',
											sic_mapped: [
												{
													code: '7381',
													description: 'DETECTIVE AND ARMORED CAR SERVICES',
												},
												{
													code: '7381',
													description: 'DETECTIVE SERVICES',
												},
											],
											state: 'MO',
											naics: ['541211', '561613'],
											sic_description: ['DETECTIVE AND ARMORED CAR SERVICES', 'DETECTIVE SERVICES'],
											longitude: -92.3073,
										},
										{
											naics_description: [
												'541110 - Offices of Lawyers',
												'524210 - Insurance Agencies and Brokerages',
												'561499 - All Other Business Support Services',
												'813319 - Other Social Advocacy Organizations',
												'524126 - Direct Property and Casualty Insurance Carriers',
											],
											zip: '65202',
											website: ['https://www.colinsgrp.com/site/'],
											address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
											city: 'COLUMBIA',
											latitude: 38.9681,
											street_addr1: '2102 WHITEGATE DR',
											ein: ['430726456', '430926456'],
											street_addr2: 'Unknown',
											sic: ['6411', '7389', '6331', '641112'],
											company_name: 'COLUMBIA INSURANCE GROUP INC',
											sic_mapped: [
												{
													code: '6411',
													description: 'INSURANCE AGENTS, BROKERS, AND SERVICE',
												},
												{
													code: '6411',
													description: 'INSURANCE AGENTS,BRKS',
												},
												{
													code: '6411',
													description: 'LIFE INSURANCE AGENTS',
												},
												{
													code: '7389',
													description: 'BUSINESS SERVICES, NEC',
												},
												{
													code: '7389',
													description: 'FINANCIAL SERVICES',
												},
												{
													code: '6331',
													description: 'FIRE, MARINE, AND CASUALTY INSURANCE',
												},
												{
													code: '6331',
													description: 'FIRE,MARINE,CAS INSUR',
												},
												{
													code: '641112',
													description: 'INSURANCE',
												},
											],
											state: 'MO',
											naics: ['541110', '524210', '561499', '813319', '524126', '524150'],
											sic_description: [
												'INSURANCE AGENTS, BROKERS, AND SERVICE',
												'INSURANCE AGENTS,BRKS',
												'LIFE INSURANCE AGENTS',
												'BUSINESS SERVICES, NEC',
												'FINANCIAL SERVICES',
												'FIRE, MARINE, AND CASUALTY INSURANCE',
												'FIRE,MARINE,CAS INSUR',
												'INSURANCE',
											],
											longitude: -92.3073,
										},
										{
											naics_description: [
												'813910 - Business Associations',
												'624190 - Other Individual and Family Services',
											],
											zip: '65202',
											website: 'Unknown',
											address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
											city: 'COLUMBIA',
											latitude: 38.9681,
											street_addr1: '2102 WHITEGATE DR',
											ein: 'Unknown',
											street_addr2: 'Unknown',
											sic: ['8322'],
											company_name: 'STATE OF MISSOURI',
											sic_mapped: [
												{
													code: '8322',
													description: 'CHILD REL SOCIAL SVCS',
												},
												{
													code: '8322',
													description: 'INDIVIDUAL AND FAMILY SERVICES',
												},
											],
											state: 'MO',
											naics: ['813910', '624190'],
											sic_description: ['CHILD REL SOCIAL SVCS', 'INDIVIDUAL AND FAMILY SERVICES'],
											longitude: -92.3073,
										},
										{
											naics_description: ['541110 - Offices of Lawyers'],
											zip: '65202',
											website: 'Unknown',
											address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
											city: 'COLUMBIA',
											latitude: 38.9681,
											street_addr1: '2102 WHITEGATE DR',
											ein: 'Unknown',
											street_addr2: 'Unknown',
											sic: 'Unknown',
											company_name: 'DARDOF INC',
											sic_mapped: 'Unknown',
											state: 'MO',
											naics: ['541110'],
											sic_description: 'Unknown',
											longitude: -92.3073,
										},
										{
											naics_description: ['541199 - All Other Legal Services'],
											zip: '65202',
											website: 'Unknown',
											address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
											city: 'COLUMBIA',
											latitude: 38.9681,
											street_addr1: '2102 WHITEGATE DR',
											ein: 'Unknown',
											street_addr2: 'Unknown',
											sic: 'Unknown',
											company_name: 'ITS A PROCESS LLC',
											sic_mapped: 'Unknown',
											state: 'MO',
											naics: ['541199'],
											sic_description: 'Unknown',
											longitude: -92.3073,
										},
										{
											naics_description: ['236115 - New Single-Family Housing Construction (except For-Sale Builders)'],
											zip: '65202',
											website: 'Unknown',
											address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
											city: 'COLUMBIA',
											latitude: 38.9681,
											street_addr1: '2102 WHITEGATE DR',
											ein: 'Unknown',
											street_addr2: 'Unknown',
											sic: 'Unknown',
											company_name: 'SAMRANY CONSTRUCTION LLC',
											sic_mapped: 'Unknown',
											state: 'MO',
											naics: ['236115'],
											sic_description: 'Unknown',
											longitude: -92.3073,
										},
										{
											naics_description: ['524210 - Insurance Agencies and Brokerages'],
											zip: '65202',
											website: 'Unknown',
											address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
											city: 'COLUMBIA',
											latitude: 38.9681,
											street_addr1: '2102 WHITEGATE DR',
											ein: 'Unknown',
											street_addr2: 'Unknown',
											sic: 'Unknown',
											company_name: 'GEORGIA CASUALTY & SURETY COMPANY',
											sic_mapped: 'Unknown',
											state: 'MO',
											naics: ['524210'],
											sic_description: 'Unknown',
											longitude: -92.3073,
										},
										{
											naics_description: [
												'531312 - Nonresidential Property Managers',
												'531120 - Lessors of Nonresidential Buildings (except Miniwarehouses)',
												'447190 - Other Gasoline Stations',
											],
											zip: '65202',
											website: 'Unknown',
											address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
											city: 'COLUMBIA',
											latitude: 38.9681,
											street_addr1: '2102 WHITEGATE DR',
											ein: 'Unknown',
											street_addr2: 'Unknown',
											sic: ['6512'],
											company_name: 'WHITEGATE SHOPPING CTR',
											sic_mapped: [
												{
													code: '6512',
													description: 'NONRESIDENT BLDG OPER',
												},
												{
													code: '6512',
													description: 'NONRESIDENTIAL BUILDING OPERATORS',
												},
											],
											state: 'MO',
											naics: ['531312', '531120', '447190'],
											sic_description: ['NONRESIDENT BLDG OPER', 'NONRESIDENTIAL BUILDING OPERATORS'],
											longitude: -92.3073,
										},
									],
								},
								violations: 'Unknown',
							},
							d3PreFill: {
								company: {
									industry_experience: 'Unknown',
									bankruptcy_flag: 'Unknown',
									arson_flag: false,
									curr_construction: false,
									hazardous_materials: false,
									eifs_work: false,
									paint_tank_bridge: false,
									road_work: false,
									cable_underground: false,
									fire_restoration: false,
									roof_work: false,
									tree_trimming: false,
									demolition_wreck: false,
									hazardous_materials_exposure: false,
									work_underground: false,
									work_above_30ft: false,
									burglar_alarm_work: false,
									hospital_work: false,
									powerline_work: false,
									traffic_signal_work: false,
									retaining_wall_work: false,
									lead_paint_removal: false,
									paint_above_30ft: false,
									barges_vessels: false,
									oil_gas_work: false,
									new_company: 'Unknown',
									hazardous_materials_pressure: false,
									naics: ['624221', '624210', '624230', '624120', '624229', '624190'],
									naics_description: [
										'624221 - Temporary Shelters',
										'624210 - Community Food Services',
										'624230 - Emergency and Other Relief Services',
										'624120 - Services for the Elderly and Persons with Disabilities',
										'624229 - Other Community Housing Services',
										'624190 - Other Individual and Family Services',
									],
									premise_exposure: false,
									naics_confidence: ['HIGH', 'HIGH', 'HIGH', 'HIGH', 'HIGH', 'HIGH'],
									personal_auto: false,
									business_open_after_2am: 'Unknown',
									alcohol_sales: false,
									open_24_hours: 'Unknown',
									asbestos_work: false,
									deep_fryers_used_on_premise: false,
									hazardous_materials_industry: false,
									equipment_lessor_renter: false,
									heavy_equipment_used: false,
									airport_work: false,
									items_sold_on_consignment: false,
									used_or_second_hand_goods_sold: false,
									used_recapped_retreaded_tires_sold: false,
									cooking_facility_in_units: false,
									auto_repair_services: false,
									customizing_services_offered: false,
									other_business_activities_on_the_premise: true,
									refill_propane_tanks: false,
									sell_products_own_label: false,
									moving_truck_rental: false,
									management_exp_gt_3yrs: 'Unknown',
									daycare_on_premise: false,
									auto_salvage: false,
									spray_painting: false,
									computer_engineering: false,
									cocktail_lounge: false,
									playground_on_premise: false,
									swimming_pool_on_premise: false,
									automobile_auction: false,
									school_on_premise: false,
									links: {
										linkedin_link: 'Unknown',
										facebook_link: 'Unknown',
										twitter_link: 'Unknown',
										yelp_link: 'Unknown',
										careers_link: 'Unknown',
										contact_link: 'Unknown',
										team_link: 'Unknown',
										news_link: 'Unknown',
										product_link: 'Unknown',
										about_us_link: 'Unknown',
										main_page_link: 'Unknown',
									},
									pre_qualification: {
										lob_desc: [
											' Services for the Elderly and Persons with Disabilities',
											' Other Community Housing Services',
											' Community Food Services',
											' Emergency and Other Relief Services',
											'CHILD REL SOCIAL SVCS',
											'INDIVIDUAL AND FAMILY SERVICES',
											' Other Individual and Family Services',
											' Temporary Shelters',
										],
										bankruptcy_indicator: 'Unknown',
										num_of_osha_violations: '0',
										product_recall_flag: false,
										HAZ_hauler_indicator: 'Unknown',
									},
									reviews: {
										reviews: 'Unknown',
										ratings: {
											yelp_rating: 'Unknown',
											google_rating: 'Unknown',
										},
									},
									hours_of_operation: 'Unknown',
									tax_lien_flag: 'Unknown',
									payroll: 'Unknown',
									years_in_business: 'Unknown',
									also_known_as: 'Unknown',
									legal_name: 'Unknown',
									email_address: 'Unknown',
									email_contact: 'Unknown',
									phone_number: ['314-474-8533'],
									website: 'Unknown',
									legal_entity: 'Unknown',
									business_name: 'Unknown',
									additional_names: ['DEPARTMENT OF SOCIAL SERVICES'],
									keyword_matches: {
										word_list: 'Unknown',
										word_objects: [
											{
												found: false,
												word: 'Demolition',
											},
											{
												found: false,
												word: 'Manufacturing',
											},
											{
												found: false,
												word: 'Live Music',
											},
											{
												found: false,
												word: 'Wood fired oven/smoker',
											},
											{
												found: false,
												word: 'Wood-fired oven',
											},
											{
												found: false,
												word: 'Wood-fired smoker',
											},
											{
												found: false,
												word: 'Wood oven',
											},
											{
												found: false,
												word: 'Wood smoker',
											},
											{
												found: false,
												word: 'Remediation',
											},
											{
												found: false,
												word: 'Mold',
											},
										],
									},
									bankruptcy_details: 'Unknown',
									boiler_work: false,
									furniture_work: false,
									exercise_facility_exists: false,
									heavy_equipment_repair: false,
									purchase_resale_automobiles: false,
									repackaging_relabeling: false,
									woodworking_on_premise: false,
									gaming_slots_on_premise: 'Unknown',
									veterinary_service_exotic_animals: false,
									veterinary_service_breeding_racing: false,
									power_plant_work: false,
									provide_roadside_service: false,
									hospital_construction_work: false,
									fire_alarm_work: false,
									sprinkler_work: false,
									manufacturing_mixing_products: false,
									mini_storage_facility: false,
									patrol_security: false,
									employment_agency: false,
									welfare_agency: 'Unknown',
									investment_services: false,
									labor_union: false,
									provide_towing_services: false,
									detective_agency: false,
									has_commercial_vehicle: 'Yes (Radius: Local, Business Use: Service)',
									CIG_business_open_after_12am: 'Unknown',
								},
								sources: ['FIRMOGRAPHIC'],
								images: {
									website_screenshots: 'Unknown',
									website_images: 'Unknown',
									places_images: 'Unknown',
									street_images: 'Unknown',
									company_vehicle_images: 'Unknown',
								},
							},
							d3Property: {
								location_of_operation: [
									{
										zip: '65202',
										user_added: false,
										square_footage: 58418,
										occupancy_subtype: 'Office Bldg (General)',
										city: 'COLUMBIA',
										latitude: 38.9681,
										address_id: 'a6ebc3e3cd766c8a',
										county: 'BOONE',
										historical_property: {
											hist_property_url: 'https://npgallery.nps.gov/AssetDetail/NRIS/02000791',
											distance_ft: 5191.82,
											latitude: '38.96068817500003',
											name: 'Hamilton--Brown Shoe Factory',
											distance_mi: 0.98,
											risk: false,
											historical_flag: false,
											longitude: '-92.32291630199995',
										},
										other_names: 'Unknown',
										street_addr1: '2102 WHITEGATE DR',
										street_addr2: 'Unknown',
										construction_type: 'Unknown',
										earthquake_mmi: {
											mmi: 4,
											risk: false,
											pga: 3,
										},
										nearest_firestation: {
											number_of_stations: 5,
											details: [
												{
													address: '2300 Oakland Gravel Road, Columbia, MO, 65202-2029',
													distance: 0.53,
													latitude: 38.97453308100006,
													name: 'Columbia Fire Department Station 4',
													longitude: -92.3019104,
												},
												{
													address: '201 Orr Street, Columbia, MO, 65201-4964',
													distance: 1.4,
													latitude: 38.95380783100006,
													name: 'Columbia Fire Department Station 1',
													longitude: -92.32585906999998,
												},
												{
													address: '201 Blueridge Road, Columbia, MO, 65202-3724',
													distance: 1.8,
													latitude: 38.983749389000025,
													name: 'Columbia Fire Department Station 9',
													longitude: -92.33399200499997,
												},
												{
													address: '1000 Ashland Road, Columbia, MO, 65201-5206',
													distance: 2.12,
													latitude: 38.93898010300006,
													name: 'Columbia Fire Department Station 3',
													longitude: -92.31970214799998,
												},
												{
													address: '1400 North Ballenger Lane, Columbia, MO, 65202-2861',
													distance: 2.15,
													latitude: 38.964969635000045,
													name: 'Columbia Fire Department Station 5',
													longitude: -92.26734924299996,
												},
											],
											distance_to_closest: 0.53,
										},
										distance_to_coast: {
											distance_ft: 1663737.31,
											distance_mi: 315.1,
											risk: false,
											body: 'Great Lakes',
										},
										owned: false,
										nearest_flood_zone: {
											bfe: 'Unknown',
											static_bfe: -9999,
											gid: 1600926,
											depth: -9999,
											bfe_revert: -9999,
											sfha_tf: 'F',
											zone_subty: 'AREA OF MINIMAL FLOOD HAZARD',
											risk: false,
											fld_zone: 'X',
											study_typ: 'NP',
											nearest_sfha: {
												static_bfe: -9999,
												gid: 1599868,
												depth: -9999,
												bfe_revert: -9999,
												distance_ft: 3334.09,
												sfha_tf: 'T',
												zone_subty: 'Unknown',
												distance_mi: 0.63,
												fld_zone: 'AE',
												study_typ: 'NP',
											},
										},
										company_name: 'STATE OF MISSOURI',
										year_built: '1967',
										state: 'MO',
										longitude: -92.3073,
										primary: true,
										occupancy_type: 'OFFICE',
									},
									{
										zip: '65202',
										user_added: false,
										square_footage: 0,
										occupancy_subtype: 'Parochial School, Private School',
										city: 'COLUMBIA',
										latitude: 38.9759,
										address_id: '0181af1d4928af79',
										county: 'BOONE',
										historical_property: {
											hist_property_url: 'https://npgallery.nps.gov/AssetDetail/NRIS/82003125',
											distance_ft: 6677.62,
											latitude: '38.96720018900004',
											name: 'Pierce Pennant Motor Hotel',
											distance_mi: 1.26,
											risk: false,
											historical_flag: false,
											longitude: '-92.35909827499995',
										},
										other_names: 'Unknown',
										street_addr1: '108 W CRAIG ST',
										street_addr2: 'Unknown',
										construction_type: 'Unknown',
										earthquake_mmi: {
											mmi: 4,
											risk: false,
											pga: 3,
										},
										nearest_firestation: {
											number_of_stations: 5,
											details: [
												{
													address: '201 Blueridge Road, Columbia, MO, 65202-3724',
													distance: 0.59,
													latitude: 38.983749389000025,
													name: 'Columbia Fire Department Station 9',
													longitude: -92.33399200499997,
												},
												{
													address: '1212 West Worley Street, Columbia, MO, 65203-2042',
													distance: 1.51,
													latitude: 38.95955276500007,
													name: 'Columbia Fire Department Station 2',
													longitude: -92.35705566399997,
												},
												{
													address: '201 Orr Street, Columbia, MO, 65201-4964',
													distance: 1.67,
													latitude: 38.95380783100006,
													name: 'Columbia Fire Department Station 1',
													longitude: -92.32585906999998,
												},
												{
													address: '2300 Oakland Gravel Road, Columbia, MO, 65202-2029',
													distance: 1.96,
													latitude: 38.97453308100006,
													name: 'Columbia Fire Department Station 4',
													longitude: -92.3019104,
												},
												{
													address: '1000 Ashland Road, Columbia, MO, 65201-5206',
													distance: 2.74,
													latitude: 38.93898010300006,
													name: 'Columbia Fire Department Station 3',
													longitude: -92.31970214799998,
												},
											],
											distance_to_closest: 0.59,
										},
										distance_to_coast: {
											distance_ft: 1668904.94,
											distance_mi: 316.08,
											risk: false,
											body: 'Great Lakes',
										},
										owned: false,
										nearest_flood_zone: {
											bfe: 'Unknown',
											static_bfe: -9999,
											gid: 1600926,
											depth: -9999,
											bfe_revert: -9999,
											sfha_tf: 'F',
											zone_subty: 'AREA OF MINIMAL FLOOD HAZARD',
											risk: false,
											fld_zone: 'X',
											study_typ: 'NP',
											nearest_sfha: {
												static_bfe: -9999,
												gid: 1600333,
												depth: -9999,
												bfe_revert: -9999,
												distance_ft: 697.53,
												sfha_tf: 'T',
												zone_subty: 'Unknown',
												distance_mi: 0.13,
												fld_zone: 'AE',
												study_typ: 'NP',
											},
										},
										company_name: 'STATE OF MISSOURI',
										year_built: 'Unknown',
										state: 'MO',
										longitude: -92.3384,
										primary: false,
										occupancy_type: 'EXEMPT',
									},
									{
										zip: '65233',
										user_added: false,
										square_footage: 'Unknown',
										occupancy_subtype: 'Unknown',
										city: 'BOONVILLE',
										latitude: 38.9446,
										address_id: '3f3362c6d5264958',
										county: 'COOPER',
										historical_property: {
											hist_property_url: 'https://npgallery.nps.gov/AssetDetail/NRIS/83000986',
											distance_ft: 11276.1,
											latitude: '38.97265970700005',
											name: 'Roeschel-Toennes-Oswald Property',
											distance_mi: 2.14,
											risk: false,
											historical_flag: false,
											longitude: '-92.75592190599997',
										},
										other_names: 'Unknown',
										street_addr1: '1680 RADIO HILL RD',
										street_addr2: 'Unknown',
										construction_type: 'Unknown',
										earthquake_mmi: {
											mmi: 4,
											risk: false,
											pga: 2,
										},
										nearest_firestation: {
											number_of_stations: 5,
											details: [
												{
													address: '500 Bingham Road, Boonville, MO, 65233-1782',
													distance: 2.28,
													latitude: 38.966125489000035,
													name: 'Boonville Fire Department',
													longitude: -92.74034118699996,
												},
												{
													address: '6th Street, Boonville, MO, 65233',
													distance: 2.71,
													latitude: 38.97625795700003,
													name: 'Boonville Fire Department Substation',
													longitude: -92.74280921699994,
												},
												{
													address: '14847 State Highway 5, Boonville, MO, 65233',
													distance: 2.99,
													latitude: 38.905490875000055,
													name: 'Cooper County Fire Protection District Station 4',
													longitude: -92.79636382999996,
												},
												{
													address: '11500 Santa Fe Road, Boonville, MO, 65233',
													distance: 3.67,
													latitude: 38.93633651700003,
													name: 'Cooper County Fire Protection District Station 2',
													longitude: -92.84006500199996,
												},
												{
													address: '16994 State Highway 87, Boonville, MO, 65233',
													distance: 4.46,
													latitude: 38.933605544000045,
													name: 'Cooper County Fire Protection District Station 1',
													longitude: -92.69081885799994,
												},
											],
											distance_to_closest: 2.28,
										},
										distance_to_coast: {
											distance_ft: 1774280.67,
											distance_mi: 336.04,
											risk: false,
											body: 'Great Lakes',
										},
										owned: false,
										nearest_flood_zone: {
											bfe: 'Unknown',
											static_bfe: -9999,
											gid: 1612755,
											depth: -9999,
											bfe_revert: -9999,
											sfha_tf: 'F',
											zone_subty: 'AREA OF MINIMAL FLOOD HAZARD',
											risk: false,
											fld_zone: 'X',
											study_typ: 'NP',
											nearest_sfha: {
												static_bfe: -9999,
												gid: 1612739,
												depth: -9999,
												bfe_revert: -9999,
												distance_ft: 4468.66,
												sfha_tf: 'T',
												zone_subty: 'Unknown',
												distance_mi: 0.85,
												fld_zone: 'A',
												study_typ: 'NP',
											},
										},
										company_name: 'STATE OF MISSOURI',
										year_built: 'Unknown',
										state: 'MO',
										longitude: -92.7726,
										primary: false,
										occupancy_type: 'Unknown',
									},
									{
										zip: '65251',
										user_added: false,
										square_footage: 'Unknown',
										occupancy_subtype: 'Unknown',
										city: 'FULTON',
										latitude: 38.847,
										address_id: 'a84e918f5f7137ae',
										county: 'CALLAWAY',
										historical_property: {
											hist_property_url: 'https://npgallery.nps.gov/AssetDetail/NRIS/95000780',
											distance_ft: 1212.56,
											latitude: '38.84712545300005',
											name: 'Bell, M. Fred, Speculative Cottage',
											distance_mi: 0.23,
											risk: true,
											historical_flag: true,
											longitude: '-91.94384464399997',
										},
										other_names: 'Unknown',
										street_addr1: '600 E 5TH ST',
										street_addr2: 'Unknown',
										construction_type: 'Unknown',
										earthquake_mmi: {
											mmi: 4,
											risk: false,
											pga: 3,
										},
										nearest_firestation: {
											number_of_stations: 3,
											details: [
												{
													address: '1201 Westminster Avenue, Fulton, MO, 65251-1054',
													distance: 1.1,
													latitude: 38.85832977300004,
													name: 'Fulton Fire Department Station 2',
													longitude: -91.95401001,
												},
												{
													address: '151 West Tennyson Road, Fulton, MO, 65251-6473',
													distance: 1.48,
													latitude: 38.827320099000076,
													name: 'Fulton Fire Department Station One',
													longitude: -91.95056915199996,
												},
												{
													address: '4965 County Road 304, Fulton, MO, 65251',
													distance: 2.05,
													latitude: 38.84838104200003,
													name: 'Central Callaway Fire District Station 1',
													longitude: -91.97763061499995,
												},
											],
											distance_to_closest: 1.1,
										},
										distance_to_coast: {
											distance_ft: 1612072.76,
											distance_mi: 305.32,
											risk: false,
											body: 'Great Lakes',
										},
										owned: false,
										nearest_flood_zone: {
											bfe: 'Unknown',
											static_bfe: -9999,
											gid: 1602753,
											depth: -9999,
											bfe_revert: -9999,
											sfha_tf: 'F',
											zone_subty: 'AREA OF MINIMAL FLOOD HAZARD',
											risk: false,
											fld_zone: 'X',
											study_typ: 'NP',
											nearest_sfha: {
												static_bfe: -9999,
												gid: 1602167,
												depth: -9999,
												bfe_revert: -9999,
												distance_ft: 988.36,
												sfha_tf: 'T',
												zone_subty: 'Unknown',
												distance_mi: 0.19,
												fld_zone: 'AE',
												study_typ: 'NP',
											},
										},
										company_name: 'STATE OF MISSOURI',
										year_built: 'Unknown',
										state: 'MO',
										longitude: -91.9396,
										primary: false,
										occupancy_type: 'Unknown',
									},
									{
										zip: '65251',
										user_added: false,
										square_footage: 'Unknown',
										occupancy_subtype: 'Unknown',
										city: 'FULTON',
										latitude: 38.8472,
										address_id: 'cfdb1115bb7887ff',
										county: 'CALLAWAY',
										historical_property: {
											hist_property_url: 'https://npgallery.nps.gov/AssetDetail/NRIS/95000780',
											distance_ft: 714.86,
											latitude: '38.84712545300005',
											name: 'Bell, M. Fred, Speculative Cottage',
											distance_mi: 0.14,
											risk: true,
											historical_flag: true,
											longitude: '-91.94384464399997',
										},
										other_names: 'Unknown',
										street_addr1: '505 E 5TH ST',
										street_addr2: 'Unknown',
										construction_type: 'Unknown',
										earthquake_mmi: {
											mmi: 4,
											risk: false,
											pga: 3,
										},
										nearest_firestation: {
											number_of_stations: 3,
											details: [
												{
													address: '1201 Westminster Avenue, Fulton, MO, 65251-1054',
													distance: 1.03,
													latitude: 38.85832977300004,
													name: 'Fulton Fire Department Station 2',
													longitude: -91.95401001,
												},
												{
													address: '151 West Tennyson Road, Fulton, MO, 65251-6473',
													distance: 1.46,
													latitude: 38.827320099000076,
													name: 'Fulton Fire Department Station One',
													longitude: -91.95056915199996,
												},
												{
													address: '4965 County Road 304, Fulton, MO, 65251',
													distance: 1.96,
													latitude: 38.84838104200003,
													name: 'Central Callaway Fire District Station 1',
													longitude: -91.97763061499995,
												},
											],
											distance_to_closest: 1.03,
										},
										distance_to_coast: {
											distance_ft: 1612406.48,
											distance_mi: 305.38,
											risk: false,
											body: 'Great Lakes',
										},
										owned: false,
										nearest_flood_zone: {
											bfe: 'Unknown',
											static_bfe: -9999,
											gid: 1602753,
											depth: -9999,
											bfe_revert: -9999,
											sfha_tf: 'F',
											zone_subty: 'AREA OF MINIMAL FLOOD HAZARD',
											risk: false,
											fld_zone: 'X',
											study_typ: 'NP',
											nearest_sfha: {
												static_bfe: -9999,
												gid: 1602315,
												depth: -9999,
												bfe_revert: -9999,
												distance_ft: 663.28,
												sfha_tf: 'T',
												zone_subty: 'FLOODWAY',
												distance_mi: 0.13,
												fld_zone: 'AE',
												study_typ: 'NP',
											},
										},
										company_name: 'STATE OF MISSOURI',
										year_built: 'Unknown',
										state: 'MO',
										longitude: -91.94,
										primary: false,
										occupancy_type: 'Unknown',
									},
									{
										zip: '65202',
										user_added: false,
										square_footage: 83978,
										occupancy_subtype: 'Office Bldg (General)',
										city: 'COLUMBIA',
										latitude: 38.9711,
										address_id: 'e0c923a71a853532',
										county: 'BOONE',
										historical_property: {
											hist_property_url: 'https://npgallery.nps.gov/AssetDetail/NRIS/02000791',
											distance_ft: 4255.64,
											latitude: '38.96068817500003',
											name: 'Hamilton--Brown Shoe Factory',
											distance_mi: 0.81,
											risk: false,
											historical_flag: false,
											longitude: '-92.32291630199995',
										},
										other_names: 'Unknown',
										street_addr1: '1500 VANDIVER DR',
										street_addr2: 'STE 100',
										construction_type: 'Unknown',
										earthquake_mmi: {
											mmi: 4,
											risk: false,
											pga: 3,
										},
										nearest_firestation: {
											number_of_stations: 5,
											details: [
												{
													address: '2300 Oakland Gravel Road, Columbia, MO, 65202-2029',
													distance: 0.8,
													latitude: 38.97453308100006,
													name: 'Columbia Fire Department Station 4',
													longitude: -92.3019104,
												},
												{
													address: '201 Orr Street, Columbia, MO, 65201-4964',
													distance: 1.3,
													latitude: 38.95380783100006,
													name: 'Columbia Fire Department Station 1',
													longitude: -92.32585906999998,
												},
												{
													address: '201 Blueridge Road, Columbia, MO, 65202-3724',
													distance: 1.3,
													latitude: 38.983749389000025,
													name: 'Columbia Fire Department Station 9',
													longitude: -92.33399200499997,
												},
												{
													address: '1000 Ashland Road, Columbia, MO, 65201-5206',
													distance: 2.23,
													latitude: 38.93898010300006,
													name: 'Columbia Fire Department Station 3',
													longitude: -92.31970214799998,
												},
												{
													address: '1212 West Worley Street, Columbia, MO, 65203-2042',
													distance: 2.34,
													latitude: 38.95955276500007,
													name: 'Columbia Fire Department Station 2',
													longitude: -92.35705566399997,
												},
											],
											distance_to_closest: 0.8,
										},
										distance_to_coast: {
											distance_ft: 1665022.16,
											distance_mi: 315.35,
											risk: false,
											body: 'Great Lakes',
										},
										owned: false,
										nearest_flood_zone: {
											bfe: 'Unknown',
											static_bfe: -9999,
											gid: 1600926,
											depth: -9999,
											bfe_revert: -9999,
											sfha_tf: 'F',
											zone_subty: 'AREA OF MINIMAL FLOOD HAZARD',
											risk: false,
											fld_zone: 'X',
											study_typ: 'NP',
											nearest_sfha: {
												static_bfe: -9999,
												gid: 1600332,
												depth: -9999,
												bfe_revert: -9999,
												distance_ft: 2040.67,
												sfha_tf: 'T',
												zone_subty: 'Unknown',
												distance_mi: 0.39,
												fld_zone: 'AE',
												study_typ: 'NP',
											},
										},
										company_name: 'STATE OF MISSOURI',
										year_built: '1998',
										state: 'MO',
										longitude: -92.3161,
										primary: false,
										occupancy_type: 'OFFICE',
									},
								],
								owned_property: 'Unknown',
								primary_property: {
									company_name: 'STATE OF MISSOURI',
									company_id: '1460f6a9-c1ab-554d-a3f0-347a74f514fa',
									ein: 'Unknown',
									street_addr1: '2102 WHITEGATE DR',
									street_addr2: 'Unknown',
									city: 'COLUMBIA',
									state: 'MO',
									zip: '65202',
									county: 'BOONE',
									latitude: 38.9681,
									longitude: -92.3073,
									address_id: 'a6ebc3e3cd766c8a',
									historical_property: {
										historical_flag: false,
										distance_ft: 5191.82,
										distance_mi: 0.98,
										name: 'Hamilton--Brown Shoe Factory',
										latitude: '38.96068817500003',
										longitude: '-92.32291630199995',
										hist_property_url: 'https://npgallery.nps.gov/AssetDetail/NRIS/02000791',
										risk: false,
									},
									distance_to_coast: {
										distance_ft: 1663737.31,
										distance_mi: 315.1,
										body: 'Great Lakes',
										risk: false,
									},
									earthquake_mmi: {
										mmi: 4,
										pga: 3,
										risk: false,
									},
									nearest_flood_zone: {
										gid: 1600926,
										fld_zone: 'X',
										zone_subty: 'AREA OF MINIMAL FLOOD HAZARD',
										study_typ: 'NP',
										static_bfe: -9999,
										bfe_revert: -9999,
										depth: -9999,
										sfha_tf: 'F',
										bfe: 'Unknown',
										nearest_sfha: {
											gid: 1599868,
											distance_ft: 3334.09,
											distance_mi: 0.63,
											fld_zone: 'AE',
											zone_subty: 'Unknown',
											study_typ: 'NP',
											static_bfe: -9999,
											bfe_revert: -9999,
											depth: -9999,
											sfha_tf: 'T',
										},
										risk: false,
									},
									nearest_firestation: {
										number_of_stations: 5,
										distance_to_closest: 0.53,
										details: [
											{
												address: '2300 Oakland Gravel Road, Columbia, MO, 65202-2029',
												distance: 0.53,
												latitude: 38.97453308100006,
												name: 'Columbia Fire Department Station 4',
												longitude: -92.3019104,
											},
											{
												address: '201 Orr Street, Columbia, MO, 65201-4964',
												distance: 1.4,
												latitude: 38.95380783100006,
												name: 'Columbia Fire Department Station 1',
												longitude: -92.32585906999998,
											},
											{
												address: '201 Blueridge Road, Columbia, MO, 65202-3724',
												distance: 1.8,
												latitude: 38.983749389000025,
												name: 'Columbia Fire Department Station 9',
												longitude: -92.33399200499997,
											},
											{
												address: '1000 Ashland Road, Columbia, MO, 65201-5206',
												distance: 2.12,
												latitude: 38.93898010300006,
												name: 'Columbia Fire Department Station 3',
												longitude: -92.31970214799998,
											},
											{
												address: '1400 North Ballenger Lane, Columbia, MO, 65202-2861',
												distance: 2.15,
												latitude: 38.964969635000045,
												name: 'Columbia Fire Department Station 5',
												longitude: -92.26734924299996,
											},
										],
									},
									square_footage: 58418,
									occupancy_subtype: 'Office Bldg (General)',
									occupancy_type: 'OFFICE',
									year_built: '1967',
									construction_type: 'Unknown',
								},
								other_tenants_at_primary: [
									{
										naics_description: [
											'541211 - Offices of Certified Public Accountants',
											'561613 - Armored Car Services',
										],
										zip: '65202',
										website: 'Unknown',
										address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
										city: 'COLUMBIA',
										latitude: 38.9681,
										street_addr1: '2102 WHITEGATE DR',
										ein: 'Unknown',
										street_addr2: 'Unknown',
										sic: ['7381'],
										company_name: 'FRED S BURRESS COMPANY INC',
										sic_mapped: [
											{
												code: '7381',
												description: 'DETECTIVE AND ARMORED CAR SERVICES',
											},
											{
												code: '7381',
												description: 'DETECTIVE SERVICES',
											},
										],
										state: 'MO',
										naics: ['541211', '561613'],
										sic_description: ['DETECTIVE AND ARMORED CAR SERVICES', 'DETECTIVE SERVICES'],
										longitude: -92.3073,
									},
									{
										naics_description: [
											'541110 - Offices of Lawyers',
											'524210 - Insurance Agencies and Brokerages',
											'561499 - All Other Business Support Services',
											'813319 - Other Social Advocacy Organizations',
											'524126 - Direct Property and Casualty Insurance Carriers',
										],
										zip: '65202',
										website: ['https://www.colinsgrp.com/site/'],
										address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
										city: 'COLUMBIA',
										latitude: 38.9681,
										street_addr1: '2102 WHITEGATE DR',
										ein: ['430726456', '430926456'],
										street_addr2: 'Unknown',
										sic: ['6411', '7389', '6331', '641112'],
										company_name: 'COLUMBIA INSURANCE GROUP INC',
										sic_mapped: [
											{
												code: '6411',
												description: 'INSURANCE AGENTS, BROKERS, AND SERVICE',
											},
											{
												code: '6411',
												description: 'INSURANCE AGENTS,BRKS',
											},
											{
												code: '6411',
												description: 'LIFE INSURANCE AGENTS',
											},
											{
												code: '7389',
												description: 'BUSINESS SERVICES, NEC',
											},
											{
												code: '7389',
												description: 'FINANCIAL SERVICES',
											},
											{
												code: '6331',
												description: 'FIRE, MARINE, AND CASUALTY INSURANCE',
											},
											{
												code: '6331',
												description: 'FIRE,MARINE,CAS INSUR',
											},
											{
												code: '641112',
												description: 'INSURANCE',
											},
										],
										state: 'MO',
										naics: ['541110', '524210', '561499', '813319', '524126', '524150'],
										sic_description: [
											'INSURANCE AGENTS, BROKERS, AND SERVICE',
											'INSURANCE AGENTS,BRKS',
											'LIFE INSURANCE AGENTS',
											'BUSINESS SERVICES, NEC',
											'FINANCIAL SERVICES',
											'FIRE, MARINE, AND CASUALTY INSURANCE',
											'FIRE,MARINE,CAS INSUR',
											'INSURANCE',
										],
										longitude: -92.3073,
									},
									{
										naics_description: [
											'813910 - Business Associations',
											'624190 - Other Individual and Family Services',
										],
										zip: '65202',
										website: 'Unknown',
										address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
										city: 'COLUMBIA',
										latitude: 38.9681,
										street_addr1: '2102 WHITEGATE DR',
										ein: 'Unknown',
										street_addr2: 'Unknown',
										sic: ['8322'],
										company_name: 'STATE OF MISSOURI',
										sic_mapped: [
											{
												code: '8322',
												description: 'CHILD REL SOCIAL SVCS',
											},
											{
												code: '8322',
												description: 'INDIVIDUAL AND FAMILY SERVICES',
											},
										],
										state: 'MO',
										naics: ['813910', '624190'],
										sic_description: ['CHILD REL SOCIAL SVCS', 'INDIVIDUAL AND FAMILY SERVICES'],
										longitude: -92.3073,
									},
									{
										naics_description: ['541110 - Offices of Lawyers'],
										zip: '65202',
										website: 'Unknown',
										address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
										city: 'COLUMBIA',
										latitude: 38.9681,
										street_addr1: '2102 WHITEGATE DR',
										ein: 'Unknown',
										street_addr2: 'Unknown',
										sic: 'Unknown',
										company_name: 'DARDOF INC',
										sic_mapped: 'Unknown',
										state: 'MO',
										naics: ['541110'],
										sic_description: 'Unknown',
										longitude: -92.3073,
									},
									{
										naics_description: ['541199 - All Other Legal Services'],
										zip: '65202',
										website: 'Unknown',
										address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
										city: 'COLUMBIA',
										latitude: 38.9681,
										street_addr1: '2102 WHITEGATE DR',
										ein: 'Unknown',
										street_addr2: 'Unknown',
										sic: 'Unknown',
										company_name: 'ITS A PROCESS LLC',
										sic_mapped: 'Unknown',
										state: 'MO',
										naics: ['541199'],
										sic_description: 'Unknown',
										longitude: -92.3073,
									},
									{
										naics_description: ['236115 - New Single-Family Housing Construction (except For-Sale Builders)'],
										zip: '65202',
										website: 'Unknown',
										address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
										city: 'COLUMBIA',
										latitude: 38.9681,
										street_addr1: '2102 WHITEGATE DR',
										ein: 'Unknown',
										street_addr2: 'Unknown',
										sic: 'Unknown',
										company_name: 'SAMRANY CONSTRUCTION LLC',
										sic_mapped: 'Unknown',
										state: 'MO',
										naics: ['236115'],
										sic_description: 'Unknown',
										longitude: -92.3073,
									},
									{
										naics_description: ['524210 - Insurance Agencies and Brokerages'],
										zip: '65202',
										website: 'Unknown',
										address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
										city: 'COLUMBIA',
										latitude: 38.9681,
										street_addr1: '2102 WHITEGATE DR',
										ein: 'Unknown',
										street_addr2: 'Unknown',
										sic: 'Unknown',
										company_name: 'GEORGIA CASUALTY & SURETY COMPANY',
										sic_mapped: 'Unknown',
										state: 'MO',
										naics: ['524210'],
										sic_description: 'Unknown',
										longitude: -92.3073,
									},
									{
										naics_description: [
											'531312 - Nonresidential Property Managers',
											'531120 - Lessors of Nonresidential Buildings (except Miniwarehouses)',
											'447190 - Other Gasoline Stations',
										],
										zip: '65202',
										website: 'Unknown',
										address: '2102 WHITEGATE DR  COLUMBIA, MO 65202',
										city: 'COLUMBIA',
										latitude: 38.9681,
										street_addr1: '2102 WHITEGATE DR',
										ein: 'Unknown',
										street_addr2: 'Unknown',
										sic: ['6512'],
										company_name: 'WHITEGATE SHOPPING CTR',
										sic_mapped: [
											{
												code: '6512',
												description: 'NONRESIDENT BLDG OPER',
											},
											{
												code: '6512',
												description: 'NONRESIDENTIAL BUILDING OPERATORS',
											},
										],
										state: 'MO',
										naics: ['531312', '531120', '447190'],
										sic_description: ['NONRESIDENT BLDG OPER', 'NONRESIDENTIAL BUILDING OPERATORS'],
										longitude: -92.3073,
									},
								],
							},
							d3Vehicles: 'Unknown',
							d3Locations: {
								location_of_operation: [
									{
										zip: '65202',
										match_info: [
											{
												match_against: '1460f6a9-c1ab-554d-a3f0-347a74f514fa',
												company_id: '1460f6a9-c1ab-554d-a3f0-347a74f514fa',
												match_type: 'NAME_MATCH',
											},
										],
										user_added: false,
										company_id: '1460f6a9-c1ab-554d-a3f0-347a74f514fa',
										city: 'COLUMBIA',
										latitude: 38.9681,
										address_id: 'a6ebc3e3cd766c8a',
										county: 'BOONE',
										other_names: 'Unknown',
										street_addr1: '2102 WHITEGATE DR',
										street_addr2: 'Unknown',
										owned: false,
										company_name: 'STATE OF MISSOURI',
										match_type: 'NAME_MATCH',
										state: 'MO',
										longitude: -92.3073,
										primary: true,
									},
									{
										zip: '65202',
										match_info: [
											{
												match_against: '1460f6a9-c1ab-554d-a3f0-347a74f514fa',
												company_id: '7a70d934-cd6e-5a66-8b2e-4d77dbb5b635',
												match_type: 'NAME_MATCH',
											},
										],
										user_added: false,
										company_id: '7a70d934-cd6e-5a66-8b2e-4d77dbb5b635',
										city: 'COLUMBIA',
										latitude: 38.9759,
										address_id: '0181af1d4928af79',
										county: 'BOONE',
										other_names: 'Unknown',
										street_addr1: '108 W CRAIG ST',
										street_addr2: 'Unknown',
										owned: false,
										company_name: 'STATE OF MISSOURI',
										match_type: 'NAME_MATCH',
										state: 'MO',
										longitude: -92.3384,
										primary: false,
									},
									{
										zip: '65233',
										match_info: [
											{
												match_against: '1460f6a9-c1ab-554d-a3f0-347a74f514fa',
												company_id: 'e04c9b12-4721-5b25-ae73-af22900c0605',
												match_type: 'NAME_MATCH',
											},
										],
										user_added: false,
										company_id: 'e04c9b12-4721-5b25-ae73-af22900c0605',
										city: 'BOONVILLE',
										latitude: 38.9446,
										address_id: '3f3362c6d5264958',
										county: 'COOPER',
										other_names: 'Unknown',
										street_addr1: '1680 RADIO HILL RD',
										street_addr2: 'Unknown',
										owned: false,
										company_name: 'STATE OF MISSOURI',
										match_type: 'NAME_MATCH',
										state: 'MO',
										longitude: -92.7726,
										primary: false,
									},
									{
										zip: '65251',
										match_info: [
											{
												match_against: '1460f6a9-c1ab-554d-a3f0-347a74f514fa',
												company_id: '2f1eb4d0-47e1-51b9-ae30-4e5957c06c0b',
												match_type: 'NAME_MATCH',
											},
										],
										user_added: false,
										company_id: '2f1eb4d0-47e1-51b9-ae30-4e5957c06c0b',
										city: 'FULTON',
										latitude: 38.847,
										address_id: 'a84e918f5f7137ae',
										county: 'CALLAWAY',
										other_names: 'Unknown',
										street_addr1: '600 E 5TH ST',
										street_addr2: 'Unknown',
										owned: false,
										company_name: 'STATE OF MISSOURI',
										match_type: 'NAME_MATCH',
										state: 'MO',
										longitude: -91.9396,
										primary: false,
									},
									{
										zip: '65251',
										match_info: [
											{
												match_against: '1460f6a9-c1ab-554d-a3f0-347a74f514fa',
												company_id: '436ff4d8-f4d3-5ee9-84f2-54dd3cd8a954',
												match_type: 'NAME_MATCH',
											},
										],
										user_added: false,
										company_id: '436ff4d8-f4d3-5ee9-84f2-54dd3cd8a954',
										city: 'FULTON',
										latitude: 38.8472,
										address_id: 'cfdb1115bb7887ff',
										county: 'CALLAWAY',
										other_names: 'Unknown',
										street_addr1: '505 E 5TH ST',
										street_addr2: 'Unknown',
										owned: false,
										company_name: 'STATE OF MISSOURI',
										match_type: 'NAME_MATCH',
										state: 'MO',
										longitude: -91.94,
										primary: false,
									},
									{
										zip: '65202',
										match_info: [
											{
												match_against: '1460f6a9-c1ab-554d-a3f0-347a74f514fa',
												company_id: 'c2feefaf-7f4d-58f9-a713-330cedcfee38',
												match_type: 'NAME_MATCH',
											},
										],
										user_added: false,
										company_id: 'c2feefaf-7f4d-58f9-a713-330cedcfee38',
										city: 'COLUMBIA',
										latitude: 38.9711,
										address_id: 'e0c923a71a853532',
										county: 'BOONE',
										other_names: 'Unknown',
										street_addr1: '1500 VANDIVER DR',
										street_addr2: 'STE 100',
										owned: false,
										company_name: 'STATE OF MISSOURI',
										match_type: 'NAME_MATCH',
										state: 'MO',
										longitude: -92.3161,
										primary: false,
									},
								],
							},
						},
					});
			}
		});

		axios.post.mockImplementation((url) => {
			switch (url) {
				case `${process.env.REACT_APP_AWS_API_DOMAIN}/common-verisk/api/getCompanyId`:
					return Promise.resolve({
						data: {
							MatchType: 'Exact',
							Address: {
								StreetAddress1: '2102 WHITEGATE DR',
								City: 'COLUMBIA',
								State: 'MO',
								Zip: '65202',
								Zip4: '2335',
								County: 'BOONE',
							},
							BopBusinesses: [
								{
									BusinessName: 'Columbia Insurance Group',
									UniqueIdentifier: 'I718271055',
									ReportUrl:
										'https://prometrixapiuat.iso.com/uw/report/bop/I718271055/36c6e139-d26b-45d9-a93c-b3c3fbe21edf',
									Address: {
										StreetAddress1: '2102 Whitegate Dr',
										City: 'Columbia',
										State: 'MO',
										Zip: '65202',
									},
								},
								{
									BusinessName: 'Columbia Insurance Group Inc',
									UniqueIdentifier: 'I438973679',
									ReportUrl:
										'https://prometrixapiuat.iso.com/uw/report/bop/I438973679/36c6e139-d26b-45d9-a93c-b3c3fbe21edf',
									Address: {
										StreetAddress1: '2102 Whitegate Dr',
										City: 'Columbia',
										State: 'MO',
										Zip: '65202',
									},
								},
							],
						},
					});
				case `${process.env.REACT_APP_AWS_API_DOMAIN}/common-datacubes/api/getCompanyId`:
					return Promise.resolve({
						data: {
							company_id: '1460f6a9-c1ab-554d-a3f0-347a74f514fa',
							company_name: 'STATE OF MISSOURI',
							street_addr1: '2102 WHITEGATE DR',
							street_addr2: '',
							city: 'COLUMBIA',
							state: 'MO',
							zip: '65202',
							search_enhancements: [
								{
									search_enhancement_source: 'US_DnB_Companies',
									search_enhancement_output: {
										hq_branch: 'Branch',
										hq_details: {
											company_name: 'STATE OF MISSOURI',
											street_addr1: '301 W HIGH ST',
											city: 'JEFFERSON CITY',
											state: 'MO',
											zip: '65101',
										},
									},
									search_enhancement_id: '780431177',
								},
							],
							phone: ['314-474-8533'],
							contact: [],
							master_id: '1460f6a9-c1ab-554d-a3f0-347a74f514fa',
							best_matched_fields_from_query: ['street_addr1', 'zip'],
							search_relevance_score: 10,
							search_id: 'd0a3af95-cd28-5d4e-a96a-789430c5e777',
						},
					});
				case `${process.env.REACT_APP_AWS_API_DOMAIN}/common-geocode/api/geocode`:
					return Promise.resolve({
						data: 'undefined{\r\n  "output_port" : [ {\r\n    "BlockSuffix" : "",\r\n    "CBSADivisionCode" : "",\r\n    "CBSAMetro" : "Y",\r\n    "CBSACode" : "17860",\r\n    "CensusBlockID" : "290190015061013",\r\n    "USFIPSCountyNumber" : "019",\r\n    "CSACode" : "190",\r\n    "CensusTract" : "001506",\r\n    "USFIPSStateCode" : "29",\r\n    "USFIPSStateCountyCode" : "29019",\r\n    "Latitude" : "38.967345",\r\n    "Longitude" : "-92.306005",\r\n    "StreetSide" : "L",\r\n    "BlockLine1" : "",\r\n    "BlockLine2" : "",\r\n    "BlockLine3" : "",\r\n    "BlockLine4" : "",\r\n    "BlockLine5" : "",\r\n    "BlockLine6" : "",\r\n    "FirmName" : "",\r\n    "AddressLine1" : "2102 Whitegate Dr",\r\n    "AddressLine2" : "",\r\n    "LastLine" : "Columbia, MO  65202-2335",\r\n    "StreetName" : "Whitegate",\r\n    "CrossStreetName" : "",\r\n    "LeadingDirectional" : "",\r\n    "CrossStreetLeadingDirectional" : "",\r\n    "HouseNumber" : "2102",\r\n    "HouseNumber2" : "",\r\n    "TrailingDirectional" : "",\r\n    "CrossStreetTrailingDirectional" : "",\r\n    "StreetSuffix" : "Dr",\r\n    "CrossStreetSuffix" : "",\r\n    "ApartmentLabel" : "",\r\n    "ApartmentLabel2" : "",\r\n    "ApartmentNumber" : "",\r\n    "ApartmentNumber2" : "",\r\n    "AdditionalInputData" : "",\r\n    "City" : "Columbia",\r\n    "StateProvince" : "MO",\r\n    "PostalCode.Base" : "65202",\r\n    "PostalCode.AddOn" : "2335",\r\n    "PostalCode" : "65202-2335",\r\n    "PrivateMailbox.Designator" : "",\r\n    "PrivateMailbox" : "",\r\n    "USUrbanName" : "",\r\n    "Country" : "United States of America",\r\n    "RRHC" : "",\r\n    "USCarrierRouteCode" : "C042",\r\n    "USBCCheckDigit" : "0",\r\n    "PostalBarCode" : "233502",\r\n    "DeliveryPointCode" : "02",\r\n    "GovernmentBuilding" : "",\r\n    "USLOTCode" : "0194A",\r\n    "USCarrierRouteSort" : "D",\r\n    "USCityDelivery" : "Y",\r\n    "PostalCodeClass" : "",\r\n    "PostalFacility" : "P",\r\n    "PostalCodeUnique" : "",\r\n    "CityStateRecordName" : "Columbia",\r\n    "CityPreferredName" : "Columbia",\r\n    "CityShortName" : "Columbia",\r\n    "DPV" : "Y",\r\n    "DPVFootnote" : "AABB",\r\n    "CMRA" : "N",\r\n    "Alternate" : "B",\r\n    "HouseNumberHigh" : "2102",\r\n    "HouseNumberLow" : "2102",\r\n    "HouseNumberParity" : "E",\r\n    "UnitNumberHigh" : "",\r\n    "UnitNumberLow" : "",\r\n    "UnitNumberParity" : "",\r\n    "PostalCodeExtensionHigh" : "2335",\r\n    "PostalCodeExtensionLow" : "2335",\r\n    "AddressLineResolved" : "",\r\n    "EWSMatch" : "",\r\n    "RecordType.Default" : "U",\r\n    "Intersection" : "F",\r\n    "IsAlias" : "N01",\r\n    "LACSAddress" : "",\r\n    "LocationCode" : "AP05",\r\n    "MatchCode" : "S00",\r\n    "RecordType" : "Normal",\r\n    "GeoStanMatchScore" : "0.0000000",\r\n    "CountryLevel" : "A",\r\n    "StreetDataType" : "MASTER LOCATION",\r\n    "StreetDataCode" : "12",\r\n    "DatabaseVersion" : "November 2022",\r\n    "ExpirationDate" : "03/30/2023",\r\n    "BlockLeft" : "290190015061013",\r\n    "BlockRight" : "",\r\n    "BlockSuffixLeft" : "",\r\n    "BlockSuffixRight" : "",\r\n    "RoadClass" : "01",\r\n    "SegmentDirection" : "F",\r\n    "SegmentHouseNumberHigh" : "2102",\r\n    "SegmentHouseNumberLow" : "2102",\r\n    "SegmentCode" : "109081226",\r\n    "SegmentLength" : "",\r\n    "SegmentParity" : "R",\r\n    "PointCode" : "102203593",\r\n    "Confidence" : "100",\r\n    "ProcessedBy" : "KGL",\r\n    "Geocoder.MatchCode" : "S8HPNTSCZA",\r\n    "IsCloseMatch" : "Y",\r\n    "GeoConfidenceCode" : "POINT",\r\n    "GeoConfidenceCentroidLatitude" : "38.967345",\r\n    "GeoConfidenceCentroidLongitude" : "-92.306005",\r\n    "StreetSegmentPoints" : [ ],\r\n    "PBKey" : "P0000DDAP809",\r\n    "Status" : "",\r\n    "Status.Code" : "",\r\n    "Status.Description" : "",\r\n    "user_fields" : [ ]\r\n  } ]\r\n}',
					});
			}
		});

		sessionStorage.setItem('authorizationToken', 'abc');
		sessionStorage.setItem('authorizationRefresh', 'def');
		sessionStorage.setItem('cigToken', 'xyz');
		sessionStorage.setItem(
			'agentJSONObject',
			'{"writingStates":["AL","AR","GA","IL","IA","KS","KY","MS","MO","NE","OK","SD","TN","TX"],"appUnderwriterEmail":"MBROWNING@COLINSGRP.COM","isAllowBillableDownpayment":true,"city":"Columbia","territoryManagerEmail":"kwilliams@colinsgrp.com                                   ","underwriterAssistantPhoneNumber":"","isAllowAgencyBill":true,"branch":"01","underwriterEmail":"AHARGIS@COLINSGRP.COM","underwriterPhoneNumber":"573-777-4054","number":"55110","territoryManagerPhoneNumber":"","pinnacleAgent":"","street":"PO Box 618","agentSubpro":"55110-00001","state":"MO","email":"","zip":"65205","underwriterAssistantName":"Zellia Harris","appUnderwriterNumber":"98","appUnderwriterName":"Test Underwriter","underwriterAssistantEmail":"ZHARRIS@COLINSGRP.COM","userId":"vndbadepwar","token":"2eff6af5-aa1a-4d4e-afd5-ede446b69d85","isHasSweepAccount":true,"subpro":"00001","underwriterNumber":"99","territoryManagerNumber":"011","phone":"573-474-6193","underwriterName":"Annette Hargis","appUnderwriterPhoneNumber":"573-777-4051  ","name":"The Demo Agency 55110-1","territoryManagerName":"Kenya Williams","iss":"Columbia","exp":1668770738}',
		);
		sessionStorage.setItem(
			'agentToken',
			'eyJhbGciOiJIUzI1NiJ9.eyJ3cml0aW5nU3RhdGVzIjpbIkFMIiwiQVIiLCJHQSIsIklMIiwiSUEiLCJLUyIsIktZIiwiTVMiLCJNTyIsIk5FIiwiT0siLCJTRCIsIlROIiwiVFgiXSwiYXBwVW5kZXJ3cml0ZXJFbWFpbCI6Ik1CUk9XTklOR0BDT0xJTlNHUlAuQ09NIiwiaXNBbGxvd0JpbGxhYmxlRG93bnBheW1lbnQiOnRydWUsImNpdHkiOiJDb2x1bWJpYSIsInRlcnJpdG9yeU1hbmFnZXJFbWFpbCI6Imt3aWxsaWFtc0Bjb2xpbnNncnAuY29tICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAiLCJ1bmRlcndyaXRlckFzc2lzdGFudFBob25lTnVtYmVyIjoiIiwiaXNBbGxvd0FnZW5jeUJpbGwiOnRydWUsImJyYW5jaCI6IjAxIiwidW5kZXJ3cml0ZXJFbWFpbCI6IkFIQVJHSVNAQ09MSU5TR1JQLkNPTSIsInVuZGVyd3JpdGVyUGhvbmVOdW1iZXIiOiI1NzMtNzc3LTQwNTQiLCJudW1iZXIiOiI1NTExMCIsInRlcnJpdG9yeU1hbmFnZXJQaG9uZU51bWJlciI6IiIsInBpbm5hY2xlQWdlbnQiOiIiLCJzdHJlZXQiOiJQTyBCb3ggNjE4IiwiYWdlbnRTdWJwcm8iOiI1NTExMC0wMDAwMSIsInN0YXRlIjoiTU8iLCJlbWFpbCI6IiIsInppcCI6IjY1MjA1IiwidW5kZXJ3cml0ZXJBc3Npc3RhbnROYW1lIjoiWmVsbGlhIEhhcnJpcyIsImFwcFVuZGVyd3JpdGVyTnVtYmVyIjoiOTgiLCJhcHBVbmRlcndyaXRlck5hbWUiOiJUZXN0IFVuZGVyd3JpdGVyIiwidW5kZXJ3cml0ZXJBc3Npc3RhbnRFbWFpbCI6IlpIQVJSSVNAQ09MSU5TR1JQLkNPTSIsInVzZXJJZCI6InZuZGJhZGVwd2FyIiwidG9rZW4iOiJkOTQyZWRhNS00YWU2LTRiMmEtYTAzYy0zMzI3YWYwMzNlNGUiLCJpc0hhc1N3ZWVwQWNjb3VudCI6dHJ1ZSwic3VicHJvIjoiMDAwMDEiLCJ1bmRlcndyaXRlck51bWJlciI6Ijk5IiwidGVycml0b3J5TWFuYWdlck51bWJlciI6IjAxMSIsInBob25lIjoiNTczLTQ3NC02MTkzIiwidW5kZXJ3cml0ZXJOYW1lIjoiQW5uZXR0ZSBIYXJnaXMiLCJhcHBVbmRlcndyaXRlclBob25lTnVtYmVyIjoiNTczLTc3Ny00MDUxICAiLCJuYW1lIjoiVGhlIERlbW8gQWdlbmN5IDU1MTEwLTEiLCJ0ZXJyaXRvcnlNYW5hZ2VyTmFtZSI6IktlbnlhIFdpbGxpYW1zIiwiaXNzIjoiQ29sdW1iaWEiLCJleHAiOjE2NzAzMjcwMDZ9.03rjJ2vzEysg7AkjgjD2WC2mCklSJR8Busoa4BnE1UE',
		);
	});

	afterEach(() => {
		jest.clearAllMocks();
		cleanup;
	});
	afterAll(() => {
		jest.clearAllMocks();
	});

	describe('SafeguardLocationDashboard', () => {
		test('renders component correctly with all fields', () => {
			const tree = renderer.create(<SafeguardLocationDashboard />).toJSON();
			expect(tree).toMatchSnapshot();
		});
	});

	describe('New location button', () => {
		test('On render button should be visible.', () => {
			renderComponent(<SafeguardLocationDashboard />);
			let locationBtn = screen.getByRole('button', {
				name: /New Location/i,
			});
			expect(locationBtn).toBeInTheDocument();
		});

		test('When button is clicked, a modal (New Window) should pop up.', async () => {
			renderComponent(<SafeguardLocationDashboard location='/quote/safeguard/locations' />);
			let locationBtn = screen.getByRole('button', {
				name: /New Location/i,
			});
			await act(async () => {
				fireEvent.click(locationBtn);
			});
			expect(screen.getByText('Location Information')).toBeInTheDocument();
		});
	});

	describe('Address mailing button', () => {
		test('When button is clicked, a modal (New Window) should pop up.', async () => {
			const { container } = renderComponent(<SafeguardLocationDashboard location='/quote/safeguard/locations' />);
			let btnNext = screen.getByRole('button', {
				name: /New Location/i,
			});
			await act(async () => {
				fireEvent.click(btnNext);
			});
			expect(screen.getByText('Location Information')).toBeInTheDocument();
			let mailingButton = screen.getByRole('button', {
				name: /Address Same As Mailing/i,
			});
			expect(mailingButton).toBeInTheDocument();
		});
		jest.setTimeout(8000);
		test('Clicking button should fill in the proceeding field with the valid address entered in the Address field on the "Policy Information" page.', async () => {
			const { container } = renderComponent(
				<QuoteContext.Provider value={quote}>
					<SafeguardLocationDashboard location='/quote/safeguard/locations' />
				</QuoteContext.Provider>,
			);
			let btnNext = screen.getByRole('button', {
				name: /New Location/i,
			});
			await act(async () => {
				fireEvent.click(btnNext);
			});
			expect(screen.getByText('Location Information')).toBeInTheDocument();
			let mailingButton = screen.getByRole('button', {
				name: /Address Same As Mailing/i,
			});
			await act(async () => {
				fireEvent.click(mailingButton);
			});
			const location = screen.getByPlaceholderText('Search places');
			await waitFor(async () => {
				await expect(location).toHaveValue('525 Court St Fulton MO 65251-1901');
			});
			const county = screen.getByText(/County/i);
			await waitFor(() => expect(county).toBeInTheDocument());
			await new Promise((r) => setTimeout(r, 3000));
			const callaway = screen.getByRole('radio', {
				name: /Callaway/i,
			});
			await waitFor(() => expect(callaway).toBeChecked());
			const protection = screen.getByText(/Protection Class/i);
			await waitFor(() => expect(protection).toBeInTheDocument());
			await new Promise((r) => setTimeout(r, 3000));
			const radio2 = screen.getByRole('radio', {
				name: 'FULTON (04)',
			});
			await waitFor(() => expect(radio2).toBeInTheDocument());
			expect(
				screen.getByRole('radio', {
					name: 'FULTON (4X)',
				}),
			).toBeInTheDocument();
			expect(
				screen.getByRole('radio', {
					name: 'MILLERSBURG FPSA (06)',
				}),
			).toBeInTheDocument();
			expect(
				screen.getByRole('radio', {
					name: 'MILLERSBURG FPSA (6X)',
				}),
			).toBeInTheDocument();
		});

		test('When button is clicked, a modal (New Window) should pop up.', async () => {
			const { container } = renderComponent(<SafeguardLocationDashboard location='/quote/safeguard/locations' />);
			let btnNext = screen.getByRole('button', {
				name: /New Location/i,
			});
			await act(async () => {
				fireEvent.click(btnNext);
			});
			expect(screen.getByText('Location Information')).toBeInTheDocument();
			let next = screen.getByTestId('locationPopupNext');
			expect(next).toBeInTheDocument();
			await act(async () => {
				fireEvent.click(next);
			});
			expect(screen.getByText('Address is required.')).toBeInTheDocument();
		});
	});

	describe('Address Component', () => {
		test('Field is viewable at render', async () => {
			const { container } = renderComponent(<SafeguardLocationDashboard location='/quote/safeguard/locations' />);
			let btnNext = screen.getByRole('button', {
				name: /New Location/i,
			});
			await act(async () => {
				fireEvent.click(btnNext);
			});
			expect(screen.getByText('Location Information')).toBeInTheDocument();
			const address = screen.getByText('Address');
			expect(address).toBeInTheDocument();
		});

		test('Field will autofill to mailing address if the preceeding button "Address Same as Mailing" is selected.', async () => {
			const { container } = renderComponent(
				<QuoteContext.Provider value={quote}>
					<SafeguardLocationDashboard location='/quote/safeguard/locations' />
				</QuoteContext.Provider>,
			);
			let btnNext = screen.getByRole('button', {
				name: /New Location/i,
			});
			await act(async () => {
				fireEvent.click(btnNext);
			});
			expect(screen.getByText('Location Information')).toBeInTheDocument();
			const address = screen.getByText('Address');
			expect(address).toBeInTheDocument();
			let mailingButton = screen.getByRole('button', {
				name: /Address Same As Mailing/i,
			});
			await act(async () => {
				fireEvent.click(mailingButton);
			});
			const location = screen.getByPlaceholderText('Search places');
			await waitFor(async () => {
				await expect(location).toHaveValue('525 Court St Fulton MO 65251-1901');
			});
		});

		test('Alternatively, the field will accept free form alphanumeric text in the form of a valid address.', async () => {
			const { container } = renderComponent(
				<QuoteContext.Provider value={quote}>
					<SafeguardLocationDashboard location='/quote/safeguard/locations' />
				</QuoteContext.Provider>,
			);
			let btnNext = screen.getByRole('button', {
				name: /New Location/i,
			});
			await act(async () => {
				fireEvent.click(btnNext);
			});
			expect(screen.getByText('Location Information')).toBeInTheDocument();
			const address = screen.getByText('Address');
			expect(address).toBeInTheDocument();
			const location = screen.getByPlaceholderText('Search places');
			await act(async () => {
				fireEvent.change(location, { target: { value: 'Area 51' } });
			});
			expect(location).toHaveValue('Area 51');
		});

		test('Field will make a call to Insurity, grabbing county or counties and protection class or protection classes.', async () => {
			const { container } = renderComponent(
				<QuoteContext.Provider value={quote}>
					<SafeguardLocationDashboard location='/quote/safeguard/locations' />
				</QuoteContext.Provider>,
			);
			let btnNext = screen.getByRole('button', {
				name: /New Location/i,
			});
			await act(async () => {
				fireEvent.click(btnNext);
			});
			expect(screen.getByText('Location Information')).toBeInTheDocument();
			const address = screen.getByText('Address');
			expect(address).toBeInTheDocument();
			let mailingButton = screen.getByRole('button', {
				name: /Address Same As Mailing/i,
			});
			await act(async () => {
				fireEvent.click(mailingButton);
			});
			const location = screen.getByPlaceholderText('Search places');
			await waitFor(async () => {
				await expect(axios.get).toHaveBeenCalledTimes(4);
			});
		});

		jest.setTimeout(8000);
		test('Those fields will default only if there is a single protection class or county available for selection.', async () => {
			const { container } = renderComponent(
				<QuoteContext.Provider value={quote}>
					<SafeguardLocationDashboard location='/quote/safeguard/locations' />
				</QuoteContext.Provider>,
			);
			let btnNext = screen.getByRole('button', {
				name: /New Location/i,
			});
			await act(async () => {
				fireEvent.click(btnNext);
			});
			expect(screen.getByText('Location Information')).toBeInTheDocument();
			let mailingButton = screen.getByRole('button', {
				name: /Address Same As Mailing/i,
			});
			await act(async () => {
				fireEvent.click(mailingButton);
			});
			const location = screen.getByPlaceholderText('Search places');
			await waitFor(async () => {
				await expect(location).toHaveValue('525 Court St Fulton MO 65251-1901');
			});
			const county = screen.getByText(/County/i);
			await waitFor(() => expect(county).toBeInTheDocument());
			await new Promise((r) => setTimeout(r, 3000));
			const callaway = screen.getByRole('radio', {
				name: /Callaway/i,
			});
			await waitFor(() => expect(callaway).toBeChecked());
			const protection = screen.getByText(/Protection Class/i);
			await waitFor(() => expect(protection).toBeInTheDocument());
			await new Promise((r) => setTimeout(r, 3000));
			const radio2 = screen.getByRole('radio', {
				name: 'FULTON (04)',
			});
			await waitFor(() => expect(radio2).not.toBeChecked());
			expect(
				screen.getByRole('radio', {
					name: 'FULTON (4X)',
				}),
			).not.toBeChecked();
			expect(
				screen.getByRole('radio', {
					name: 'MILLERSBURG FPSA (06)',
				}),
			).not.toBeChecked();
			expect(
				screen.getByRole('radio', {
					name: 'MILLERSBURG FPSA (6X)',
				}),
			).not.toBeChecked();
		});

		test('Field is required to proceed with quote.', async () => {
			const { container } = renderComponent(<SafeguardLocationDashboard location='/quote/safeguard/locations' />);
			let btnNext = screen.getByRole('button', {
				name: /New Location/i,
			});
			await act(async () => {
				fireEvent.click(btnNext);
			});
			expect(screen.getByText('Location Information')).toBeInTheDocument();
			let next = screen.getByTestId('locationPopupNext');
			expect(next).toBeInTheDocument();
			await act(async () => {
				fireEvent.click(next);
			});
			expect(screen.getByText('Address is required.')).toBeInTheDocument();
		});
	});
});
