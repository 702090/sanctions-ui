import { RadioButton } from 'components/shared/form/RadioButton';
import { InformationMessage } from 'components/shared/messages/InformationMessage';
import { UnderwritingQuestion } from 'components/UnderwritingQuestion';
import QuoteContext from 'context/quoteContext';
import bopClassCodesJson from 'data/BOPClassCodes';
import bldgQuestionsJson from 'data/BuildingQuestions';
import d3questionsJson from 'data/DatacubesQuestionMapping';
import occupancyQuestionsJson from 'data/OccupancyQuestions';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { Component } from 'react';
import BuildingQuestionRules from 'safeguard/locationDashboard/buildingQuestions/BuildingQuestionRules';
import { ModalNavButtons } from 'safeguard/locationDashboard/components/ModalNavButtons';
import { prefillUsed } from 'utils/BusinessFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import { cleanValues, getDatacubesQuestionValue, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { checkReferrals, validate } from 'validation/Validate';

const visibility = {};
const { d3questions } = d3questionsJson;
const { occupancyQuestions } = occupancyQuestionsJson;

export default class SafeguardBuildingQuestionsForm extends Component {
	static contextType = QuoteContext;

	dirty = false;

	state = { protectionClassOptions: [] };

	initialValues = {
		locationId: this.props.locationId,
		id: this.props.buildingId,
		questions: {
			reviewedCorrect: '',
		},
	};

	dependentQuestions = {};

	classQuestions = [];

	rulesOnLoad = false;

	UNSAFE_componentWillMount() {
		const { building } = this.props;
		const state = _.get(this.context, `quote.addresses.${this.props.locationId}.state`);
		this.classQuestions = duplicate(bopClassCodesJson.classCodes[state][building.classId].questions);
		this.occupancyQuestionIds = duplicate(occupancyQuestions[building.occupancyType]);

		if (!isBlank(this.occupancyQuestionIds)) {
			this.classQuestions = this.classQuestions.concat(this.occupancyQuestionIds);
		}

		const buildingQuestions = building.questions || {};
		this.classQuestions.forEach((qidObj, index) => {
			const qid = _.isObject(qidObj) ? qidObj.id : qidObj;
			const thisQstn = bldgQuestionsJson.questions[qid];
			this.initialValues.questions[qid] =
				buildingQuestions[qid] ||
				getDatacubesQuestionValue(qid, _.get(this.context, `quote.sfg.locations.${this.props.locationId}`), {}) ||
				thisQstn.d ||
				'';
			if (thisQstn.da) {
				const dependencyParts = _.split(thisQstn.da, '_');
				const dependencies = _.get(this.dependentQuestions, `${dependencyParts[0]}.${dependencyParts[1]}`, new Set());
				dependencies.add(qid);
				if (!this.dependentQuestions[dependencyParts[0]]) {
					this.dependentQuestions[dependencyParts[0]] = {};
				}
				this.dependentQuestions[dependencyParts[0]][dependencyParts[1]] = dependencies;
				if (buildingQuestions[dependencyParts[0]] == dependencyParts[1]) {
					visibility[qid] = true;
				} else {
					visibility[qid] = false;
				}
			}
			this.classQuestions[index] = { id: qid, order: thisQstn.order };
		});
		this.classQuestions = _.sortBy(this.classQuestions, (q) => q.order);
		this.initialValues.questions.reviewedCorrect = buildingQuestions.reviewedCorrect || '';
	}

	componentDidMount() {
		// If the form is not empty, trigger validation
		runRulesOnLoad(this.formProps, this.formProps.initialValues, ['']);
	}

	updateVisibilities = (qid, value) => {
		const dependencies = this.dependentQuestions[qid];
		_.forIn(dependencies, (qidSet, depAns) => {
			[...qidSet].forEach((dependentQid) => {
				// keep == instead of ===
				visibility[dependentQid] = depAns == value; /* eslint eqeqeq: [0] */
			});
		});
	};

	getPrefillToolTips = (qid, d3Object, buildingObj) => {
		const d3Called = !!d3Object;
		const d3Answers = _.get(d3Object, 'questions');
		const currentQuestion = bldgQuestionsJson.questions[qid];
		const optionsObject = _.get(currentQuestion, 'o', {});

		let tooltipObject = {
			answered: 'This question has not been answered before.\n',
			APICalled: `Datacubes has ${d3Called ? '' : 'NOT'} been called.\n`,
		};

		const defaultValue = _.find(optionsObject, (o) => {
			return o.value === _.get(currentQuestion, 'd', {});
		});
		if (!isBlank(defaultValue)) {
			tooltipObject.codeDefault = `The hardcoded default for this question is ${defaultValue.text}.\n`;
		}

		const priorQuestionValue = _.get(buildingObj, `questions.${qid}`, {});
		if (!isBlank(priorQuestionValue)) {
			const priorSavedValue = _.find(optionsObject, (o) => {
				return o.value === priorQuestionValue;
			});
			tooltipObject.answered = `The last saved value was ${priorSavedValue.text}\n`;
		}

		if (!d3questions[qid]) {
			tooltipObject.APIResponse = 'Datacubes does not answer this question.\n';
		} else if (d3Answers) {
			let d3Response = [];
			_.forEach(d3questions[qid], (d3Question) => {
				if (_.has(d3Answers, `${d3Question}`)) {
					d3Response.push(_.get(d3Answers, `${d3Question}`, false));
				}
			});
			if (d3Response.length === 0) {
				tooltipObject.APIResponse = 'There may be an error with mapping.\n';
			} else if (d3Response.some((u) => u === true)) {
				tooltipObject.APIResponse = 'Datacubes returned true (Yes).\n';
			} else if (d3Response.every((u) => u === 'Unknown')) {
				tooltipObject.APIResponse = 'Datacubes returned Unknown.\n';
			} else {
				tooltipObject.APIResponse = 'Datacubes returned false (No).\n';
			}
		} else {
			if (!isBlank(_.get(d3Object, 'errorMessage', ''))) {
				tooltipObject.APIResponse = `Error: ${d3Object.errorMessage}\n`;
			} else {
				tooltipObject.APIResponse = 'Datacubes encountered an unaccounted for error.\n';
			}
		}

		return tooltipObject.answered + tooltipObject.APICalled + tooltipObject.APIResponse + tooltipObject.codeDefault;
	};

	render() {
		const { locationId, newLocation, newBuilding, building, buildingId, callBack } = this.props;
		const { quote } = this.context;
		let buildingCopy = duplicate(building);
		const d3Object = _.get(this.context, `quote.sfg.locations.${this.props.locationId}.prefillData.datacubes`);
		const prefillsPresent = {
			verisk: false,
			verisk360: false,
			datacubes: true,
			ncci: false,
		};
		return (
			<Formik
				render={(formikProps) => {
					this.formProps = formikProps;
					this.dirty = formikProps.dirty;
					cleanValues(formikProps.values, visibility);
					checkReferrals(this.context, formikProps.values, BuildingQuestionRules, visibility, { building: building });
					if (!this.rulesOnLoad) {
						formikProps.validateForm(formikProps.values);
						this.rulesOnLoad = true;
					}
					return (
						<Form id='screen'>
							<InformationMessage
								message='Select information on this page has been pre-filled by a third-party service.'
								fieldDisplay={prefillUsed(quote, formikProps.values, prefillsPresent, locationId)}
							/>
							<p>{buildingCopy.classId}</p>
							{this.classQuestions.map((questionIdObj) => {
								const qid = questionIdObj.id;
								return (
									<div key={qid}>
										<UnderwritingQuestion
											key={qid}
											qid={qid}
											dependentQuestions={this.dependentQuestions[qid]}
											updateVisibilities={this.updateVisibilities}
											visibility={visibility}
											tooltip={this.getPrefillToolTips(qid, d3Object, buildingCopy)}
										/>
									</div>
								);
							})}
							<Field
								name='questions.reviewedCorrect'
								label='I have reviewed all questions and the answers I have provided are based on information provided by the insured or on my knowledge of the risk.'
								component={RadioButton}
								options={[
									{ text: 'I Agree', value: 'Y' },
									{ text: 'I Disagree', value: 'N' },
								]}
								ignoreTouched
							/>
							<ModalNavButtons
								currentModal='safeguardBuildingQuestions'
								onClose={this.props.handleClose}
								locationId={locationId}
								newLocation={newLocation}
								buildingId={buildingId}
								newBuilding={newBuilding}
								building={_.merge(buildingCopy, formikProps.values)}
								formikProps={formikProps}
								saveValues={() => this.context.onBldQstnModalSubmit(formikProps.values, this.dirty, this.props)}
								callBack={callBack}
							/>
						</Form>
					);
				}}
				initialValues={this.initialValues}
				onSubmit={(values, formikActions) => {
					cleanValues(values, visibility);
					this.context.onBldQstnModalSubmit(values, this.dirty, this.props);
					formikActions.setSubmitting(false);
					this.props.handleClose();
				}}
				validate={(values) => {
					checkReferrals(this.context, values, BuildingQuestionRules, visibility, { building: building });
					const validResults = validate(
						values,
						BuildingQuestionRules.rules(quote, locationId, buildingCopy.classId),
						duplicate(BuildingQuestionRules.requiredStructure),
					);
					logPageErrors(validResults, this.formProps.touched, 'sfg');
					return validResults;
				}}
			/>
		);
	}
}
