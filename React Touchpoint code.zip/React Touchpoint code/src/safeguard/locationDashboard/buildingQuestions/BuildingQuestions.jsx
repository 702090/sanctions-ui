import React from 'react';
import { PageSection } from 'components/shared/sections/PageSection';
import { Field } from 'formik';
import { RadioButton } from 'components/shared/form/RadioButton';

function pickQuestions(buildingId, classCode, visibility, updateFields) {
	switch (classCode) {
		case '3111':
			return <Field name='sfg.coverages.CDBG.deductible' label='Deductible' component={RadioButton} />;
		default:
			// No Questions
			break;
	}
}

export const SFGBuildingQuestions = ({ buildingId, classCode, updateFields }) => (
	<PageSection title='Building Questions' className='questionSection' name='section_buildingQuestions'>
		BuildingQuestions
		<div className='questionFields'>{pickQuestions(buildingId, classCode, updateFields)}</div>
	</PageSection>
);
