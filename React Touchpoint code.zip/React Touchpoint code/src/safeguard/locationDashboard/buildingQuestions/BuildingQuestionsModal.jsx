import { ModalStepper } from 'components/shared/navigation/ModalStepper';
import QuoteContext from 'context/quoteContext';
import React, { Component } from 'react';
import SafeguardBuildingQuestionsForm from 'safeguard/locationDashboard/buildingQuestions/BuildingQuestionsForm';
import { Modal } from 'semantic-ui-react';
import { pageAnalytics } from 'utils/ScreenFunctions';
import { replaceReferrals } from 'validation/RunReferrals';

export default class BuildingQuestionsModal extends Component {
	static contextType = QuoteContext;

	constructor() {
		super();
		this.state = {
			isOpen: false,
		}; // state to control the state of popup
	}

	handleOpen = (callBack, locationId, newLocation, buildingId, newBuilding, building) => {
		// If no questions, forward to handle open on building coverages
		this.setState({
			isOpen: true,
			callBack,
			locationId,
			newLocation,
			buildingId,
			newBuilding,
			building,
		});
		pageAnalytics(this.props.location.pathname + '/BuildingQuestionsModal', true);
	};

	handleClose = () => {
		this.setState({ isOpen: false });
		replaceReferrals(this.context);
		pageAnalytics(this.props.location.pathname);
		this.state.callBack();
	};

	render() {
		const { callBack, locationId, newLocation, newBuilding, buildingId, building } = this.state;
		return (
			<Modal
				closeIcon
				open={this.state.isOpen}
				closeOnDimmerClick={false}
				onClose={this.handleClose}
				className='banded'
			>
				<div id='colorBlock' className='bldg' />
				<ModalStepper
					currentModal='safeguardBuildingQuestions'
					handleClose={this.handleClose}
					locationId={locationId}
					newLocation={newLocation}
					buildingId={buildingId}
					newBuilding={newBuilding}
					building={building}
				/>
				<Modal.Content>
					<SafeguardBuildingQuestionsForm
						buildingId={buildingId}
						locationId={locationId}
						newLocation={newLocation}
						handleClose={this.handleClose}
						newBuilding={newBuilding}
						building={building}
						callBack={callBack}
						{...this.props}
					/>
				</Modal.Content>
			</Modal>
		);
	}
}
