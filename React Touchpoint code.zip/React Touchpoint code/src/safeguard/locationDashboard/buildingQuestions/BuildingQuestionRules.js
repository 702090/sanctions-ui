import QuoteContext from 'context/quoteContext';
import bopClassCodesJson from 'data/BOPClassCodes';
import bldgQuestionsJson from 'data/BuildingQuestions';
import _ from 'lodash';
import { duplicate } from 'utils/ObjectFunctions';
import { isBlank } from 'utils/StringFunctions';

export default class BuildingQuestionRules {
	static contextType = QuoteContext;

	static requiredStructure = {
		questions: { reviewedCorrect: '' },
	};

	static rules(quote, locationId, classId) {
		const { state } = quote.addresses[locationId];
		const classQuestions = bopClassCodesJson.classCodes[state][classId].questions;
		const questionsToTest = {
			questions: {},
		};

		classQuestions.forEach((qid) => {
			if (!_.isString(qid)) {
				qid = qid.id;
			}
			questionsToTest.questions[qid] = [
				[(value) => !isBlank(value), 'This question is required.'],
				[
					(value) => {
						const question = bldgQuestionsJson.questions[qid];
						let thisOption = {};
						question.o.forEach((option) => {
							// loop over possible options for this question and get the selected option
							if (option.value === value || (option.value === -1 && option.r === 'J')) {
								thisOption = option;
							}
						});
						const number = value;
						let ok = true;
						if (thisOption.r === 'J') {
							switch (question.qy) {
								case 'D':
									ok = false;
									break;
								case 'P':
									if (number > 100) {
										ok = false;
									}
								// Fall through
								case 'I':
									if (number < 0) {
										ok = false;
									} else if (!(thisOption.mn === 0 && thisOption.mx === 0)) {
										if (thisOption.mx < thisOption.mn && thisOption.mx === 0) {
											// and up condition
											if (thisOption.mn > number) {
												ok = false;
											}
										} else if (thisOption.mn < thisOption.mx) {
											if (thisOption.mn > number || thisOption.mx < number) {
												ok = false;
											}
										} else {
											// ranges are not set up correctly, so reject
											ok = false;
										}
									}
									break;
								default: // T and S do not need testing
							}
						}
						return ok;
					},
					'Due to the answer to this question, you cannot proceed with this quote.',
				],
			];
		});
		questionsToTest.questions.reviewedCorrect = [
			[(value) => !isBlank(value), 'This question is required.'],
			[(value) => value === 'Y', 'To proceed with this quote, you must agree with this statement.'],
		];
		return questionsToTest;
	}

	static referrals(context, values, visibility, extraData) {
		let classId;
		const { locationId, id: buildingId } = values;
		if (extraData) {
			classId = extraData.building.classId;
		} else {
			classId = _.get(context, `quote.sfg.locations.${locationId}.buildings.${buildingId}.classId`);
		}
		const state = _.get(context, `quote.addresses.${locationId}.state`);
		const classQuestions = duplicate(_.get(bopClassCodesJson.classCodes[state][classId], 'questions', []));
		const questionsToTest = {
			questions: {},
		};

		classQuestions.forEach((qid) => {
			if (qid.id) {
				qid = qid.id;
			}

			questionsToTest.questions[qid] = [
				[
					(value) => {
						const question = bldgQuestionsJson.questions[qid];
						let thisOption;
						question.o.forEach((option) => {
							// loop over possible options for this question and get the selected option
							if (option.value === value || (option.value === -1 && option.r === 'F')) {
								thisOption = option;
							}
						});
						const number = value;

						let thisVis = false;
						if (!visibility) {
							const thisQstn = bldgQuestionsJson.questions[qid];
							if (thisQstn.da) {
								const dependencyParts = _.split(thisQstn.da, '_');
								thisVis = values.questions[dependencyParts[0]] == dependencyParts[1]; /* eslint eqeqeq: [0] */
							} else {
								thisVis = true;
							}
						}

						let ok = true;
						if (thisOption && thisOption.r === 'F') {
							switch (question.qy) {
								case 'D':
									ok = false;
									break;
								case 'P':
									if (number > 100) {
										ok = false;
									}
								// Fall through
								case 'I':
									if (number < 0) {
										ok = false;
									} else if (!(thisOption.mn === 0 && thisOption.mx === 0)) {
										if (thisOption.mx < thisOption.mn && thisOption.mx === 0) {
											// and up condition
											if (thisOption.mn > number) {
												ok = false;
											}
										} else if (thisOption.mn < thisOption.mx) {
											if (thisOption.mn > number || thisOption.mx < number) {
												ok = false;
											}
										} else {
											// ranges are not set up correctly, so reject
											ok = false;
										}
									}
									break;
								default: // T and S do not need testing
							}
						}
						return ok || !_.get(visibility, qid, thisVis);
					},
					'SBQ01',
				],
			];
		});
		return questionsToTest;
	}
	static name() {
		return 'sfgBuildingQuestions';
	}
}
