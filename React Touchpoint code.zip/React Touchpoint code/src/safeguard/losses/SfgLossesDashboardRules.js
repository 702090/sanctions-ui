import { getFieldDisplayArray } from 'data/FieldVisibility';
import _ from 'lodash';
import { getVisibility } from 'utils/ScreenFunctions';

class SfgLossesDashboardRules {
	static requiredStructure = {
		section_losses_sfg: '',
		sfg: { noLosses: false },
	};

	static rules(quote, values, visibility) {
		// use values for current page validation
		// use quote for external page validation
		if (!visibility) {
			visibility = getVisibility(getFieldDisplayArray('safeguardLosses'), quote, values);
		}

		return {
			sfg: {
				noLosses: [
					[
						(value) => value || !visibility.noLosses,
						'Please verify there have been no losses in the past three years. If no losses, please check the box stating this to continue with this quote.',
					],
				],
			},
		};
	}

	static referrals(context, values) {
		return {
			section_losses_sfg: [
				[(value) => _.size(_.get(context, 'quote.sfg.losses', {})) < 3, 'SLH01'],
				[(value) => getTotalPaidAmount(context.quote) < 10000, 'SLH02'],
			],
		};
	}

	static name() {
		return 'sfgLossDashboard';
	}
}

function getTotalPaidAmount(quote) {
	const losses = _.get(quote, 'sfg.losses', {});
	let totalAmountPaid = 0;

	Object.keys(losses).forEach((key) => {
		totalAmountPaid += losses[key].totalAmountPaid;
	});

	return totalAmountPaid;
}
export default SfgLossesDashboardRules;
