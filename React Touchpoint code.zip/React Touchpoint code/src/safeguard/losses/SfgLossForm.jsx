import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { SubmitButton } from 'components/shared/buttons/SubmitButton';
import { DatePicker } from 'components/shared/form/DatePicker';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputText } from 'components/shared/form/inputs/InputText';
import { RadioButton } from 'components/shared/form/RadioButton';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import selectOptionsJson from 'data/SelectOptions';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { Component } from 'react';
import SfgLossRules from 'safeguard/losses/SfgLossRules';
import { cleanValues, getVisibility, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { v4 as uuidv4 } from 'uuid';
import { validate } from 'validation/Validate';

let visibility = {};
const { loss_history_claim_Status } = selectOptionsJson;

export default class SfgLossForm extends Component {
	static contextType = QuoteContext;

	dirty = false;
	state = {};

	UNSAFE_componentWillMount() {
		this.lossHistory = _.get(this.context, `quote.sfg.losses.${this.props.id}`, {});
	}

	componentDidMount() {
		// If the form is not empty, trigger validation
		runRulesOnLoad(this.formProps, this.formProps.initialValues, ['id']);
	}

	render() {
		const { quote } = this.context;
		let { id } = this.props;
		return (
			<Formik
				render={(formikProps) => {
					this.formProps = formikProps;
					this.dirty = formikProps.dirty;
					if (id === 'NEW') {
						id = formikProps.values.id;
					}

					visibility = getVisibility(getFieldDisplayArray('safeguardLossHistory'), quote, formikProps.values);
					cleanValues(formikProps.values, visibility);
					return (
						<Form id='screen'>
							<Field
								name='dateOfClaim'
								label='Date Of Claim'
								component={!this.lossHistory.fromLexisNexis ? DatePicker : InputText}
								disabled={this.lossHistory.fromLexisNexis}
							/>
							<Field
								name='dateReported'
								label='Date Reported'
								component={!this.lossHistory.fromLexisNexis ? DatePicker : InputText}
								disabled={this.lossHistory.fromLexisNexis}
							/>
							<Field
								name='status'
								label='Claim Status'
								component={RadioButton}
								options={loss_history_claim_Status}
								disabled={this.lossHistory.fromLexisNexis}
							/>
							<Field
								name='lossDescription'
								label='Loss Description'
								component={InputText}
								disabled={this.lossHistory.fromLexisNexis}
								maxLength='120'
							/>
							<PageSection name='section_payments' label='Payments and Reserves' errors={formikProps.errors} />
							<PageSection title='Coverage 1'>
								<Field
									name='coverage1AmountPaid'
									label='Amount Paid'
									component={InputNumber}
									optional
									disabled={this.lossHistory.fromLexisNexis}
								/>
								<Field
									name='coverage1ReserveAmount'
									label='Reserve Amount'
									component={InputNumber}
									optional
									disabled={this.lossHistory.fromLexisNexis}
								/>
							</PageSection>
							<PageSection title='Coverage 2'>
								<Field
									name='coverage2AmountPaid'
									label='Amount Paid'
									component={InputNumber}
									optional
									disabled={this.lossHistory.fromLexisNexis}
								/>
								<Field
									name='coverage2ReserveAmount'
									label='Reserve Amount'
									component={InputNumber}
									optional
									disabled={this.lossHistory.fromLexisNexis}
								/>
							</PageSection>
							<PageSection title='Coverage 3'>
								<Field
									name='coverage3AmountPaid'
									label='Amount Paid'
									component={InputNumber}
									optional
									disabled={this.lossHistory.fromLexisNexis}
								/>
								<Field
									name='coverage3ReserveAmount'
									label='Reserve Amount'
									component={InputNumber}
									optional
									disabled={this.lossHistory.fromLexisNexis}
								/>
							</PageSection>
							<PageSection title='Coverage 4'>
								<Field
									name='coverage4AmountPaid'
									label='Amount Paid'
									component={InputNumber}
									optional
									disabled={this.lossHistory.fromLexisNexis}
								/>
								<Field
									name='coverage4ReserveAmount'
									label='Reserve Amount'
									component={InputNumber}
									optional
									disabled={this.lossHistory.fromLexisNexis}
								/>
							</PageSection>
							<PageSection title='Coverage 5'>
								<Field
									name='coverage5AmountPaid'
									label='Amount Paid'
									component={InputNumber}
									optional
									disabled={this.lossHistory.fromLexisNexis}
								/>
								<Field
									name='coverage5ReserveAmount'
									label='Reserve Amount'
									component={InputNumber}
									optional
									disabled={this.lossHistory.fromLexisNexis}
								/>
							</PageSection>
							<PageSection title='Coverage Other'>
								<Field
									name='coverage6AmountPaid'
									label='Amount Paid'
									component={InputNumber}
									optional
									disabled={this.lossHistory.fromLexisNexis}
								/>
								<Field
									name='coverage6ReserveAmount'
									label='Reserve Amount'
									component={InputNumber}
									optional
									disabled={this.lossHistory.fromLexisNexis}
								/>
							</PageSection>
							<SimpleButton onClick={this.props.handleClose} content='Cancel' type='button' />
							{!this.lossHistory.fromLexisNexis ? (
								<SubmitButton
									error={Object.keys(formikProps.errors).length > 0}
									disabled={this.lossHistory.fromLexisNexis}
									content='Save'
								/>
							) : null}
						</Form>
					);
				}}
				initialValues={{
					id: id && id !== 'NEW' ? id : uuidv4(),
					dateOfClaim: this.lossHistory.dateOfClaim || '',
					dateReported: this.lossHistory.dateReported || '',
					status: this.lossHistory.status || '',
					lossDescription: this.lossHistory.lossDescription || '',
					coverage1AmountPaid: this.lossHistory.coverage1AmountPaid || '',
					coverage1ReserveAmount: this.lossHistory.coverage1ReserveAmount || '',
					coverage2AmountPaid: this.lossHistory.coverage2AmountPaid || '',
					coverage2ReserveAmount: this.lossHistory.coverage2ReserveAmount || '',
					coverage3AmountPaid: this.lossHistory.coverage3AmountPaid || '',
					coverage3ReserveAmount: this.lossHistory.coverage3ReserveAmount || '',
					coverage4AmountPaid: this.lossHistory.coverage4AmountPaid || '',
					coverage4ReserveAmount: this.lossHistory.coverage4ReserveAmount || '',
					coverage5AmountPaid: this.lossHistory.coverage5AmountPaid || '',
					coverage5ReserveAmount: this.lossHistory.coverage5ReserveAmount || '',
					coverage6AmountPaid: this.lossHistory.coverage6AmountPaid || '',
					coverage6ReserveAmount: this.lossHistory.coverage6ReserveAmount || '',
				}}
				onSubmit={(values, formikActions) => {
					cleanValues(values, visibility);
					this.context.onLossHistoryModalSubmit(values, this.dirty, 'sfg', this.props, SfgLossRules);
					formikActions.setSubmitting(false);
					this.props.handleClose();
				}}
				validate={(values) => {
					const validResults = validate(
						values,
						SfgLossRules.rules(quote, values, visibility),
						SfgLossRules.requiredStructure,
					);
					logPageErrors(validResults, this.formProps.touched, 'sfg');
					return validResults;
				}}
			/>
		);
	}
}
