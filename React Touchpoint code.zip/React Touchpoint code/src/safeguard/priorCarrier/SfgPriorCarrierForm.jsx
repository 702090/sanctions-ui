import { DatePicker } from 'components/shared/form/DatePicker';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputText } from 'components/shared/form/inputs/InputText';
import { RadioButton } from 'components/shared/form/RadioButton';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { useContext, useEffect } from 'react';
import { toast } from 'react-toastify';
import SfgPriorCarrierRules from 'safeguard/priorCarrier/SfgPriorCarrierRules';
import http from 'services/httpService';
import { cleanValues, getVisibility, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { checkReferrals, validateNew } from 'validation/Validate';

const SafeguardPriorCarrierForm = (props) => {
	const context = useContext(QuoteContext);
	let visibility = {};
	let dirty = false;
	let formProps;

	useEffect(() => {
		// If the form is not empty, trigger validation

		runRulesOnLoad(
			formProps,
			formProps.initialValues,
			['priorCarrier'],
			isBlank(_.get(context, 'quote.sfg.priorCarrier', '')),
		);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	const verifyCigPolicy = (e, formikProps) => {
		const requestBody = {
			policyNumber: _.get(formikProps, 'values.sfg.priorPolicyNumber', ''),
			effectiveDate: _.get(context, 'quote.effectiveDate', ''),
		};

		http
			.post(`${process.env.REACT_APP_POLICY_VERIFICATION}?auth=${sessionStorage.getItem('cigToken')}`, requestBody)
			.then((response) => {
				const priorPolicyEffectiveDate = _.get(response, 'data.originalPolicyEffdte', '');
				const priorPolicyProduct = _.get(response, 'data.originalPolicyProduct', '');
				const cancelReason = _.get(response, 'data.cancelReason', '');
				if (!isBlank(priorPolicyEffectiveDate)) {
					_.set(formikProps, 'values.sfg.priorPolicyEffectiveDate', priorPolicyEffectiveDate);
					_.set(formikProps, 'values.sfg.priorPolicyProduct', priorPolicyProduct);
					_.set(formikProps, 'values.sfg.cancelReason', cancelReason);
					_.set(formikProps, 'values.sfg.priorPolicyCigVerified', true);
				} else {
					_.unset(formikProps, 'values.sfg.priorPolicyEffectiveDate');
					_.unset(formikProps, 'values.sfg.priorPolicyProduct');
					_.unset(formikProps, 'values.sfg.cancelReason');
					_.set(formikProps, 'values.sfg.priorPolicyCigVerified', false);
				}
				formikProps.validateForm(formikProps.values);
			})
			.catch(() => {
				toast.error('Error verifying policy.');
			});
	};

	const { quote } = context;
	return (
		<Formik
			render={(formikProps) => {
				formProps = formikProps;
				dirty = formikProps.dirty;
				visibility = getVisibility(getFieldDisplayArray('safeguardPriorCarrier'), quote, formikProps.values);
				cleanValues(formikProps.values, visibility);
				checkReferrals(context, formikProps.values, SfgPriorCarrierRules);
				return (
					<Form id='screen'>
						<PageSection>
							<Field
								name='sfg.priorCarrier'
								label='Do you have a prior carrier?'
								component={RadioButton}
								ignoreTouched
							/>
							<Field
								name='sfg.cigPriorCarrier'
								label='Is the prior carrier with Columbia Insurance Group?'
								component={RadioButton}
								fieldDisplay={visibility['sfg.cigPriorCarrier']}
							/>
							<Field
								name='sfg.priorPolicyNumber'
								label='Prior policy number'
								component={InputText}
								fieldDisplay={visibility['sfg.priorPolicyNumber']}
								maxLength='15'
								additionalOnBlur={(e) => verifyCigPolicy(e, formikProps)}
							/>
							<Field
								name='sfg.carrierName'
								label='What is the prior carrier name?'
								component={InputText}
								fieldDisplay={visibility['sfg.carrierName']}
								maxLength='35'
							/>
							<Field
								name='sfg.expirationDate'
								label='Expiration Date'
								component={DatePicker}
								fieldDisplay={visibility['sfg.expirationDate']}
								optional
							/>
							<Field
								name='sfg.annualPremium'
								label='Annual Premium'
								component={InputNumber}
								type='currency'
								fieldDisplay={visibility['sfg.annualPremium']}
								maxLength='10'
								optional
							/>
						</PageSection>
						<NavigationButtons
							formikProps={formikProps}
							back
							location={props.location}
							history={props.history}
							rulesObject={SfgPriorCarrierRules}
						/>
					</Form>
				);
			}}
			initialValues={{
				sfg: {
					priorCarrier: _.get(quote, 'sfg.priorCarrier') || '',
					cigPriorCarrier: _.get(quote, 'sfg.cigPriorCarrier') || '',
					priorPolicyNumber: _.get(quote, 'sfg.priorPolicyNumber') || '',
					carrierName: _.get(quote, 'sfg.carrierName') || '',
					expirationDate: _.get(quote, 'sfg.expirationDate') || _.get(quote, 'effectiveDate'),
					annualPremium: _.get(quote, 'sfg.annualPremium') || '',
					cancelReason: _.get(quote, 'sfg.cancelReason') || '',
				},
			}}
			onSubmit={(values, formikActions) => {
				cleanValues(values, visibility);

				if (dirty) {
					let clearSan = false;

					if (
						_.get(quote, 'sfg.priorCarrier') === 'N' &&
						_.get(values, 'sfg.priorCarrier') === 'Y' &&
						_.get(values, 'sfg.cigPriorCarrier') === 'Y'
					) {
						clearSan = true;
					}

					if (
						_.get(quote, 'sfg.priorCarrier') === 'Y' &&
						_.get(values, 'sfg.priorCarrier') === 'Y' &&
						_.get(quote, 'sfg.cigPriorCarrier') !== _.get(values, 'sfg.cigPriorCarrier')
					) {
						clearSan = true;
					}

					if (
						_.get(quote, 'sfg.priorCarrier') === 'Y' &&
						_.get(quote, 'sfg.cigPriorCarrier') === 'Y' &&
						_.get(values, 'sfg.priorCarrier') === 'N'
					) {
						clearSan = true;
					}

					if (clearSan) {
						_.set(quote, 'sfg.san', '');
					}
				}

				return context.onSubmit(values, dirty, false, false, props, SfgPriorCarrierRules);
			}}
			validate={(values) => {
				checkReferrals(context, values, SfgPriorCarrierRules);

				const validResults = validateNew(quote, values, SfgPriorCarrierRules, visibility);
				logPageErrors(validResults, formProps.touched, 'sfg');
				return validResults;
			}}
		/>
	);
};

export default SafeguardPriorCarrierForm;
