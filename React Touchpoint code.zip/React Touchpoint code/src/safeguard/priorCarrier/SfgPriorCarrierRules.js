import { getFieldDisplayArray } from 'data/FieldVisibility';
import _ from 'lodash';
import { isValidDate } from 'utils/DateFunctions';
import { getVisibility } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';

export default class SfgPriorCarrierRules {
	static requiredStructure = {
		sfg: {
			priorCarrier: '',
			cigPriorCarrier: '',
			priorPolicyNumber: '',
		},
	};

	static optionalStructure = {
		sfg: {
			expirationDate: '',
			annualPremium: '',
		},
	};

	static rules(quote, values, visibility) {
		if (values && !visibility) {
			visibility = getVisibility(getFieldDisplayArray('safeguardPriorCarrier'), quote, values);
		}

		// Rules won't apply if this is a new venture
		if (_.get(quote, 'newVenture') === 'Y') {
			return {};
		}

		return {
			sfg: {
				priorCarrier: [[(value) => !isBlank(value), 'Prior Carrier is required.']],
				cigPriorCarrier: [
					[(value) => !isBlank(value) || !visibility['sfg.cigPriorCarrier'], 'CIG Prior Carrier is required.'],
				],
				priorPolicyNumber: [
					[(value) => !isBlank(value) || !visibility['sfg.priorPolicyNumber'], 'Prior Policy Number is required.'],
					[
						(value) => _.get(values, 'sfg.priorPolicyCigVerified', true) || !visibility['sfg.priorPolicyNumber'],
						'The prior policy number you entered is not a valid Columbia policy number.  Please provide a valid number or remove Prior Insurance Coverage.',
					],
				],
				carrierName: [[(value) => !isBlank(value) || !visibility['sfg.carrierName'], 'Carrier Name is required.']],
				expirationDate: [[(value) => isBlank(value) || isValidDate(value), 'You must enter a valid date.']],
			},
		};
	}

	static referrals(quote, values, visibility) {
		return {
			sfg: {
				priorCarrier: [[(value) => value !== 'N', 'SPI01']],
				priorPolicyNumber: [
					[
						(value) => !_.includes(['N1', 'N2', 'N3', 'N4', '02', '05', '06'], _.get(values, 'sfg.cancelReason', '')),
						'SPI02',
					],
				],
			},
		};
	}

	static name() {
		return 'sfgPriorCarrier';
	}
}
