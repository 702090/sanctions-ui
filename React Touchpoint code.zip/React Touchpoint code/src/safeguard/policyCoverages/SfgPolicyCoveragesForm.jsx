import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { Select } from 'components/shared/form/Select';
import { InformationMessage } from 'components/shared/messages/InformationMessage';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import classCodeListsJson from 'data/ClassCodeLists';
import selectOptionsJson from 'data/SelectOptions';
import { isAfter, isBefore, parseISO } from 'date-fns';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { Component } from 'react';
import { toast } from 'react-toastify';
import { covgMaps, SFGPolicyCoverage } from 'safeguard/policyCoverages/SfgPolicyCoverages';
import SfgPolicyCoveragesRules from 'safeguard/policyCoverages/SfgPolicyCoveragesRules';
import {
	checkCoverages,
	coverageRollOffMessages,
	distillBuildings,
	distillLocations,
	getFirstLocation,
	getPolicyCoverageList,
	getPredState,
} from 'utils/BusinessFunctions';
import { duplicate, getSet } from 'utils/ObjectFunctions';
import { cleanValues, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { checkReferrals, validate } from 'validation/Validate';

const { sfg_policyCoverages, sfg_policyCoverages_original } = selectOptionsJson;

export default class SafeguardCoveragesForm extends Component {
	static contextType = QuoteContext;
	visibility;
	predState;
	fieldVisibility = {
		'sfg.coverages.CDCR.cyber10': false,
		'sfg.coverages.CDCR.cyber9': false,
		'sfg.coverages.CDCR.cyber8': false,
		'sfg.coverages.CDCR.cyber7': false,
		'sfg.coverages.CDCR.cyber6': false,
		'sfg.coverages.CDCR.cyber5': false,
		'sfg.coverages.CDCR.cyber4': false,
		'sfg.coverages.CDCR.cyber3': false,
		'sfg.coverages.CDCR.cyber2': false,
		'sfg.coverages.CDCR.cyber1': false,
		'sfg.coverages.CITE.blanketSubLimit': false,
		'sfg.coverages.CITE.blanketLimit': false,
		'sfg.coverages.CITE.actualCashValue': false,
		'sfg.coverages.CITE.scheduleLimit': false,
		'sfg.coverages.CITE.schedule': false,
		'sfg.coverages.CDUM.uninsuredPropertyDamageLimit': false,
		'sfg.coverages.CDUM.underinsuredLimit': false,
		'sfg.coverages.CDUM.underinsuredLimitAR': false,
		newCite: false,
	};
	defaultCoverages = ['CDPL', 'CDCR'];
	newCiteOptions = false;

	dirty = false;

	state = {
		currentCoverages: new Set(),
		newCoverageOptions: [],
		deletedCoverages: new Set(),
	};

	coveragesWithoutFields = getSet([
		'CDSC',
		'CDPN',
		'CDPL',
		'CDPC',
		'CDOH',
		'NOWN',
		'HIRE',
		'CDFD',
		'CDPO',
		'CDPA',
		'CDEI',
		'CDDS',
		'CDDX',
		'CDDW',
		'CDDE',
		'CDCM',
		'CDDC',
		'CDAA',
		'CDAC',
		'CDIY',
		'CDBB',
		'CDBS',
		'BRLP',
		'CDBP',
	]);

	coverageRollOffMessage = [];

	UNSAFE_componentWillMount() {
		const { occupancyCodes, classCodes, buildingCoverages, totalBppLimits } = distillBuildings(
			_.get(this.context, 'quote.sfg.locations'),
		);

		const { totalSales } = distillLocations(this.context.quote);

		const firstLocation = getFirstLocation(this.context.quote);
		this.predState = _.get(this.context, `quote.addresses.${firstLocation}.state`);

		if (!_.get(this.context, 'quote.sfg.coverages')) {
			this.forceSave = true;
		}

		let quoteCurrentCoverages = _.get(this.context, 'quote.sfg.coverages.currentCoverages', this.defaultCoverages);
		if (quoteCurrentCoverages instanceof Set) {
			quoteCurrentCoverages = [...quoteCurrentCoverages];
		}
		let currentCoverages = getSet(
			quoteCurrentCoverages.filter((coverage) =>
				checkCoverages(
					coverage,
					classCodes,
					occupancyCodes,
					this.predState,
					quoteCurrentCoverages,
					totalBppLimits,
					buildingCoverages,
					_.get(this.context, 'quote.effectiveDate', ''),
				),
			),
		);

		this.coverageRollOffMessage = coverageRollOffMessages({ quoteCurrentCoverages, currentCoverages });

		let deletedCoverages = getSet(_.get(this.context, 'quote.sfg.coverages.deletedCoverages', new Set()));

		currentCoverages = this.rollOnCoverages(
			this.predState,
			currentCoverages,
			occupancyCodes,
			deletedCoverages,
			classCodes,
		);

		_.set(this.context, 'quote.sfg.coverages.currentCoverages', currentCoverages);

		_.set(this.context, 'quote.sfg.coverages.deletedCoverages', deletedCoverages);
		const { newCoverageOptions, vis } = getPolicyCoverageList(
			_.get(this.context, `quote.addresses.${firstLocation}.state`),
			currentCoverages,
			occupancyCodes,
			classCodes,
			this.context.quote.effectiveDate,
			totalBppLimits,
		);
		this.visibility = vis;
		this.updateFieldVisibilityCDCR(_.get(this.context, 'quote.sfg.coverages.CDCR.limit', 50000));
		this.updateFieldVisibilityCITE(_.get(this.context, 'quote.sfg.coverages.CITE.covgType', '1'));
		this.updateFieldVisibilityCDUM(this.predState);

		// TODO Temporary, can remove this code and references to it in SfgPolicyCoverages after enough time has past
		this.newCiteOptions =
			(isAfter(parseISO(_.get(this.context, 'quote.effectiveDate')), parseISO('2020-03-31')) &&
				_.includes(['AR', 'IL', 'MO'], this.predState)) ||
			(isAfter(parseISO(_.get(this.context, 'quote.effectiveDate')), parseISO('2020-04-30')) &&
				!_.includes(['KY', 'GA'], this.predState));
		if (_.get(this.context, 'quote.sfg.coverages.CITE.blanketSubLimit') === '1000' && !this.newCiteOptions) {
			_.set(this.context, 'quote.sfg.coverages.CITE.blanketSubLimit', '');
		}

		this.setState({
			currentCoverages,
			newCoverageOptions,
			deletedCoverages,
			firstLocation,
			occupancyCodes,
			classCodes,
			predState: this.predState,
			totalSales,
			totalBppLimits,
			buildingCoverages,
		});
	}

	componentWillUnmount() {
		this.visibility = {};
	}

	componentDidMount() {
		// If the form is not empty, trigger validation
		runRulesOnLoad(this.formProps, this.formProps.initialValues, ['']);
	}

	rollOnCoverages = (predState, currentCoverages, occupancyCodes, deletedCoverages, classCodes) => {
		occupancyCodes = getSet(occupancyCodes);
		const classCodesArray = [...classCodes];

		if (!currentCoverages.has('TRSM') || isBlank(_.get(this.context, 'quote.sfg.coverages.TRSM.included'))) {
			// This corrects an issue if they leave the page immediately on first visit to coverages
			this.forceSave = true;
		}
		currentCoverages.add('TRSM');

		if (
			!(
				deletedCoverages.has('CDEP') ||
				_.intersection(classCodesArray, classCodeListsJson.attorneyClasses).length > 0 ||
				(predState === 'SD' && isBefore(parseISO(_.get(this.context, 'quote.effectiveDate')), parseISO('2022-03-01')))
			)
		) {
			currentCoverages.add('CDEP');
		}

		if (predState === 'GA') {
			currentCoverages.add('CDMD');
		}
		if (occupancyCodes.has('A')) {
			currentCoverages.add('HIRE');
			currentCoverages.add('NOWN');
		}
		if (occupancyCodes.has('10')) {
			currentCoverages.add('CITE');
		}
		// roll on automatically for IL and occType A or if adding Hire/Nown to other occupancies,
		// cannot be deleted so make sure always rolls on
		if (
			predState === 'IL' &&
			(occupancyCodes.has('A') || currentCoverages.has('HIRE') || currentCoverages.has('NOWN'))
		) {
			currentCoverages.add('CDUM');
		}
		// roll on automatically for AR and occtyp A or if adding Hire/Nown
		// can be deleted so don't reroll on
		if (
			predState === 'AR' &&
			(occupancyCodes.has('A') || currentCoverages.has('HIRE') || currentCoverages.has('NOWN')) &&
			!deletedCoverages.has('CDUM')
		) {
			currentCoverages.add('CDUM');
		}

		return currentCoverages;
	};

	updateFieldVisibilityCDCR = (newValue) => {
		this.fieldVisibility = {
			...this.fieldVisibility,
			'sfg.coverages.CDCR.cyber10': false,
			'sfg.coverages.CDCR.cyber9': false,
			'sfg.coverages.CDCR.cyber8': false,
			'sfg.coverages.CDCR.cyber7': false,
			'sfg.coverages.CDCR.cyber6': false,
			'sfg.coverages.CDCR.cyber5': false,
			'sfg.coverages.CDCR.cyber4': false,
			'sfg.coverages.CDCR.cyber3': false,
			'sfg.coverages.CDCR.cyber2': false,
			'sfg.coverages.CDCR.cyber1': false,
		};
		switch (newValue) {
			case '1000000':
			case '500000':
				this.fieldVisibility['sfg.coverages.CDCR.cyber10'] = true;
				this.fieldVisibility['sfg.coverages.CDCR.cyber9'] = true;
				this.fieldVisibility['sfg.coverages.CDCR.cyber8'] = true;
				this.fieldVisibility['sfg.coverages.CDCR.cyber7'] = true;
				this.fieldVisibility['sfg.coverages.CDCR.cyber6'] = true;
			// falls through keep comment so Lint doesn't get mad
			case '250000':
				this.fieldVisibility['sfg.coverages.CDCR.cyber5'] = true;
				this.fieldVisibility['sfg.coverages.CDCR.cyber4'] = true;
			// falls through keep comment so Lint doesn't get mad
			case '100000':
				this.fieldVisibility['sfg.coverages.CDCR.cyber3'] = true;
				this.fieldVisibility['sfg.coverages.CDCR.cyber2'] = true;
				this.fieldVisibility['sfg.coverages.CDCR.cyber1'] = true;
			// falls through keep comment so Lint doesn't get mad
			case '50000':
			default:
		}
	};

	updateFieldVisibilityCITE = (newValue) => {
		this.fieldVisibility = {
			...this.fieldVisibility,
			'sfg.coverages.CITE.blanketSubLimit': false,
			'sfg.coverages.CITE.blanketLimit': false,
			'sfg.coverages.CITE.scheduleLimit': false,
			'sfg.coverages.CITE.schedule': false,
			'sfg.coverages.CITE.actualCashValue': false,
			newCite: false,
		};
		const effectiveDateToDate = parseISO(this.context.quote.effectiveDate);
		const newCite =
			(isAfter(
				effectiveDateToDate,
				parseISO('2020-03-31'), //,
			) &&
				_.includes(['AR', 'IL', 'MO'], this.predState)) ||
			(isAfter(
				effectiveDateToDate,
				parseISO('2020-04-30'), //,
			) &&
				!_.includes(['KY', 'GA'], this.predState));
		if (newCite) {
			this.fieldVisibility['newCite'] = true;
		}

		if (_.includes(['1', '3'], newValue)) {
			if (newValue === '1') {
				_.set(this.context, 'quote.sfg.coverages.CITE.schedule', []);
				_.set(this.context, 'quote.sfg.coverages.CITE.scheduleLimit', '');
				this.context.updateQuoteState(this.context.quote);
			}
			this.fieldVisibility['sfg.coverages.CITE.blanketSubLimit'] = true;
			this.fieldVisibility['sfg.coverages.CITE.blanketLimit'] = true;
			if (newCite) {
				this.fieldVisibility['sfg.coverages.CITE.actualCashValue'] = true;
			}
		}
		if (_.includes(['2', '3'], newValue)) {
			this.fieldVisibility['sfg.coverages.CITE.scheduleLimit'] = true;
			this.fieldVisibility['sfg.coverages.CITE.schedule'] = true;
		}
	};

	updateFieldVisibilityCDUM = (predState) => {
		this.fieldVisibility = {
			...this.fieldVisibility,
			'sfg.coverages.CDUM.uninsuredPropertyDamageLimit': false,
			'sfg.coverages.CDUM.underinsuredLimit': false,
			'sfg.coverages.CDUM.underinsuredLimitAR': false,
		};
		// AR has an additional field. IL does not show underinsured limit. AR limit is defaulted and disabled
		if (predState === 'AR') {
			this.fieldVisibility['sfg.coverages.CDUM.uninsuredPropertyDamageLimit'] = true;
			this.fieldVisibility['sfg.coverages.CDUM.underinsuredLimitAR'] = true;
		} else if (predState !== 'IL') {
			this.fieldVisibility['sfg.coverages.CDUM.underinsuredLimit'] = true;
		}
	};

	setAnualAggregate = (data, setFieldValue) => {
		setFieldValue('sfg.coverages.CDCO.annualAggregate', data, false);
	};

	removeCoverage = (coverageId, formikProps, hideToast) => {
		const { currentCoverages } = this.state;
		currentCoverages.delete(coverageId);
		const { deletedCoverages } = this.state;
		deletedCoverages.add(coverageId);

		// if HIRE && NOWN are removed, remove CDUM but allow for it to roll back on if HIRE/NOWN are added again in IL
		// if on deleted coverages it will not auto reroll on again
		if (
			_.includes(['HIRE', 'NOWN'], coverageId) &&
			!currentCoverages.has('NOWN') &&
			!currentCoverages.has('HIRE') &&
			currentCoverages.has('CDUM')
		) {
			currentCoverages.delete('CDUM');
		}

		formikProps.values.sfg.coverages.currentCoverages = currentCoverages;
		const { newCoverageOptions, vis } = getPolicyCoverageList(
			this.state.predState,
			currentCoverages,
			this.state.occupancyCodes,
			this.state.classCodes,
			this.context.quote.effectiveDate,
			this.state.totalBppLimits,
		);
		this.visibility = vis;
		this.setState({ currentCoverages, newCoverageOptions, deletedCoverages });
		formikProps.validateForm(formikProps.values);
		if (!hideToast) {
			toast.success('Coverage Removed!');
		}

		this.context.savePageValues(formikProps.values);
	};

	render() {
		const { quote } = this.context;
		return (
			<Formik
				render={(formikProps) => {
					this.formProps = formikProps;
					if (this.forceSave) {
						//This is for props sent to onBack
						formikProps.dirty = this.forceSave;
					}
					this.dirty = formikProps.dirty || !isBlank(this.coverageRollOffMessage);
					cleanValues(formikProps.values, this.fieldVisibility);
					if (!isBlank(formikProps.values)) {
						checkReferrals(this.context, formikProps.values, SfgPolicyCoveragesRules);
					}
					const availablePolicyCoverages = isAfter(parseISO(quote.effectiveDate), parseISO('2020-05-01'))
						? sfg_policyCoverages
						: sfg_policyCoverages_original;
					return (
						<Form id='screen'>
							{!isBlank(this.coverageRollOffMessage) &&
								this.coverageRollOffMessage.map((message) => (
									<InformationMessage key={message} message={message} fieldDisplay />
								))}
							<PageSection className='addCoverage'>
								<Field
									name='sfgPolicyCoverages'
									label='Add New Coverage'
									component={Select}
									options={this.state.newCoverageOptions}
									search
								/>
								<SimpleButton
									content='Add Coverage'
									id='AddCoverage'
									primary
									onClick={() => {
										const data = formikProps.values.sfgPolicyCoverages || '';
										if (!isBlank(data)) {
											let { currentCoverages } = this.state;
											const { deletedCoverages } = this.state;
											currentCoverages.add(data);
											currentCoverages = this.rollOnCoverages(
												this.predState,
												currentCoverages,
												[...this.state.occupancyCodes],
												deletedCoverages,
												this.state.classCodes,
											);
											const { newCoverageOptions } = getPolicyCoverageList(
												this.predState,
												currentCoverages,
												this.state.occupancyCodes,
												this.state.classCodes,
												quote.effectiveDate,
												this.state.totalBppLimits,
											);
											formikProps.values.sfg.coverages.currentCoverages = currentCoverages;
											this.visibility[`sfg.coverages.${data}`] = true;
											if (this.coveragesWithoutFields.has(data)) {
												toast.success(`${_.find(availablePolicyCoverages, (c) => data === c.value).text} Added!`);
											}
											this.setState({
												currentCoverages,
												newCoverageOptions,
												newCoverage: this.coveragesWithoutFields.has(data) ? '' : data,
											});
											formikProps.validateForm(formikProps.values);
											formikProps.values.sfgPolicyCoverages = '';
										}
									}}
								/>
							</PageSection>
							{availablePolicyCoverages.map((coverage) => {
								let updateFields = () => {};
								if (coverage.value === 'CDCR') {
									updateFields = this.updateFieldVisibilityCDCR;
								} else if (coverage.value === 'CDCO') {
									updateFields = (data) => this.setAnualAggregate(data, formikProps.setFieldValue);
								} else if (coverage.value === 'CITE') {
									updateFields = this.updateFieldVisibilityCITE;
								} else if (coverage.value === 'CDUM') {
									updateFields = this.updateFieldVisibilityCDUM;
								}
								return (
									<SFGPolicyCoverage
										key={coverage.value}
										coverage={coverage}
										predState={this.state.predState}
										isAdded={this.state.currentCoverages.has(coverage.value)}
										removeCoverage={(coverageId, hideToast) => this.removeCoverage(coverageId, formikProps, hideToast)}
										visibility={this.fieldVisibility}
										updateFields={updateFields}
										hasAutoOccupancy={this.state.occupancyCodes.has('A')}
										hasContractorOccupancy={this.state.occupancyCodes.has('10')}
										hasHireNonOwn={this.state.currentCoverages.has('NOWN') || this.state.currentCoverages.has('HIRE')}
										isNewCoverage={this.state.newCoverage === coverage.value}
										formikProps={formikProps}
										resetNewCoverage={() => this.setState({ newCoverage: '' })}
										newCiteOptions={this.newCiteOptions}
									/>
								);
							})}
							<NavigationButtons
								formikProps={formikProps}
								back
								location={this.props.location}
								history={this.props.history}
								rulesObject={SfgPolicyCoveragesRules}
							/>
						</Form>
					);
				}}
				initialValues={
					quote.sfg
						? {
								sfg: {
									...quote.sfg,
									coverages: {
										currentCoverages:
											quote.sfg.coverages && quote.sfg.coverages.currentCoverages
												? getSet(quote.sfg.coverages.currentCoverages)
												: getSet(this.defaultCoverages),
										deletedCoverages:
											quote.sfg.coverages && quote.sfg.coverages.deletedCoverages
												? quote.sfg.coverages.deletedCoverages
												: this.state.deletedCoverages,
										CDCR: covgMaps.CDCRmap(quote.sfg.coverages),
										CDCP: covgMaps.CDCPmap(quote.sfg.coverages),
										CDBG: covgMaps.CDBGmap(quote.sfg.coverages),
										BICO: covgMaps.BICOmap(quote.sfg.coverages),
										CFFT: covgMaps.CFFTmap(quote.sfg.coverages),
										CODO: covgMaps.CODOmap(quote.sfg.coverages),
										CDCO: covgMaps.CDCOmap(quote.sfg.coverages),
										CITE: covgMaps.CITEmap(quote.sfg.coverages, this.fieldVisibility),
										LLCG: covgMaps.LLCGmap(quote.sfg.coverages),
										CDDP: covgMaps.CDDPmap(quote.sfg.coverages),
										CDEC: covgMaps.CDECmap(quote.sfg.coverages),
										CDED: covgMaps.CDEDmap(quote.sfg.coverages),
										CDEB: covgMaps.CDEBmap(quote.sfg.coverages),
										EMDI: covgMaps.EMDImap(quote.sfg.coverages),
										CDEP: covgMaps.CDEPmap(quote.sfg.coverages, getPredState(quote)),
										IDFR: covgMaps.IDFRmap(quote.sfg.coverages),
										CDHR: covgMaps.CDHRmap(quote.sfg.coverages),
										CDAF: covgMaps.CDAFmap(quote.sfg.coverages),
										ICPO: covgMaps.ICPOmap(quote.sfg.coverages),
										CDLQ: covgMaps.CDLQmap(quote.sfg.coverages),
										MOTL: covgMaps.MOTLmap(quote.sfg.coverages),
										PLPM: covgMaps.PLPMmap(quote.sfg.coverages),
										PHOT: covgMaps.PHOTmap(quote.sfg.coverages),
										CDPR: covgMaps.CDPRmap(quote.sfg.coverages),
										CDSM: covgMaps.CDSMmap(quote.sfg.coverages),
										TCLP: covgMaps.TCLPmap(quote.sfg.coverages),
										CDVL: covgMaps.CDVLmap(quote.sfg.coverages),
										VETL: covgMaps.VETLmap(quote.sfg.coverages),
										CDWS: covgMaps.CDWSmap(quote.sfg.coverages),
										CMCD: covgMaps.CMCDmap(quote.sfg.coverages),
										CDUM: covgMaps.CDUMmap(quote.sfg.coverages),
										FDCO: covgMaps.FDCOmap(quote.sfg.coverages),
										CDMD: covgMaps.CDMDmap(quote.sfg.coverages),
										ELDT: covgMaps.ELDTmap(quote.sfg.coverages),
										TRSM: covgMaps.TRSMmap(quote.sfg.coverages),
									},
								},
						  }
						: {}
				}
				onSubmit={(values, formikActions) => {
					cleanValues(values, this.visibility);
					cleanValues(values, this.fieldVisibility);
					// CAP Symbol has to be adjusted if not 7 and HIRE/NOWN on quote
					if (
						(_.includes('CAP'),
						_.get(quote, 'products', ['sfg']) &&
							(values.sfg.coverages.currentCoverages.has('HIRE') || values.sfg.coverages.currentCoverages.has('NOWN')))
					) {
						_.set(quote, 'cap.symbols.liability', '7');
					}
					return this.context.onSubmit(
						values,
						this.forceSave || this.dirty,
						false,
						false,
						this.props,
						SfgPolicyCoveragesRules,
					);
				}}
				validate={(values) => {
					checkReferrals(this.context, values, SfgPolicyCoveragesRules);
					const validResults = validate(
						values,
						SfgPolicyCoveragesRules.rules(
							quote,
							values,
							this.fieldVisibility,
							[...this.state.buildingCoverages],
							this.state.totalBppLimits,
						),
						duplicate(SfgPolicyCoveragesRules.requiredStructure(quote, values)),
					);
					logPageErrors(validResults, this.formProps.touched, 'sfg');
					return validResults;
				}}
			/>
		);
	}
}
