import classCodeListsJson from 'data/ClassCodeLists';
import { getFieldDisplayArray, requiredQuestionMessage } from 'data/FieldVisibility';
import ruleMessagesJson from 'data/RuleMessages';
import selectOptionsJson from 'data/SelectOptions';
import { isAfter, isBefore, parseISO } from 'date-fns';
import _ from 'lodash';
import { always, map } from 'ramda';
import { calculateCDLQ, distillBuildings, getPredState } from 'utils/BusinessFunctions';
import { isValidDate, yearsFromDate } from 'utils/DateFunctions';
import { duplicate, getSet } from 'utils/ObjectFunctions';
import { getVisibility } from 'utils/ScreenFunctions';
import { isBlank, isBlankZ } from 'utils/StringFunctions';

export default class SfgPolicyCoveragesRules {
	static requiredStructure(quote, values) {
		if (!values) {
			values = duplicate(quote);
		}
		const CITEDepth = _.get(values, 'sfg.coverages.CITE.schedule', []);
		let i;
		const schedule = [];
		for (i = 0; i < Math.max(CITEDepth.length, 1); i++) {
			schedule[i] = { limit: '', desc: '', serialNo: '' };
		}

		//TODO:
		// const schedule2 =
		// 	CITEDepth === ''
		// 		? ''
		// 		: CITEDepth.map((obj) => {
		// 				return { limit: '', desc: '', serialNo: '' };
		// 		  });
		return {
			section_PLPM: '',
			section_CDLQ: '',
			section_CDDE: '',
			section_CDDW: '',
			section_CDWS: '',
			section_CDSM: '',
			section_CDCR: '',
			section_TCLP: '',
			section_FDCO: '',
			section_ICPO: '',
			section_ELDT: '',
			section_AGGL: '', // for error purposes, coverage no longer available
			sfg: {
				coverages: {
					CDCR: {
						limit: '',
						cyber1: '',
						cyber2: '',
						cyber3: '',
						cyber4: '',
						cyber5: '',
						cyber6: '',
						cyber7: '',
						cyber8: '',
						cyber9: '',
						cyber10: '',
					},
					CDCP: { numAmendOfCP: '' },
					CDBG: { deductible: '' },
					CFFT: { numEmployees: '' },
					CODO: { limit: '', deductible: '' },
					CDCO: { limit: '', payroll: '' },
					CITE: {
						limit: '',
						covgType: '',
						blanketSubLimit: '',
						blanketLimit: '',
						actualCashValue: '',
						scheduleLimit: '',
						nonOwnTools: '',
						schedule,
						employeeTools: '',
					},
					LLCG: { limit: '' },
					CDDP: { numDays: '' },
					CDEC: { limit: '' },
					ELDT: { limit: '' },
					CDED: { coverageType: '', limit: '' },
					CDEB: { limit: '' },
					EMDI: { limit: '', numEmployees: '' },
					CDEP: { occupancyDesc: '', numEmployees: '' },
					IDFR: { limit: '' },
					CDAF: { limit: '' },
					ICPO: { limit: '' },
					// CDLQ: { exposure: cdlqStructure },
					CDLQ: { exposure: '' },
					PLPM: { grossSales: '' },
					CDPR: { number: '' },
					CDSM: { aggregate: '' },
					TCLP: { limit: '', numEmployees: '' },
					CDVL: { limit: '' },
					VETL: { exposure: '' },
					CDWS: { exposure: '' },
					CDUM: { uninsuredLimit: '', underinsuredLimit: '' },
					AGGL: { premium: '' },
					FDCO: { limit: '', expenses: '' },
					TRSM: { included: '' },
				},
			},
		};
	}

	static optionalStructure = {
		sfg: {
			coverages: {
				BICO: {
					extPeriodOfIndemnity: '',
					ordinaryPayroll: '',
					timePeriod: '',
				},
				CFFT: { addtlLocations: '' },
				CDEB: { retroDte: '' },
				EMDI: { forgeryLimit: '', addtlLocations: '' },
				MOTL: { safeDepBox: '', guestProperty: '' },
				PHOT: { worldwide: '', equipmentLimit: '' },
				TCLP: { addtlLocations: '' },
				CDMD: { liabilityType: '' },
				CITE: { employeeTools: '' },
			},
		},
	};

	// TODO when CAP added - If policy doesn't have CAP in quote and is auto risk (occtyp A) must have Hired or Non Owned coverage (HIRE,NOWN) not sure if both or just one. Double check
	static rules(quote, values, visibility, buildingCoverages, totalBppLimits) {
		if (!values) {
			values = duplicate(quote);
		}

		if (!visibility) {
			visibility = getVisibility(getFieldDisplayArray('safeguardPolicyCoverage'), quote, values);
		}
		// use values for current page validation
		// use quote for external page validation
		const { attorneyClasses, liquorLiabilityReferClasses } = classCodeListsJson;
		const { sfgPolicy_CDCR } = ruleMessagesJson;
		const { sfg_CITE_limit } = selectOptionsJson;
		const predState = getPredState(quote);
		const currentCoverages = getSet(_.get(values, 'sfg.coverages.currentCoverages', []));
		const { classCodes } = distillBuildings(_.get(quote, 'sfg.locations'));
		const classCodeArray = [...classCodes];
		const newCite =
			(isAfter(
				parseISO(quote.effectiveDate),
				parseISO('2020-03-31'), //,
			) &&
				_.includes(['AR', 'IL', 'MO'], predState)) ||
			(isAfter(
				parseISO(quote.effectiveDate),
				parseISO('2020-04-30'), //,
			) &&
				!_.includes(['KY', 'GA'], predState));

		const CDCRnoCount = currentCoverages.has('CDCR') // this  will only work if the answers get cleared when limit is changed which I think happens
			? (_.get(values, 'sfg.coverages.CDCR.cyber2', '') === 'N' ? 1 : 0) +
			  (_.get(values, 'sfg.coverages.CDCR.cyber3', '') === 'N' ? 1 : 0) +
			  (_.get(values, 'sfg.coverages.CDCR.cyber4', '') === 'N' ? 1 : 0) +
			  (_.get(values, 'sfg.coverages.CDCR.cyber5', '') === 'N' ? 1 : 0) +
			  (_.get(values, 'sfg.coverages.CDCR.cyber6', '') === 'N' ? 1 : 0) +
			  (_.get(values, 'sfg.coverages.CDCR.cyber7', '') === 'N' ? 1 : 0) +
			  (_.get(values, 'sfg.coverages.CDCR.cyber8', '') === 'N' ? 1 : 0) +
			  (_.get(values, 'sfg.coverages.CDCR.cyber9', '') === 'N' ? 1 : 0) +
			  (_.get(values, 'sfg.coverages.CDCR.cyber10', '') === 'N' ? 1 : 0)
			: 0; // 0 for no cyber

		const scheduleCITE = {
			desc: [
				[
					(value) => !currentCoverages.has('CITE') || !isBlank(value) || values.sfg.coverages.CITE.covgType === '1',
					requiredQuestionMessage,
				],
			],
			limit: [
				[
					(value) => !currentCoverages.has('CITE') || !isBlank(value) || values.sfg.coverages.CITE.covgType === '1',
					requiredQuestionMessage,
				],
			],
		};
		return {
			section_AGGL: [[(value) => !currentCoverages.has('AGGL'), 'This coverage is no longer available.']],
			section_CDCR: [
				[
					(value) => !currentCoverages.has('CDCR') || _.get(values, 'sfg.coverages.CDCR.cyber1', '') !== 'Y',
					sfgPolicy_CDCR,
				],
				[
					(value) =>
						!currentCoverages.has('CDCR') ||
						!(_.get(values, 'sfg.coverages.CDCR.limit', '') === '100000' && CDCRnoCount >= 2),
					sfgPolicy_CDCR,
				],
				[
					(value) =>
						!currentCoverages.has('CDCR') ||
						!(_.get(values, 'sfg.coverages.CDCR.limit', '') === '250000' && CDCRnoCount > 2),
					sfgPolicy_CDCR,
				],
				[
					(value) =>
						!currentCoverages.has('CDCR') ||
						!(_.includes(['500000', '1000000'], _.get(values, 'sfg.coverages.CDCR.limit', '')) && CDCRnoCount > 8),
					sfgPolicy_CDCR,
				],
			],
			section_TCLP: [
				[
					(value) => !currentCoverages.has('TCLP') || currentCoverages.has('EMDI'),
					"Employee dishonesty coverage is required with Theft of Client's Property coverage. Please add Employee dishonesty coverage to the policy",
				],
			],
			section_FDCO: [
				[
					(value) => !(currentCoverages.has('FDCO') && _.has(buildingCoverages, 'RSEN')),
					'Risks with building level Restaurant Enhancement Endorsement coverage cannot have policy level Food Contamination coverage.',
				],
			],
			section_ICPO: [
				[
					(value) => !currentCoverages.has('ICPO') || (currentCoverages.has('ICPO') && totalBppLimits > 0),
					'Interruption of Computer Operations Coverage" is not available if there is no Business Personal Property.  Please either remove this coverage or add a Business Personal Property Limit',
				],
			],
			section_ELDT: [
				[
					(value) => !currentCoverages.has('ELDT') || (currentCoverages.has('ELDT') && totalBppLimits > 0),
					'Electronic Data Coverage is not available if there is no Business Personal Property.  Please either remove this coverage or add a Business Personal Property Limit',
				],
			],
			section_CDEP: [
				[
					(value) =>
						// catch existing quotes that should not have this coverage
						!currentCoverages.has('CDEP') ||
						(currentCoverages.has('CDEP') && _.intersection(classCodeArray, attorneyClasses).length > 0),
					'Due to the building class codes this coverage is no longer allowed. Please remove this coverage to proceed with this quote',
				],
			],
			sfg: {
				coverages: {
					CDCR: {
						cyber1: [
							[
								(value) =>
									!currentCoverages.has('CDCR') || !(visibility['sfg.coverages.CDCR.cyber1'] && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						cyber2: [
							[
								(value) =>
									!currentCoverages.has('CDCR') || !(visibility['sfg.coverages.CDCR.cyber2'] && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						cyber3: [
							[
								(value) =>
									!currentCoverages.has('CDCR') || !(visibility['sfg.coverages.CDCR.cyber3'] && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						cyber4: [
							[
								(value) =>
									!currentCoverages.has('CDCR') || !(visibility['sfg.coverages.CDCR.cyber4'] && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						cyber5: [
							[
								(value) =>
									!currentCoverages.has('CDCR') || !(visibility['sfg.coverages.CDCR.cyber5'] && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						cyber6: [
							[
								(value) =>
									!currentCoverages.has('CDCR') || !(visibility['sfg.coverages.CDCR.cyber6'] && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						cyber7: [
							[
								(value) =>
									!currentCoverages.has('CDCR') || !(visibility['sfg.coverages.CDCR.cyber7'] && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						cyber8: [
							[
								(value) =>
									!currentCoverages.has('CDCR') || !(visibility['sfg.coverages.CDCR.cyber8'] && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						cyber9: [
							[
								(value) =>
									!currentCoverages.has('CDCR') || !(visibility['sfg.coverages.CDCR.cyber9'] && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						cyber10: [
							[
								(value) =>
									!currentCoverages.has('CDCR') || !(visibility['sfg.coverages.CDCR.cyber10'] && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					CDCP: {
						numAmendOfCP: [
							[(value) => !currentCoverages.has('CDCP') || !isBlank(value), requiredQuestionMessage],
							[(value) => !currentCoverages.has('CDCP') || value <= 3, 'Please enter a number from 1  to 3'],
						],
					},
					CDBG: {
						deductible: [[(value) => !currentCoverages.has('CDBG') || !isBlank(value), requiredQuestionMessage]],
					},
					CFFT: {
						limit: [[(value) => !currentCoverages.has('CFFT') || !isBlank(value), requiredQuestionMessage]],
						numEmployees: [[(value) => !currentCoverages.has('CFFT') || !isBlank(value), requiredQuestionMessage]],
					},
					CODO: {
						limit: [[(value) => !currentCoverages.has('CODO') || !isBlank(value), requiredQuestionMessage]],
						deductible: [[(value) => !currentCoverages.has('CODO') || !isBlank(value), requiredQuestionMessage]],
					},
					CDCO: {
						limit: [[(value) => !currentCoverages.has('CDCO') || !isBlank(value), requiredQuestionMessage]],
						payroll: [
							[(value) => !currentCoverages.has('CDCO') || !isBlank(value), requiredQuestionMessage],
							[(value) => value <= 500000, 'Payroll must be less than or equal to $500,000'],
						],
					},
					CITE: {
						limit: [
							[(value) => !currentCoverages.has('CITE') || !isBlank(value), requiredQuestionMessage],
							//! FIXME TODO "Temporary" rule for 05/01/2020 effective date change
							[
								(value) =>
									!currentCoverages.has('CITE') ||
									(isBefore(parseISO(quote.effectiveDate), parseISO('2020-05-01')) &&
										_.find(sfg_CITE_limit, (c) => value === c.value) !== undefined) ||
									!(newCite && value === 'Default'),
								requiredQuestionMessage,
							],
							//! "Temporary" date checks in this rule. Will need to keep min/max portion
							[
								(value) => !currentCoverages.has('CITE') || (newCite && value >= 3000 && value <= 250000) || !newCite,
								'Limit must be between $3,000 and $250,000',
							],
						],
						covgType: [[(value) => !currentCoverages.has('CITE') || !isBlank(value), requiredQuestionMessage]],
						blanketSubLimit: [
							[
								(value) =>
									!currentCoverages.has('CITE') ||
									!(isBlank(value) && visibility['sfg.coverages.CITE.blanketSubLimit']),
								requiredQuestionMessage,
							],
						],
						blanketLimit: [
							[
								(value) =>
									!currentCoverages.has('CITE') || !isBlank(value) || !visibility['sfg.coverages.CITE.blanketLimit'],
								requiredQuestionMessage,
							],
							[
								(value) =>
									!currentCoverages.has('CITE') ||
									(_.toNumber(values.sfg.coverages.CITE.blanketLimit) >= 3000 &&
										_.toNumber(values.sfg.coverages.CITE.blanketLimit) <= 250000) ||
									!visibility['sfg.coverages.CITE.blanketLimit'],
								'Limit must be greater than or equal to $3,000 and less than or equal to $250,000',
							],
						],
						actualCashValue: [
							[
								(value) =>
									!currentCoverages.has('CITE') ||
									values.sfg.coverages.CITE.covgType === '2' ||
									!(
										isBlank(value) &&
										(visibility['sfg.coverages.CITE.actualCashValue'] ||
											//! Temporary or clause because visibility is not passed in off page
											newCite)
									),
								requiredQuestionMessage,
							],
						],
						nonOwnTools: [
							[
								(value) => !currentCoverages.has('CITE') || value <= 250000,
								'Limit must be less than or equal to $250,000',
							],
							[
								(value) => !currentCoverages.has('CITE') || value !== 0,
								'Non owned tools and equipment must be greater than 0 or left blank if not applicable.',
							],
						],
						employeeTools: [
							[
								(value) => !currentCoverages.has('CITE') || value !== 0,
								'Employee tools must be greater than 0 or left blank if not applicable.',
							],
						],
						scheduleLimit: [
							[
								(value) => value <= 250000,
								'The maximum limit for Contractors Scheduled Tools and Equipment coverage of $250,000 has been exceeded.  Please contact your Underwriter for possible alternative.',
							],
							[
								(value) => !(isBlank(value) && visibility['sfg.coverages.CITE.schedule']),
								'Enter at least one scheduled item below.',
							],
						],
						schedule: map(always(scheduleCITE)),
						// getScheduleRules(values.sfg.coverages.CITE.schedule),
					},
					LLCG: {
						limit: [
							[(value) => !currentCoverages.has('LLCG') || !isBlank(value), requiredQuestionMessage],
							[
								(value) => !currentCoverages.has('LLCG') || value <= 500000,
								'Limit must be less than or equal to $500,000',
							],
						],
					},
					CDDP: {
						numDays: [[(value) => !currentCoverages.has('CDDP') || !isBlank(value), requiredQuestionMessage]],
					},
					CDEC: {
						limit: [[(value) => !currentCoverages.has('CDEC') || !isBlank(value), requiredQuestionMessage]],
					},
					ELDT: {
						limit: [[(value) => !currentCoverages.has('ELDT') || !isBlank(value), requiredQuestionMessage]],
					},
					CDED: {
						coverageType: [[(value) => !currentCoverages.has('CDED') || !isBlank(value), requiredQuestionMessage]],
						limit: [[(value) => !currentCoverages.has('CDED') || !isBlank(value), requiredQuestionMessage]],
					},
					CDEB: {
						limit: [
							[(value) => !currentCoverages.has('CDEB') || !isBlank(value), requiredQuestionMessage],
							[
								(value) => !currentCoverages.has('CDEB') || parseInt(quote.sfg.liabilityLimit) >= parseInt(value),
								`The limit must be less than or equal to the policy liability limit ($${quote.sfg.liabilityLimit})`,
							],
						],
						retroDte: [
							[(value) => isBlank(value) || isValidDate(value), 'You must enter a valid date.'],
							[
								(value) => yearsFromDate(value, quote.effectiveDate) > -5 || isBlank(value),
								"Retroactive Date must be within five years of this quote's effective date.",
							],
						],
					},
					EMDI: {
						limit: [[(value) => !currentCoverages.has('EMDI') || !isBlank(value), requiredQuestionMessage]],
						numEmployees: [[(value) => !currentCoverages.has('EMDI') || !isBlank(value), requiredQuestionMessage]],
						addtlLocations: [
							[
								(value) => (value > 0 && value <= 24) || isBlankZ(value),
								'The number of Additional Locations should be between 1 and 24 or left blank.',
							],
						],
					},
					CDEP: {
						occupancyDesc: [[(value) => !currentCoverages.has('CDEP') || !isBlank(value), requiredQuestionMessage]],
						numEmployees: [
							[(value) => !currentCoverages.has('CDEP') || !isBlank(value), requiredQuestionMessage],
							[
								(value) =>
									// Trigger based on number of employees for accounting and medical class codes
									!(
										currentCoverages.has('CDEP') &&
										((_.intersection(classCodeArray, ['63611', '63621', '63631', '63641', '64011', '64021']).length >
											0 &&
											value > 25) ||
											(_.intersection(classCodeArray, ['63981', '63991']).length > 0 && value > 10))
									),
								'Due to the number of employees, this class is not eligible for Employment Related Practices Liability coverage.  Please remove this coverage to continue with this quote.',
							],
						],
					},
					IDFR: {
						limit: [
							[(value) => !currentCoverages.has('IDFR') || !isBlank(value), requiredQuestionMessage],
							[(value) => !currentCoverages.has('IDFR') || value >= 25000, 'Limit must be $25,000 or greater.'],
						],
					},
					CDAF: {
						limit: [[(value) => !currentCoverages.has('CDAF') || !isBlank(value), requiredQuestionMessage]],
					},
					ICPO: {
						limit: [[(value) => !currentCoverages.has('ICPO') || !isBlank(value), requiredQuestionMessage]],
					},
					CDLQ: {
						exposure: [[(value) => !currentCoverages.has('CDLQ') || !isBlank(value), requiredQuestionMessage]],
					},
					PLPM: {
						grossSales: [[(value) => !currentCoverages.has('PLPM') || !isBlank(value), requiredQuestionMessage]],
					},
					CDPR: {
						number: [
							[(value) => !currentCoverages.has('CDPR') || !isBlank(value), requiredQuestionMessage],
							[(value) => !currentCoverages.has('CDPR') || value < 10000, 'Number must be less than 10,000.'],
						],
					},
					CDSM: {
						aggregate: [[(value) => !currentCoverages.has('CDSM') || !isBlank(value), requiredQuestionMessage]],
					},
					TCLP: {
						limit: [[(value) => !currentCoverages.has('TCLP') || !isBlank(value), requiredQuestionMessage]],
						numEmployees: [[(value) => !currentCoverages.has('TCLP') || !isBlank(value), requiredQuestionMessage]],
					},
					CDVL: {
						limit: [[(value) => !currentCoverages.has('CDVL') || !isBlank(value), requiredQuestionMessage]],
					},
					VETL: {
						exposure: [[(value) => !currentCoverages.has('VETL') || !isBlank(value), requiredQuestionMessage]],
					},
					CDWS: {
						exposure: [
							[(value) => !currentCoverages.has('CDWS') || !isBlank(value), requiredQuestionMessage],
							[(value) => !currentCoverages.has('CDWS') || value <= 3, 'Number must be less than or equal to 3.'],
						],
					},
					CDUM: {
						uninsuredLimit: [
							[(value) => !currentCoverages.has('CDUM') || !isBlank(value), requiredQuestionMessage],
							[
								(value) => !currentCoverages.has('CDUM') || parseInt(quote.sfg.liabilityLimit) >= parseInt(value),
								`The uninsured limit must be less than or equal to the policy liability limit ($${quote.sfg.liabilityLimit})`,
							],
						],
						underinsuredLimit: [
							[
								(value) =>
									!currentCoverages.has('CDUM') ||
									!(visibility['sfg.coverages.CDUM.underinsuredLimit'] && isBlank(value)),
								requiredQuestionMessage,
							],
							[
								(value) =>
									!currentCoverages.has('CDUM') ||
									!visibility['sfg.coverages.CDUM.underinsuredLimit'] ||
									parseInt(quote.sfg.liabilityLimit) >= parseInt(value),
								`The underinsured limit must be less than or equal to the policy liability limit ($${quote.sfg.liabilityLimit})`,
							],
						],
						uninsuredPropertyDamageLimit: [
							[
								(value) =>
									!currentCoverages.has('CDUM') ||
									!(visibility['sfg.coverages.CDUM.uninsuredPropertyDamageLimit'] && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},

					FDCO: {
						limit: [
							[(value) => !currentCoverages.has('FDCO') || !isBlank(value), requiredQuestionMessage],
							[
								(value) => !currentCoverages.has('FDCO') || (value >= 10000 && value <= 1000000),
								'Limit must be between $10,000 and $1,000,000',
							],
						],
						expenses: [
							[(value) => !currentCoverages.has('FDCO') || !isBlank(value), requiredQuestionMessage],
							[
								(value) => !currentCoverages.has('FDCO') || (value >= 3000 && value <= 300000),
								'Limit must be between $3,000 and $300,000',
							],
						],
					},
					TRSM: {
						included: [[(value) => !isBlank(value), requiredQuestionMessage]],
					},
				},
			},
		};
	}

	static referrals(context, values) {
		const cdlqReferrals = [];

		const classCodesList = [...distillBuildings(_.get(context, 'quote.sfg.locations')).classCodes];
		const coverages = getSet(_.get(values, 'sfg.coverages.currentCoverages'));
		const { liquorLiabilityReferClasses } = classCodeListsJson;

		if (coverages.has('CDLQ')) {
			const cdlqStuff = calculateCDLQ(values);
			_.forIn(cdlqStuff, (val, id) => {
				cdlqReferrals.push([(value) => false, val]);
			});
		}

		// valid rule liquor exposure < CDLQRatio * location gross sale (location by location basis)
		const returnObject = {
			section_PLPM: [[(value) => !coverages.has('PLPM'), 'SPC01']],
			section_CDLQ: [
				[
					(value) => !(coverages.has('CDLQ') && _.intersection(classCodesList, liquorLiabilityReferClasses).length > 0),
					'SPC02',
				],
			],
			section_CDDE: [[(value) => !coverages.has('CDDE'), 'SPC03']],
			section_CDDW: [[(value) => !coverages.has('CDDW'), 'SPC04']],
			section_CDSM: [[(value) => !coverages.has('CDSM'), 'SPC09']],
			sfg: {
				coverages: {
					CDLQ: {
						exposure: cdlqReferrals,
					},
					CDCR: {
						limit: [[(value) => !coverages.has('CDCR') || !_.includes(['500000', '1000000'], value), 'SPC10']],
					},
				},
			},
		};
		return returnObject;
	}
	static name() {
		return 'sfgPolicyCoverages';
	}
}
