import { EndorsementLink } from 'components/EndorsementLink';
import { RemoveCoverageButton } from 'components/shared/buttons/RemoveCoverageButton';
import { DatePicker } from 'components/shared/form/DatePicker';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { RadioButton } from 'components/shared/form/RadioButton';
import { ScheduleTable } from 'components/shared/form/ScheduleTable';
import { Select } from 'components/shared/form/Select';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import coveragesListJson from 'data/CoveragesList';
import selectOptionsJson from 'data/SelectOptions';
import { Field } from 'formik';
import _ from 'lodash';
import React from 'react';
import { toast } from 'react-toastify';
import { duplicate } from 'utils/ObjectFunctions';
import { isBlank } from 'utils/StringFunctions';

const {
	sfg_BICO_extPeriodOfIndemnity,
	sfg_BICO_ordinaryPayroll,
	sfg_CDAF_limit,
	sfg_CDBG_deductible,
	sfg_CDCO_limit,
	sfg_CDCR_limit,
	sfg_CDDP_numDays,
	sfg_CDEB_limit,
	sfg_CDEC_limit,
	sfg_CDED_coverageType,
	sfg_CDED_limit,
	sfg_CDEP_occupancyDesc,
	sfg_CDMD_liabilityType,
	sfg_CDSM_aggregate,
	sfg_CDUM_underinsuredLimit,
	sfg_CDUM_underinsuredLimitAR,
	sfg_CDUM_uninsuredLimit,
	sfg_CDUM_uninsuredPropertyDamageLimit,
	sfg_CDVL_limit,
	sfg_CFFT_limit,
	sfg_CITE_blanketSubLimit,
	sfg_CITE_covgType,
	sfg_CITE_limit,
	sfg_CODO_deductible,
	sfg_CODO_limit,
	sfg_EMDI_limit,
	sfg_MOTL_guestProperty,
	sfg_MOTL_safeDepBox,
	sfg_TCLP_limit,
} = selectOptionsJson;
const { sfg_URLs } = coveragesListJson;

function pickCoverage(coverage, predState, visibility, updateFields, formikProps, newCiteOptions) {
	switch (coverage.value) {
		case 'CDCP':
			// numAmendOfCP - IbPMisc1322018
			//          max string length of 4
			return (
				<Field
					name='sfg.coverages.CDCP.numAmendOfCP'
					label='Number of Amendment of Cancellation Provisions'
					component={InputNumber}
					width='tiny'
				/>
			);
		case 'CDBG':
			// deductible - IbPDedAmt322011
			return (
				<Field
					name='sfg.coverages.CDBG.deductible'
					label='Deductible'
					component={RadioButton}
					options={sfg_CDBG_deductible}
				/>
			);
		case 'BICO':
			// extPeriodOfIndemnity - IbPMisc2322019
			// ordinaryPayroll - IbPMisc1322018
			// timePeriod - IbPMisc3322020
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.BICO.extPeriodOfIndemnity'
						label='Extended Period of Indemnity'
						component={Select}
						options={sfg_BICO_extPeriodOfIndemnity}
						optionalSelect
					/>
					<Field
						name='sfg.coverages.BICO.ordinaryPayroll'
						label='Ordinary Payroll'
						component={Select}
						options={sfg_BICO_ordinaryPayroll}
						optionalSelect
					/>
					<Field name='sfg.coverages.BICO.timePeriod' label='Time Period' component={Select} optionalSelect />
				</React.Fragment>
			);
		case 'CFFT':
			// limit - IbPLimit_322014
			// addtlLocations - IbEmpNoLoc_322007
			//          max string length of 5
			// numEmployees -IbEmpNoEE_322006
			//          max string length of 5
			return (
				<React.Fragment>
					<Field name='sfg.coverages.CFFT.limit' label='Limit' component={Select} options={sfg_CFFT_limit} />
					<Field
						name='sfg.coverages.CFFT.addtlLocations'
						label='Additional Locations'
						component={InputNumber}
						width='tiny'
						optional
					/>
					<Field
						name='sfg.coverages.CFFT.numEmployees'
						label='Number of Employees'
						component={InputNumber}
						width='tiny'
					/>
				</React.Fragment>
			);
		case 'CODO':
			// limit - ibPLimit_322014
			// deductible - ibPDedAmt322011
			// baseRate - IbPMisc1_322018
			//          max string length of 5
			// premium - IbPInputPrem_322012
			//          max string length of 9
			// extReportingPremium - IbPMisc2_322019
			//          max string length of 13
			// retroactiveDte - IbMisc1Dt
			// pendOrPriorLitDte - IbMisc2Dt
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.CODO.limit'
						label='Limit'
						component={Select}
						width='small'
						options={sfg_CODO_limit}
					/>
					<Field
						name='sfg.coverages.CODO.deductible'
						label='Deductible'
						component={RadioButton}
						options={sfg_CODO_deductible}
					/>
				</React.Fragment>
			);
		case 'CDCO':
			// limit - IbPLimit_322014
			// exReportingPeriod - IbPMisc1322018
			// annualAggregate - IbPLimit2_322015
			// payroll - IbPMisc3322020
			//          max string length of 10
			// retroDate - IbMisc1Dt
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.CDCO.limit'
						label='Each Claim'
						component={RadioButton}
						options={sfg_CDCO_limit}
						additionalOnChange={updateFields}
					/>
					<Field
						name='sfg.coverages.CDCO.annualAggregate'
						label='Annual Aggregate'
						component={InputNumber}
						type='currency'
						disabled
						width='small'
					/>
					<Field
						name='sfg.coverages.CDCO.payroll'
						label='Payroll'
						component={InputNumber}
						type='currency'
						width='small'
						maxLength='7'
					/>
				</React.Fragment>
			);
		case 'CITE':
			// limit - IbPLimit_322014 - 3000 will be displayed as default but not mapped a value, only mapped if they choose a higher limit
			// covgType - ibTypeCd
			// blanketSubLimit - ibLimit6322043
			//          Dependency: covgType = 1 or 3
			// blanketLimit - IbPLimit2_322015 - Will be defaulted to display 3000 but do not map this value to insurity unless it is increased
			//          Dependency: covgType = 1 or 3
			// nonOwnTools - ibPLimit4322017
			//          max string length of 7
			//          valueRange: 1 - 250000
			// employeeTools - ibLimit5322034
			//          max string length of 5
			//          valueRange: 1 - 99999
			// scheduleLimit - ibPLimit3322016
			//          total from schedule
			const calcLimit = (val) => {
				let scheduleLimit = 0;
				scheduleValues.forEach((entry) => {
					scheduleLimit += entry.limit || 0;
				});
				formikProps.setFieldValue('sfg.coverages.CITE.scheduleLimit', scheduleLimit, false);
			};
			const scheduleFields = [
				{
					title: 'Description',
					name: 'desc',
					width: 'normal',
					maxLength: '40',
				},
				{
					title: 'SerialNumber',
					name: 'serialNo',
					optional: true,
					maxLength: '10',
				},
				{
					title: 'Limit',
					name: 'limit',
					component: InputNumber,
					onBlur: calcLimit,
					type: 'currency',
				},
			];
			const blankRow = {};
			scheduleFields.forEach((field, index) => {
				blankRow[field.name] = '';
			});
			let scheduleValues = _.get(formikProps.values, 'sfg.coverages.CITE.schedule', [blankRow]);
			if (isBlank(scheduleValues)) {
				scheduleValues = [blankRow];
			}
			if (!_.isArray(scheduleValues)) {
				scheduleValues = _.values(scheduleValues);
			}
			scheduleValues.forEach((row, index) => {
				scheduleValues[index] = _.merge(_.clone(blankRow), row);
			});
			return (
				<React.Fragment>
					{visibility['newCite'] ? (
						<Field
							name='sfg.coverages.CITE.limit'
							label='Contractors Installation'
							component={InputNumber}
							type='currency'
							width='small'
							maxLength='7'
						/>
					) : (
						<Field
							name='sfg.coverages.CITE.limit'
							label='Contractors Installation-Property At Each Covered Job Site'
							component={RadioButton}
							options={sfg_CITE_limit}
						/>
					)}
					<Field
						name='sfg.coverages.CITE.covgType'
						label='Contractors Tools and Equipment-Coverage Type'
						component={RadioButton}
						options={sfg_CITE_covgType}
						additionalOnChange={(newValue) => {
							updateFields(newValue);
							if (_.includes(['1', '3'], newValue)) {
								if (!_.get(formikProps.values, 'sfg.coverages.CITE.blanketSubLimit')) {
									formikProps.setFieldValue('sfg.coverages.CITE.blanketSubLimit', '500', false);
								}
								if (!_.get(formikProps.values, 'sfg.coverages.CITE.blanketLimit')) {
									formikProps.setFieldValue('sfg.coverages.CITE.blanketLimit', 3000, false);
								}
							}
						}}
					/>
					<Field
						name='sfg.coverages.CITE.blanketSubLimit'
						label='Blanket Sub-limit'
						component={RadioButton}
						options={
							newCiteOptions
								? sfg_CITE_blanketSubLimit
								: _.filter(duplicate(sfg_CITE_blanketSubLimit), (o) => o.value !== '1000')
						}
						width='small'
						fieldDisplay={visibility['sfg.coverages.CITE.blanketSubLimit']}
					/>
					<Field
						name='sfg.coverages.CITE.blanketLimit'
						label='Blanket Limit'
						component={InputNumber}
						type='currency'
						width='small'
						maxLength='7'
						fieldDisplay={visibility['sfg.coverages.CITE.blanketLimit']}
					/>
					<Field
						name='sfg.coverages.CITE.actualCashValue'
						label='Actual Cash Value Applies'
						component={RadioButton}
						fieldDisplay={visibility['sfg.coverages.CITE.actualCashValue']}
					/>
					<Field
						name='sfg.coverages.CITE.nonOwnTools'
						label='Non Owned Tools and Equipment'
						component={InputNumber}
						optional
						width='small'
						maxLength='7'
					/>
					<Field
						name='sfg.coverages.CITE.employeeTools'
						label={"Employees' Tools"}
						component={InputNumber}
						optional
						width='small'
						maxLength='6'
					/>
					<Field
						name='sfg.coverages.CITE.scheduleLimit'
						label='Schedule Limit'
						component={InputNumber}
						type='currency'
						disabled
						fieldDisplay={visibility['sfg.coverages.CITE.scheduleLimit']}
						width='small'
					/>
					<QuoteContext.Consumer>
						{(context) => (
							<ScheduleTable
								parentName='sfg.coverages.CITE'
								fields={scheduleFields}
								values={isBlank(scheduleValues) ? [blankRow] : scheduleValues}
								addAction={() => {
									scheduleValues.push(blankRow);
									formikProps.setFieldValue('sfg.coverages.CITE.schedule', scheduleValues, false);
								}}
								removeAction={(index) => {
									if (scheduleValues.length > 1) {
										scheduleValues.splice(index, 1);
										formikProps.setFieldValue('sfg.coverages.CITE.schedule', scheduleValues);
										calcLimit();
									} else {
										formikProps.setFieldValue('sfg.coverages.CITE.schedule', [blankRow], false);
										formikProps.setFieldValue('sfg.coverages.CITE.scheduleLimit', 0);
									}
									context.savePageValues(formikProps.values);
								}}
								visible={visibility['sfg.coverages.CITE.schedule']}
							/>
						)}
					</QuoteContext.Consumer>
				</React.Fragment>
			);
		case 'LLCG':
			// limit - IbPLimit_322014
			//          max string length of 11
			//          valueRange: 0 - 500000
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.LLCG.limit'
						label='Limit'
						component={InputNumber}
						type='currency'
						width='small'
						maxLength='7'
					/>
				</React.Fragment>
			);
		case 'CDCR':
			// limit - IbPLimit_322014
			// Cyber1
			// Cyber2 - Cyber2
			// Cyber3 - Cyber3
			// Cyber4 - Cyber4
			// Cyber5 - Cyber5
			// Cyber6 - Cyber6
			// Cyber7 - Cyber7
			// Cyber8 - Cyber8
			// Cyber9 - Cyber9
			// Cyber10 - Cyber10
			return (
				<div className='flexFields'>
					<Field
						name='sfg.coverages.CDCR.limit'
						label='Annual Aggregate Limit'
						component={RadioButton}
						options={sfg_CDCR_limit}
						width='small'
						additionalOnChange={updateFields}
					/>
					<Field
						name='sfg.coverages.CDCR.cyber1'
						label='Has the applicant suffered a breach of personal information in the last 12 months?'
						component={RadioButton}
						width='small'
						fieldDisplay={visibility['sfg.coverages.CDCR.cyber1']}
					/>
					<Field
						name='sfg.coverages.CDCR.cyber2'
						label='Does the applicant conduct background screens on prospective employees?'
						component={RadioButton}
						width='small'
						fieldDisplay={visibility['sfg.coverages.CDCR.cyber2']}
					/>
					<Field
						name='sfg.coverages.CDCR.cyber3'
						label='Does the applicant have document retention/destruction policies in place and posted?'
						component={RadioButton}
						width='small'
						fieldDisplay={visibility['sfg.coverages.CDCR.cyber3']}
					/>
					<Field
						name='sfg.coverages.CDCR.cyber4'
						label='Are computer security measures, e.g. firewall, secured wireless connectivity, virus protection, regularly maintained and updated?'
						component={RadioButton}
						fieldDisplay={visibility['sfg.coverages.CDCR.cyber4']}
						width='small'
					/>
					<Field
						name='sfg.coverages.CDCR.cyber5'
						label='Are employee, customer and other physical records maintained in a secure environment with limited access?'
						component={RadioButton}
						width='small'
						fieldDisplay={visibility['sfg.coverages.CDCR.cyber5']}
					/>
					<Field
						name='sfg.coverages.CDCR.cyber6'
						label='Is a comprehensive Information Security and Privacy Policy in place?'
						component={RadioButton}
						width='small'
						fieldDisplay={visibility['sfg.coverages.CDCR.cyber6']}
					/>
					<Field
						name='sfg.coverages.CDCR.cyber7'
						label='Is regular security training/information provided to all people who have access to personally identifying information, whether in paper or electronic format?'
						component={RadioButton}
						width='small'
						fieldDisplay={visibility['sfg.coverages.CDCR.cyber7']}
					/>
					<Field
						name='sfg.coverages.CDCR.cyber8'
						label='Is anti-virus software installed on all computers and maintained via a central resource?'
						component={RadioButton}
						width='small'
						fieldDisplay={visibility['sfg.coverages.CDCR.cyber8']}
					/>
					<Field
						name='sfg.coverages.CDCR.cyber9'
						label='Are all users issued unique IDs and passwords when connecting to or accessing the internal network?'
						component={RadioButton}
						width='small'
						fieldDisplay={visibility['sfg.coverages.CDCR.cyber9']}
					/>
					<Field
						name='sfg.coverages.CDCR.cyber10'
						label='Are hardcopy files containing personal information (personnel/payroll, tax records) kept in a separate and secure area?'
						component={RadioButton}
						width='small'
						fieldDisplay={visibility['sfg.coverages.CDCR.cyber10']}
					/>
				</div>
			);
		case 'CDDP':
			// numDays - IbPMisc1_322018
			return (
				<Field
					name='sfg.coverages.CDDP.numDays'
					label='Number of Days'
					component={RadioButton}
					options={sfg_CDDP_numDays}
					width='small'
				/>
			);
		case 'CDEC':
			// limit - IbPLimit_322014
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.CDEC.limit'
						label='Limit'
						component={RadioButton}
						options={sfg_CDEC_limit}
						width='small'
					/>
				</React.Fragment>
			);
		case 'ELDT':
			// limit - IbPLimit_322014
			//          max string length of 13
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.ELDT.limit'
						label='Increased Limit'
						component={InputNumber}
						type='currency'
						width='small'
					/>
				</React.Fragment>
			);
		case 'CDED':
			// coverageType - ibPMisc1322018
			// limit - ibPLimit_322014
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.CDED.coverageType'
						label='Coverage Type'
						component={RadioButton}
						options={sfg_CDED_coverageType}
						width='small'
					/>
					<Field
						name='sfg.coverages.CDED.limit'
						label='Limit'
						component={RadioButton}
						options={sfg_CDED_limit}
						width='small'
					/>
				</React.Fragment>
			);
		case 'CDEB':
			// limit - IbPLimit_322014
			// retroDte - IbMisc1Dt
			// extRepotPeriod - IbMisc2Dt
			// extReportPrem - IbMisc5Info
			//          max string length of 10
			// - IbPMisc1_322018
			//          Default in rating to 1000
			// - IbPLimit2_322015
			//          Default in rating to ibPolicyCoverageCDEB_PLimit * 2
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.CDEB.limit'
						label='Limit of Insurance'
						component={RadioButton}
						options={sfg_CDEB_limit}
						width='small'
					/>
					<Field
						name='sfg.coverages.CDEB.retroDte'
						label='Retroactive Date'
						component={DatePicker}
						width='small'
						optional
					/>
				</React.Fragment>
			);
		case 'EMDI':
			// limit - IbPLimit_322014
			// forgeryLimit - IbPLimit2_322015
			// numEmployees - IbEmpNoEE_322006
			//          max string length of 3
			// addtlLocations - IbEmpNoLoc_322007
			// - ibPMisc2322019
			//        Default in rating - if any building, on any location, has 09411 class code, default to 'Y', otherwise, 'N'
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.EMDI.limit'
						label='Limit of Liability'
						component={RadioButton}
						options={sfg_EMDI_limit}
						width='small'
					/>
					<Field
						name='sfg.coverages.EMDI.forgeryLimit'
						label='Forgery Limit'
						component={RadioButton}
						width='small'
						optional
					/>
					<Field
						name='sfg.coverages.EMDI.numEmployees'
						label='Number of Employees'
						component={InputNumber}
						width='tiny'
						maxLength='3'
					/>
					<Field
						name='sfg.coverages.EMDI.addtlLocations'
						label='Additional Locations'
						component={InputNumber}
						width='tiny'
						optional
					/>
				</React.Fragment>
			);
		case 'CDEP':
			// occupancyDesc - IbPMisc3322020
			// limit - IbPLimit_322014
			// deductible - IbPDedAmt322011
			// numEmployees - IbEmpNoEE_322006
			//        valueRange: 1-99999
			// - IbMisc1Dt
			//        Default in rating to policy effective date
			return (
				<div className='flexFields'>
					<Field
						name='sfg.coverages.CDEP.occupancyDesc'
						label='Occupancy Description'
						component={RadioButton}
						options={sfg_CDEP_occupancyDesc}
					/>
					<Field
						name='sfg.coverages.CDEP.limit'
						label='Limit'
						component={InputNumber}
						type='currency'
						width='small'
						disabled
					/>
					<Field
						name='sfg.coverages.CDEP.deductible'
						label='Deductible'
						component={InputNumber}
						type='currency'
						width='small'
						disabled
					/>
					<Field
						name='sfg.coverages.CDEP.numEmployees'
						label='Number of Employees'
						component={InputNumber}
						width='small'
						maxLength='6'
					/>
				</div>
			);
		case 'IDFR':
			// limit - IbPLimit_322014
			//        valueRange: 25000-9999999999
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.IDFR.limit'
						label='Limit'
						component={InputNumber}
						type='currency'
						maxLength='13'
						width='small'
					/>
				</React.Fragment>
			);
		case 'CDHR':
			// limit - IbPLimit322014
			// - IbChargeTypeInd
			//        Default in rating 'N'
			return (
				<React.Fragment>
					<Field name='sfg.coverages.CDHR.limit' label='Limit' component={InputNumber} type='currency' disabled />
				</React.Fragment>
			);
		case 'CDAF':
			// limit - IbPLimit_322014
			return (
				<React.Fragment>
					<Field name='sfg.coverages.CDAF.limit' label='Limit' component={RadioButton} options={sfg_CDAF_limit} />
				</React.Fragment>
			);
		case 'ICPO':
			// limit - IbPLimit_322014
			//        valueRange: 1-9999999999
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.ICPO.limit'
						label='Increased Limit'
						component={InputNumber}
						type='currency'
						maxLength='13'
						width='small'
					/>
				</React.Fragment>
			);
		case 'CDLQ':
			// exposure - ibExposureAmt322026
			//        valueRange: 1-9999999
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.CDLQ.exposure'
						label='Receipts from Liquor Sales'
						component={InputNumber}
						type='currency'
						width='small'
						maxLength='9'
						showCause
					/>
				</React.Fragment>
			);
		case 'MOTL':
			// safeDepBox - IbPLimit_322014
			// guestProperty - IbPLimit2_322015
			// - IbPLimit3_322016
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.MOTL.safeDepBox'
						label='Guest Property in Safe Deposit Boxes Limit'
						component={Select}
						options={sfg_MOTL_safeDepBox}
						optionalSelect
					/>
					<Field
						name='sfg.coverages.MOTL.guestProperty'
						label='Guest Property Limit'
						component={Select}
						options={sfg_MOTL_guestProperty}
						optionalSelect
					/>
				</React.Fragment>
			);
		case 'PLPM':
			// grossSales - IbExposureAmt322026
			// - IbPMisc1322018
			//        Default in rating '1', may not even need to send, Insurity prefills when you do it there
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.PLPM.grossSales'
						label='Annual Pharmacy Gross Sales'
						component={InputNumber}
						type='currency'
						maxLength='10'
					/>
				</React.Fragment>
			);
		case 'PHOT':
			// worldwide - ibTypeCd
			// equipmentLimit - IbPLimit322014
			// - IbPClassCode_322008
			//        Default in rating '71899', may not even need to send, Insurity prefills when you do it there
			return (
				<React.Fragment>
					<Field name='sfg.coverages.PHOT.worldwide' label='Worldwide' component={Select} optionalSelect />
					<Field
						name='sfg.coverages.PHOT.equipmentLimit'
						label='Photographic Equipment Limit'
						component={InputNumber}
						type='currency'
						optional
						maxLength='11'
					/>
				</React.Fragment>
			);
		case 'CDPR':
			// number - ibPMisc1322018
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.CDPR.number'
						label='Number of Primary / Noncontributory'
						component={InputNumber}
						width='tiny'
						maxLength='7'
					/>
				</React.Fragment>
			);
		case 'CDSM':
			// aggregate - IbPLimit_322014
			// premium - IbPInputPrem_322012
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.CDSM.aggregate'
						label='Aggregate'
						component={RadioButton}
						options={sfg_CDSM_aggregate}
					/>
				</React.Fragment>
			);
		case 'TCLP':
			// limit - IbPLimit_322014
			// addtlLocations - IbEmpNoLoc_322007
			// numEmployees - IbEmpNoEE_322006
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.TCLP.limit'
						label='Limit of Liability'
						component={RadioButton}
						options={sfg_TCLP_limit}
					/>
					<Field
						name='sfg.coverages.TCLP.addtlLocations'
						label='Additional Locations'
						component={InputNumber}
						optional
						width='tiny'
						maxLength='6'
					/>
					<Field
						name='sfg.coverages.TCLP.numEmployees'
						label='Number of Employees'
						component={InputNumber}
						width='tiny'
						maxLength='6'
					/>
				</React.Fragment>
			);
		case 'CDVL':
			// limit - IbPLimit_322014
			return (
				<React.Fragment>
					<Field name='sfg.coverages.CDVL.limit' label='Limit' component={RadioButton} options={sfg_CDVL_limit} />
				</React.Fragment>
			);
		case 'VETL':
			// exposure - ibExposureAmt322026
			//        valueRange: 1-9999
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.VETL.exposure'
						label='Number of Veterinarians'
						component={InputNumber}
						width='tiny'
						maxLength='5'
					/>
				</React.Fragment>
			);
		case 'CDWS':
			// exposure - ibPMisc1322018
			//        valueRange: 1-9999
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.CDWS.exposure'
						label='Number of Waiver of Subrogations'
						component={InputNumber}
						width='tiny'
						maxLength='6'
					/>
				</React.Fragment>
			);
		case 'FDCO':
			// limit - IbPLimit322014
			// expenses - IbPLimit2_322015
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.FDCO.limit'
						label='Increased BI/EE Limit'
						component={InputNumber}
						type='currency'
					/>
					<Field
						name='sfg.coverages.FDCO.expenses'
						label='Additional Advertising Expenses'
						component={InputNumber}
						type='currency'
					/>
				</React.Fragment>
			);
		case 'CDMD':
			// liabilityType - IbPMisc2322019
			return (
				<React.Fragment>
					{predState === 'GA' ? (
						<Field
							name='sfg.coverages.CDMD.liabilityType'
							label='Liability Type'
							component={RadioButton}
							options={sfg_CDMD_liabilityType}
						/>
					) : (
						'Added to policy.'
					)}
				</React.Fragment>
			);
		case 'CDUM':
			// uninsuredLimit - IbPLimit_322014
			// underinsuredLimit - IbPLimit3322016 (for AR map uninsuredLimit to this)
			// for AR map uninsuredLimit to both IbPLimit_322014 IbPLimit3322016
			return (
				<React.Fragment>
					<Field
						name='sfg.coverages.CDUM.uninsuredLimit'
						label={predState === 'IL' ? 'Uninsured/Underinsured' : 'Uninsured Limit'}
						component={RadioButton}
						options={sfg_CDUM_uninsuredLimit}
					/>
					<Field
						name='sfg.coverages.CDUM.underinsuredLimit'
						label='Underinsured Limit'
						component={RadioButton}
						options={sfg_CDUM_underinsuredLimit}
						fieldDisplay={visibility['sfg.coverages.CDUM.underinsuredLimit']}
					/>
					<Field
						name='sfg.coverages.CDUM.underinsuredLimitAR'
						label='Underinsured Limit AR'
						component={RadioButton}
						options={sfg_CDUM_underinsuredLimitAR}
						fieldDisplay={visibility['sfg.coverages.CDUM.underinsuredLimitAR']}
						disabled
					/>
					<Field
						name='sfg.coverages.CDUM.uninsuredPropertyDamageLimit'
						label='Uninsured Property Damage Limit'
						component={RadioButton}
						options={sfg_CDUM_uninsuredPropertyDamageLimit}
						fieldDisplay={visibility['sfg.coverages.CDUM.uninsuredPropertyDamageLimit']}
					/>
				</React.Fragment>
			);
		case 'TRSM':
			// included - ibChargeTypeInd
			// cannot be removed
			return (
				<React.Fragment>
					<Field name='sfg.coverages.TRSM.included' label='Is Terrorism Coverage Included?' component={RadioButton} />
				</React.Fragment>
			);
		case 'CDSC':
		case 'CDPN':
		case 'CDPL':
		case 'CDPC':
		case 'CDOH':
		case 'NOWN':
		case 'HIRE':
		case 'CDFD':
		case 'CDPO':
		case 'CDPA':
		case 'CDEI':
		case 'CDDS':
		case 'CDDX':
		case 'CDDW':
		case 'CDDE':
		case 'CDCM':
		case 'CDDC':
		case 'CDAA':
		case 'CDAC':
		case 'CDIY':
		case 'CDBB':
		case 'CDBS':
		case 'BRLP':
		case 'CDBP':
			return <React.Fragment>Added to policy.</React.Fragment>;
		default:
			return null;
	}
	// CDBB
	// need rule, only available for barbershop risks
	// maybe should only show up in the list for them??
	// CDPA
	// need rule only available for Attorneys
	// maybe should only show up in the list for them??
	// CDFD
	// need rule only available for Funeral Homes
	// maybe should only show up in the list for them??
}

export const SFGPolicyCoverage = ({
	coverage,
	predState,
	isAdded,
	removeCoverage,
	visibility,
	updateFields,
	hasAutoOccupancy,
	hasContractorOccupancy,
	hasHireNonOwn,
	isNewCoverage,
	newCiteOptions,
	formikProps,
	resetNewCoverage,
}) => {
	const { touched, errors, setFormikState } = formikProps;
	let urlSummary = '';
	let urlPDF = '';

	if (sfg_URLs[coverage.value]) {
		urlSummary = sfg_URLs[coverage.value][0].urlSum;
		urlPDF = sfg_URLs[coverage.value][0].urlPDF;
	}

	if (isAdded) {
		const coverageErrors = _.get(errors, `sfg.coverages.${coverage.value}`, {});
		const groupErrors = _.findKey(errors, (error, key) => _.startsWith(key, `group_${coverage.value}`));

		return (
			<QuoteContext.Consumer>
				{(context) => (
					<PageSection
						title={coverage.text}
						className='coverageSection'
						name={`section_${coverage.value}`}
						errors={errors}
						showCause
						isNewCoverage={isNewCoverage}
						cancelAction={() => {
							resetNewCoverage();
							removeCoverage(coverage.value, true);
							formikProps.validateForm(formikProps.values);
						}}
						saveAction={() => {
							if (isBlank(coverageErrors) && isBlank(groupErrors)) {
								toast.success(`${coverage.text} Added!`);
								resetNewCoverage();
							} else {
								_.forIn(coverageErrors, (fieldError, fieldName) => {
									if (fieldName === 'schedule') {
										_.forIn(fieldError, (rowErrors, rowIndex) =>
											_.forIn(rowErrors, (scheduleFieldError, scheduleFieldName) =>
												_.set(
													touched,
													`sfg.coverages.${coverage.value}.schedule.${rowIndex}.${scheduleFieldName}`,
													true,
												),
											),
										);
									} else {
										_.set(touched, `sfg.coverages.${coverage.value}.${fieldName}`, true);
									}
								});
								setFormikState({ focusCoverage: coverage.value }); // this forces re-render
							}
							formikProps.validateForm(formikProps.values);
							context.savePageValues(formikProps.values);
						}}
					>
						{!isBlank(urlSummary) ? <EndorsementLink summary={urlSummary} pdf={urlPDF} /> : ''}

						{isNewCoverage ||
						(predState === 'GA' && coverage.value === 'CDMD') ||
						(hasAutoOccupancy && coverage.value === 'HIRE') ||
						(hasAutoOccupancy && coverage.value === 'NOWN') ||
						(hasAutoOccupancy && predState === 'IL' && coverage.value === 'CDUM') ||
						(hasContractorOccupancy && coverage.value === 'CITE') ||
						(predState === 'IL' && hasHireNonOwn && coverage.value === 'CDUM') ||
						coverage.value === 'TRSM' ? (
							''
						) : (
							<RemoveCoverageButton
								onClick={(event) => {
									removeCoverage(coverage.value);
								}}
							/>
						)}
						<div className='coverageFields'>
							{pickCoverage(coverage, predState, visibility, updateFields, formikProps, newCiteOptions)}
						</div>
					</PageSection>
				)}
			</QuoteContext.Consumer>
		);
	}
	return null;
};
export const covgMaps = {
	CDCPmap: (coverages) => ({
		numAmendOfCP: _.get(coverages, 'CDCP.numAmendOfCP', ''),
	}),
	CDBGmap: (coverages) => ({
		deductible: _.get(coverages, 'CDBG.deductible', ''),
	}),
	BICOmap: (coverages) => ({
		extPeriodOfIndemnity: _.get(coverages, 'BICO.extPeriodOfIndemnity', ''),
		ordinaryPayroll: _.get(coverages, 'BICO.ordinaryPayroll', ''),
		timePeriod: _.get(coverages, 'BICO.timePeriod', ''),
	}),
	CFFTmap: (coverages) => ({
		limit: _.get(coverages, 'CFFT.limit', ''),
		addtlLocations: _.get(coverages, 'CFFT.addtlLocations', ''),
		numEmployees: _.get(coverages, 'CFFT.numEmployees', ''),
	}),
	CODOmap: (coverages) => ({
		limit: _.get(coverages, 'CODO.limit', ''),
		deductible: _.get(coverages, 'CODO.deductible', ''),
	}),
	CDCOmap: (coverages) => ({
		limit: _.get(coverages, 'CDCO.limit', ''),
		annualAggregate: _.get(coverages, 'CDCO.annualAggregate', ''),
		payroll: _.get(coverages, 'CDCO.payroll', ''),
	}),
	CITEmap: (coverages, visibility) => {
		let limit = _.get(coverages, 'CITE.limit');
		if (visibility['newCite']) {
			limit = limit === 'Default' || !limit ? 3000 : limit;
		} else {
			const validValue = _.find(sfg_CITE_limit, (c) => _.get(coverages, 'CITE.limit') === c.value);
			// If effective date is changed back to before 05/01/2020 and current limit is not in option list, reset to blank and make agent choose again
			if (!(isBlank(limit) || validValue)) {
				limit = '';
			} else {
				limit = limit || 'Default';
			}
		}
		return {
			limit,
			covgType: _.get(coverages, 'CITE.covgType', '1'),
			blanketSubLimit: _.get(coverages, 'CITE.blanketSubLimit', '500'),
			blanketLimit: _.get(coverages, 'CITE.blanketLimit', 3000),
			actualCashValue: _.get(coverages, 'CITE.actualCashValue', ''),
			nonOwnTools: _.get(coverages, 'CITE.nonOwnTools', ''),
			employeeTools: _.get(coverages, 'CITE.employeeTools', ''),
			scheduleLimit: _.get(coverages, 'CITE.scheduleLimit', ''),
			schedule: _.get(coverages, 'CITE.schedule', []),
		};
	},
	LLCGmap: (coverages) => ({
		limit: _.get(coverages, 'LLCG.limit', ''),
	}),
	CDCRmap: (coverages) => ({
		limit: _.get(coverages, 'CDCR.limit', '50000'),
		cyber1: _.get(coverages, 'CDCR.cyber1', ''),
		cyber2: _.get(coverages, 'CDCR.cyber2', ''),
		cyber3: _.get(coverages, 'CDCR.cyber3', ''),
		cyber4: _.get(coverages, 'CDCR.cyber4', ''),
		cyber5: _.get(coverages, 'CDCR.cyber5', ''),
		cyber6: _.get(coverages, 'CDCR.cyber6', ''),
		cyber7: _.get(coverages, 'CDCR.cyber7', ''),
		cyber8: _.get(coverages, 'CDCR.cyber8', ''),
		cyber9: _.get(coverages, 'CDCR.cyber9', ''),
		cyber10: _.get(coverages, 'CDCR.cyber10', ''),
	}),
	CDDPmap: (coverages) => ({
		numDays: _.get(coverages, 'CDDP.numDays', ''),
	}),
	CDECmap: (coverages) => ({
		limit: _.get(coverages, 'CDEC.limit', ''),
	}),
	ELDTmap: (coverages) => ({
		limit: _.get(coverages, 'ELDT.limit', ''),
	}),
	CDEDmap: (coverages) => ({
		coverageType: _.get(coverages, 'CDED.coverageType', ''),
		limit: _.get(coverages, 'CDED.limit', ''),
	}),
	CDEBmap: (coverages) => ({
		limit: _.get(coverages, 'CDEB.limit', ''),
		retroDte: _.get(coverages, 'CDEB.retroDte', ''),
	}),
	EMDImap: (coverages) => ({
		limit: _.get(coverages, 'EMDI.limit', ''),
		forgeryLimit: _.get(coverages, 'EMDI.forgeryLimit', ''),
		numEmployees: _.get(coverages, 'EMDI.numEmployees', ''),
		addtlLocations: _.get(coverages, 'EMDI.addtlLocations', ''),
	}),
	CDEPmap: (coverages, state) => ({
		occupancyDesc: _.get(coverages, 'CDEP.occupancyDesc', ''),
		limit: _.get(coverages, 'CDEP.limit', state === 'AR' ? '50000' : '100000'),
		deductible: _.get(coverages, 'CDEP.deductible', '2500'),
		numEmployees: _.get(coverages, 'CDEP.numEmployees', ''),
	}),
	IDFRmap: (coverages) => ({
		limit: _.get(coverages, 'IDFR.limit', ''),
	}),
	CDHRmap: (coverages) => ({
		limit: _.get(coverages, 'CDHR.limit', '10000'),
	}),
	CDAFmap: (coverages) => ({
		limit: _.get(coverages, 'CDAF.limit', ''),
	}),
	ICPOmap: (coverages) => ({
		limit: _.get(coverages, 'ICPO.limit', ''),
	}),
	CDLQmap: (coverages) => ({
		exposure: _.get(coverages, 'CDLQ.exposure', ''),
	}),
	MOTLmap: (coverages) => ({
		safeDepBox: _.get(coverages, 'MOTL.safeDepBox', ''),
		guestProperty: _.get(coverages, 'MOTL.guestProperty', ''),
	}),
	PLPMmap: (coverages) => ({
		grossSales: _.get(coverages, 'PLPM.grossSales', ''),
	}),
	PHOTmap: (coverages) => ({
		worldwide: _.get(coverages, 'PHOT.worldwide', ''),
		equipmentLimit: _.get(coverages, 'PHOT.equipmentLimit', ''),
	}),
	CDPRmap: (coverages) => ({
		number: _.get(coverages, 'CDPR.number', ''),
	}),
	CDSMmap: (coverages) => ({
		aggregate: _.get(coverages, 'CDSM.aggregate', ''),
	}),
	TCLPmap: (coverages) => ({
		limit: _.get(coverages, 'TCLP.limit', ''),
		addtlLocations: _.get(coverages, 'TCLP.addtlLocations', ''),
		numEmployees: _.get(coverages, 'TCLP.numEmployees', ''),
	}),
	CDVLmap: (coverages) => ({
		limit: _.get(coverages, 'CDVL.limit', ''),
	}),
	VETLmap: (coverages) => ({
		exposure: _.get(coverages, 'VETL.exposure', ''),
	}),
	CDWSmap: (coverages) => ({
		exposure: _.get(coverages, 'CDWS.exposure', ''),
	}),
	CMCDmap: (coverages) => ({
		liabilityType: _.get(coverages, 'CMCD.liabilityType', '2'),
	}),
	CDUMmap: (coverages) => ({
		uninsuredLimit: _.get(coverages, 'CDUM.uninsuredLimit', ''),
		underinsuredLimit: _.get(coverages, 'CDUM.underinsuredLimit', ''),
		underinsuredLimitAR: _.get(coverages, 'CDUM.underinsuredLimitAR', ''),
		uninsuredPropertyDamageLimit: _.get(coverages, 'CDUM.uninsuredPropertyDamageLimit'),
	}),
	FDCOmap: (coverages) => ({
		limit: _.get(coverages, 'FDCO.limit', ''),
		expenses: _.get(coverages, 'FDCO.expenses', ''),
	}),
	CDMDmap: (coverages) => ({
		liabilityType: _.get(coverages, 'CDMD.liabilityType', '2'),
	}),
	TRSMmap: (coverages) => ({
		included: _.get(coverages, 'TRSM.included', 'Y'),
	}),
};
