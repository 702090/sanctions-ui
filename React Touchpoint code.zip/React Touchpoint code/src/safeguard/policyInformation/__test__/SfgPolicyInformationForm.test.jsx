import '@testing-library/jest-dom';
import { act, cleanup, fireEvent, render, screen, waitFor, getAllByRole } from '@testing-library/react';
import React from 'react';

import SafeguardPolicyInformationForm from '../SfgPolicyInformationForm';
/* eslint-disable testing-library/no-unnecessary-act */

describe('Policy Information testing', () => {
	let testUseEffect;
	const mockUseEffect = () => {
		testUseEffect.mockImplementationOnce(() => {});
	};
	let component;
	beforeEach(() => {
		// eslint-disable-next-line testing-library/no-render-in-setup
		component = render(<SafeguardPolicyInformationForm handleSubmit={jest.fn()} handleCancel={jest.fn()} />);
		testUseEffect = jest.spyOn(React, 'useEffect');
		mockUseEffect();
	});

	afterEach(() => {
		jest.clearAllMocks();

		cleanup;
	});
	afterAll(() => {
		jest.clearAllMocks();
	});
	function getBusinessType() {
		return screen.getByTestId('insured');
	}
	function getSubcontractingWork() {
		return screen.queryByText('Percentage of Subcontracting Work');
	}

	describe('Unit Test-Safeguard-Business Information', () => {
		test('render Business Information component', () => {
			const { asFragment } = component;
			expect(asFragment()).toMatchSnapshot();
		});
		test('Business Information: business type field should be visible', () => {
			const businessType = getBusinessType();
			expect(businessType).toBeInTheDocument();
		});
		test('All dropdown options should be visible', async () => {
			const selectBusinessType = getBusinessType();
			await act(async () => {
				fireEvent.click(selectBusinessType);
			});
			const selectOptions = getAllByRole(selectBusinessType, 'option');
			expect(selectOptions[0].innerHTML.includes('Auto Service Risk')).toBeTruthy();
			expect(selectOptions[1].innerHTML.includes('Contractors (not eligible in Mississippi or Texas)')).toBeTruthy();
			expect(selectOptions[2].innerHTML.includes('Mercantile')).toBeTruthy();
			expect(selectOptions[3].innerHTML.includes('Office')).toBeTruthy();
			expect(selectOptions[4].innerHTML.includes('Service/Processing')).toBeTruthy();
			expect(selectOptions[5].innerHTML.includes('Restaurants – Not Fast Food')).toBeTruthy();
			expect(selectOptions[6].innerHTML.includes('Restaurants – Fast Food')).toBeTruthy();
			expect(selectOptions[7].innerHTML.includes('Apartment')).toBeTruthy();
			expect(selectOptions[8].innerHTML.includes('Condo - Apartment')).toBeTruthy();
			expect(selectOptions[9].innerHTML.includes('Condo - Office')).toBeTruthy();
		});

		test('Selecting "contractoes(not elible in Mississippi or Texas) will cause "percentage of Subcontracting work" field to be visible.', async () => {
			const selectBusinessType = getBusinessType();
			await act(async () => {
				fireEvent.click(selectBusinessType);
			});
			const selectOptions = getAllByRole(selectBusinessType, 'option');
			await act(async () => {
				fireEvent.click(selectOptions[1]);
			});
			const dropdown = getBusinessType();
			const display = dropdown.children[0];
			expect(display).toHaveTextContent('Contractors (not eligible in Mississippi or Texas)');
			const subContractingWork = getSubcontractingWork();
			await waitFor(() => {
				expect(subContractingWork).toBeInTheDocument();
			});
		});
		test('Selecting an option not "Contractors(not eligible in Mississippi or Texas) cause "percentage of subcontracting work) to not be visible.', async () => {
			const selectBusinessType = getBusinessType();
			await act(async () => {
				fireEvent.click(selectBusinessType);
			});
			const selectOptions = getAllByRole(selectBusinessType, 'option');
			await act(async () => {
				fireEvent.click(selectOptions[0]);
			});
			const dropdown = getBusinessType();
			const display = dropdown.children[0];
			expect(display).toHaveTextContent('Auto Service Risk');
			const subContractingWork = getSubcontractingWork();
			await waitFor(() => {
				expect(subContractingWork).not.toBeInTheDocument();
			});
		});
	});
});
