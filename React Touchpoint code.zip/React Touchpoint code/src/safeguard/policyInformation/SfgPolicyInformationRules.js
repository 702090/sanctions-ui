import { getFieldDisplayArray, requiredQuestionMessage } from 'data/FieldVisibility';
import { getVisibility } from 'utils/ScreenFunctions';
import { isBlank, isBlankZ } from 'utils/StringFunctions';

export default class SfgPolicyInformationRules {
	static requiredStructure = {
		sfg: { businessType: '', percentSubcontracting: '' },
	};

	static rules(quote, values, visibility) {
		if (!visibility) {
			visibility = getVisibility(getFieldDisplayArray('sfgPolicyInformation'), quote, values);
		}

		return {
			sfg: {
				businessType: [[(value) => !isBlank(value), 'Safeguard Business Type is required.']],
				percentSubcontracting: [
					[(value) => !visibility['sfg.percentSubcontracting'] || !isBlankZ(value), requiredQuestionMessage],
					[
						(value) => value >= 0 && value <= 10,
						'This risk is not eligible for Safeguard. Please contact your underwriter for possible placement with one of our other products.',
					],
				],
			},
		};
	}

	static referrals(quote, values) {
		return {};
	}

	static name() {
		return 'sfgPolicyInformation';
	}
}
