import InputNumber from 'components/shared/form/inputs/InputNumber';
import { RadioButton } from 'components/shared/form/RadioButton';
import { Select } from 'components/shared/form/Select';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import selectOptionsJson from 'data/SelectOptions';
import { Field, Form, Formik } from 'formik';
import React, { useContext, useEffect } from 'react';
import SfgPolicyInformationRules from 'safeguard/policyInformation/SfgPolicyInformationRules';
import { askSubcontracting } from 'utils/FieldDisplay';
import { cleanValues, getVisibility, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { validateNew } from 'validation/Validate';

const SafeguardPolicyInformationForm = (props) => {
	const context = useContext(QuoteContext);
	const { quote } = context;
	const { sfg_businessType, sfg_liabilityLimit, sfg_medPayLimit } = selectOptionsJson;

	let dirty = false;
	let formProps;
	let visibility = {};

	useEffect(() => {
		// If the form is not empty, trigger validation
		runRulesOnLoad(formProps, formProps.initialValues, ['liabilityLimit', 'productAggLimit', 'medPayLimit']);

		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	return (
		<Formik
			render={(formikProps) => {
				formProps = formikProps;
				dirty = formikProps.dirty;
				visibility = getVisibility(getFieldDisplayArray('sfgPolicyInformation'), quote, formikProps.values);
				cleanValues(formikProps.values, visibility);
				return (
					<Form id='screen'>
						<PageSection title='Business Information'>
							<Field name='sfg.businessType' label='Business Type' component={Select} options={sfg_businessType} />
							<Field
								name='sfg.percentSubcontracting'
								label='Percentage of Subcontracting Work'
								component={InputNumber}
								type='percent'
								width='tiny'
								fieldDisplay={visibility['sfg.percentSubcontracting']}
							/>
							<Field
								name='sfg.liabilityLimit'
								label='Liability Limit'
								component={RadioButton}
								options={sfg_liabilityLimit}
								additionalOnChange={(value, setFieldValue) => {
									setFieldValue('sfg.productAggLimit', value * 2, false);
								}}
							/>
							<Field
								name='sfg.productAggLimit'
								label='Products / Completed Operations Aggregate'
								component={InputNumber}
								type='currency'
								disabled
							/>
							<Field
								name='sfg.medPayLimit'
								label='Medical Expenses Limit'
								component={RadioButton}
								options={sfg_medPayLimit}
							/>
						</PageSection>
						<NavigationButtons
							formikProps={formikProps}
							back
							location={props.location}
							history={props.history}
							rulesObject={SfgPolicyInformationRules}
						/>
					</Form>
				);
			}}
			initialValues={{
				sfg: isBlank(context.quote.sfg)
					? {
							businessType: '',
							percentSubcontracting: '',
							liabilityLimit: '1000000',
							productAggLimit: '2000000',
							medPayLimit: '5000',
					  }
					: context.quote.sfg,
			}}
			onSubmit={(values, formikActions) => {
				cleanValues(values, visibility);
				context.onSubmit(values, dirty, false, false, props, SfgPolicyInformationRules);
			}}
			validate={(values) => {
				const validResults = validateNew(context.quote, values, SfgPolicyInformationRules);
				logPageErrors(validResults, formProps.touched, 'sfg');
				return validResults;
			}}
		/>
	);
};

export default SafeguardPolicyInformationForm;
