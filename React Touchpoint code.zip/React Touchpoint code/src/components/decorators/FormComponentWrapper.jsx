import { WarningMessage } from 'components/shared/messages/WarningMessage';
import QuoteContext from 'context/quoteContext';
import referralMessagesJson from 'data/ReferralMessages';
import _ from 'lodash';
import React from 'react';
import { Popup } from 'semantic-ui-react';
import { isEmployee } from 'utils/BusinessFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import { buildReferralMessage } from 'utils/ScreenFunctions';

const withDisplay =
	(PassedComponent) =>
	// eslint-disable-next-line react/display-name
	({
		suffix, // for input labeled
		optional, // boolean
		optionalSelect, //boolean for deselect option
		options,
		field, // from Formik
		form: { touched, dirty, errors, values, setFieldValue, setFieldTouched }, // from Formik
		label,
		subLabel,
		width, // tiny, small, normal(or blank), large, massive(or ginormous)
		className,
		fieldDisplay, // for dynamic visibility
		additionalOnChange, // for changing fields other than this one
		additionalOnBlur,
		ignoreTouched,
		showCause,
		horizontal,
		labelHoverMessage,
		labelPrefillHoverMessage,
		hidden,
		...props
	}) =>
		(
			<QuoteContext.Consumer>
				{(context) => {
					if (!ignoreTouched) {
						ignoreTouched = false;
					}
					const { messages } = referralMessagesJson;
					const referrals = _.get(context, 'quote.referrals', {});
					const parentId = values.locationId ? `${values.locationId}.${values.id}` : values.id;
					let fieldReferrals = [];
					if (referrals) {
						// if referrals exist on the quote, try to get the referrals for this field (parentId is there if there is a locationId)
						fieldReferrals = _.get(referrals, field.name + (parentId ? `.${parentId}` : ''), []);
					}

					const fieldError = _.get(errors, field.name, '');
					const fieldTouched = _.get(touched, field.name, false);

					const isError = (fieldTouched || ignoreTouched) && errors && fieldError !== '';

					let newOptions = duplicate(options);
					if (optionalSelect && newOptions) {
						newOptions.unshift({ text: '- Select -', value: '' });
					}

					switch (width) {
						case 'tiny':
							width = 'wTiny';
							break;
						case 'small':
							width = 'wSmall';
							break;
						case 'medium':
							width = 'wMedium';
							break;
						case 'compact':
							width = 'wCompact';
							break;
						case 'large':
							width = 'wLarge';
							break;
						case 'ginormous': // for Dean
						case 'massive':
							width = 'wMassive';
							break;
						case 'normal':
						default:
							width = 'wNormal';
					}
					if (className) {
						className = `${className} ${isError ? ' error' : ''}`;
					} else {
						className = isError ? ' error' : '';
					}

					if (horizontal) {
						className += ' horizontal';
					}

					if (fieldDisplay === undefined || fieldDisplay) {
						if (props.value) {
							field.value = props.value;
						}
						return (
							<div className={`field ${className} ${width}`}>
								<label className={className} htmlFor={field.name}>
									{label}
									{subLabel && <span className='subLabel'>{subLabel}</span>}
									{(optional || optionalSelect) && <span className='optional'>(Optional)</span>}
									{labelHoverMessage && (
										<Popup
											trigger={
												<div className='hoverMessage'>
													<i className='fas fa-question-circle' />
												</div>
											}
											content={labelHoverMessage}
											position='top center'
											basic
										/>
									)}
									{labelPrefillHoverMessage && isEmployee() && (
										<Popup
											trigger={
												<div className='hoverMessage'>
													<i className='fas fa-digging' />
												</div>
											}
											className='linebreak'
											content={labelPrefillHoverMessage}
											position='top left'
											flowing
											basic
										/>
									)}
								</label>
								<PassedComponent
									className={`${className} ${width}`}
									setFieldValue={setFieldValue}
									setFieldTouched={setFieldTouched}
									formValues={values}
									dirty={dirty}
									options={newOptions}
									{...props}
									{...field}
									additionalOnChange={additionalOnChange ? additionalOnChange : () => null}
									additionalOnBlur={additionalOnBlur ? additionalOnBlur : () => null}
								/>
								{suffix}
								<div className='error'>{isError && fieldError}</div>
								<div className='referrals'>
									{!fieldError && fieldReferrals && (fieldTouched || ignoreTouched) && _.isArray(fieldReferrals)
										? _.sortBy(fieldReferrals, (referral) => {
												let sort = '';
												if (referral.length > 5) {
													sort += referral.slice(5, 7);
												}
												if (referral.length > 7) {
													sort += `.${referral.slice(7, 9)}`;
												}
												return sort;
										  }).map((referral) => {
												const target = buildReferralMessage(referral);
												return (
													<WarningMessage
														key={referral}
														message={
															(showCause ? target : '') +
															messages[
																referral.slice(0, 5)
															] /* slice to get first 5 digits which is the message code, the other digits are for the total list */
														}
														fieldDisplay={fieldDisplay || true}
													/>
												);
										  })
										: ''}
								</div>
							</div>
						);
					}
					return null;
				}}
			</QuoteContext.Consumer>
		);

export default withDisplay;
