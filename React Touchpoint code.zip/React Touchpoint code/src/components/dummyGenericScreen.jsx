import { InputText } from 'components/shared/form/inputs/InputText';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import { Field, Form, Formik } from 'formik';
import React, { Component } from 'react';
import { cleanValues, getVisibility, logPageErrors } from 'utils/ScreenFunctions';
import { validate } from 'validation/Validate';

export default class DummyGenericForm extends Component {
	static contextType = QuoteContext;

	visibility = {};
	dirty = false;
	formProps;

	render() {
		const { quote } = this.context;
		return (
			<Formik
				render={(formikProps) => {
					formProps = formikProps;
					this.dirty = formikProps.dirty;
					this.visibility = getVisibility(getFieldDisplayArray('workComp'), quote, formikProps.values);
					cleanValues(formikProps.values, this.visibility);
					return (
						<Form id='screen'>
							<PageSection title='Dummy Section'>
								<Field
									name='dummyField'
									label='Dummy Field'
									component={InputText}
									fieldDisplay={this.visibility.dummyField}
								/>
							</PageSection>
							<NavigationButtons
								formikProps={formikProps}
								back
								location={this.props.location}
								history={this.props.history}
							/>
						</Form>
					);
				}}
				initialValues={{}}
				onSubmit={(values, formikActions) => {
					cleanValues(values, visibility);
					return this.context.onSubmit(values, this.dirty, false, false, this.props);
				}}
				validate={(values) => {
					const validResults = validate(values, {}, {});
					logPageErrors(validResults, formProps.touched, 'all');
					return validResults;
				}}
			/>
		);
	}
}
