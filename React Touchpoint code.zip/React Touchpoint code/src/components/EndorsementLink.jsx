import React from 'react';

export const EndorsementLink = ({ summary, pdf }) => (
	<div>
		<a href={summary} target='_blank' rel='noopener noreferrer' className='far fa-file-pdf fa-lg'>
			&nbsp;Summary
		</a>
		&nbsp;&nbsp;|&nbsp;&nbsp;
		<a href={pdf} target='_blank' rel='noopener noreferrer' className='far fa-file-pdf fa-lg'>
			&nbsp;Form
		</a>
		<br />
		<br />
	</div>
);
