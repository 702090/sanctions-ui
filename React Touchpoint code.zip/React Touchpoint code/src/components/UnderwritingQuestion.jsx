import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputText } from 'components/shared/form/inputs/InputText';
import { RadioButton } from 'components/shared/form/RadioButton';
import undwQuestionsJson from 'data/BuildingQuestions';
import { Field } from 'formik';
import parse from 'html-react-parser';
import React from 'react';

export const UnderwritingQuestion = ({
	qid,
	dependentQuestions,
	updateVisibilities,
	visibility,
	questionIn,
	tooltip,
}) => {
	let fieldDisplay = visibility[qid];
	const question = questionIn || undwQuestionsJson.questions[qid];
	if (question.da) {
		fieldDisplay = fieldDisplay && visibility[question.da.split('_')[0]];
	}
	const questionText = parse(question.qt);
	let field = '';
	const name = `${questionIn ? 'policyQuestions' : 'questions'}.${qid}`;
	switch (question.qy) {
		case 'D': // dropdown
			field = (
				<Field
					name={name}
					label={questionText}
					component={RadioButton}
					options={question.o}
					fieldDisplay={fieldDisplay}
					additionalOnChange={(v, sfv, fv) => updateVisibilities(qid, v)}
					ignoreTouched
					labelPrefillHoverMessage={tooltip}
				/>
			);
			break;
		case 'I': // integer
			field = (
				<Field
					name={name}
					label={question.qt}
					component={InputNumber}
					fieldDisplay={fieldDisplay}
					width='small'
					ignoreTouched
					prefillHoverMessage={tooltip}
				/>
			);
			break;
		case 'P': // percentage
			field = (
				<Field
					name={name}
					label={question.qt}
					component={InputNumber}
					type='percent'
					fieldDisplay={fieldDisplay}
					width='tiny'
					ignoreTouched
					prefillHoverMessage={tooltip}
				/>
			);
			break;
		case 'C': // currency
			field = (
				<Field
					name={name}
					label={question.qt}
					component={InputNumber}
					type='currency'
					fieldDisplay={fieldDisplay}
					width='small'
					ignoreTouched
					prefillHoverMessage={tooltip}
				/>
			);
			break;
		case 'S': // statement, no question
			field = fieldDisplay ? <p>{question.qt}</p> : null;
			break;
		case 'T': // Text
			field = (
				<Field
					name={name}
					label={question.qt}
					component={InputText}
					fieldDisplay={fieldDisplay}
					ignoreTouched
					prefillHoverMessage={tooltip}
				/>
			);
			break;
		default:
			field = null;
	}
	return <div className='undQuestion'>{field}</div>;
};
