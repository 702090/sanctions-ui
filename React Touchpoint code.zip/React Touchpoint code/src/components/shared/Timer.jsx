import React, { Component } from 'react';

class Timer extends Component {
	state = {};
	speedId = {};

	start = () => {
		this.startTime = new Date().getTime();

		this.speedId = setInterval(() => {
			this.setState({
				timeTook: (Math.floor((new Date().getTime() - this.startTime) / 100) / 10).toFixed(1),
			});
		}, 50);
	};

	stop = () => {
		this.setState({
			timeTook: (Math.floor((new Date().getTime() - this.startTime) / 100) / 10).toFixed(1),
		});
		clearInterval(this.speedId);
	};

	render() {
		return (
			<div>
				<h3 id='timer' className='sectionHeader'>
					{this.state.timeTook}
				</h3>
			</div>
		);
	}
}

export default Timer;
