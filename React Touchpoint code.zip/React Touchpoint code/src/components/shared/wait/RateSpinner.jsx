import React, { Component } from 'react';
import NumberFormat from 'react-number-format';
import _ from 'lodash';

class RateSpinner extends Component {
	state = { totalRate: 0, running: true };

	timerId = {};

	componentDidMount() {
		this.min = this.props.min || 1000;
		this.max = this.props.max || 10000;

		this.timerId = setInterval(() => {
			const totalRate = _.random(this.min, this.max - 1, false);
			this.setState({ totalRate });
		}, 20);
		const totalRate = _.random(this.min, this.max - 1, false);
		this.setState({ totalRate });
	}

	end = (totalRate) => {
		const rateChars = _.reverse(_.split(`${totalRate}`, ''));
		const endChars = '';
		this.countDown(this.min / 10, this.max / 10, rateChars, endChars, 0, 0, totalRate, rateChars.length - 4);

		clearInterval(this.timerId);
	};

	countDown = (min, max, list, endChars, index, counter, actualTotalRate, overshot) => {
		if (index >= list.length) {
			this.setState({ totalRate: _.toNumber(actualTotalRate), running: false });
		} else {
			if (min < 1) {
				min = 1;
			}

			this.setState({
				totalRate: _.toNumber(_.random(min, max - 1, false) + list[index] + endChars),
			});

			if (min < max) {
				if (counter >= 5) {
					if (overshot > 0) {
						overshot--;
					} else {
						min /= 10;
						max /= 10;
					}
					endChars = `${list[index]}${endChars}`;
					index++;
					counter = 0;
				} else {
					counter++;
				}
				setTimeout(() => this.countDown(min, max, list, endChars, index, counter, actualTotalRate, overshot), 20);
			} else {
				this.setState({
					totalRate: _.toNumber(actualTotalRate),
					running: false,
				});
			}
		}
	};

	render() {
		return (
			<React.Fragment>
				<NumberFormat
					className='odometer'
					value={this.state.totalRate}
					displayType='text'
					thousandSeparator
					prefix='$'
				/>
				{this.state.running ? <div className='odometer-block'>Rating...</div> : ''}
			</React.Fragment>
		);
	}
}

export default RateSpinner;
