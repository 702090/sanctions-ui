import React from 'react';

export const HLoader = ({ label }) => (
	<div className='hLoadingWrapper'>
		<div className='hLoading'>
			<div />
			<div />
			<div />
			<div />
			<div />
		</div>
		<div className='hLoadingLabel'>{label}</div>
	</div>
);
