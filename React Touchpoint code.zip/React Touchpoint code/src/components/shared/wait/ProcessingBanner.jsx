import QuoteContext from 'context/quoteContext';
import React, { useContext, useEffect, useState } from 'react';
import FlipLoader from './FlipLoader';
import _ from 'lodash';

const ProcessingBanner = () => {
	const context = useContext(QuoteContext);
	const [active, setActive] = useState(false);

	useEffect(() => {
		setActive(_.get(context, 'rate.gettingProposal', false));
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [context.rate.gettingProposal]);

	if (active) {
		let proposalType;
		switch (context.rate.gettingProposal) {
			case '1':
				proposalType = 'detailed';
				break;
			case '2':
				proposalType = 'summary';
				break;
			case '3':
				proposalType = 'summary (w/o marketing)';
				break;
			default:
		}
		return (
			<div id='working'>
				Getting the {proposalType} proposal.
				<br /> The document will open in a new tab when ready.
				<FlipLoader />
			</div>
		);
	} else {
		return null;
	}
};

export default ProcessingBanner;
