import React from 'react';

export const DashLoader = () => (
	<div className='dashLoader'>
		<div className='dash uno' />
		<div className='dash dos' />
		<div className='dash tres' />
		<div className='dash cuatro' />
		<div className='dash cinco' />
	</div>
);
