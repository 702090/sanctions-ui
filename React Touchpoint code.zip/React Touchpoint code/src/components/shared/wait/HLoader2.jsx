import React from 'react';

export const HLoader2 = ({ label }) => (
	<div className='hLoadingWrapper2'>
		<div className='a' style={{ '--n': 8 }}>
			<div className='dot' style={{ '--i': 0 }} />
			<div className='dot' style={{ '--i': 1 }} />
			<div className='dot' style={{ '--i': 2 }} />
			<div className='dot' style={{ '--i': 3 }} />
			<div className='dot' style={{ '--i': 4 }} />
			<div className='dot' style={{ '--i': 5 }} />
			<div className='dot' style={{ '--i': 6 }} />
			<div className='dot' style={{ '--i': 7 }} />
		</div>
		<div className='hLoadingLabel2'>{label}</div>
	</div>
);
