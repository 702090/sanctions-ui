import React from 'react';

export const Spinner = ({ label, size }) => (
	<div className={`spinner ${size || ''}`}>
		<div id='preloader'>
			<div id='loader' />
			<div id='loaderLabel'>{label || 'Please Wait...'}</div>
		</div>
	</div>
);
