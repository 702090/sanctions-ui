import React from 'react';

const FlipLoader = (props) => {
	return (
		<div className='flipLoader'>
			<div />
			<div />
			<div />
			<div />
			<div />
		</div>
	);
};

export default FlipLoader;
