import _ from 'lodash';
import React from 'react';
import { Table } from 'semantic-ui-react/';

class DraggableTableRow extends React.Component {
	onDragStart = (ev, idx) => {
		_.set(ev, 'ev.dataTransfer.index', idx);
	};

	onDragOver = (ev) => {
		ev.preventDefault();
	};

	onDrop = (ev, a) => {
		if (ev.ev) {
			ev = ev.ev;
		}
		let b = _.get(ev, 'dataTransfer.index');
		this.props.action(Number(a), Number(b));
	};

	render() {
		let { idx, className } = this.props;
		className = (this.props.draggable ? 'draggable ' : '') + className;
		return this.props.draggable ? (
			<Table.Row
				draggable
				className={className}
				onDragStart={(e) => this.onDragStart(e, idx)}
				onDragOver={(e) => this.onDragOver(e)}
				onDrop={(e) => {
					this.onDrop(e, idx);
				}}
			>
				{this.props.children}
			</Table.Row>
		) : (
			<Table.Row>{this.props.children}</Table.Row>
		);
	}
}

export default DraggableTableRow;
