import React from 'react';
import { Popup } from 'semantic-ui-react';
import { SimpleButton } from 'components/shared/buttons/SimpleButton';

export const IconButton = ({ label, alt, iconName, size, ...props }) => {
	return (
		<Popup
			trigger={
				<SimpleButton
					{...props}
					id={label}
					content={
						<React.Fragment>
							<i className={iconName + ' ' + (size || 'large')} />
							&nbsp;
							{label}
						</React.Fragment>
					}
				/>
			}
			content={alt}
			position='bottom center'
		/>
	);
};
