import { IconButton } from 'components/shared/buttons/IconButton';
import React from 'react';
import { SimpleButton } from 'components/shared/buttons/SimpleButton';

export const ModeButton = ({ openClick, closeClick, mode, type }) => {
	switch (type) {
		case 'copy':
			return (
				<div className='modeButtonWrapper'>
					<IconButton
						className='copyModeButton'
						onClick={openClick}
						iconName='fal fa-copy'
						label='Copy'
						alt='Click to start copying Buildings.'
						title='Click to start copying Buildings.'
					/>
					<SimpleButton className={`exitCopyModeButton ${mode}`} onClick={closeClick} content='Done Copying' />
				</div>
			);
		case 'delete':
			return (
				<div className='modeButtonWrapper'>
					<IconButton
						className='deleteModeButton'
						onClick={openClick}
						iconName='fal fa-trash-alt'
						label='Delete'
						alt='Click to begin deleting Locations or Buildings.'
						title='Click to begin deleting Locations or Buildings.'
					/>
					<SimpleButton className={`exitDeleteModeButton ${mode}`} onClick={closeClick} content='Done Deleting' />
				</div>
			);
		default:
			break;
	}
};
