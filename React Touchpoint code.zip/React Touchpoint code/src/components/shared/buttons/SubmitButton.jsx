import React from 'react';
import { Button } from 'semantic-ui-react';

export const SubmitButton = ({ error, content, onClick, disabled, datatestId }) => (
	<Button
		type='submit'
		primary
		content={content}
		id={content}
		onClick={onClick}
		className={error ? 'error' : ''}
		disabled={disabled}
		data-testid={datatestId}
	/>
);

export default SubmitButton;
