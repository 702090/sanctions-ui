import React from 'react';
import { Button } from 'semantic-ui-react';

export const SimpleButton = ({ onClick, ...props }) => (
	<Button
		type='button'
		{...props}
		onClick={() => {
			onClick();
			return false; // this keeps the button from submitting the page
		}}
	/>
);
