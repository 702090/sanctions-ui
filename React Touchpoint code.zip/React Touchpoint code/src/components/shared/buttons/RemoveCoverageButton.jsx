import React from 'react';
import { Icon } from 'semantic-ui-react';

export const RemoveCoverageButton = ({ onClick }) => (
	<div className='delete deleteButton' onClick={onClick}>
		<Icon name='close' size='large' />
		Remove
	</div>
);
