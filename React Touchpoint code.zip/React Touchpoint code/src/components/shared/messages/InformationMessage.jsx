import React from 'react';
import { Message } from 'semantic-ui-react';

export const InformationMessage = ({ message, fieldDisplay, url }) => {
	if (fieldDisplay) {
		return (
			<Message attached='bottom' color='blue'>
				<i className='fas fa-info-circle' />
				&nbsp;&nbsp;
				{message}
				{url && (
					<a href={url.href} target='_blank' rel='noopener noreferrer' className={url.className}>
						{url.label}
					</a>
				)}
			</Message>
		);
	}
	return null;
};
