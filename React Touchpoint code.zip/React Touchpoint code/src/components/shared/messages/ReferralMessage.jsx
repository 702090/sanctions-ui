import React from 'react';

export const ReferralMessage = ({ target, message }) => {
	if (target !== '') {
		target += ':';
	}
	return (
		<li>
			<span className='referralTarget'>{target}&nbsp;</span>
			{message}
		</li>
	);
};
