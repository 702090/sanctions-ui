import React from 'react';
import { Message } from 'semantic-ui-react';

export const WarningMessage = ({ message, fieldDisplay }) => {
	if (fieldDisplay) {
		return (
			<Message warning attached='bottom' color='yellow'>
				<i className='fas fa-exclamation-triangle' />
				&nbsp;&nbsp;
				{message}
			</Message>
		);
	}
	return null;
};
