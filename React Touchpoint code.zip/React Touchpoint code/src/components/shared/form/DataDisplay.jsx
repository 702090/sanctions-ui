import withDisplay from 'components/decorators/FormComponentWrapper';
import React from 'react';
import NumberFormat from 'react-number-format';
import { Popup } from 'semantic-ui-react';
import { isEmployee } from 'utils/BusinessFunctions';

export const DataDisplay = withDisplay((props) => {
	let displayText = props.value;

	if (props.options) {
		props.options.forEach((option) => {
			if (option.value === props.value) {
				displayText = option.text;
			}
		});
	}

	let component;
	switch (props.type) {
		case 'currency':
			component = <NumberFormat value={props.value} displayType='text' thousandSeparator prefix='$' />;
			break;
		case 'link':
			component = (
				<div>
					<a href={props.url} target='_blank' rel='noopener noreferrer'>
						{displayText}
					</a>
				</div>
			);
			break;
		default:
			component = (
				<span>
					{props.prefix ? props.prefix : ''} {displayText}&nbsp;
					{props.suffix ? props.suffix : ''}
				</span>
			);
	}

	return (
		<div>
			{component}
			{props.prefillHoverMessage && isEmployee() && (
				<Popup
					trigger={
						<div className='hoverMessage'>
							<i className='fas fa-digging' />
						</div>
					}
					className='linebreak'
					content={props.prefillHoverMessage}
					position='top left'
					flowing
					basic
				/>
			)}
		</div>
	);
});
