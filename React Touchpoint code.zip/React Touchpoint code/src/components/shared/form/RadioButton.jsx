import withDisplay from 'components/decorators/FormComponentWrapper';
import _ from 'lodash';
import React from 'react';
import { Radio } from 'semantic-ui-react';

export const RadioButton = withDisplay(
	({
		value,
		onChange,
		options,
		className,
		dirty,
		formValues,
		additionalOnChange,
		additionalOnBlur,
		setFieldValue,
		setFieldTouched,
		multiColumn,
		ignoreSingle,
		...props
	}) => {
		const columns = (1 / multiColumn) * 100;
		if (!options) {
			options = [
				{ text: 'Yes', value: 'Y' },
				{ text: 'No', value: 'N' },
			];
		}
		return (
			<div className={`${className} radioOptions${multiColumn ? ' multiColumn' : ''}`}>
				{_.map(options, (option, idx) => (
					<div
						key={option.text}
						className='radioOption'
						style={{ width: `${columns}%` }}
						id={`radio_${props.name}_${option.value}`}
					>
						<Radio
							className={`${props.name}_${idx}`}
							id={`${props.name}_${option.value}`}
							checked={value === option.value || (options.length === 1 && !ignoreSingle)}
							{...props}
							label={option.text}
							onChange={(e, data) => {
								additionalOnChange(option.value, setFieldValue, formValues);
								setFieldValue(props.name, option.value);
							}}
						/>
					</div>
				))}
			</div>
		);
	},
);
