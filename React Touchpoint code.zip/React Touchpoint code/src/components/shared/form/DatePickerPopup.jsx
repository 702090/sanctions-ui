import React, { Component } from 'react';
import DayPicker from 'react-day-picker';
import 'react-day-picker/lib/style.css';
import { Icon, Popup } from 'semantic-ui-react';
import { getYearMonth, toDate } from 'utils/DateFunctions';

class DatePicker extends Component {
	constructor() {
		super();
		this.state = {
			isOpen: false,
		}; // state to control the state of popup
	}

	handleOpen = () => {
		this.setState({ isOpen: true });
	};

	handleClose = () => {
		this.setState({ isOpen: false });
	};
	modifiers = {
		highlighted: new Date(2018, 12, 12),
	};

	render() {
		return (
			<Popup
				trigger={<Icon className='calendarIcon' name='calendar alternate outline' size='large' circular />}
				on='click'
				open={this.state.isOpen}
				onOpen={this.handleOpen}
				onClose={this.handleClose}
				content={
					<DayPicker
						onDayClick={(date) => {
							this.props.selectDate(this.props.setFieldValue, date, this.props.name, this.props.touched);
							this.handleClose();
						}}
						initialMonth={getYearMonth(this.props.value)}
						selectedDays={[toDate(this.props.value)]}
					/>
				}
				position='bottom right'
			/>
		);
	}
}

export default DatePicker;
