import withDisplay from 'components/decorators/FormComponentWrapper';
import React from 'react';
import { Checkbox } from 'semantic-ui-react';

export const RadioToggle = withDisplay(
	({
		value,
		name,
		options,
		dirty,
		formValues,
		additionalOnChange,
		additionalOnBlur,
		setFieldValue,
		setFieldTouched,
		toggle,
		...props
	}) => (
		<Checkbox
			toggle={toggle}
			checked={value}
			{...props}
			name={name}
			id={name}
			onChange={(e) => {
				additionalOnChange(e);
				setFieldValue(name, !value);
			}}
		/>
	),
);
