import withDisplay from 'components/decorators/FormComponentWrapper';
import React from 'react';
import Geosuggest from 'react-geosuggest';

export const InputCompanyName = withDisplay(
	({
		options,
		dirty,
		formValues,
		additionalOnChange,
		additionalOnBlur,
		setFieldValue,
		setFieldTouched,
		onBlur,
		value,
		...props
	}) => (
		<Geosuggest
			country='us'
			{...props}
			id={props.name}
			initialValue={value}
			inputClassName={props.className}
			onBlur={(e) => {
				setFieldTouched(props.name, true, false);
				onBlur(e);
			}}
			onChange={(e) => {
				setFieldTouched(props.name, true, false);
				additionalOnChange(e, setFieldValue);
			}}
			onSuggestSelect={(suggestions) => {
				setFieldTouched(props.name, true, false);
				additionalOnChange(suggestions, setFieldValue);
			}}
		/>
	),
);
