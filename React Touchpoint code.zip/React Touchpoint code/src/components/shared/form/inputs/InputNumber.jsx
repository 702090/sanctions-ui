import withDisplay from 'components/decorators/FormComponentWrapper';
import React from 'react';
import NumberFormat from 'react-number-format';
import { Popup } from 'semantic-ui-react';
import { isEmployee } from 'utils/BusinessFunctions';

const InputNumber = withDisplay(
	({
		className,
		options,
		dirty,
		formValues,
		onChange,
		onBlur,
		additionalOnChange,
		additionalOnBlur,
		setFieldValue,
		setFieldTouched,
		type,
		hoverMessage,
		decimalScale,
		ignoreCommas,
		prefillHoverMessage,
		...props
	}) => {
		let inputAttachment;
		let suffix = false;
		let prefix = false;
		switch (type) {
			case 'currency':
				prefix = true;
				className += ' left icon';
				inputAttachment = <i aria-hidden='true' className='dollar icon' />;
				break;
			case 'sqft':
				suffix = true;
				className += ' right labeled';
				inputAttachment = <div className='ui basic label label'>sqft</div>;
				break;
			case 'percent':
				suffix = true;
				className += ' right labeled';
				inputAttachment = <div className='ui basic label label'>%</div>;
				break;
			default:
				inputAttachment = '';
		}

		let floatValue = props.value;
		return (
			<div className={`ui input${className}`}>
				{prefix && inputAttachment}
				<NumberFormat
					{...props}
					id={props.name}
					thousandSeparator={ignoreCommas ? null : true}
					allowNegative={false}
					decimalScale={decimalScale ? decimalScale : 0}
					onValueChange={(val) => {
						if (val.value === '') {
							floatValue = undefined;
						} else {
							floatValue = val.floatValue;
						}
						setFieldTouched(props.name);
						setFieldValue(props.name, val.floatValue);
						additionalOnChange && additionalOnChange(floatValue, setFieldValue);
					}}
					onBlur={(val) => {
						additionalOnBlur(floatValue);
						setFieldTouched(props.name);
					}}
				/>
				{suffix && inputAttachment}
				{hoverMessage && (
					<Popup
						trigger={
							<div className='hoverMessage'>
								<i className='fas fa-question-circle' />
							</div>
						}
						content={hoverMessage}
						position='top center'
						basic
					/>
				)}
				{prefillHoverMessage && isEmployee() && (
					<Popup
						trigger={
							<div className='hoverMessage'>
								<i className='fas fa-digging' />
							</div>
						}
						className='linebreak'
						content={prefillHoverMessage}
						position='top left'
						flowing
						basic
					/>
				)}
			</div>
		);
	},
);

export default InputNumber;
