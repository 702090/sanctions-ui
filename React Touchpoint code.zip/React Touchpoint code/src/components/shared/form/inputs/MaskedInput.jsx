import withDisplay from 'components/decorators/FormComponentWrapper';
import React from 'react';
import InputMask from 'react-input-mask';
import { Input } from 'semantic-ui-react';

export const MaskedInput = withDisplay(
	({
		options,
		dirty,
		formValues,
		onChange,
		additionalOnChange,
		onBlur,
		additionalOnBlur,
		setFieldValue,
		setFieldTouched,
		...props
	}) => (
		<Input
			{...props}
			children={
				<InputMask
					{...props}
					id={props.name}
					onChange={(e) => {
						additionalOnChange();
						onChange(e);
					}}
					onBlur={(e) => {
						additionalOnBlur(e);
						onBlur(e);
					}}
				/>
			}
		/>
	),
);
