import withDisplay from 'components/decorators/FormComponentWrapper';
import React from 'react';
import { Popup, TextArea } from 'semantic-ui-react';
import { isEmployee } from 'utils/BusinessFunctions';
import { cleanSpecialCharacters } from 'utils/StringFunctions';

export const InputTextArea = withDisplay(
	({
		options,
		dirty,
		formValues,
		onChange,
		onBlur,
		additionalOnChange,
		additionalOnBlur,
		setFieldValue,
		setFieldTouched,
		prefillHoverMessage,
		...props
	}) => (
		<React.Fragment>
			<TextArea
				{...props}
				id={props.name}
				onChange={(e) => {
					additionalOnChange();
					onChange(e);
				}}
				onBlur={(e) => {
					additionalOnBlur(e);
					cleanSpecialCharacters(e, setFieldValue, props.name);
					onBlur(e);
				}}
			/>
			{prefillHoverMessage && isEmployee() && (
				<Popup
					trigger={
						<div className='hoverMessage'>
							<i className='fas fa-digging' />
						</div>
					}
					className='linebreak'
					content={prefillHoverMessage}
					position='top left'
					flowing
					basic
				/>
			)}
		</React.Fragment>
	),
);
