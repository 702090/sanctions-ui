import { RadioButton } from 'components/shared/form/RadioButton';
import _ from 'lodash';
import * as po_box from 'po-box';
import { geocodeAddress, getkentuckyTax, parseAddress, validateAddress } from 'services/addressService';
import { isBlank } from 'utils/StringFunctions';

export function setAddressValues(addressObject, cleanedAddress, validated, setFieldValue, addressName) {
	const city = cleanedAddress.City || '';
	addressObject.city = city;

	const state = cleanedAddress.StateProvince || '';
	addressObject.state = state;

	const streetNumber = cleanedAddress.HouseNumber || '';
	addressObject.streetNumber = streetNumber;

	const zip = cleanedAddress.PostalCode || '';
	addressObject.zip = zip;

	addressObject.county = cleanedAddress.USCountyName || '';

	let streetName = '';
	if (addressObject.poBox) {
		streetName = cleanedAddress.AddressLine1;
	} else if (addressObject.ruralRoute) {
		streetName = _.startsWith(cleanedAddress.AddressLine1.toLowerCase(), 'rr')
			? cleanedAddress.AddressLine1
			: `RR ${cleanedAddress.AddressLine1}`;
	} else {
		streetName = cleanedAddress.StreetName || '';
		if (validated) {
			if (cleanedAddress.LeadingDirectional) {
				streetName = `${cleanedAddress.LeadingDirectional} ${streetName}`;
			}
			if (cleanedAddress.StreetSuffix) {
				streetName += ` ${cleanedAddress.StreetSuffix}`;
			}
			if (cleanedAddress.TrailingDirectional) {
				streetName += ` ${cleanedAddress.TrailingDirectional}`;
			}
		}
	}
	addressObject.streetName = streetName;

	let unit = '';
	if (cleanedAddress.ApartmentLabel && !addressObject.ruralRoute) {
		unit = `${cleanedAddress.ApartmentLabel} ${cleanedAddress.ApartmentNumber}`;
		addressObject.unit = unit;
	}

	const fullAddress = `${streetNumber} ${streetName}${unit === '' ? '' : ` ${unit}`} ${city} ${state} ${zip}`.trim();

	addressObject.fullAddress = fullAddress;
	addressObject.validated = validated;
	setFieldValue(addressName, addressObject, true);
}

export async function callAddressValidation(address, modal, addressName, formikProps, props, context) {
	context.updateServiceStatus('addressValidation', true);
	if (address && address.fullAddress && !isBlank(address.fullAddress)) {
		let returnValue = await validateAddress(address); // call out to Pitney Bowes via webservice
		returnValue = returnValue.replace('undefined', ''); // TODO: Figure out how to get rid of the Undefined before this
		returnValue = JSON.parse(returnValue);
		let validated = false;
		const firstResult = returnValue.output_port[0];

		const statusCode = firstResult['Status.Code'];

		if (statusCode) {
			const statusDescription = firstResult['Status.Description'];

			switch (statusCode) {
				case 'UnableToValidate':
					console.info('Unable To Validate Address');

					const parsedAddress = await parseAddress(address.fullAddress);

					if (_.get(parsedAddress, 'addressParts.zipCode', '') === '' && firstResult['PostalCode.Input'] === '') {
						firstResult.PostalCode = '00000';
					} else {
						firstResult.AddressLine1 = _.get(parsedAddress, 'addressParts.addressLine1', '');
						firstResult.City = _.get(parsedAddress, 'addressParts.city', '');
						firstResult.StateProvince = _.get(parsedAddress, 'addressParts.state', '');
						firstResult.PostalCode = _.get(parsedAddress, 'addressParts.zipCode', '');
					}
					break;
				case 'MultipleMatchesFound':
					console.info('Multiple Address Matches Found');

					let addressOptions = [];
					if (returnValue.output_port) {
						addressOptions = returnValue.output_port.map((v, index) => ({
							value: index,
							text: `${v.AddressLine1} ${v.City}, ${v.StateProvince} ${v.PostalCode}`,
						}));
					}
					modal.current.handleOpen(
						{
							field: {
								name: 'addressOptions',
								label: 'Select An Address',
								component: RadioButton,
								options: addressOptions,
								width: 'massive',
							},
						},
						(v) => {
							formikProps.setFieldValue(`${addressName}.fullAddress`, addressOptions[v].text, false);
							formikProps.setFieldValue(`${addressName}.validated`, true, false);
							formikProps.setFieldValue(`${addressName}.validationFailedMessage`, ''); // The last value set needs to run validation
						},
					);
					break;
				default:
					// TODO: have something here that will let us know what codes this has fallen through to
					validated = true;
					break;
			}
			if (statusDescription) {
				_.set(address, 'validationFailedMessage', statusDescription);
			}
		} else {
			validated = true;
		}

		if (
			_.startsWith(address.fullAddress.toLowerCase(), 'p') &&
			// eslint-disable-next-line import/namespace
			po_box.pobox.containsPoBox(address.fullAddress)
		) {
			address.poBox = true;
		} else {
			address.poBox = false;
		}

		const ruralRouteRegex = /^R.? ?R/i;
		if (address.fullAddress && ruralRouteRegex.test(address.fullAddress)) {
			address.ruralRoute = true;
		} else {
			address.ruralRoute = false;
		}

		setAddressValues(address, firstResult, validated, formikProps.setFieldValue, addressName);
		if (props) {
			callGeocode(addressName, address, formikProps.setFieldValue);
			props.getProtectionClassCodes(address, true, formikProps.setFieldValue);
			props.getCounties(address, true, formikProps.setFieldValue);
		}

		if (validated && address.state === 'KY') {
			callKentuckyTax(addressName, address, formikProps.setFieldValue);
		}
	} else {
		formikProps.setFieldValue(addressName.fullAddress, '', false);
		formikProps.setFieldValue(addressName.validated, false);
		formikProps.validateForm(formikProps.values);
	}

	context.updateServiceStatus('addressValidation', false);
}

export async function callGeocode(addressName, addressObject, setFieldValue) {
	if (addressObject.fullAddress && !isBlank(addressObject.fullAddress)) {
		let returnValue = await geocodeAddress(addressObject);
		if (!_.isEmpty(returnValue)) {
			returnValue = returnValue.replace('undefined', ''); // TODO: Figure out how to get rid of the Undefined before this
			returnValue = JSON.parse(returnValue);

			const firstResult = returnValue.output_port[0];

			if (firstResult.Latitude) {
				_.set(addressObject, 'latitude', firstResult.Latitude);
				_.set(addressObject, 'longitude', firstResult.Longitude);

				setFieldValue(`${addressName}.latitude`, firstResult.Latitude);
				setFieldValue(`${addressName}.longitude`, firstResult.Longitude);
			}
		}
	}
}

export async function callKentuckyTax(addressName, addressObject, setFieldValue) {
	let taxDistrict = 9999; // Default to No Tax District Address
	let returnValue = await getkentuckyTax(addressObject);

	const premiumTaxArray = returnValue.PremiumTax.PremiumTax;

	let continueLoop = true;
	premiumTaxArray.forEach((element) => {
		if (continueLoop) {
			if (_.get(element, 'TaxCode', '-').indexOf('-') < 0) {
				taxDistrict = element.TaxCode;
			}
			if (!isBlank(_.get(element, 'TerritoryType', '')) && _.get(element, 'TerritoryType', '').indexOf('City') > -1) {
				taxDistrict = element.TaxCode;
				continueLoop = false;
			}
		}
	});

	addressObject.kentuckyTaxDistrict = taxDistrict;
	setFieldValue(`${addressName}.kentuckyTaxDistrict`, taxDistrict);
}
