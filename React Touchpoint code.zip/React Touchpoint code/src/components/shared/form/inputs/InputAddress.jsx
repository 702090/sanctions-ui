import withDisplay from 'components/decorators/FormComponentWrapper';
import { callAddressValidation } from 'components/shared/form/inputs/Addresses';
import QuoteContext from 'context/quoteContext';
import _ from 'lodash';
import React from 'react';
import Geosuggest from 'react-geosuggest';
import { getSTPData } from 'utils/BusinessFunctions';

export const InputAddress = withDisplay(
	({
		options,
		dirty,
		formValues,
		additionalOnChange,
		additionalOnBlur,
		setFieldValue,
		setFieldTouched,
		value,
		skipValidation,
		formikProps,
		geocode,
		...props
	}) => (
		<QuoteContext.Consumer>
			{(context) => (
				<Geosuggest
					country='us'
					{...props}
					initialValue={value}
					inputClassName={props.className}
					id={props.name}
					onBlur={async (e) => {
						// Address Validation
						setFieldTouched(props.name, true, false);
						if (!skipValidation) {
							if (dirty && !_.get(formValues, props.addressName).city) {
								await callAddressValidation(
									_.get(formValues, props.addressName),
									context.optionModal,
									props.addressName,
									formikProps,
									geocode ? props : false,
									context,
								);
								if (geocode) {
									getSTPData(context, formValues.addressL, formikProps);
								}
							}
						}
					}}
					onChange={(e) => {
						additionalOnChange(e, props.addressName, setFieldValue);
					}}
					onSuggestSelect={async (suggestion) => {
						const address = additionalOnChange(suggestion, props.addressName, setFieldValue);
						await callAddressValidation(
							address,
							context.optionModal,
							props.addressName,
							formikProps,
							geocode ? props : false,
							context,
						);
						if (geocode) {
							setFieldValue('protectionClass', '', false);
							getSTPData(context, address, formikProps);
						}
					}}
				/>
			)}
		</QuoteContext.Consumer>
	),
);
