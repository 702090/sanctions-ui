// eslint-disable-next-line no-unused-vars
function preventChars(event) {
	let { key } = event;

	if (event.type === 'paste') {
		key = event.clipboardData.getData('text/plain');
	}

	const regex = /[0-9]|\./;
	if (!regex.test(key)) {
		event.returnValue = false;
		if (event.preventDefault) event.preventDefault();
		return false;
	}
	return true;
}
