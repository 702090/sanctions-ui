import { InputAddress } from 'components/shared/form/inputs/InputAddress';
import { RadioButton } from 'components/shared/form/RadioButton';
import QuoteContext from 'context/quoteContext';
import { Field } from 'formik';
import _ from 'lodash';
import React, { Component } from 'react';
import { addressExists, getAllAddresses, getLocationAddresses } from 'utils/BusinessFunctions';
import { parseAddress } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { v4 as uuidv4 } from 'uuid';

export default class AddressPicker extends Component {
	static contextType = QuoteContext;

	state = {};

	addressOptions = [];

	UNSAFE_componentWillMount() {
		if (this.props.sfgOnly) {
			this.addressOptions = getLocationAddresses(
				this.context.quote.addresses,
				false,
				_.get(this.context, 'quote.sfg.locations', {}),
				this.props.sfgOnly,
			);
		} else {
			this.addressOptions = getAllAddresses(this.context.quote.addresses, this.props.state);
			this.addressOptions.push({
				value: 'New',
				text: 'I need to add a new address',
			});
		}
	}

	addressChange = (id, sfv, fv, checkbox, formikProps, additionalOnChange) => {
		if (id === 'New') {
			const { quote } = this.context;
			this.context.entryModal.current.handleOpen(
				{
					field: {
						label: this.props.addLabel,
						component: InputAddress,
						name: 'entryField.fullAddress',
						width: 'massive',
						addressName: 'entryField',
						additionalOnChange: parseAddress,
					},

					rules: (values) => ({
						entryField: {
							fullAddress: [
								[
									(value) => {
										return _.get(values, 'entryField.state', '') === this.props.state || !this.props.state;
									},
									'Address must be located in the state being selected.',
								],
								[(value) => _.get(values, 'entryField.zip', '') !== '00000', 'This address must include a zipcode.'],
								[
									(value) => !isBlank(_.get(values, 'entryField.streetNumber', '')),
									'Please make sure you have entered a street number.',
								],
								[
									(value) => !isBlank(_.get(values, 'entryField.streetName', '')),
									'Please make sure you have entered a street name.',
								],
								[(value) => _.get(values, 'entryField.validated'), 'Invalid Address'],
							],
						},
					}),
					structure: {},
				},
				(v) => {
					if (v) {
						const checkAddressId = addressExists(quote.addresses, v.fullAddress);
						if (checkAddressId) {
							sfv(this.props.name, checkAddressId, false);
						} else {
							id = uuidv4();
							_.set(quote, `addresses.${id}`, v);
							this.addressOptions.unshift({
								value: id,
								text: v.fullAddress,
							});

							if (checkbox) {
								const addressList = fv[this.props.name];
								addressList.push(id);
								sfv(this.props.name, addressList, false);
							} else {
								sfv(this.props.name, id, false);
							}
							this.context.updateQuote(quote, this.props);
						}
					} else {
						sfv(this.props.name, _.get(quote, this.props.name, ''), false);
					}
					additionalOnChange(id, sfv);
					formikProps && formikProps.validateForm(this.props.formikProps.values);
				},
			);
		}
	};

	render() {
		let additionalOnChange = this.props.additionalOnChange;
		if (!this.props.additionalOnChange) {
			additionalOnChange = () => {};
		}

		return (
			<Field
				name={this.props.name}
				label={this.props.label}
				component={this.props.component || RadioButton}
				options={this.addressOptions}
				additionalOnChange={(v, sfv, fv) => {
					additionalOnChange(v, sfv);
					this.addressChange(v, sfv, fv, this.props.checkbox, this.props.formikProps, additionalOnChange);
				}}
				ignoreSingle
			/>
		);
	}
}
