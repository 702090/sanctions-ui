import React from 'react';
import withDisplay from 'components/decorators/FormComponentWrapper';
import { Spinner } from 'components/shared/wait/Spinner';

export const Loading = withDisplay(
	({
		options,
		dirty,
		formValues,
		onChange,
		additionalOnChange,
		additionalOnBlur,
		setFieldValue,
		setFieldTouched,
		...props
	}) => <Spinner label='loading' size='small' />,
);
