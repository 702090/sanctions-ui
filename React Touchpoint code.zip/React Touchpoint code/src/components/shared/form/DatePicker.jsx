import React from 'react';
import 'react-day-picker/lib/style.css';
import { formatDate, formatDateObject } from 'utils/DateFunctions';
import DatePickerPopup from 'components/shared/form/DatePickerPopup';
import { MaskedInput } from 'components/shared/form/inputs/MaskedInput';
import _ from 'lodash';

const selectDate = (setFieldValue, date, name, touched) => {
	touched[name] = true;
	const newDate = formatDateObject(date);
	setFieldValue(name, newDate);
};

export const DatePicker = ({ field, form, ...props }) => {
	if (_.includes(field.value, '-')) {
		field.value = formatDate(field.value);
	}
	return (
		<MaskedInput
			field={field}
			form={form}
			className='datePicker'
			{...props}
			id={props.name}
			mask='99/99/9999'
			suffix={
				<DatePickerPopup
					selectDate={selectDate}
					setFieldValue={form.setFieldValue}
					name={field.name}
					touched={form.touched}
					value={field.value}
				/>
			}
		/>
	);
};
