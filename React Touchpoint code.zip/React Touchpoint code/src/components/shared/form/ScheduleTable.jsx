import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { InputText } from 'components/shared/form/inputs/InputText';
import { Field } from 'formik';
import React from 'react';

export const ScheduleTable = ({ fields, parentName, removeAction, addAction, values, visible }) => {
	if (visible) {
		return (
			<table className='schedule'>
				<thead>
					<tr>
						{fields.map((field, index) => (
							<th key={field.name}>
								{field.title}
								<br />
								{field.optional && <span className='optional'>(Optional)</span>}
							</th>
						))}
						<th>
							<SimpleButton content='Add' primary onClick={addAction} />
						</th>
					</tr>
				</thead>
				<tbody>
					{values.map((rowValues, vI) => (
						<tr key={vI}>
							{fields.map((field) => (
								<td key={`${parentName}.schedule.${vI}.${field.name}`}>
									<Field
										name={`${parentName}.schedule.${vI}.${field.name}`}
										component={field.component || InputText}
										width={field.width || 'tiny'}
										additionalOnBlur={field.onBlur}
										type={field.type}
										maxLength={field.maxLength}
									/>
								</td>
							))}
							<td>
								<SimpleButton
									content='Remove'
									primary
									onClick={() => {
										removeAction(vI);
									}}
								/>
							</td>
						</tr>
					))}
				</tbody>
			</table>
		);
	}
	return '';
};
