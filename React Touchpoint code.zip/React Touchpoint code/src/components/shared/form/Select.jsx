import withDisplay from 'components/decorators/FormComponentWrapper';
import React from 'react';
import { Dropdown } from 'semantic-ui-react';

export const Select = withDisplay(
	({
		onChange,
		options,
		dirty,
		formValues,
		additionalOnChange,
		additionalOnBlur,
		setFieldValue,
		setFieldTouched,
		...props
	}) => {
		if (!options) {
			options = [
				{ text: 'Yes', value: 'Y' },
				{ text: 'No', value: 'N' },
			];
		}

		options.forEach((option) => {
			option.id = `${props.name}_${option.value}`;
		});

		return (
			<Dropdown
				data-testid='insured'
				search={props.search}
				selection
				clearable
				options={options}
				id={props.name}
				{...props}
				onChange={(e, data) => {
					additionalOnChange(data.value, setFieldValue);
					setFieldTouched(props.name, true, false);
					setFieldValue(props.name, data.value);
				}}
			/>
		);
	},
);
