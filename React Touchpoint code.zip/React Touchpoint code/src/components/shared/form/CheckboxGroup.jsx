import withDisplay from 'components/decorators/FormComponentWrapper';
import { FieldArray, Field } from 'formik';
import _ from 'lodash';
import React from 'react';
import { Checkbox } from 'semantic-ui-react';

export const CheckboxGroup = withDisplay(
	({
		value,
		options,
		dirty,
		formValues,
		onChange,
		additionalOnChange,
		additionalOnBlur,
		setFieldValue,
		setFieldTouched,
		additionalInfoFields,
		...props
	}) => (
		<FieldArray
			{...props}
			render={(arrayHelpers) =>
				options.map((option) => {
					const checked = _.includes(value, option.value);
					const additionalFields = [];

					if (additionalInfoFields && additionalInfoFields[option.value] && checked) {
						additionalInfoFields[option.value].forEach((fieldProps) => {
							fieldProps.className = `checkboxField${fieldProps.className ? ` ${fieldProps.className}` : ''}`;
							additionalFields.push(<Field key={`${option.value}_${fieldProps.name}`} {...fieldProps} />);
						});
					}

					return (
						<React.Fragment key={option.value}>
							<Checkbox
								name={props.name}
								id={`${props.name}_${option.value}`}
								type='checkbox'
								value={option.value}
								checked={checked}
								label={option.text}
								onChange={(e) => {
									if (!checked) {
										arrayHelpers.push(option.value);
									} else {
										arrayHelpers.remove(value.indexOf(option.value));
									}
									additionalOnChange(option.value, setFieldValue, formValues);
								}}
							/>
							<br />
							{additionalFields.map((field) => field)}
						</React.Fragment>
					);
				})
			}
		/>
	),
);
