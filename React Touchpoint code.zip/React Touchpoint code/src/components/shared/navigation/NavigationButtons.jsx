import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { SubmitButton } from 'components/shared/buttons/SubmitButton';
import QuoteContext from 'context/quoteContext';
import proposalOptionsJson from 'data/ProposalOptions';
import React, { useContext } from 'react';
import { isBlank } from 'utils/StringFunctions';

const NavigationButtons = (props) => {
	const context = useContext(QuoteContext);

	const paymentRetry = props.paymentRetry;
	const { proposalOptions } = proposalOptionsJson;

	let formik = {
		values: {},
		errors: {},
		dirty: false,
	};
	if (props.formikProps) {
		formik = props.formikProps;
	}

	const onClick = () => context.onBack(formik.values, formik.dirty, props.insurityPush, props, props.rulesObject);
	const hasErrors = Object.keys(formik.errors).length > 0 || (props.ratingErrors && !isBlank(props.ratingErrors));
	const disableNext =
		props.disableNext ||
		(!paymentRetry &&
			((props.location?.pathname === '/quote/rate' && !props.doneRating) ||
				(hasErrors && props.location?.pathname === '/quote/rate')));

	const proposalOptionsFunc = () => {
		context.optionModal.current.handleOpen(
			{
				name: 'Proposal Options',
				label: 'Select Proposal type below.',
				options: proposalOptions,
			},
			(v, sfv, fv) => {
				props.proposalOnClick(v);
			},
			true,
		);
	};

	return (
		<div id='navigationButtons'>
			{props.back && (
				<React.Fragment>
					<div id='navigateleft' className='navigate'>
						<i className='far fa-chevron-square-left' onClick={onClick} />
					</div>
					<SimpleButton onClick={onClick} id='Back' content='Back' />
				</React.Fragment>
			)}
			{props.proposalOnClick && (
				<SimpleButton
					id='Proposal'
					className={`proposal${props.gettingProposal ? ' active' : ''}`}
					content={
						props.gettingProposal ? (
							<span className='withElipsis'>Loading PDF</span>
						) : (
							<>
								<i className='fal fa-download large' />
								Print All Proposals
							</>
						)
					}
					onClick={proposalOptionsFunc}
					disabled={props.gettingProposal !== false || !props.doneRating || hasErrors}
				/>
			)}
			{paymentRetry && (
				<React.Fragment>
					<SimpleButton id='paymentRetry' className='issue' content='Try Again' onClick={() => paymentRetry('r')} />
					<SimpleButton id='paymentRetry' className='issue' content='Quote List' onClick={() => paymentRetry('h')} />
				</React.Fragment>
			)}
			{props.completeIssue && (
				<SimpleButton
					id='completeissue'
					className='issue'
					content='Complete Issue'
					disabled={disableNext}
					onClick={formik.submitForm}
				/>
			)}
			{!paymentRetry && !props.issuing && (
				<React.Fragment>
					<SubmitButton
						error={hasErrors}
						datatestId={props.datatestId}
						content={typeof props.save !== 'undefined' && props.save ? 'Save' : 'Next'}
						disabled={disableNext}
						rulesObject={props.rulesObject}
					/>

					{!disableNext && (
						<div id='navigateRight' className='navigate'>
							<i className='far fa-chevron-square-right' onClick={formik.submitForm} />
						</div>
					)}
				</React.Fragment>
			)}
		</div>
	);
};

export default NavigationButtons;
