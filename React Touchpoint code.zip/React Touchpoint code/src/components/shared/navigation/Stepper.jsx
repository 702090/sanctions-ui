import _ from 'lodash';
import React from 'react';

export const Stepper = ({ pages, location, history }) => {
	if (
		!(
			_.startsWith(location.pathname, '/quote/load/') ||
			location.pathname === '/quote' ||
			location.pathname === '/quote/issue/submitted' ||
			location.pathname === '/quote/issue/progress' ||
			location.pathname === '/quote/issue/additionalForms'
		)
	) {
		let page = pages.find((p) => p.url === location.pathname);
		if (!page) {
			const pathname = _.split(location.pathname, '/', 3).join('/');
			page = pages.find((p) => p.url === pathname);
		}
		let lastValid = -1;

		return (
			<div
				id='stepperWrapper'
				className={
					page.title === 'Rate' ||
					location.pathname === '/quote/issue/summary' ||
					location.pathname === '/quote/issue/billingInformation'
						? 'rating'
						: ''
				}
			>
				<div id='stepper'>
					{page.children && page.children.length > 0 ? (
						page.children.map((child) => {
							if (!child.hidden && child.visible) {
								let className = 'inside';
								if (_.includes(location.pathname, child.url)) {
									className += ' is-active';
								}
								if (child.valid) {
									lastValid = child.order;
									className += ' is-complete';
								}
								if (
									child.valid ||
									child.order == (lastValid + 0.1).toPrecision(child.order > 1 ? 2 : 1) /* eslint eqeqeq: [0] */
								) {
									className += ' is-valid';
								}
								const key = `step_${child.url}`;
								return (
									<div
										className={className}
										key={key}
										onClick={
											child.valid ||
											child.order == (lastValid + 0.1).toPrecision(child.order > 1 ? 2 : 1) /* eslint eqeqeq: [0] */
												? () => {
														history.push(child.url);
												  }
												: null
										}
									>
										<span>{child.title}</span>
									</div>
								);
							} else {
								return null;
							}
						})
					) : (
						<div
							className={`only inside is-active${
								// TODO: Fix this!
								false ? 'is-complete' : ''
							}`}
						>
							<span>{page.title === 'Rate' ? '' : page.title}</span>
							<div className='eraser' />
						</div>
					)}
				</div>
			</div>
		);
	}
	return null;
};
