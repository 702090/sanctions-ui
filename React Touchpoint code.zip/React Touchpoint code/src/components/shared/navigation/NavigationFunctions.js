import _ from 'lodash';
import { duplicate } from 'utils/ObjectFunctions';

/**
 * Creates an array of pairs from an objects attributes where first item of pair is the key and second is the value.
 * This array is sorted by the "order" attribute.
 * @param {JSONObject} object A JSON screen object
 * @return {Array} A sorted array of key value pairs
 */
export function toSortedPairList(object, sortCriteria) {
	const screenList = _.toPairs(object);
	if (!sortCriteria) {
		return _.sortBy(screenList, [(screen) => screen[1].order]);
	}
	return _.sortBy(screenList, [(screen) => _.get(screen[1], sortCriteria)]);
}

/**
 * Returns the next page in the application.
 * @param {number} currentScreenOrder Value of "order" from ScreenOrder.json
 * @return {string} Path of the next page.
 */
function getNextPage(currentPage, navItems) {
	const nav = navItems
		.map((navItem) => {
			let nextPage;
			if (navItem.visible) {
				if (navItem.children) {
					nextPage = navItem.children.find((child) => child.order > currentPage.order && child.visible);
				} else if (navItem.order > currentPage.order) {
					nextPage = navItem;
				}
			}
			return nextPage;
		})
		.filter((item) => item)[0];
	return nav ? nav.url : undefined;
}

/**
 * Returns the previous page or section in the application.
 * @param {number} currentScreenOrder Value of "order" from ScreenOrder.json
 * @return {string} Path of the previous page or section.
 */
function getBackPage(currentPage, navItems) {
	if (currentPage.order === 0) {
		// This should never return but here for failsafe. Will send you to quotelist screen.
		return '/';
	}
	return navItems
		.reverse()
		.map((navItem) => {
			let nextPage;
			if (navItem.visible) {
				if (navItem.children) {
					nextPage = navItem.children.reverse().find((child) => child.order < currentPage.order && child.visible);
				} else if (navItem.order < currentPage.order) {
					nextPage = navItem;
				}
			}
			return nextPage;
		})
		.filter((item) => item)[0].url;
}

/**
 * Given a path and direction to move, will return the requested page.
 * @param {string} currentPage Path of the page you are currently on.
 * @param {string} direction 'next' or 'back'
 * @return {string} Path of the requested page.
 */
export function getPage(currentPageUrl, direction, navItems) {
	// This will show or hide the Issue left nav item when appropriate
	navItems.forEach((navItem) => {
		if (navItem.url.includes('issue')) {
			if (currentPageUrl.includes('issue') || currentPageUrl.includes('rate')) {
				navItem.visible = true;
			} else {
				navItem.visible = false;
			}
		}
	});

	navItems = duplicate(navItems);
	const pages = navItems
		.map((navItem) => {
			let currentItem;
			if (navItem.children) {
				const chil = navItem.children.find((child) => child.url === currentPageUrl);
				currentItem = chil;
			}
			if (navItem.url === currentPageUrl) {
				currentItem = navItem;
			}
			return currentItem;
		})
		.filter((item) => item);
	const currentPage = pages[0];

	if (direction === 'next') {
		const url = getNextPage(currentPage, navItems);
		return url;
	}
	if (direction === 'back') {
		return getBackPage(currentPage, navItems);
	}
	if (direction === 'progress') {
		return '/quote/issue/progress';
	}
	if (direction === 'submitted') {
		return '/quote/issue/submitted';
	}
	if (direction === 'cardPayment') {
		return '/quote/issue/cardPayment';
	}
	if (direction === 'cardDeclined') {
		return '/quote/issue/cardPaymentDecline';
	}
	if (direction === 'quoteList') {
		return '/';
	}
	if (direction === 'paymentRetry') {
		return '/quote/issue/billingInformation';
	}
	return currentPage;
}
/**
 * This takes the decimal part of the child's screen order and converts it to an array index
 * @param {number} childOrder
 * @return {number} The zero index Array index
 */
export function getChildIndex(childOrder) {
	const decimalPart = `${childOrder}`.split('.');
	return _.toNumber(decimalPart[1]) - 1;
}

/**
 * Used to get the path to the main section
 * @param {string} screen Path of the screen you are currently on.
 * @return {string} Path of the parent screen
 */
export function getParentPath(screen) {
	return screen.substr(0, screen.lastIndexOf('/'));
}

export function modalNavigation(
	context,
	forward,
	currentModal,
	locationId,
	newLocation,
	buildingId,
	newBuilding,
	additional,
) {
	switch (currentModal) {
		case 'safeguardLocation':
			if (newLocation) {
				// go to building
				context.refBuilding.current.handleOpen(locationId, newLocation, 'NEW', true, additional);
			} else {
				// go to location coverages
				context.refLocCoverages.current.handleOpen(locationId, newLocation);
			}
			break;
		case 'safeguardLocationCoverages':
			if (newLocation) {
				const buildings = _.get(context, `quote.sfg.locations.${locationId}.buildings`, {});
				buildingId = Object.keys(buildings)[0];
				context.refBuilding.current.handleOpen(locationId, newLocation, buildingId, true);
			} else {
				context.refLocation.current.handleOpen(locationId, newLocation);
			}
			break;
		default:
	}
}
