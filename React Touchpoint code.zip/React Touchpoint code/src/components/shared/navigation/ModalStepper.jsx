import QuoteContext from 'context/quoteContext';
import _ from 'lodash';
import React from 'react';
import { buildingHasQuestions } from 'utils/BusinessFunctions';

export const ModalStepper = ({
	currentModal,
	handleClose,
	locationId,
	newLocation,
	buildingId,
	building,
	newBuilding,
}) => {
	let steps = '';
	building = building || {};
	const buildingTitle = newBuilding ? 'New Building ' : `Building ${building.order} `;

	switch (currentModal) {
		case 'safeguardLocation':
			if (newLocation) {
				steps = <Step active title='Location Information' only />;
			} else {
				steps = addLocationMenus(currentModal);
			}
			break;
		case 'safeguardLocationCoverages':
			if (newLocation) {
				steps = <Step active title='Location Coverages' only />;
			} else {
				steps = addLocationMenus(currentModal);
			}
			break;
		case 'safeguardBuilding':
			if (newBuilding || newLocation) {
				steps = <Step active title={`${buildingTitle}Information`} only />;
			} else {
				steps = addBuildingMenus(currentModal, locationId, building, buildingTitle);
			}
			break;
		case 'safeguardBuildingQuestions':
			if (newBuilding || newLocation) {
				steps = <Step active title={`${buildingTitle}Questions`} only />;
			} else {
				steps = addBuildingMenus(currentModal, locationId, building, buildingTitle);
			}
			break;
		case 'safeguardBuildingCoverages':
			if (newBuilding || newLocation) {
				steps = <Step active title={`${buildingTitle}Coverages`} only />;
			} else {
				steps = addBuildingMenus(currentModal, locationId, building, buildingTitle);
			}
			break;
		case 'safeguardLosses':
		case 'capLosses':
		case 'wcpLosses':
			steps = <Step active title='Loss History Information' only />;
			break;
		case 'capVehicle':
			steps = <Step active title='Vehicle Information' only />;
			break;
		case 'capDriver':
			steps = <Step active title='Driver Information' only />;
			break;
		case 'wcpOfficer':
			steps = <Step active title='Workers Compensation Officers' only />;
			break;
		default:
	}

	return <div id='stepper'>{steps}</div>;
};
const addLocationMenus = (current) => (
	<React.Fragment>
		<Step active={current === 'safeguardLocation'} title='Location Information' />
		<Step active={current === 'safeguardLocationCoverages'} title='Location Coverages' />
	</React.Fragment>
);
const addBuildingMenus = (current, locationId, building, buildingTitle) => (
	<QuoteContext.Consumer>
		{(context) => {
			const quote = _.get(context, 'quote', {});
			const hasQuestions = buildingHasQuestions(locationId, building, quote);
			return (
				<React.Fragment>
					<Step active={current === 'safeguardBuilding'} title={`${buildingTitle}Information`} />
					{hasQuestions ? (
						<Step active={current === 'safeguardBuildingQuestions'} title={`${buildingTitle}Questions`} />
					) : (
						''
					)}
					<Step active={current === 'safeguardBuildingCoverages'} title={`${buildingTitle}Coverages`} />
				</React.Fragment>
			);
		}}
	</QuoteContext.Consumer>
);

const Step = ({ title, active, only }) => {
	let className = 'inside is-complete';
	if (only) {
		className = `only ${className}`;
	}
	if (active) {
		className = `${className} is-active`;
	}
	return (
		<div className={className} key={title}>
			<span>{title}</span>
			<div className='eraser' />
		</div>
	);
};
