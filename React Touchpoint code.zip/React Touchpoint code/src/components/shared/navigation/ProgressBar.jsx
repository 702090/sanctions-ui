import React from 'react';
import { NavItem } from 'components/shared/navigation/NavItem';
import { NavLink } from 'react-router-dom';
import _ from 'lodash';
import QuoteContext from 'context/quoteContext';

const ProgressBar = ({ pages, location, lastValidPageIndex }) => (
	<QuoteContext.Consumer>
		{(context) => (
			<div id='navWrapper'>
				{!(location.pathname === '/quote/issue/submitted' || location.pathname === '/quote/issue/progress') &&
					pages.map((page, index) => {
						// The last valid page to navigate to is the first one with an error
						// NOTE: We check if the first page is valid to enable to the second page or not.
						// This is pertinent during new quote creation
						if (!page.valid && !lastValidPageIndex && pages[0].valid) {
							lastValidPageIndex = index;
						}
						// If this is the first nav item or the first page is valid and is the last valid page or the last valid page is the current page, display a link
						return page.order === 0 || (!lastValidPageIndex && pages[0].valid) || lastValidPageIndex === index ? (
							<NavLink to={page.url} key={page.url}>
								<NavItem page={page} active={_.includes(location.pathname, page.url)} completed={page.valid} />
							</NavLink>
						) : (
							// Otherwise, just display text
							<NavItem page={page} key={page.url} />
						);
					})}
			</div>
		)}
	</QuoteContext.Consumer>
);

export default ProgressBar;
