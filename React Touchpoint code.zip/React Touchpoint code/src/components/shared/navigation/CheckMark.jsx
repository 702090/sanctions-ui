import React from 'react';

export const CheckMark = () => (
	<div className='check_mark'>
		<div className='container'>
			<input type='checkbox' id='cbtest' defaultChecked />
			<label htmlFor='cbtest' className='check-box' />
		</div>
	</div>
);
