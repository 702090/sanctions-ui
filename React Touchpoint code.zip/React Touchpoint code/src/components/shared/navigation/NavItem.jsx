import { CheckMark } from 'components/shared/navigation/CheckMark';
import React from 'react';

export const NavItem = ({ page, active, completed }) => {
	const itemClass = `${active ? ' active' : ''}${completed ? ' completed' : ''}`;
	if (page.visible) {
		return (
			<div className={`navItem${itemClass}`} key={page.order}>
				<div className={`navIcon${itemClass}`}>{completed ? <CheckMark /> : <i className={page.icon} />}</div>
				<div className='navTitle'>{page.title}</div>
			</div>
		);
	}
	return null;
};
