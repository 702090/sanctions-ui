import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { SubmitButton } from 'components/shared/buttons/SubmitButton';
import { PageSection } from 'components/shared/sections/PageSection';
import { Field, Form, Formik } from 'formik';
import React, { Component } from 'react';
import { Modal } from 'semantic-ui-react';
import { duplicate } from 'utils/ObjectFunctions';
import { logPageErrors } from 'utils/ScreenFunctions';
import { isBlankR } from 'utils/StringFunctions';
import { validate } from 'validation/Validate';

export class EntryModal extends Component {
	constructor() {
		super();
		this.state = {
			isOpen: false,
			options: {},
		}; // state to control the state of popup
	}

	handleOpen = (options, callBack, rules) => {
		this.setState({ isOpen: true, callBack, options, rules });
	};

	handleClose = (v) => {
		this.setState({ isOpen: false });
		this.state.callBack(v);
	};

	render() {
		const { options } = this.state;
		options.callback = this.handleClose;
		return (
			<Modal open={this.state.isOpen}>
				<Modal.Content>
					<Formik
						render={(formikProps) => {
							this.formProps = formikProps;
							return (
								<Form id='screen'>
									<PageSection title={options.title}>
										<Field
											{...options.field}
											name={options.field.name ? options.field.name : 'entryField'}
											formikProps={formikProps}
										/>
										<SimpleButton onClick={this.handleClose} content='Cancel' />
										<SubmitButton primary content='Save' error={!isBlankR(formikProps.errors)} />
									</PageSection>
								</Form>
							);
						}}
						initialValues={{
							entryField: '',
						}}
						validate={(values) => {
							//! This is because at some point formik is passing formik props as values instead of just values.
							if (values.values) {
								values = values.values;
							}
							const validResults = validate(values, options.rules(values), duplicate(options.structure));

							logPageErrors(validResults, this.formProps.touched, 'all');
							return validResults;
						}}
						onSubmit={(values, formikActions) => {
							this.handleClose(values.entryField);
						}}
					/>
				</Modal.Content>
			</Modal>
		);
	}
}
