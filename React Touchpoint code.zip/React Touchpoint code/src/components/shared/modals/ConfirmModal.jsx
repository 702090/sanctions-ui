import React, { Component } from 'react';
import { Button, Modal } from 'semantic-ui-react';

export class ConfirmModal extends Component {
	state = { open: false };

	handleOpen = (title, text, callback) => {
		this.setState({
			open: true,
			callback,
			title,
			text,
		});
	};

	close = () => this.setState({ open: false });

	render() {
		const { title, text, callback } = this.state;
		return (
			<Modal id='confirmModal' open={this.state.open} closeOnEscape closeOnDimmerClick={false} onClose={this.close}>
				<Modal.Header>{title}</Modal.Header>
				<Modal.Content>
					<p>{text}</p>
				</Modal.Content>
				<Modal.Actions>
					<Button onClick={this.close} negative>
						No
					</Button>
					<Button
						onClick={() => {
							this.close();
							callback();
						}}
						positive
						labelPosition='right'
						icon='checkmark'
						content='Yes'
					/>
				</Modal.Actions>
			</Modal>
		);
	}
}

export default ConfirmModal;
