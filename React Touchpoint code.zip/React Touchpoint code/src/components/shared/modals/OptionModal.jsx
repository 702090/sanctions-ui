import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { Field, Form, Formik } from 'formik';
import React, { Component } from 'react';
import { Modal } from 'semantic-ui-react';
import { isBlank } from 'utils/StringFunctions';

export class OptionModal extends Component {
	constructor() {
		super();
		this.state = {
			isOpen: false,
			options: {},
		}; // state to control the state of popup
	}

	handleOpen = (options, callBack, decorated) => {
		this.setState({ isOpen: true, callBack, options, decorated });
	};

	handleClose = (v, sfv, fv) => {
		this.setState({ isOpen: false });
		this.state.callBack(v, sfv, fv);
	};

	render() {
		const { options } = this.state;
		return (
			<Modal open={this.state.isOpen}>
				<Modal.Content>
					<Formik
						render={(formikProps) => (
							<Form id='screen'>
								{this.state.decorated ? (
									<>
										<h2>{options.label}</h2>
										<div id='decoratedContainer'>
											{options.options.map((val, key) => (
												<div
													className='decoratedOption'
													key={val.value}
													onClick={() => {
														this.handleClose(val.value);
													}}
												>
													<h3>{val.text}</h3>
													{val.details && !isBlank(val.details) && (
														<ul>
															{val.details.map((detail, idx) => (
																<li key={idx}>{detail}</li>
															))}
														</ul>
													)}
													<div className='decoratedAction'>
														<span>
															Get {val.text}
															<br />
															proposal
														</span>
													</div>
												</div>
											))}
										</div>
										<div id='navigationButtons' className='bottom'>
											<SimpleButton onClick={this.handleClose} content='Cancel' />
										</div>
									</>
								) : (
									<Field {...options.field} additionalOnChange={this.handleClose} />
								)}
							</Form>
						)}
						initialValues={{}}
					/>
				</Modal.Content>
			</Modal>
		);
	}
}
