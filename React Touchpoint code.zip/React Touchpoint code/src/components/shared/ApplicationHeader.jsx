import React from 'react';
import { NavLink } from 'react-router-dom';
import { Menu } from 'semantic-ui-react';
import _ from 'lodash';

const getGreeting = () => {
	const hr = new Date().getHours(); // leave as new Date(), not toDate(), to keep current hours

	if (hr >= 0 && hr < 4) {
		return 'Good night';
	} else if (hr >= 4 && hr < 11) {
		return 'Good morning';
	} else if (hr >= 11 && hr < 17) {
		return 'Good afternoon';
	} else if (hr >= 17 && hr < 24) {
		return 'Good evening';
	} else {
		return null;
	}
};
const ApplicationHeader = ({ agent, className, imagePath, pathname }) => (
	<Menu secondary id='appHeader' className={className}>
		<Menu.Item>
			<NavLink to='/'>
				<img alt='logo' src={imagePath} />
			</NavLink>
		</Menu.Item>

		<Menu.Item position='right'>
			{(pathname === '/' || _.startsWith(pathname, '/quote')) && (
				<img src={require('images/Novarica-white.png')} id='awards' />
			)}
			<div id='agentInfo'>
				{getGreeting()}
				,&nbsp;&nbsp;
				{agent && agent.name}
				<br />
				<a href='/' className='quoteListLink'>
					Exit to Quote List
				</a>
			</div>
		</Menu.Item>
	</Menu>
);

export default ApplicationHeader;
