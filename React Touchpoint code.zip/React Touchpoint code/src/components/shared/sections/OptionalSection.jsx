import _ from 'lodash';
import React from 'react';

export const OptionalSection = ({ name, errors, children, text, touched, vertical }) => {
	const error = _.get(errors, name, '') && touched;
	const childJSX = <div className={`optionalGroup${error ? ' error' : ''}`}>{children}</div>;
	const textJSX = (
		<div className={`groupText${error ? ' error' : ''}`}>
			{text || 'You must fill in at least one of these fields.'}
		</div>
	);

	return (
		<div className={`optionalWrapper${vertical ? 'Vertical' : ''}`}>
			{vertical ? (
				<React.Fragment>
					{textJSX}
					{childJSX}
				</React.Fragment>
			) : (
				<React.Fragment>
					{childJSX}
					{textJSX}
				</React.Fragment>
			)}
		</div>
	);
};
