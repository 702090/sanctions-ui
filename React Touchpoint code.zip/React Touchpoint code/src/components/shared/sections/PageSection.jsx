import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { WarningMessage } from 'components/shared/messages/WarningMessage';
import QuoteContext from 'context/quoteContext';
import referralMessagesJson from 'data/ReferralMessages';
import _ from 'lodash';
import React from 'react';
import { buildReferralMessage } from 'utils/ScreenFunctions';

export const PageSection = ({
	className,
	title,
	name,
	errors,
	children,
	locationId,
	buildingId,
	showCause,
	isNewCoverage,
	saveAction,
	cancelAction,
	biggerHeader,
}) => {
	const { messages } = referralMessagesJson;
	const path = name;
	let referralPath = name;
	if (locationId) {
		referralPath = `${referralPath}.${locationId}`;
		if (buildingId) {
			referralPath = `${referralPath}.${buildingId}`;
		}
	}
	const content = (
		<QuoteContext.Consumer>
			{(context) => (
				<div className={`pageSection${className ? ` ${className}` : ''}${isNewCoverage ? ' focusSection' : ''}`}>
					{biggerHeader ? <h2 className='sectionHeader'>{title}</h2> : <h3 className='sectionHeader'>{title}</h3>}
					{_.get(errors, path, []).map((error) => (
						<div className='error' key={error}>
							{error}
						</div>
					))}
					{_.sortBy(_.get(context.quote.referrals, referralPath, []), (referral) => {
						let sort = '';
						if (referral.length > 5) {
							sort += referral.slice(5, 7);
						}
						if (referral.length > 7) {
							sort += `.${referral.slice(7, 9)}`;
						}
						return sort;
					}).map((referral) => {
						const target = buildReferralMessage(referral);
						return (
							<WarningMessage
								key={referral}
								message={
									(showCause ? target : '') +
									messages[
										referral.slice(0, 5)
									] /* slice to get first 5 digits which is the message code, the other digits are for the total list */
								}
								fieldDisplay
							/>
						);
					})}
					{children}
					{isNewCoverage && (
						<div>
							<SimpleButton content='Cancel' primary onClick={cancelAction} />
							<SimpleButton content='Add' primary onClick={saveAction} />
						</div>
					)}
				</div>
			)}
		</QuoteContext.Consumer>
	);
	if (isNewCoverage) {
		return <div id='coverageDimmer'>{content}</div>;
	}
	return <React.Fragment>{content}</React.Fragment>;
};
