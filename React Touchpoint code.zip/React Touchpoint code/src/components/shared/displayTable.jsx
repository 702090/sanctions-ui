import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import DraggableTableRow from 'components/shared/DraggableTableRow';
import QuoteContext from 'context/quoteContext';
import _ from 'lodash';
import React, { useContext } from 'react';
import NumberFormat from 'react-number-format';
import { Table } from 'semantic-ui-react';
import { isBlank } from 'utils/StringFunctions';

export const DisplayTable = ({
	display,
	handleSort,
	column,
	direction,
	handleDelete,
	handleCopy,
	columns,
	errors,
	callBack,
	listOptions,
	additionalData,
	reference,
	location,
	history,
	handleDrop,
	handleRestore,
	tableContent,
	displayOrder,
}) => {
	const context = useContext(QuoteContext);
	if (display.length >= 1) {
		return (
			<Table selectable sortable singleLine>
				<Table.Header>
					<Table.Row>
						{columns.map((c, colNum) => {
							if (c.name) {
								return (
									<Table.HeaderCell
										key={'header_' + c.name + colNum}
										sorted={column === c.name && handleSort ? direction : null}
										onClick={c.noSort || !handleSort ? () => {} : handleSort(c.name)}
										width={c.width || 5}
										className={(c.noSort || !handleSort ? 'noHover' : '') + (c.class ? ' ' + c.class : '')}
									>
										<span>{c.display}</span>
									</Table.HeaderCell>
								);
							} else {
								return <Table.HeaderCell className='noHover' key={c.name + colNum} />;
							}
						})}
					</Table.Row>
				</Table.Header>
				<Table.Body>
					{display.map((data, dataIndex) => (
						<DraggableTableRow
							idx={dataIndex}
							key={dataIndex}
							action={!handleSort ? handleDrop : () => {}}
							className={
								(errors[data[0]] ? 'preError ' : '') +
								(additionalData ? 'preAdditionalData ' : '') +
								(_.get(data[1], 'lexisNexisPrefill', false) ? 'prefil ' : '')
							}
							draggable={!handleSort}
						>
							{columns.map((colData, colNum) => {
								let dispData = _.get(data[1], colData.name);
								if (!dispData) {
									dispData = colData.default;
								}
								if (colData.name === 'order') {
									dispData = _.toNumber(isBlank(dispData) ? '0' : dispData) + 1;
								}
								if (colData.transform) {
									dispData = colData.transform(dispData);
								}

								if (colData.name) {
									return (
										<Table.Cell
											onClick={() => {
												reference &&
													reference.current.handleOpen(data[0], data[1], callBack, location, history, listOptions);
											}}
											textAlign={_.isNumber(dispData) ? 'right' : 'left'}
											key={`data_${data[0]}_${colData.name}`}
										>
											{colData.truncate ? (
												_.truncate(dispData, { length: 48 })
											) : colData.type === 'currency' && dispData ? (
												<NumberFormat value={dispData} displayType='text' thousandSeparator prefix='$' />
											) : dispData === 'Y' && colData.noSort ? (
												<i className='fas fa-check' />
											) : dispData === 'N' && colData.noSort ? (
												<i className='fas fa-times' />
											) : dispData && colData.bold ? (
												<div className='bold'>{dispData}</div>
											) : dispData ? (
												dispData
											) : colData.noSort ? (
												<i className='fas fa-ban' />
											) : null}
											{errors[data[0]] && ((!displayOrder && colNum === 0) || (displayOrder && colNum === 1)) && (
												<div className='error'>
													This entry has&nbsp;
													{_.size(errors[data[0]])} error
													{_.size(errors[data[0]]) > 1 && 's'}.
												</div>
											)}
											{additionalData &&
												additionalData[dataIndex] &&
												((!displayOrder && colNum === 0) || (displayOrder && colNum === 1)) &&
												(Array.isArray(additionalData[dataIndex]) ? (
													<ul className='additionalData'>
														{additionalData[dataIndex].map((aData) => (
															<li key={aData}>{aData}</li>
														))}
													</ul>
												) : (
													<div className='additionalData'>{additionalData[dataIndex]}</div>
												))}
										</Table.Cell>
									);
								} else if (colData.restore) {
									return (
										<Table.Cell textAlign='right' key={`data_${data[0]}_blank${colNum}`}>
											<SimpleButton
												className='restore'
												content='Restore'
												onClick={() => handleRestore(data[0])}
												id={data[0]}
											/>
										</Table.Cell>
									);
								} else if (colData.copy) {
									return (
										<Table.Cell textAlign='right' key={`data_${data[0]}_blank${colNum}`}>
											<SimpleButton className='copy' content='Copy' onClick={() => handleCopy(data[0])} id={data[0]} />
										</Table.Cell>
									);
								} else {
									return (
										<Table.Cell textAlign='right' key={`data_${data[0]}_blank${colNum}`}>
											{!data[1][colData.deletable] && (
												<SimpleButton
													className='delete'
													content=''
													onClick={() =>
														context.confirmModal.current.handleOpen(
															`Delete ${_.startCase(tableContent)}`,
															`Are you sure you want to delete this ${_.startCase(tableContent)}?`,
															() => handleDelete(data[0]),
														)
													}
													id={data[0]}
													icon='delete'
												/>
											)}
										</Table.Cell>
									);
								}
							})}
						</DraggableTableRow>
					))}
				</Table.Body>
			</Table>
		);
	} else if (tableContent) {
		return (
			<div className='displayTableInstructions'>
				<p>This is where your {tableContent}s will show up once you have added one.</p>
				<p>
					Use the "Add {_.startCase(tableContent)}" button to create a new {tableContent}.
				</p>
			</div>
		);
	} else {
		return null;
	}
};
