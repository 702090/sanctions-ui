import React from 'react';
import { duplicate } from 'utils/ObjectFunctions';

export const MultiProgressBar = ({ bars, steps, id }) => {
	let stepStyle = { width: 100 / steps.length + '%' };
	return (
		<div id={id} className='progressWrapper'>
			<div className='progressSteps'>
				{steps.map((step, idx) => (
					<div key={'step' + step} style={stepStyle}>
						<span>{step}</span>
					</div>
				))}
			</div>
			<div className='progressBars'>
				{bars.map((bar) => {
					let style = { width: (bar.step / steps.length) * 100 + '%' };
					return (
						<div key={bar.name} className='progressBarWrapper'>
							<div className='progressLabel'>{bar.prod}</div>
							<div className={`progress-bar stripes${bar.error ? ' error' : ''}`}>
								<span className={`progress-bar-inner${bar.error ? ' error' : ''}`} style={style}>
									{bar.error || bar.label}
								</span>
							</div>
						</div>
					);
				})}
			</div>
		</div>
	);
};

export const processSteps = (stepData) => {
	const processedSteps = stepData.reduce((flattenedArray, milestone, milestoneIndex) => {
		//get the weighted total number of steps to be able to calculate the locations of each step
		const weightedStepCount = milestone.reduce((total, stepObj) => total + (stepObj.weight || 1), 0);

		let subStepTotal = 0;

		milestone.forEach((subStepObj, subStepIndex) => {
			//calculate the location of each step and add the step with the location to the flattened array that the JSX component needs
			if (subStepIndex === 0) {
				subStepTotal = subStepTotal - 1 / weightedStepCount;
			}
			let newStep = duplicate(subStepObj);
			subStepTotal += (subStepObj.weight || 1) / weightedStepCount;
			newStep.location = milestoneIndex + subStepTotal;
			flattenedArray.push(newStep);
		});

		return flattenedArray;
	}, []);

	return processedSteps;
};
