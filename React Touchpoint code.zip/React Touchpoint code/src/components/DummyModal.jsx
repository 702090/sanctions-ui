import { InputText } from 'components/shared/form/inputs/InputText';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import { Field, Form, Formik } from 'formik';
import QuoteContext from 'context/quoteContext';
import React, { Component } from 'react';
import { cleanValues, getVisibility } from 'utils/ScreenFunctions';
import { validate } from 'validation/Validate';

let visibility = {};
let nextModal;
let formProps;

export default class DummyModalForm extends Component {
	static contextType = QuoteContext;

	state = { protectionClassOptions: [] };

	componentDidMount() {}

	render() {
		const { quote } = this.context;
		return (
			<React.Fragment>
				<Formik
					render={(formikProps) => {
						formProps = formikProps;
						visibility = getVisibility(getFieldDisplayArray('dummyModal'), quote, formikProps.values);
						cleanValues(formikProps.values, visibility);
						nextModal = this.props.nextModal.current;
						return (
							<Form>
								<Field
									name='dummyField'
									label='Dummy Field'
									component={InputText}
									fieldDisplay={visibility.dummyField}
								/>
								<NavigationButtons
									formikProps={formikProps}
									back
									location={this.props.location}
									history={this.props.history}
								/>
							</Form>
						);
					}}
					initialValues={{}}
					onSubmit={(values, formikActions) => {
						cleanValues(values, visibility);
						this.context.onDummyModalSubmit(values);
						formikActions.setSubmitting(false);
						this.props.handleClose();
					}}
					validate={(values) => {
						const validResults = validate(values, {}, {});
						logPageErrors(validResults, formProps.touched, 'all');
						return validResults;
					}}
				/>
			</React.Fragment>
		);
	}
}
