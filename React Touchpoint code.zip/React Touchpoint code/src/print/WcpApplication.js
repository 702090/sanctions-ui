import wcpQuestionsJson from 'data/wcpPolicyQuestions';
import _ from 'lodash';
import { additionalInterestsSection } from 'print/sections/AdditionalInterests';
import { attachmentsSection } from 'print/sections/Attachments';
import { contactInformationSection } from 'print/sections/ContactInformation';
import { generalSection } from 'print/sections/General';
import { legaleseSection, signatureSection } from 'print/sections/Legalese';
import { paymentInformationSection } from 'print/sections/PaymentInformation';
import { priorCarrierSection } from 'print/sections/PriorCarrier';
import { priorLossesSection } from 'print/sections/PriorLosses';
import { questionSection } from 'print/sections/Questions';
import { referralsSection } from 'print/sections/Referrals';
import { remarksSection } from 'print/sections/Remarks';
import {
	wcpClassCodesSection,
	wcpModifiersSection,
	workersCompensationSection,
} from 'print/sections/WorkersCompensation';
import React from 'react';

export function WcpApplication(content, quote, agent) {
	// const content = [];
	const { wcpQuestions } = wcpQuestionsJson;
	// General Information
	content.push(<p className='break-before' />);
	content.push(generalSection(quote, 'wcp', 'Workers Compensation Policy Application'));

	//Workers Compensation
	content.push(workersCompensationSection(_.get(quote, 'wcp', {})));

	// Locations & classes
	content.push(wcpClassCodesSection(quote));

	// Policy Questions
	content.push(questionSection('Policy Questions', _.get(quote, 'policyQuestions', {}), wcpQuestions));

	// Prior Carrier
	const newVenture = _.get(quote, 'newVenture', '');
	content.push(priorCarrierSection(_.get(quote, 'wcp', {}), newVenture));

	// Prior Losses
	content.push(priorLossesSection({ losses: _.get(quote, 'wcp.losses', {}), product: 'wcp' }));

	// Additional Interests
	content.push(additionalInterestsSection(_.get(quote, 'additionalInterests', {}), 'sfg', quote));

	//Payment Information
	content.push(paymentInformationSection(quote, 'wcp'));

	//Workers Compensation Modifiers
	content.push(wcpModifiersSection(quote));

	//Contact Information
	content.push(contactInformationSection(_.get(quote, 'contacts', {})));

	//Remarks
	content.push(remarksSection(_.get(quote, 'remarks', '')));

	// Attachments
	content.push(attachmentsSection(quote.attachments));

	//Referrals
	content.push(referralsSection(quote, 'wcp'));

	//Legalese/Signatures
	content.push(legaleseSection(true));
	content.push(<p className='break-before' />);
	content.push(signatureSection());

	return content;
}
