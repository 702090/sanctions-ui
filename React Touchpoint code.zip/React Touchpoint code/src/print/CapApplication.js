import capQuestionsJson from 'data/capPolicyQuestions';
import _ from 'lodash';
import { additionalInterestsSection } from 'print/sections/AdditionalInterests';
import { attachmentsSection } from 'print/sections/Attachments';
import { capPolicySymbolsLimitsSection, capStateLimitsSection } from 'print/sections/CommercialAuto';
import { contactInformationSection } from 'print/sections/ContactInformation';
import { capDriversSection } from 'print/sections/Drivers';
import { generalSection } from 'print/sections/General';
import { legaleseSection, signatureSection } from 'print/sections/Legalese';
import { paymentInformationSection } from 'print/sections/PaymentInformation';
import { priorCarrierSection } from 'print/sections/PriorCarrier';
import { priorLossesSection } from 'print/sections/PriorLosses';
import { questionSection } from 'print/sections/Questions';
import { referralsSection } from 'print/sections/Referrals';
import { remarksSection } from 'print/sections/Remarks';
import { capVehiclesSection } from 'print/sections/Vehicles';
import React from 'react';

const { capQuestions } = capQuestionsJson;

export function CapApplication(content, quote, agent) {
	// const content = [];

	// General Information
	content.push(<p className='break-before' />);
	content.push(generalSection(quote, 'cap', 'Commercial Auto Policy Application'));

	// Policy Symbols and Limits
	content.push(capPolicySymbolsLimitsSection(quote));

	// State Limits and Coverages
	content.push(capStateLimitsSection(quote));

	// Policy Questions
	content.push(questionSection('Policy Questions', _.get(quote, 'policyQuestions', {}), capQuestions));

	// Vehicles
	content.push(capVehiclesSection(quote, false));
	if (quote.cap.deletedVehicles) {
		content.push(capVehiclesSection(quote, true));
	}

	// Drivers
	content.push(capDriversSection(quote));

	// Prior Carrier
	const newVenture = _.get(quote, 'newVenture', '');
	content.push(priorCarrierSection(_.get(quote, 'cap', {}), newVenture));

	// Prior Losses
	content.push(priorLossesSection({ losses: _.get(quote, 'cap.losses', {}), product: 'cap' }));

	// Additional Interests
	content.push(additionalInterestsSection(_.get(quote, 'additionalInterests', {}), 'cap', quote));

	// Payment Information
	content.push(paymentInformationSection(quote, 'cap'));

	// Contact Information
	content.push(contactInformationSection(_.get(quote, 'contacts', {})));

	// Remarks
	content.push(remarksSection(_.get(quote, 'remarks', '')));

	// Attachments
	content.push(attachmentsSection(quote.attachments));

	// Referrals
	content.push(referralsSection(quote, 'cap'));

	// Legalese/Signatures
	content.push(legaleseSection(false));
	content.push(<p className='break-before' />);
	content.push(signatureSection());

	return content;
}
