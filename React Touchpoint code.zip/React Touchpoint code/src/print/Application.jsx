import { parseJwt } from '@columbiainsurance/functions-js';
import _ from 'lodash';
import { formatDate } from 'print/utils/FieldDisplay';
import React, { Component } from 'react';
import { toast } from 'react-toastify';
import { getAgentToken } from 'services/agentService';
import { getQuote } from 'services/quoteService';
import { getFullInsuredName } from 'utils/BusinessFunctions';
import { CapApplication } from './CapApplication';
import { CupApplication } from './CupApplication';
import { SfgApplication } from './SfgApplication';
import { WcpApplication } from './WcpApplication';
import './_print.scss';

class Application extends Component {
	state = {};

	render() {
		const { quote, agent } = this.state;
		let product = this.props.match.params.product;
		let content = [];

		if (!quote) {
			return <React.Fragment />;
		}

		if (product === '') {
			product = 'all';
		}

		// {_.includes(quote.products, 'cup')

		if (product === 'sfg' || product === 'all') {
			content = SfgApplication(quote, agent);
		}
		if ((product === 'cap' || product === 'all') && _.includes(quote.products, 'cap')) {
			content = CapApplication(content, quote, agent);
		}
		if ((product === 'wcp' || product === 'all') && _.includes(quote.products, 'wcp')) {
			content = WcpApplication(content, quote, agent);
		}
		if ((product === 'cup' || product === 'all') && _.includes(quote.products, 'cup')) {
			content = CupApplication(content, quote, agent);
		}

		return <div className='printable'>{this.drawHeader(content, quote, agent)}</div>;
	}

	async UNSAFE_componentWillMount() {
		// Get the agent
		let agent = await JSON.parse(sessionStorage.getItem('agentJSONObject'));

		// Get the quote
		let quote = {};
		try {
			quote = await getQuote(this.props.match.params.agentSubpro, this.props.match.params.id);
		} catch (err) {
			toast.error('The requested quote could not be found.');
			console.error(err);
			this.props.history.replace('/');
		}

		// If we have the wrong agent for the quote, look up the right one
		if (quote.agentSubpro !== agent.agentSubpro) {
			agent = await getAgentToken(quote.agentSubpro, agent.userId);
			agent = parseJwt(agent);
		}

		this.setState({ quote, agent });
	}

	drawHeader(content, quote, agent) {
		// return <div className="content">{content}</div>;
		return (
			<div className='printable'>
				<table>
					<thead>
						<tr>
							<td>
								<div className='header-space'>&nbsp;</div>
							</td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>
								<div className='content'>{content}</div>
							</td>
						</tr>
					</tbody>
					<tfoot>
						<tr>
							<td>
								<div className='footer-space'>&nbsp;</div>
							</td>
						</tr>
					</tfoot>
				</table>

				<div className='print-header'>
					<div className='left'>
						<img src='https://portal.colinsgrp.com/images/CigLogoColor.jpg' alt='CIG Logo' />
					</div>
					<div className='middle'>
						Prepared for {getFullInsuredName(quote)} by
						<div className='agentName'>{agent.name}</div>
						on {formatDate(new Date(), 'text')}
					</div>
					<div className='right'>
						{agent.street}
						<br />
						{agent.city}, {agent.state} {agent.zip}
						<br />
						{agent.phone}
					</div>
				</div>
				<div className='print-footer'>
					<img src='https://portal.colinsgrp.com/images/SafeGuardLogo.png' alt='Safeguard Logo' />
				</div>
			</div>
		);
	}
}

export default Application;
