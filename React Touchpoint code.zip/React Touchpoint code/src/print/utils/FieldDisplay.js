import _ from 'lodash';
import selectOptions from 'data/SelectOptions';
import coverageParameters from 'data/CoverageParameters';

export const formatPhoneNumber = (value) => {
	if (!value) {
		return '';
	}

	value += '';
	value = value.trim();

	if (isNaN(value)) {
		return value;
	}

	if (value.length === 7) {
		return `${value.substring(0, 3)}-${value.substring(3, 7)}`;
	}
	if (value.length === 10) {
		return `(${value.substring(0, 3)}) ${value.substring(3, 6)}-${value.substring(6, 10)}`;
	}
	return value;
};

export const formatCurrency = (amount, showCents) => {
	amount += '';
	amount = amount.replace('$', '').replace(',', '');

	if (amount === '') {
		return '';
	}

	if (isNaN(amount)) {
		return amount;
	}

	let formattedResult = '';

	if (showCents) {
		formattedResult = new Intl.NumberFormat('en-US', {
			style: 'currency',
			currency: 'USD',
			maximumFractionDigits: 2,
			minimumFractionDigits: 2,
		}).format(amount);
	} else {
		formattedResult = new Intl.NumberFormat('en-US', {
			style: 'currency',
			currency: 'USD',
			maximumFractionDigits: 0,
			minimumFractionDigits: 0,
		}).format(amount);
	}
	return formattedResult === '$NaN' ? '' : formattedResult;
};

export const formatDate = (date) => {
	return new Intl.DateTimeFormat('en-US').format(date);
};

export const convertValue = (value, name, state) => {
	if (name === 'wcp_smallDeductible2') {
		value = value + state;
	}

	const match = _.find(_.get(selectOptions, name, {}), (c) => value === c.value);
	let newValue = match ? match.text : value;

	// Special check for yes/no questions
	newValue = newValue === 'Y' ? 'Yes' : newValue;
	newValue = newValue === 'N' ? 'No' : newValue;

	return newValue;
};

export const convertParamValue = (value, name) => {
	let newValue = convertValue(value, name);
	const currencyTriggerWords = [
		'amount',
		'deduct',
		'limit',
		'expense',
		'exposure',
		'food contamination',
		'receipts',
		'sales',
		'rented to you',
		'damageToPremises',
		'employeeTools',
		'nonOwnTools',
		'broadenedDamage',
	];

	const excludedTriggerWords = ['VETL', 'CDWS'];

	if (
		value === newValue &&
		currencyTriggerWords.filter((s) => name.toLowerCase().includes(s.toLowerCase())).length > 0 &&
		excludedTriggerWords.filter((s) => name.toLowerCase().includes(s.toLowerCase())).length < 1
	) {
		newValue = formatCurrency(newValue);
	}

	return newValue;
};

export const convertParamName = (name) => {
	return _.get(coverageParameters, name, name);
};
