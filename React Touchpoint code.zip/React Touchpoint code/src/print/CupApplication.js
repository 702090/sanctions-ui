import React from 'react';
import _ from 'lodash';
import { generalSection } from 'print/sections/General';
import { contactInformationSection } from 'print/sections/ContactInformation';
import { cupPolicyInformation, cupUnderlyingPolicies } from 'print/sections/CommercialUmbrella';
import { priorCarrierSection } from 'print/sections/PriorCarrier';
import { priorLossesSection } from 'print/sections/PriorLosses';
import { referralsSection } from 'print/sections/Referrals';
import { remarksSection } from 'print/sections/Remarks';
import { attachmentsSection } from 'print/sections/Attachments';
import { paymentInformationSection } from 'print/sections/PaymentInformation';
import { legaleseSection, signatureSection } from 'print/sections/Legalese';

export function CupApplication(content, quote, agent) {
	// General Information
	content.push(<p className='break-before' />);
	content.push(generalSection(quote, 'cup', 'Commercial Umbrella Policy'));

	// Policy Information
	content.push(cupPolicyInformation(quote));

	// Underlying Policies
	content.push(cupUnderlyingPolicies(quote));

	// Prior Carrier
	const newVenture = _.get(quote, 'newVenture', '');
	content.push(priorCarrierSection(_.get(quote, 'cup', {}), newVenture));

	// Prior Losses
	content.push(priorLossesSection({ losses: _.get(quote, 'cup.losses', {}), product: 'cup' }));

	// Payment Information
	content.push(paymentInformationSection(quote, 'cup'));

	// Contact Information
	content.push(contactInformationSection(_.get(quote, 'contacts', {})));

	// Remarks
	content.push(remarksSection(_.get(quote, 'remarks', '')));

	// Attachments
	content.push(attachmentsSection(_.get(quote, 'attachments', '')));

	// Referrals
	content.push(referralsSection(quote, 'cup'));

	// Legalese/Signatures
	content.push(legaleseSection(false));
	content.push(<p className='break-before' />);
	content.push(signatureSection());

	return content;
}
