import { isBlank } from '@columbiainsurance/functions-js';
import questionsJson from 'data/BuildingQuestions';
import sfgQuestionsJson from 'data/sfgPolicyQuestions';
import _ from 'lodash';
import { additionalInterestsSection } from 'print/sections/AdditionalInterests';
import { attachmentsSection } from 'print/sections/Attachments';
import {
	buildingClassificationInformationSection,
	buildingCoverageInformationSection,
	buildingInformationSection,
} from 'print/sections/Building';
import { contactInformationSection } from 'print/sections/ContactInformation';
import { generalSection } from 'print/sections/General';
import { legaleseSection, signatureSection } from 'print/sections/Legalese';
import { locationInformationSection } from 'print/sections/Location';
import { locationQuestionsSection } from 'print/sections/LocationQuestions';
import { paymentInformationSection } from 'print/sections/PaymentInformation';
import { priorCarrierSection } from 'print/sections/PriorCarrier';
import { priorLossesSection } from 'print/sections/PriorLosses';
import { questionSection } from 'print/sections/Questions';
import { referralsSection } from 'print/sections/Referrals';
import { remarksSection } from 'print/sections/Remarks';
import { sfgCoverageSection } from 'print/sections/SfgCoverages';
import { sfgPolicySection } from 'print/sections/SfgPolicy';
import React from 'react';
import { toSortedPairList } from 'utils/ObjectFunctions';
import './_print.scss';

export function SfgApplication(quote, agent) {
	let content = [];
	const { sfgQuestions } = sfgQuestionsJson;
	const { questions } = questionsJson;

	// General Information
	content.push(generalSection(quote, 'sfg', 'Safeguard Policy Application', 'far fa-shield-alt'));

	// Policy Information
	content.push(sfgPolicySection(quote, agent));

	// Policy Coverages
	content.push(
		sfgCoverageSection('Policy Coverages', _.get(quote, 'sfg.coverages', {}), 'sfg_policyCoverages_original'),
	);

	// Policy Questions
	content.push(questionSection('Policy Questions', _.get(quote, 'policyQuestions', {}), sfgQuestions));

	//Locations & Buildings Header
	content.push(<p className='break-before' />);
	content.push(<h1>Locations and Buildings</h1>);

	// Step through all the locations
	let locationsSorted = toSortedPairList(_.get(quote, 'sfg.locations', {}));
	_.forIn(locationsSorted, (value, key) => {
		let location = value[1];

		if (location.order !== 1) {
			content.push(<p className='break-before' />);
		}

		//Location Information
		content.push(locationInformationSection(value[0], quote));

		// Location Coverages
		content.push(sfgCoverageSection('Location Coverages', _.get(location, 'coverages', {}), 'sfg_LocationCoverages'));

		if (!isBlank(location.additionalQuestions)) {
			content.push(locationQuestionsSection(value[0], quote));
		}
		//
		// Step through all the buildings for this location
		//
		let buildingsSorted = toSortedPairList(_.get(location, 'buildings', {}));
		_.forIn(buildingsSorted, (bldgValue, bldgKey) => {
			let building = bldgValue[1];

			//location# / building# heading
			content.push(
				<div className='fullWidth'>
					<br />
					<h3>
						Location #{location.order} - Building #{building.order}
					</h3>
					<br />
				</div>,
			);

			// Building Classification Information
			content.push(buildingClassificationInformationSection(quote, building));

			// Building  Information
			content.push(buildingInformationSection(quote, building));

			// Building Coverage Information
			content.push(buildingCoverageInformationSection(quote, building));

			// Building Coverages
			content.push(sfgCoverageSection('Building Coverages', _.get(building, 'coverages', {}), 'sfg_buildingCoverages'));

			//Building Questions
			content.push(questionSection('Building Questions', _.get(building, 'questions', {}), questions));
		});
	});

	// Prior Carrier
	const newVenture = _.get(quote, 'newVenture', '');
	content.push(priorCarrierSection(_.get(quote, 'sfg', {}), newVenture));

	// Prior Losses
	content.push(priorLossesSection({ losses: _.get(quote, 'sfg.losses', {}), product: 'sfg' }));

	// Additional Interests
	content.push(additionalInterestsSection(_.get(quote, 'additionalInterests', {}), 'sfg', quote));

	//Payment Information
	content.push(paymentInformationSection(quote, 'sfg'));

	//Contact Information
	content.push(contactInformationSection(_.get(quote, 'contacts', {})));

	//Remarks
	content.push(remarksSection(_.get(quote, 'remarks', ''), _.get(quote, 'businessDescription', '')));

	//Attachments
	content.push(attachmentsSection(quote.attachments));

	//Referrals
	content.push(referralsSection(quote, 'sfg'));

	//Legalese/Signatures
	content.push(legaleseSection(false));
	content.push(<p className='break-before' />);
	content.push(signatureSection());

	return content;
}
