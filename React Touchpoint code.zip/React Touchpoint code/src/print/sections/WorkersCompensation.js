import _ from 'lodash';
import { convertValue, formatCurrency } from 'print/utils/FieldDisplay';
import React from 'react';
import { getPredState } from 'utils/BusinessFunctions';
import { toSortedPairList } from 'utils/ObjectFunctions';
import { formatNumber } from 'print/utils/FieldDisplay.js';
import NumberFormat from 'react-number-format';

export const workersCompensationSection = (wcp) => {
	let contents = [];

	contents.push(<div>Limit</div>);
	contents.push(<div>Liability (Accident/Policy/Employee)</div>);
	contents.push(<div>{convertValue(_.get(wcp, 'employersLiability', ''), 'wcp_employersLiability')}</div>);

	contents.push(<div>Officers</div>);
	contents.push(<div>Are Sole Proprietors, Partners or Executive Officers Included?</div>);
	contents.push(<div>{convertValue(_.get(wcp, 'officersIncluded', ''))}</div>);

	if (_.get(wcp, 'officersIncluded', 'N') === 'Y') {
		contents.push(<div>&nbsp;</div>);
		contents.push(<div>Number of Included Sole Proprietors, Partners or Officers</div>);
		contents.push(<div>{_.get(wcp, 'numberOfOfficersIncluded', '0')}</div>);

		let officersSorted = toSortedPairList(_.filter(_.get(wcp, 'officers', {}), { includedExcluded: 'INC' }));

		if (officersSorted.length > 0) {
			_.forIn(officersSorted, (value, key) => {
				const officer = value[1];

				contents.push(<div className='medium'>&nbsp;</div>);
				if (key === '0') {
					contents.push(<div>Names</div>);
				} else {
					contents.push(<div>&nbsp;</div>);
				}
				contents.push(
					<div>
						<b>{officer.name}</b>
						<br />
						Title: {officer.title}
						<br />
						Ownership: {officer.ownershipPercent}%<br />
						Status: {officer.includedExcluded}
					</div>,
				);
			});
		}
	}

	return (
		<div className='noBreak'>
			<h1>Workers Compensation</h1>
			<div className='threeColumnSection'>{contents}</div>
		</div>
	);
};

export const wcpModifiersSection = (quote) => {
	let elements = [];
	const state = getPredState(quote);
	const wcp = _.get(quote, 'wcp', {});
	const modifiers = _.get(wcp, 'modifiers.' + state, {});

	if (_.get(wcp, 'experienceMod', '') === '' && !modifiers) {
		elements.push(
			<div>
				<b>No Modifiers Entered</b>
			</div>,
		);
	} else {
		elements.push(<div>Experience Modifier</div>);
		elements.push(
			<div>
				<NumberFormat
					value={_.get(wcp, 'experienceMod', 1)}
					displayType='text'
					thousandSeparator
					decimalScale={2}
					fixedDecimalScale
				/>
			</div>,
		);
		elements.push(<div>Risk ID</div>);
		elements.push(<div>{parseInt(_.get(wcp, 'riskId', ''))}</div>);

		if (modifiers) {
			elements.push(<div>Small Deductible 1</div>);
			elements.push(<div>{formatCurrency(_.get(modifiers, 'smallDeductible1', ''), false)}</div>);

			elements.push(<div>Small Deductible 2</div>);
			elements.push(
				<div>{convertValue(_.get(modifiers, 'smallDeductible2', ''), 'wcp_smallDeductible2_' + state)}</div>,
			);

			elements.push(<div>Blanket Waiver</div>);
			elements.push(<div>{convertValue(_.get(modifiers, 'blanketWaiver', ''), '')}</div>);
		}
	}

	return (
		<div className='noBreak'>
			<h1>Workers Compensation Modifiers</h1>
			<div className='printSection'>{elements}</div>
		</div>
	);
};

export const wcpClassCodesSection = (quote) => {
	// This array will hold all of our locations & classes
	let locationList = [];

	// Step through all the addresses so we can look for classes
	const addresses = toSortedPairList(_.get(quote, 'addresses', {}));
	const classes = toSortedPairList(_.get(quote, 'wcp.classCodes', {}));
	_.forIn(addresses, (address) => {
		let classList = [];
		let totalEmployeeCount = _.get(quote, `wcp.employeesByLocation.id${address[0]}`);
		const accumEmployees = !totalEmployeeCount;

		// For each address, look for classes that match that address
		let totalEmployeesFromClasses = 0;
		_.forIn(classes, (thisClass) => {
			if (thisClass[1].location === address[0]) {
				let classContents = [];
				if (accumEmployees) {
					totalEmployeesFromClasses =
						totalEmployeesFromClasses +
						_.toNumber(thisClass[1].fullTimeEmployees || 0) +
						_.toNumber(thisClass[1].partTimeEmployees || 0);
				}
				classContents.push(<div>Full Time Employees</div>);
				classContents.push(<div>{thisClass[1].fullTimeEmployees}</div>);
				classContents.push(<div>Part Time Employees</div>);
				classContents.push(<div>{thisClass[1].partTimeEmployees}</div>);
				classContents.push(<div>Annual Payroll</div>);
				classContents.push(<div>{formatCurrency(thisClass[1].annualPayroll, false)}</div>);
				classList.push(
					<div className='noBreak'>
						<div className='wcpClassDescription'>
							{thisClass[1].classCode} - {thisClass[1].classCodeDescription}
						</div>
						<div className='printSection'>{classContents}</div>
					</div>,
				);
			}
		});

		// If this address has any WCP classes on it, add it to the list
		if (classList.length > 0) {
			const employeesByLocation = totalEmployeeCount || totalEmployeesFromClasses;
			locationList.push(
				<div className='noBreak'>
					<div className='wcpClassAddress'>{address[1].fullAddress}</div>
					<div className='printSection'>
						<div className='wide'>Total of Full and Part-time Employees at Location</div>
						<div>{employeesByLocation}</div>
					</div>
					{classList}
				</div>,
			);
		}
	});

	// Assemble and return the overall list
	return (
		<div className='noBreak'>
			<h1>Class Codes</h1>
			{locationList}
		</div>
	);
};
