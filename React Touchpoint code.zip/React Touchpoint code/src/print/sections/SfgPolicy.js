import React from 'react';
import _ from 'lodash';
import { formatCurrency } from 'print/utils/FieldDisplay';

export const sfgPolicySection = (quote, agent) => {
	return (
		<div className='noBreak'>
			<h1>Policy Information</h1>
			<div className='printSection'>
				<div>Liability Limit</div>
				<div>{formatCurrency(_.get(quote, 'sfg.liabilityLimit', ''))}</div>
				<div>Product Aggregate Limit</div>
				<div>{formatCurrency(_.get(quote, 'sfg.productAggLimit', ''))}</div>
				<div>Medical Payment Limit</div>
				<div>{formatCurrency(_.get(quote, 'sfg.medPayLimit', ''))}</div>
			</div>
		</div>
	);
};
