import _ from 'lodash';
import { convertParamName, convertParamValue, convertValue, formatCurrency } from 'print/utils/FieldDisplay';
import React from 'react';

export const sfgCoverageSection = (title, coverages, selectLookup) => {
	let coverageList = [];
	if (coverages.currentCoverages && coverages.currentCoverages.length > 0) {
		coverages.currentCoverages.forEach((coverage) => {
			coverageList.push(<div>{convertValue(coverage, selectLookup)}</div>);
			coverageList.push(buildCoverageParams(coverage, _.get(coverages, coverage)));
		});
	} else {
		coverageList.push(<div>No additional coverages added.</div>);
	}

	return (
		<div className='noBreak'>
			{title === 'Policy Coverages' && <h1>{title}</h1>}
			{title === 'Location Coverages' && <h4>{title}</h4>}
			{title === 'Building Coverages' && <h4>{title}</h4>}
			<div className='printSection coverages'>{coverageList}</div>
		</div>
	);
};

const buildCoverageParams = (coverage, params) => {
	const paramList = [];
	const scheduleTable = [];

	const paramArray = _.toPairs(params);
	paramArray.forEach((param, idx) => {
		if (typeof param[1] !== 'object') {
			paramList.push(<div>{convertParamName(`${coverage}_${param[0]}`)}</div>);
			paramList.push(<div>{convertParamValue(param[1], `sfg_${coverage}_${param[0]}`)}</div>);
		} else {
			// BUILD THE SCHEDULE HERE
			const titleRow = [<th key={idx}>Schedule Items</th>];
			param[1].forEach((row, index) => {
				const scheduleRow = [<td key={index}>&nbsp;</td>];
				_.forIn(row, (value, name) => {
					scheduleRow.push(_.includes(name, 'limit') ? <td>{formatCurrency(value, false)}</td> : <td>{value}</td>);
					if (index === 0) {
						titleRow.push(<th>{name}</th>);
					}
				});
				scheduleTable.push(<tr>{scheduleRow}</tr>);
			});
			scheduleTable.unshift(<tr>{titleRow}</tr>);
		}
	});

	// If we have a schedule, add it at the end
	if (scheduleTable.length > 0) {
		paramList.push(
			<div className='schedule fullWidth'>
				<table>
					<tbody>{scheduleTable}</tbody>
				</table>
			</div>,
		);
	}

	return <div className='parameterList'>{paramList}</div>;
};
