import _ from 'lodash';
import { convertValue, formatCurrency } from 'print/utils/FieldDisplay';
import React from 'react';
import { formatNumberWithCommas } from 'utils/BusinessFunctions';
import {
	checkBuildingUpdates,
	checkIfLeasing,
	checkNumberOfSwimmingPools,
	checkOwnerOccupied,
	checkPlayground,
	checkTotalPayroll,
	checkTotalSales,
	isContractorOccupancy,
	isNotHomeOffice,
} from 'utils/FieldDisplay';
import { isBlankZ } from 'utils/StringFunctions';

//
// Building Classification Information
//
export const buildingClassificationInformationSection = (quote, building) => {
	const showPlayground = checkPlayground(quote, building);
	const showOwnerOccupancy = checkOwnerOccupied(quote, building) && _.get(building, 'ownerOccupied') !== '';
	const showSwimmingPools = checkNumberOfSwimmingPools(quote, building);
	const showTenantList = checkIfLeasing(quote, building);

	let content = [];

	if (showOwnerOccupancy) {
		content.push(
			<div>Owner Occupied</div>,
			<div>{convertValue(_.get(building, 'ownerOccupied', ''), 'sfg_ownerOccupied_short')}</div>,
		);
	}

	if (showTenantList) {
		const numberOfTenants = _.get(building, 'numberOfTenants', 0);
		let tenantList = content.push(<div>Number of Tenants</div>, <div>{numberOfTenants}</div>);
		for (let i = 1; i <= numberOfTenants; i++) {
			content.push(<div>Tenant {i}</div>, <div>{_.get(building, `tenant${i}`, '')}</div>);
		}
	}

	if (showPlayground) {
		content.push(
			<div>Playground</div>,
			<div>{convertValue(_.get(building, 'playground', ''))}</div>,
			<div>Amusement Area</div>,
			<div>{convertValue(_.get(building, 'amusementArea', ''))}</div>,
		);
	}

	if (showSwimmingPools) {
		content.push(<div>Number of Swimming Pools</div>, <div>{_.get(building, 'numberOfSwimmingPools', '')}</div>);
	}

	return (
		<div className='noBreak'>
			<h4>
				<u>Classification Information</u>
			</h4>
			<div className='printSection'>
				<div>Class Description</div>
				<div className='wide'>
					{_.get(building, 'classCode', '')} -{_.get(building, 'classCodeDescription', '')}
				</div>

				<div>Business Type</div>
				<div>{convertValue(_.get(building, 'occupancyType', ''), 'sfg_occupancyType')}</div>

				<div># of Mortgagees/Loss Payees</div>
				<div>{_.get(building, 'numberOfMortgageesLossPayees', '')}</div>

				<div>Additional Insured</div>
				<div>{convertValue(_.get(building, 'additionalInsureds', ''))}</div>
				{content}
			</div>
		</div>
	);
};

//
// Building Information
//
export const buildingInformationSection = (quote, building) => {
	const showContratorExtras = isNotHomeOffice(quote, building);
	const showPermanentYard = isContractorOccupancy(quote, building);
	const showBuildingUpdates = checkBuildingUpdates(quote, building);

	let displayData = [];
	if (showContratorExtras) {
		displayData.push(
			<div>Number of Stories</div>,
			<div>{_.get(building, 'numberOfStories', '')}</div>,
			<div>Square Footage</div>,
			<div>{formatNumberWithCommas(_.get(building, 'squareFootage', ''))}</div>,
			<div>Sprinkler</div>,
			<div>{convertValue(_.get(building, 'sprinkler', ''))}</div>,
			<div>Roof Type</div>,
			<div>{_.get(building, 'roofType', '')}</div>,
		);
	}
	if (showPermanentYard) {
		displayData.push(<div>Permanent Yard</div>, <div>{formatCurrency(_.get(building, 'permanentYard', ''))}</div>);
	}

	const percentSubcontracting = _.get(quote, 'sfg.percentSubcontracting', '');
	if (building.occupancyType === '10' && !isBlankZ(percentSubcontracting)) {
		displayData.push(<div>Percentage of Subcontracting Work</div>, <div>{percentSubcontracting} %</div>);
	}

	if (showBuildingUpdates) {
		displayData.push(
			<div>Year Roof Updated</div>,
			<div>{_.get(building, 'roofYear', '')}</div>,
			<div>Year Electrical Updated</div>,
			<div>{_.get(building, 'wiringYear', '')}</div>,
			<div>Year Plumbing Updated</div>,
			<div>{_.get(building, 'plumbingYear', '')}</div>,
			<div>Year Heating Updated</div>,
			<div>{_.get(building, 'primaryHeatingYear', '')}</div>,
		);
	}

	return (
		<div className='noBreak'>
			<h4>
				<u>Building Information</u>
			</h4>
			<div className='printSection'>
				<div>Original Construction Year</div>
				<div>{_.get(building, 'constructionYear')}</div>
				<div>Construction</div>
				<div>{convertValue(_.get(building, 'constructionType', ''), 'sfg_constructionType')}</div>
				{displayData}
			</div>
		</div>
	);
};

//
// Building Coverage Information
//
export const buildingCoverageInformationSection = (quote, building) => {
	let lebLabel = '';

	if (checkTotalPayroll(quote, building)) {
		lebLabel = 'Total Payroll';
	} else if (checkTotalSales(quote, building)) {
		lebLabel = 'Total Sales';
	}

	let content = [];

	if (lebLabel !== '') {
		content.push(<div>{lebLabel}</div>, <div>{formatCurrency(_.get(building, 'liabilityExposureBasis', ''))}</div>);
	}

	return (
		<div className='noBreak'>
			<h4>
				<u>Building Coverage Information</u>
			</h4>
			<div className='printSection'>
				<div>Building Limit</div>
				<div>{formatCurrency(_.get(building, 'buildingLimit', ''), false)}</div>

				<div>Business Personal Property Limit</div>
				<div>{formatCurrency(_.get(building, 'bppLimit', ''), false)}</div>

				<div>Building Valuation</div>
				<div>{convertValue(_.get(building, 'buildingValuation', ''), 'sfg_buildingValuation')}</div>

				{content}
			</div>
		</div>
	);
};
