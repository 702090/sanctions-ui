import additionalQuestionsJson from 'data/AdditionalQuestions';
import _ from 'lodash';
import React from 'react';

export const locationQuestionsSection = (locId, quote) => {
	const location = _.get(quote, `sfg.locations.${locId}`);
	const roofQuestions = additionalQuestionsJson.questions.locationRoofQuestions;
	const existingQuestions = location.additionalQuestions;

	return (
		<div className='noBreak'>
			<h4>Location Questions</h4>
			{_.map(existingQuestions, (value, key) => {
				return (
					<div className='printSection questions noBreak' key={key}>
						<div className='noBreak'>{roofQuestions[key]}</div>
						<div className='noBreak'>{value === 'Y' ? 'Yes' : 'No'}</div>
					</div>
				);
			})}
		</div>
	);
};
