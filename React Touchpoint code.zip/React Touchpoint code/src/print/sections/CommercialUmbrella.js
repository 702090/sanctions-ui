import _ from 'lodash';
import { convertValue, formatCurrency } from 'print/utils/FieldDisplay';
import React from 'react';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import { getVisibility } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';

//*************************************************************
//
// contents Information
//
//*************************************************************
export const cupPolicyInformation = (quote) => {
	const cup = _.get(quote, 'cup', {});

	let visibility = getVisibility(getFieldDisplayArray('commercialUmbrella'), quote, quote);

	let contents = [];

	contents.push(<div>Umbrella Limit</div>);
	contents.push(<div>{formatCurrency(_.get(cup, 'umbrellaLimit', ''), false)}</div>);

	if (visibility['cup.restaurantLiquor']) {
		contents.push(<div>Restaurants w/Liquor sales greater than 25%</div>);
		contents.push(<div>{convertValue(_.get(cup, 'restaurantLiquor', 'N'))}</div>);
	}

	contents.push(<div>Payroll Exposure</div>);
	contents.push(<div>{formatCurrency(_.get(cup, 'payrollExposure', ''), false)}</div>);

	if (_.get(cup, 'allOther', '') !== '') {
		contents.push(<div>All Other Receipts Exposure</div>);
		contents.push(<div>{formatCurrency(_.get(cup, 'allOther'), false)}</div>);
	} else if (_.get(cup, 'contractingManufacturing', '') !== '') {
		contents.push(<div>Contracting/Manufacturing Receipts Exposure</div>);
		contents.push(<div>{formatCurrency(_.get(cup, 'contractingManufacturing'), false)}</div>);
	}

	contents.push(<div>Professional Liability</div>);
	contents.push(<div>{convertValue(_.get(cup, 'professionalLiability', ''))}</div>);

	if (_.get(cup, 'professionalLiability', 'N') === 'Y') {
		if (visibility['cup.clergyProfessionalCount']) {
			contents.push(<div>Number of Clergy Professional</div>);
			contents.push(<div>{_.get(cup, 'clergyProfessionalCount', '')}</div>);
		}

		if (visibility['cup.barbersBeuticiansCount']) {
			contents.push(<div>Number of Barbers/Beauticians</div>);
			contents.push(<div>{_.get(cup, 'barbersBeuticiansCount', '')}</div>);
		}

		if (visibility['cup.veterinariansCount']) {
			contents.push(<div>Number of Veterinarians</div>);
			contents.push(<div>{_.get(cup, 'veterinariansCount', '')}</div>);
		}

		if (visibility['cup.funeralDirectorsMorticiansCount']) {
			contents.push(<div>Number of Funeral Directors/Morticians</div>);
			contents.push(<div>{_.get(cup, 'funeralDirectorsMorticiansCount', '')}</div>);
		}

		if (visibility['cup.pharmacistsCount']) {
			contents.push(<div>Number of Pharmacists</div>);
			contents.push(<div>{_.get(cup, 'pharmacistsCount', '')}</div>);
		}

		if (visibility['cup.printersEOCount']) {
			contents.push(<div>Number of Printer's Errors & Omissions</div>);
			contents.push(<div>{_.get(cup, 'printersEOCount', '')}</div>);
		}

		if (visibility['cup.condoDirectorsOfficersCount']) {
			contents.push(<div>Number of Condominium - Directors and Officers</div>);
			contents.push(<div>{_.get(cup, 'condoDirectorsOfficersCount', '')}</div>);
		}

		if (visibility['cup.opticiansOptometristsCount']) {
			contents.push(<div>Number of Opticians/Optometrists</div>);
			contents.push(<div>{_.get(cup, 'opticiansOptometristsCount', '')}</div>);
		}

		if (visibility['cup.seniorCitizensCount']) {
			contents.push(<div>Number of Senior Citizens Housing Directors & Officers</div>);
			contents.push(<div>{_.get(cup, 'seniorCitizensCount', '')}</div>);
		}
	}

	contents.push(<div>Federal Terrorism</div>);
	contents.push(<div>{convertValue(_.get(cup, 'federalTerrorism', ''))}</div>);

	contents.push(<div className='wide'>Underlying liability loss greater than $150,000 in the past 3 years</div>);
	contents.push(<div>{convertValue(_.get(cup, 'underlyingLiability', ''))}</div>);

	// Assemble and return the overall list
	return (
		<div className='noBreak'>
			<h1>Policy Information</h1>
			<div className='printSection'>{contents}</div>
		</div>
	);
};

//*************************************************************
//
// Underlying Policies
//
//*************************************************************
export const cupUnderlyingPolicies = (quote) => {
	const up = _.get(quote, 'cup.underlyingPolicies', {});
	let contents = [];
	let details = [];
	let showDisclaimer = false;

	//-----------------------------------------------
	//Safeguard
	//-----------------------------------------------

	// sfg is on policy
	details = [];
	if (_.includes(quote.products, 'sfg')) {
		contents.push(
			<div className='sectionHeader'>
				Safeguard
				<br />
				<br />
			</div>,
		);

		contents.push(
			<div className='fullWidth'>
				Safeguard information that is being quoted will be applied.
				<br />
				<br />
			</div>,
		);

		details.push(<div>Carrier</div>);
		details.push(<div>Columbia Mutual Insurance Co</div>);

		if (!isBlank(_.get(quote, 'sfg.umbrellaData.liabilityPremium'))) {
			details.push(<div>Liability Premium *</div>);
			details.push(<div>{formatCurrency(_.get(quote, 'sfg.umbrellaData.liabilityPremium'), false)}</div>);
		}

		details.push(<div>Liability Limit</div>);
		details.push(<div>{formatCurrency(_.get(quote, 'sfg.liabilityLimit'), false)}</div>);

		details.push(<div>Liability/Medical Agg Limit</div>);
		details.push(<div>{formatCurrency(_.get(quote, 'sfg.productAggLimit'), false)}</div>);

		details.push(<div>Products Aggregate</div>);
		details.push(<div>{formatCurrency(_.get(quote, 'sfg.productAggLimit'), false)}</div>);

		details.push(<div>Coverage Type</div>);
		details.push(<div>Occurrence</div>);

		if (!isBlank(_.get(up, 'sfg.driverCount', ''))) {
			details.push(<div>Number of Drivers</div>);
			details.push(<div>{_.get(up, 'sfg.driverCount', '')}</div>);
		}

		contents.push(<div className='printSection'>{details}</div>);

		contents.push(
			<div>
				<br />
				<br />
			</div>,
		);

		if (!isBlank(_.get(quote, 'sfg.umbrellaData.liabilityPremium'))) {
			contents.push(<div>* Subject to change at rating</div>);
		}

		contents.push(
			<div>
				<br />
				<br />
			</div>,
		);
	}

	//-----------------------------------------------
	//Commercial Auto
	//-----------------------------------------------

	// cap is on policy
	details = [];
	if (_.includes(quote.products, 'cap')) {
		contents.push(<div className='sectionHeader'>Commercial Auto</div>);
		contents.push(<br />);
		contents.push(
			<div>
				Commercial Auto information that is being quoted will be applied.
				<br />
				<br />
			</div>,
		);

		details.push(<div>Carrier</div>);
		details.push(<div>Columbia Mutual Insurance Co</div>);

		const driverCount = Object.keys(_.get(quote, 'cap.drivers', {})).length;
		details.push(<div>Number of Drivers</div>);
		details.push(<div>{_.get(up, 'cap.driverCount', driverCount)}</div>);

		details.push(<div>Liability Limit</div>);
		details.push(<div>{formatCurrency(_.get(quote, 'cap.liabilityLimit'), false)}</div>);

		if (!isBlank(_.get(quote, 'cap.umbrellaData.biPerPerson'))) {
			showDisclaimer = true;
			details.push(<div>BI Per Person *</div>);
			details.push(<div>{formatCurrency(_.get(quote, 'cap.umbrellaData.biPerPerson', ''), false)}</div>);
		}

		if (!isBlank(_.get(quote, 'cap.umbrellaData.biPerAccident'))) {
			showDisclaimer = true;
			details.push(<div>BI Per Accident *</div>);
			details.push(<div>{formatCurrency(_.get(quote, 'cap.umbrellaData.biPerAccident', ''), false)}</div>);
		}

		if (!isBlank(_.get(quote, 'cap.umbrellaData.pdPerAccident'))) {
			showDisclaimer = true;
			details.push(<div>PD Per Accident *</div>);
			details.push(<div>{formatCurrency(_.get(quote, 'cap.umbrellaData.pdPerAccident', ''), false)}</div>);
		}

		if (!isBlank(_.get(quote, 'cap.umbrellaData.liabilitySymbol'))) {
			showDisclaimer = true;
			details.push(<div>Hired / Non-Owned *</div>);
			details.push(<div>{_.get(quote, 'cap.umbrellaData.liabilitySymbol')}</div>);
		}

		if (!isBlank(_.get(quote, 'cap.umbrellaData.lightExposureAmount'))) {
			showDisclaimer = true;
			details.push(<div>Number of PPT,Light,and Medium Vehicles *</div>);
			details.push(<div>{_.get(quote, 'cap.umbrellaData.lightExposureAmount')}</div>);
		}

		if (!isBlank(_.get(quote, 'cap.umbrellaData.lightPremiumAmount'))) {
			showDisclaimer = true;
			details.push(<div>PPT,Light,and Medium Vehicles Premium *</div>);
			details.push(<div>{formatCurrency(_.get(quote, 'cap.umbrellaData.lightPremiumAmount', ''), false)}</div>);
		}

		if (!isBlank(_.get(quote, 'cap.umbrellaData.heavyExposureAmount'))) {
			showDisclaimer = true;
			details.push(<div>"Number Of Heavy Vehicles *"</div>);
			details.push(<div>{_.get(quote, 'cap.umbrellaData.heavyExposureAmount')}</div>);
		}

		if (!isBlank(_.get(quote, 'cap.umbrellaData.heavyPremiumAmount'))) {
			showDisclaimer = true;
			details.push(<div>Heavy Vehicles Premium *</div>);
			details.push(<div>{formatCurrency(_.get(quote, 'cap.umbrellaData.heavyPremiumAmount', ''), false)}</div>);
		}

		if (!isBlank(_.get(quote, 'cap.umbrellaData.extraHeavyExposureAmount'))) {
			showDisclaimer = true;
			details.push(<div>Number of Extra Heavy Truck Tractor Vehicles *</div>);
			details.push(<div>{_.get(quote, 'cap.umbrellaData.extraHeavyExposureAmount')}</div>);
		}

		if (!isBlank(_.get(quote, 'cap.umbrellaData.extraHeavyPremiumAmount'))) {
			showDisclaimer = true;
			details.push(<div>Extra Heavy Truck Tractor Vehicles Premium *</div>);
			details.push(
				<div>
					details.push(
					<div>{formatCurrency(_.get(quote, 'cap.umbrellaData.extraHeavyPremiumAmount', ''), false)}</div>
					);
				</div>,
			);
		}
		contents.push(<div className='printSection'>{details}</div>);

		contents.push(
			<div>
				<br />
				<br />
			</div>,
		);

		if (showDisclaimer) {
			contents.push(<div>* Subject to change at rating</div>);
			contents.push(
				<div>
					<br />
					<br />
				</div>,
			);
		}
	}

	if (!_.includes(quote.products, 'cap') && !isBlank(_.get(up, 'cap', {})) && _.get(up, 'cap.retrieved', false)) {
		details = [];
		contents.push(<div className='sectionHeader'>Commercial Auto</div>);
		contents.push(<br />);
		contents.push(
			<div>
				Commercial Auto information that is being quoted will be applied.
				<br />
				<br />
			</div>,
		);

		details.push(<div>Carrier</div>);
		details.push(<div>{_.get(up, 'cap.carrier', '')}</div>);

		details.push(<div>Policy Number</div>);
		details.push(<div>{_.get(up, 'up.cap.policyNumber', '')}</div>);

		details.push(<div>Effective Date</div>);
		details.push(<div>{_.get(up, 'cap.effectiveDate', '')}</div>);

		details.push(<div>Expiration Date</div>);
		details.push(<div>{_.get(up, 'cap.expirationDate', '')}</div>);

		details.push(<div>Number of Drivers</div>);
		details.push(<div>{_.get(up, 'cap.driverCount', '')}</div>);

		details.push(<div>Liability Limit</div>);
		details.push(<div>{formatCurrency(_.get(up, 'cap.liabilityLimit'), false)}</div>);

		if (!isBlank(_.get(up, 'cap.biPerPerson'))) {
			details.push(<div>BI Per Person *</div>);
			details.push(<div>{formatCurrency(_.get(up, 'cap.biPerPerson', ''), false)}</div>);
		}

		if (!isBlank(_.get(up, 'cap.biPerAccident'))) {
			details.push(<div>BI Per Accident *</div>);
			details.push(<div>{formatCurrency(_.get(up, 'cap.biPerAccident', ''), false)}</div>);
		}

		if (!isBlank(_.get(up, 'cap.pdPerAccident', ''))) {
			details.push(<div>PD Per Accident</div>);
			details.push(<div>{formatCurrency(_.get(up, 'cap.pdPerAccident', ''), false)}</div>);
		}

		if (!isBlank(_.get(up, 'cap.liabilitySymbol'))) {
			details.push(<div>Hired / Non-Owned</div>);
			details.push(<div>{_.get(up, 'cap.liabilitySymbol', '')}</div>);
		}

		if (!isBlank(_.get(up, 'cap.lightExposureAmount', ''))) {
			details.push(<div>Number of PPT,Light,and Medium Vehicles</div>);
			details.push(<div>{_.get(up, 'cap.lightExposureAmount', '')}</div>);
		}

		if (!isBlank(_.get(up, 'cap.lightPremiumAmount', ''))) {
			details.push(<div>PPT,Light,and Medium Vehicles Premium</div>);
			details.push(<div>{formatCurrency(_.get(up, 'cap.lightPremiumAmount', ''), false)}</div>);
		}

		if (!isBlank(_.get(up, 'cap.heavyExposureAmount', ''))) {
			details.push(<div>Number Of Heavy Vehicles</div>);
			details.push(<div>{_.get(up, 'cap.heavyExposureAmount', '')}</div>);
		}

		if (!isBlank(_.get(up, 'cap.heavyPremiumAmount', ''))) {
			details.push(<div>Heavy Vehicles Premium</div>);
			details.push(<div>{formatCurrency(_.get(up, 'cap.heavyPremiumAmount', ''), false)}</div>);
		}

		if (!isBlank(_.get(up, 'cap.extraHeavyExposureAmount'))) {
			details.push(<div>Number of Extra Heavy Truck Tractor Vehicles</div>);
			details.push(<div>{_.get(up, 'cap.extraHeavyExposureAmount', '')}</div>);
		}

		if (!isBlank(_.get(up, 'cap.extraHeavyPremiumAmount'))) {
			details.push(<div>Extra Heavy Truck Tractor Vehicles Premium</div>);
			details.push(<div>{formatCurrency(_.get(up, 'cap.extraHeavyPremiumAmount', ''), false)}</div>);
		}

		contents.push(<div className='printSection'>{details}</div>);

		contents.push(
			<div>
				<br />
				<br />
			</div>,
		);
	}

	//-----------------------------------------------
	//Workers Comp
	//-----------------------------------------------

	// wcp is on policy
	details = [];
	if (_.includes(quote.products, 'wcp')) {
		contents.push(<div className='sectionHeader'>Workers Compensation</div>);
		contents.push(<br />);

		details.push(<div>Carrier</div>);
		details.push(<div>{_.get(up, 'wcp.carrier', 'Columbia Mutual Insurance Co')}</div>);

		details.push(<div>Limit Per Accident</div>);
		details.push(<div>{formatCurrency(_.get(quote, 'wcp.employersLiability').split('/')[0], false)}</div>);

		details.push(<div>Disease Policy Limit</div>);
		details.push(<div>{formatCurrency(_.get(quote, 'wcp.employersLiability').split('/')[1], false)}</div>);

		details.push(<div>Disease Per Employee</div>);
		details.push(<div>{formatCurrency(_.get(quote, 'wcp.employersLiability').split('/')[2], false)}</div>);
	}

	// wcp is NOT on policy
	// quote.underlyingPolicies.wcp is NOT empty
	// quote.underlyingPolicies.wcp.retrieved is truthy
	if (!_.includes(quote.products, 'wcp') && !isBlank(_.get(up, 'wcp', {})) && _.get(up, 'wcp.retrieved', false)) {
		contents.push(<div className='sectionHeader'>Workers Compensation</div>);
		contents.push(<br />);

		details.push(<div>Carrier</div>);
		details.push(<div>{(_.get(up, 'wcp.carrierName'), '')}</div>);

		details.push(<div>Policy Number</div>);
		details.push(<div>{_.get(up, 'wcp.policyNumber', '')}</div>);

		details.push(<div>Limit Per Accident</div>);
		details.push(<div>{formatCurrency(_.get(up, 'wcp.limitPerAccident', ''), false)}</div>);

		details.push(<div>Disease Policy Limit</div>);
		details.push(<div>{formatCurrency(_.get(up, 'wcp.biPerPerson', ''), false)}</div>);

		details.push(<div>Disease Per Employee</div>);
		details.push(<div>{formatCurrency(_.get(up, 'wcp.liabilityMedicalAggLimit', ''), false)}</div>);
	}

	// wcp is NOT on policy
	// quote.underlyingPolicies.wcp is empty
	// OR
	// quote.underlyingPolicies.wcp is NOT empty && quote.underlyingPolicies.wcp.retrieved is falsey
	if (
		!_.includes(quote.products, 'wcp') &&
		(isBlank(_.get(up, 'wcp', {})) || (!isBlank(_.get(up, 'wcp', {})) && !_.get(up, 'wcp.retrieved', false)))
	) {
		contents.push(<div className='sectionHeader'>Workers Compensation</div>);
		contents.push(<br />);

		if (_.get(up, 'wcp.manual', '') !== 'Y') {
			details.push(<div className='halfWidth'>Would you like to add a Workers Compensation Policy?</div>);
			details.push(<div className='halfWidth'>No</div>);
		}

		if (_.get(up, 'wcp.manual', '') === 'Y') {
			contents.push(
				<div>
					<br />
				</div>,
			);
			details.push(<div>Carrier</div>);
			details.push(<div>{_.get(up, 'wcp.carrier', '')}</div>);

			details.push(<div>Policy Number</div>);
			details.push(<div>{_.get(up, 'wcp.policyNumber', '')}</div>);

			details.push(<div>Effective Date</div>);
			details.push(<div>{_.get(up, 'wcp.effectiveDate', '')}</div>);

			details.push(<div>Expiration Date</div>);
			details.push(<div>{_.get(up, 'wcp.expirationDate', '')}</div>);

			details.push(<div>Limit per Accident</div>);
			details.push(<div>{formatCurrency(_.get(up, 'wcp.limitPerAccident', ''), false)}</div>);

			details.push(<div>BI per Person</div>);
			details.push(<div>{formatCurrency(_.get(up, 'wcp.biPerPerson', ''), false)}</div>);

			details.push(<div>Liability / Medical Agg Limit</div>);
			details.push(<div>{formatCurrency(_.get(up, 'wcp.liabilityMedicalAggLimit', ''), false)}</div>);
		}
	}

	contents.push(<div className='printSection'>{details}</div>);
	contents.push(<br />);

	// Assemble and return the overall list
	//-----------------------------------------------
	return (
		<div className='noBreak'>
			<h1>Underlying Policies</h1>
			<div>{contents}</div>
		</div>
	);
};
