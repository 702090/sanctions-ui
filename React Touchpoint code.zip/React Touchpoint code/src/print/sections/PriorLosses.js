import { isBlank } from '@columbiainsurance/functions-js';
import _ from 'lodash';
import { convertValue, formatCurrency } from 'print/utils/FieldDisplay';
import React from 'react';

export const priorLossesSection = (options) => {
	const { losses, product } = options;

	const lossesList = _.reduce(
		losses,
		(result, value) => {
			const partitionNumber = _.includes(['P', 'D'], value.designation) ? 1 : 0;
			(result[partitionNumber] || (result[partitionNumber] = [])).push(
				<div className='printSection separated noBreak' key={_.get(value, 'id', '')}>
					{partitionNumber === 1 && !isBlank(_.get(value, 'driverName')) && (
						<>
							<div>Driver Name</div>
							<div className='wide'>{value.driverName}</div>
						</>
					)}
					<div>Date of Loss</div>
					<div>{_.get(value, 'dateOfClaim')}</div>
					<div>Claim Status</div>
					<div>{convertValue(_.get(value, 'status', ''), 'loss_history_claim_Status')}</div>
					<div>Amount Paid</div>
					<div>{formatCurrency(_.get(value, 'totalAmountPaid', ''), false)}</div>
					<div>Amount Reserved</div>
					<div>{formatCurrency(_.get(value, 'totalReserveAmount'), false)}</div>
					<div>Loss Description</div>
					<div className='wide'>{_.get(value, 'lossDescription', '')}</div>
					{partitionNumber === 1 && (
						<>
							<div>Driver Claim Type</div>
							<div>{_.get(value, 'designation') === 'P' ? 'Personal' : 'Commercial'}</div>
						</>
					)}
				</div>,
			);
			return result;
		},
		[],
	);

	return (
		<div className='noBreak'>
			<h1>Prior Named Insured Losses</h1>
			{!isBlank(_.get(lossesList, '0', '')) ? (
				<div key={lossesList[0].id}>{lossesList[0]}</div>
			) : (
				<div key='0'>
					<b>No prior named insured losses in the past 3 years</b>
				</div>
			)}
			{product === 'cap' && (
				<>
					<h1>Prior Driver Losses</h1>
					{!isBlank(_.get(lossesList, '1', '')) ? (
						<div key={lossesList[1].id}>{lossesList[1]}</div>
					) : (
						<div key='1'>
							<b>No prior driver losses in the past 3 years</b>
						</div>
					)}
				</>
			)}
		</div>
	);
};
