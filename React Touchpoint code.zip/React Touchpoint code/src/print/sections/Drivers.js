import statesJson from 'data/states';
import _ from 'lodash';
import React from 'react';

const { states } = statesJson;

export const capDriversSection = (quote) => {
	const drivers = _.get(quote, 'cap.drivers', {});
	const rows = [];

	if (!drivers) {
		rows.push(<div>No Drivers Entered</div>);
	} else {
		_.forEach(drivers, (driverInfo, key) => {
			rows.push(
				<div className='printSection separated noBreak'>
					<div>Driver Name</div>
					<div>
						{_.get(driverInfo, 'name.first', '')} {_.get(driverInfo, 'name.last', '')}
					</div>
					<div>License State</div>
					<div>{_.get(states, _.get(driverInfo, 'licenseState', ''), '')}</div>
				</div>,
			);
		});
	}

	return (
		<div className='noBreak'>
			<h1>Drivers</h1>
			<div>{rows}</div>
		</div>
	);
};
