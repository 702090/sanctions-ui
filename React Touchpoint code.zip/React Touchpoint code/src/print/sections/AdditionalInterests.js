import _ from 'lodash';
import { convertValue } from 'print/utils/FieldDisplay';
import React from 'react';
import { getFullName } from 'utils/BusinessFunctions';

export const additionalInterestsSection = (additionalInterests, product, quote) => {
	let additionalInterestList = [];

	// Step through the additional interests
	_.forIn(additionalInterests, (interest, id) => {
		// Build the location/building set for this interest - there may be multiples
		let buildings = [];

		if (interest.interestBuilding) {
			interest.interestBuilding.forEach((locBld) => {
				const loc = _.get(quote, `${product}.locations.${locBld.split('_')[0]}`);
				const bld = _.get(loc, `buildings.${locBld.split('_')[1]}`);
				if (loc && bld) {
					buildings.push(<div>Interest Building</div>);
					buildings.push(
						<div className='wide'>
							{_.get(quote, `addresses.${locBld.split('_')[0]}.fullAddress`, '')}, Building #{_.get(bld, 'order', '')}
						</div>,
					);
				}
			});
		}
		// Put the interest together
		if (_.get(interest, `${product}InterestType`)) {
			additionalInterestList.push(
				<div className='printSection separated'>
					<div>Primary Name</div>
					<div>{getFullName(_.get(interest, 'primaryName', {}))}</div>
					<div>Interest Type</div>
					<div>{convertValue(_.get(interest, `${product}InterestType`), `${product}_InterestType`)}</div>
					<div>Secondary Name</div>
					<div>{getFullName(_.get(interest, 'secondaryName', {}))}</div>
					<div>Address</div>
					<div className='wide'>{_.get(interest, 'address.fullAddress', '')}</div>
					{buildings}
				</div>,
			);
		}
	});

	// If the list is empty, add on the "no additional interests" message
	if (additionalInterestList.length === 0) {
		// We have no additional interests
		additionalInterestList.push(
			<div className='printSection'>
				<div>
					<b>No additional interests</b>
				</div>
			</div>,
		);
	}

	return (
		<div className='noBreak'>
			<h1>Additional Interests</h1>
			<div>{additionalInterestList}</div>
		</div>
	);
};
