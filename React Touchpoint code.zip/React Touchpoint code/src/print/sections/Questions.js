import _ from 'lodash';
import React from 'react';

export const questionSection = (title, questions, definitions) => {
	let questionList = [];
	let questionDisplay = [];

	// First lets build a list of question object with the answers embedded
	_.forIn(questions, (value, key) => {
		//only handle keys that start w/ q
		if (key.startsWith('q')) {
			//get the questions object
			const results = definitions[key];

			//make sure we have data
			if (results) {
				const question = results;
				const match = _.find(results.o, (c) => value === c.value);
				_.set(question, 'answer', match ? match.text : value);
				_.set(question, 'id', key);
				_.set(question, 'answerCode', value);
				questionList.push(question);
			}
		}
	});

	// If there are no questions, just say so
	if (questionList.length === 0) {
		questionDisplay.push(<div>No Questions Found</div>);
	} else {
		// Sort the array to get the questions in order
		questionList.sort((a, b) => a.order - b.order);

		// Step through all the questions
		questionList.forEach((question) => {
			// Check to see if this question is dependent on others
			let showQuestion = !question.da;
			if (question.da) {
				const dependentQ = question.da.split('_')[0];
				const dependentA = question.da.split('_')[1];
				showQuestion = _.find(
					questionList,
					(q) => q.id == dependentQ && q.answerCode == dependentA /* eslint eqeqeq: [0] */,
				);
			}
			// If this question should show up, put it on
			if (showQuestion) {
				questionDisplay.push(<div className='noBreak'>{question.qt.replace(/<[^>]+>/g, '')}</div>);
				questionDisplay.push(<div className='noBreak'>{question.answer}</div>);
			}
		});
	}

	let titleComponent = <h1>{title}</h1>;
	if (title === 'Building Questions') {
		titleComponent = <h4>{title}</h4>;
	}

	return (
		<div className='noBreak'>
			{titleComponent}
			<div className='printSection questions noBreak'>{questionDisplay}</div>
		</div>
	);
};
