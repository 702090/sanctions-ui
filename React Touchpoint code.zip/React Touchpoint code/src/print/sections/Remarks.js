import React from 'react';
import { isBlank } from 'utils/StringFunctions';

export const remarksSection = (remarks, businessDescription) => {
	const remarksList = [];
	let businessDesc = '';

	if (!isBlank(businessDescription)) {
		businessDesc = (
			<React.Fragment>
				<div>
					<b>Business Description provided by Verisk: </b> {businessDescription}
				</div>
				<br />
			</React.Fragment>
		);
	}

	if (!remarks && !businessDescription) {
		// We have no remarks
		remarksList.push(
			<div className='printSection'>
				<div>
					<b>No Remarks Entered</b>
				</div>
			</div>,
		);
	} else {
		remarksList.push(<div>{remarks}</div>);
	}

	return (
		<div className='noBreak'>
			<h1>Remarks</h1>
			{!isBlank(businessDesc) && businessDesc}
			<p>
				<div>{remarksList}</div>
			</p>
		</div>
	);
};
