import { getFieldDisplayArray, updateSectionVisibility } from 'data/FieldVisibility';
import statesJson from 'data/states';
import _ from 'lodash';
import { convertValue, formatCurrency } from 'print/utils/FieldDisplay';
import React from 'react';
import { getQuoteAddress } from 'utils/BusinessFunctions';
import { getVisibility } from 'utils/ScreenFunctions';

const { states } = statesJson;
//
// CAP - Policy Limits
//
export const capPolicySymbolsLimitsSection = (quote) => {
	let cap = _.get(quote, 'cap', {});

	let rows = [];

	//Registration Address
	rows.push(
		<tr>
			<td className='description'>Registration Address</td>
			<td className='value' colSpan='2'>
				{getQuoteAddress(_.get(quote, 'addresses'), _.get(cap, 'registrationAddress', -1))}
			</td>
		</tr>,
	);

	//Liability
	rows.push(
		<tr>
			<td className='description'>Liability</td>
			<td className='title'>Symbol:</td>
			<td className='value'>{convertValue(_.get(cap, 'symbols.liability', ''), 'cap_symbols_liability')}</td>
		</tr>,
	);
	rows.push(
		<tr>
			<td />
			<td className='title'>Limit:</td>
			<td className='value'>{formatCurrency(_.get(cap, 'liabilityLimit', ''), false)}</td>
		</tr>,
	);
	rows.push(
		<tr>
			<td />
			<td className='title'>Limit Type:</td>
			<td className='value'>CSL</td>
		</tr>,
	);

	//Blank line
	rows.push(
		<tr>
			<td colSpan='3'>
				<br />
			</td>
		</tr>,
	);

	//UM /UIM
	rows.push(
		<tr>
			<td className='description'>UM / UIM</td>
			<td className='title'>Symbol:</td>
			<td className='value'>{convertValue(_.get(cap, 'symbols.umUIM', ''), 'cap_symbols_umUIM')}</td>
		</tr>,
	);
	//Blank line
	rows.push(
		<tr>
			<td colSpan='3'>
				<br />
			</td>
		</tr>,
	);

	//PIP
	rows.push(
		<tr>
			<td className='description'>PIP</td>
			<td className='title'>Symbol:</td>
			<td className='value'>{convertValue(_.get(cap, 'symbols.pip', ''), 'cap_symbols_pip_TX')}</td>
		</tr>,
	);
	//Blank line
	rows.push(
		<tr>
			<td colSpan='3'>
				<br />
			</td>
		</tr>,
	);

	//Addtl PIP
	rows.push(
		<tr>
			<td className='description'>Additional PIP</td>
			<td className='title'>Symbol:</td>
			<td className='value'>{convertValue(_.get(cap, 'symbols.additionalPip', ''), 'cap_symbols_additionalPip')}</td>
		</tr>,
	);
	//Blank line
	rows.push(
		<tr>
			<td colSpan='3'>
				<br />
			</td>
		</tr>,
	);

	//Med Pay
	rows.push(
		<tr>
			<td className='description'>Med Pay</td>
			<td className='title'>Symbol:</td>
			<td className='value'>{convertValue(_.get(cap, 'symbols.medPay', ''), 'cap_symbols_medPay')}</td>
		</tr>,
	);
	rows.push(
		<tr>
			<td />
			<td className='title'>Limit:</td>
			<td className='value'>{formatCurrency(_.get(cap, 'medPayLimit', ''), false)}</td>
		</tr>,
	);
	rows.push(
		<tr>
			<td />
			<td className='title'>Limit Type:</td>
			<td className='value'>Each Insured</td>
		</tr>,
	);

	//Blank line
	rows.push(
		<tr>
			<td colSpan='3'>
				<br />
			</td>
		</tr>,
	);

	//Comprehensive
	rows.push(
		<tr>
			<td className='description'>Comprehensive</td>
			<td className='title'>Symbol:</td>
			<td className='value'>{convertValue(_.get(cap, 'symbols.comp', ''), 'cap_symbols_comp')}</td>
		</tr>,
	);
	if (_.get(cap, 'symbols.comp', '0') !== '0') {
		rows.push(
			<tr>
				<td />
				<td className='title'>Deductible:</td>
				<td className='value'>{formatCurrency(_.get(cap, 'compDeductible', ''), false)}</td>
			</tr>,
		);
	}
	//Blank line
	rows.push(
		<tr>
			<td colSpan='3'>
				<br />
			</td>
		</tr>,
	);

	//Collision
	rows.push(
		<tr>
			<td className='description'>Collision</td>
			<td className='title'>Symbol:</td>
			<td className='value'>{convertValue(_.get(cap, 'symbols.coll', ''), 'cap_symbols_coll')}</td>
		</tr>,
	);
	if (_.get(cap, 'symbols.coll', '0') !== '0') {
		rows.push(
			<tr>
				<td />
				<td className='title'>Deductible:</td>
				<td className='value'>{formatCurrency(_.get(cap, 'collDeductible', ''), false)}</td>
			</tr>,
		);
	}
	//Blank line
	rows.push(
		<tr>
			<td colSpan='3'>
				<br />
			</td>
		</tr>,
	);

	//only show towing if comp or collision is selected
	if (_.get(cap, 'symbols.coll', '0') !== '0') {
		//Towing
		rows.push(
			<tr>
				<td className='description'>Towing</td>
				<td className='title'>Symbol:</td>
				<td className='value'>{convertValue(_.get(cap, 'symbols.tow', ''), 'cap_symbols_tow')}</td>
			</tr>,
		);
		//Blank line
		rows.push(
			<tr>
				<td colSpan='3'>
					<br />
				</td>
			</tr>,
		);
	}

	//Premier Endorsement
	rows.push(
		<tr>
			<td className='description'>Premier Endorsement</td>
			<td className='title' />
			<td className='value'>{_.get(cap, 'premier', 'N') === 'Y' ? 'Coverage Accepted' : 'Coverage Declined'}</td>
		</tr>,
	);

	return (
		<div className='nobreak'>
			<h1>Policy Symbols and Limits</h1>
			<div className='capLimitsSection fullWidth'>
				<table className='capLimitsSection'>
					<tbody>{rows}</tbody>
				</table>
			</div>
		</div>
	);
};

//
// CAP - State Limits
//
export const capStateLimitsSection = (quote) => {
	const cap = _.get(quote, 'cap', {});
	const coverages = _.get(cap, 'coverages', {});
	let rows = [];
	let sectionVisibility = {};

	const visibility = getVisibility(getFieldDisplayArray('commercialAuto'), quote);

	_.map(coverages.currentStates, (state) => {
		//find a match for our states
		_.forIn(coverages, (value, key) => {
			// find a match for our key

			if (key === state) {
				//
				// State Header
				//
				rows.push(
					<tr>
						<td>
							<div className='wcpClassAddress'>{_.get(states, state, '')}</div>
						</td>
						<td className='value'>{getQuoteAddress(_.get(quote, 'addresses', []), _.get(value, 'address', -1))}</td>
					</tr>,
				);
				if (visibility['cap.umCombinedSingleLimit'] || visibility['cap.towingLimitDisablement']) {
					rows.push(
						<tr>
							<td className='section' colSpan='2'>
								Limits
							</td>
						</tr>,
					);
					rows.push(
						<tr>
							<td className='title'>Uninsured Motorist Combined Single Limit</td>
							<td className='value'>{formatCurrency(_.get(value, 'umCombinedSingleLimit', ''), false)}</td>
						</tr>,
					);
					if (visibility['cap.towingLimitDisablement']) {
						rows.push(
							<tr>
								<td className='title'>Towing Limit per Disablement</td>
								<td className='value'>{formatCurrency(_.get(value, 'towingLimitDisablement', ''), false)}</td>
							</tr>,
						);
					}
				}

				if (visibility['cap.hiredNonOwn']) {
					rows.push(
						<tr>
							<td className='section' colSpan='2'>
								Hired/NonOwn
							</td>
						</tr>,
					);
					rows.push(
						<tr>
							<td className='title'>Non Owned Auto Liability - Number of Employees</td>
							<td className='value'>{_.get(value, 'hiredNonOwn', '')}</td>
						</tr>,
					);
					rows.push(
						<tr>
							<td className='title'>Hired Auto Liability</td>
							<td className='value'>{_.get(value, 'hiredAutoLiability', '')}</td>
						</tr>,
					);
				}

				if (visibility['cap.otherThanCollisionAnnualCost']) {
					rows.push(
						<tr>
							<td className='section' colSpan='2'>
								Hired Physical Damage
							</td>
						</tr>,
					);
					rows.push(
						<tr>
							<td className='title'>Other than Collision Annual Cost of Hire</td>
							<td className='value'>{formatCurrency(_.get(value, 'otherThanCollisionAnnualCost', ''), false)}</td>
						</tr>,
					);
					rows.push(
						<tr>
							<td className='title'>Other than Collision Deductible</td>
							<td className='value'>{formatCurrency(_.get(value, 'otherThanCollisionDeductible', ''), false)}</td>
						</tr>,
					);
					rows.push(
						<tr>
							<td className='title'>Collision Cost of Hire Amount</td>
							<td className='value'>{formatCurrency(_.get(value, 'collisionCostHireAmount', ''), false)}</td>
						</tr>,
					);
					rows.push(
						<tr>
							<td className='title'>Collision Deductible</td>
							<td className='value'>{formatCurrency(_.get(value, 'collisionDeductible', ''), false)}</td>
						</tr>,
					);
				}

				sectionVisibility = updateSectionVisibility(quote, state);

				if (
					visibility['cap.driveOtherCar'] ||
					((state === 'AR' || state === 'GA') && visibility['cap.umCombinedSingleLimit']) ||
					state === 'KY'
				) {
					rows.push(
						<tr>
							<td className='section' colSpan='2'>
								OptionalCoverages
							</td>
						</tr>,
					);
					if (visibility['cap.driveOtherCar']) {
						rows.push(
							<tr>
								<td className='title'>Would you like to add Drive Other Car Coverage?</td>
								<td className='value'>{convertValue(_.get(value, 'driveOtherCar', ''))}</td>
							</tr>,
						);
						if (_.get(value, 'driveOtherCar', '') === 'Y' && visibility['cap.driveOtherCar']) {
							rows.push(
								<tr>
									<td className='title'>How many individuals are covered?</td>
									<td className='value'>{convertValue(_.get(value, 'numberIndividualsCovered', ''))}</td>
								</tr>,
							);
						}
					}
					//AR
					if (state === 'AR' && visibility['cap.coverages.AR.umDeductible']) {
						rows.push(
							<tr>
								<td className='title'>UM PD Limit</td>
								<td className='value'>{formatCurrency(_.get(value, 'umPdLimit', ''), false)}</td>
							</tr>,
						);
					}
					//GA
					if (state === 'GA' && visibility['cap.coverages.GA.umDeductible']) {
						rows.push(
							<tr>
								<td className='title'>UM Deductible</td>
								<td className='value'>
									{formatCurrency(convertValue(_.get(value, 'umDeductible', ''), 'cap_umDeductible'), false)}
								</td>
							</tr>,
						);
						rows.push(
							<tr>
								<td className='title'>Add On Coverage</td>
								<td className='value'>{convertValue(_.get(value, 'addOnCoverage', ''))}</td>
							</tr>,
						);
					}
					//KY
					if (state === 'KY') {
						rows.push(
							<tr>
								<td className='title'>Tort Rejection Indicator</td>
								<td className='value'>{formatCurrency(_.get(value, 'tortRejectionIndicator', ''), false)}</td>
							</tr>,
						);
					}
				}

				if (
					sectionVisibility[`cap.coverages.${state}.additionalPip`] ||
					sectionVisibility[`cap.coverages.${state}.pipLimit`] ||
					state === 'KY'
				) {
					rows.push(
						<tr>
							<td className='section' colSpan='2'>
								PIP
							</td>
						</tr>,
					);

					//KY
					if (state === 'KY') {
						rows.push(
							<tr>
								<td className='title'>PIP Misc 1</td>
								<td className='value'>{convertValue(_.get(value, 'pipMisc1', ''), 'cap_pipMisc1')}</td>
							</tr>,
						);
						rows.push(
							<tr>
								<td className='title'>PIP Deductible</td>
								<td className='value'>{convertValue(_.get(value, 'pipDeductible', ''), 'cap_pipDeductible')}</td>
							</tr>,
						);
					}

					//TX
					if (state === 'TX' && sectionVisibility[`cap.coverages.${state}.pipLimit`]) {
						rows.push(
							<tr>
								<td className='title'>PIP Limit</td>
								<td className='value'>{formatCurrency(_.get(value, 'pipLimit', ''), false)}</td>
							</tr>,
						);
					}

					if (sectionVisibility[`cap.coverages.${state}.additionalPip`]) {
						rows.push(
							<tr>
								<td className='title'>Additional PIP</td>
								<td className='value'>
									{convertValue(_.get(value, 'additionalPip', ''), `cap_additionalPip${state}`)}
								</td>
							</tr>,
						);
					}
				}
			}
		});
		rows.push(
			<tr>
				<td colSpan='2'>
					<hr className='seperated' />
				</td>
			</tr>,
		);
	});

	rows.pop();

	return (
		<div className='noBreak'>
			<h1>State Coverages and Limits</h1>
			<table className='fullWidth'>
				<tbody>{rows}</tbody>
			</table>
		</div>
	);
};
