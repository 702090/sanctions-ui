import _ from 'lodash';
import { convertValue, formatCurrency } from 'print/utils/FieldDisplay';
import React from 'react';

export const locationInformationSection = (locId, quote) => {
	const location = _.get(quote, `sfg.locations.${locId}`);
	const address = _.get(quote, `addresses.${locId}.fullAddress`);
	const imageUrl = `https://maps.googleapis.com/maps/api/staticmap?zoom=15&size=640x400&maptype=roadmap&center=${address}&markers=color:red|${address}&components=country:US&key=${process.env.REACT_APP_GOOGLE_KEY}`;

	return (
		<div className='noBreak locationPrintSection'>
			<img src={imageUrl} className='locationImage' alt='Location Map' />
			<h2>
				Location #{location.order}
				<br />
				{address}
			</h2>

			<div className='printSection'>
				<div className='medium'>Protection Class</div>
				<div className='medium'>{_.get(location, 'protectionClass', '')}</div>
				<div className='medium'>Property Deductible Amount</div>
				<div className='medium'>
					{convertValue(_.get(location, 'propertyDeductibleAmount', ''), 'sfg_propertyDeductible')}
				</div>
				<div className='medium'>Wind Hail Deductible</div>
				<div className='medium'>{convertValue(_.get(location, 'windHailDeductible', ''), 'sfg_windHail')}</div>
				<div className='medium'>Wind Exclusion</div>
				<div className='medium'>
					{_.get(location, 'windIndicator', '') === '2' ? 'Both - Direct and Indirect Damage' : ''}
				</div>
				<div className='medium'>Gross Sales</div>
				<div className='medium'>{formatCurrency(_.get(location, 'grossSales', ''), false)}</div>
			</div>
		</div>
	);
};
