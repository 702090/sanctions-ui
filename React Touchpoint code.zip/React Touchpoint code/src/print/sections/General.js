import _ from 'lodash';
import { convertValue } from 'print/utils/FieldDisplay';
import React from 'react';
import { displayPolicyNumber, displayQuoteNumber, getFullInsuredName } from 'utils/BusinessFunctions';
import { formatDate } from 'utils/DateFunctions';
import { isBlank } from 'utils/StringFunctions';

export const generalSection = (quote, product, title, icon) => {
	let contents = [];

	if (_.includes(['b', 'c'], _.get(quote, 'status', ''))) {
		contents.push(<div>Policy Number</div>);
		contents.push(<div>{displayPolicyNumber(quote, product === 'sfg' ? 'BPP' : product.toUpperCase())}</div>);
	} else {
		contents.push(<div>Quote Number</div>);
		contents.push(<div>{displayQuoteNumber(quote, product === 'sfg' ? 'BPP' : product.toUpperCase())}</div>);
	}
	contents.push(<div>SAN</div>);
	contents.push(<div>{_.get(quote, product + '.san', 'Not rated yet')}</div>);
	contents.push(<div>Insured Name</div>);
	contents.push(<div>{getFullInsuredName(quote)}</div>);
	contents.push(<div>Effective Date</div>);
	contents.push(<div>{formatDate(quote.effectiveDate, 'text')}</div>);
	contents.push(<div>DBA</div>);
	contents.push(<div>{_.get(quote, 'insuredName.dba', '')}</div>);
	contents.push(<div>Customer Number</div>);
	contents.push(<div>{_.get(quote, 'customerNumber', '')}</div>);
	contents.push(<div>Risk Entered By</div>);
	contents.push(<div>{_.get(quote, 'personEnteringRisk', '')}</div>);
	contents.push(<div>FEIN</div>);
	contents.push(<div>{_.get(quote, 'fein', '')}</div>);
	contents.push(<div>Risk Entered By Email</div>);
	contents.push(<div className='wide'>{_.get(quote, 'personEnteringRiskEmail', '')}</div>);
	contents.push(<div>Mailing Address</div>);
	contents.push(<div className='wide'>{_.get(quote, 'addresses[1].fullAddress', '')}</div>);
	contents.push(<div>Description of Operation</div>);
	contents.push(<div className='wide'>{convertValue(_.get(quote, 'sfg.businessType', ''), 'sfg_businessType')}</div>);
	if (!isBlank(quote.newVenture)) {
		contents.push(<div>New Venture</div>);
		contents.push(<div>{quote.newVenture === 'Y' ? 'Yes' : 'No'}</div>);
		if (!isBlank(quote.numberYearsExperience)) {
			contents.push(<div>Years Experience</div>);
			contents.push(<div>{quote.numberYearsExperience}</div>);
		}
	}

	contents.push();

	return (
		<div className='noBreak'>
			<div className='printPolicyTitle'>
				{icon && <i className={icon} />} {title}
			</div>
			<h1>General Information</h1>
			<div className='printSection'>{contents}</div>
		</div>
	);
};
