import React from 'react';
import { ReferralList } from 'sidebar/Referrals';
import { isBlankR } from 'utils/StringFunctions';

export const referralsSection = (quote, prod) => (
	<div className='noBreak'>
		<h1>Referrals</h1>
		<div className='printReferrals'>
			{isBlankR(quote.referrals) ? (
				<div className='printSection'>
					<div>
						<b>There Are No Referrals For This Risk</b>
					</div>
				</div>
			) : (
				<ReferralList quote={quote} products={['tp', prod]} generateHTML />
			)}
		</div>
	</div>
);
