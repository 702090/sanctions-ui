import React from 'react';
import _ from 'lodash';
import { formatPhoneNumber } from 'print/utils/FieldDisplay';

export const contactInformationSection = (contacts) => {
	let contactsList = [];
	let contents = [];

	if (contacts.allContactsSame !== 'Y') {
		if (_.get(contacts, 'accounting.lastName', '') !== '') {
			contactsList.push({
				name: 'Accounting',
				info: contacts.accounting,
			});
		}
		if (_.get(contacts, 'claims.lastName', '') !== '') {
			contactsList.push({
				name: 'Claims',
				info: contacts.claims,
			});
		}
		if (_.get(contacts, 'inspection.lastName', '') !== '') {
			contactsList.push({
				name: 'Inspection',
				info: contacts.inspection,
			});
		}
		if (_.get(contacts, 'other.lastName', '') !== '') {
			contactsList.push({
				name: 'Other',
				info: contacts.other,
			});
		}
	} else {
		// set them all to accounting
		if (_.get(contacts, 'accounting.lastName', '') !== '') {
			contactsList.push({
				name: 'Accounting',
				info: contacts.accounting,
			});
			contactsList.push({
				name: 'Claims',
				info: contacts.accounting,
			});
			contactsList.push({
				name: 'Other',
				info: contacts.accounting,
			});
			contactsList.push({
				name: 'Inspection',
				info: contacts.accounting,
			});
		}
	}

	_.forIn(contactsList, (value, key) => {
		contents.push(
			<div className='threeColumnSection'>
				<div>{_.get(value, 'name', '')}</div>
				<div>Name</div>
				<div>
					{_.get(value, 'info.firstName', '')} {_.get(value, 'info.lastName', '')}
				</div>

				<div> </div>
				<div>Phone Number</div>
				<div>{formatPhoneNumber(_.get(value, 'info.phone', ''))}</div>

				<div> </div>
				<div>Email Address</div>
				<div>{_.get(value, 'info.email', '')}</div>
			</div>,
		);
	});

	if (contactsList.length === 0) {
		contents.push(
			<div>
				<b>No Contacts Have Been Entered</b>
			</div>,
		);
	}

	return (
		<div className='noBreak'>
			<h1>Contact Information</h1>
			{contents}
		</div>
	);
};
