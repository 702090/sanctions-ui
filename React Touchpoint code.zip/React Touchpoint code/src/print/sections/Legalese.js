import legaleseJson from 'print/Legalese';
import React from 'react';

const { legalese, signatureSection: signatureLines } = legaleseJson;

export const legaleseSection = (includeTitles) => {
	let paras = [];

	//add a blank header
	paras.push(<div className='break-before' />);

	legalese.forEach((statement) => {
		//add title if desired and there is one
		paras.push(
			<p className='legalParagraph'>
				{includeTitles && statement.title !== '' ? <span className='legalHeader'>{statement.title} </span> : ''}
				{statement.text}
			</p>,
		);
	});

	return <div className='legaleseSection'>{paras}</div>;
};

export function signatureSection() {
	let paras = [];

	signatureLines.forEach((signature, index) => {
		paras.push(
			<div className='signatureLine'>
				<span>{signature.text}</span>
				{index > 0 && <span />}
			</div>,
		);
	});

	return <div className='signatureSection'>{paras}</div>;
}
