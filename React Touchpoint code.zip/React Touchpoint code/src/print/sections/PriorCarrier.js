import _ from 'lodash';
import { formatCurrency } from 'print/utils/FieldDisplay';
import React from 'react';
import { formatDate } from 'utils/DateFunctions';

export const priorCarrierSection = (product, newVenture) => {
	if (_.get(product, 'priorCarrier') !== 'Y' || newVenture === 'Y') {
		return (
			<div className='noBreak'>
				<h1>Prior Carrier</h1>
				<div className='printSection'>
					<div className='bold'>{newVenture === 'Y' ? 'New Venture' : 'No Prior Carriers Entered'}</div>
				</div>
			</div>
		);
	}

	let contents = [];

	contents.push(<div>Prior Carrier</div>);
	contents.push(<div>{_.get(product, 'carrierName', '')}</div>);

	if (formatDate(_.get(product, 'expirationDate', '')) !== '') {
		contents.push(<div>Expiration Date</div>);
		contents.push(<div>{formatDate(_.get(product, 'expirationDate', ''))}</div>);
	}

	if (_.get(product, 'priorPolicyNumber', '') !== '') {
		contents.push(<div>Prior Policy Number</div>);
		contents.push(<div>{_.get(product, 'priorPolicyNumber', '')}</div>);
	}
	if (_.get(product, 'annualPremium', '') !== '') {
		contents.push(<div>Prior Premium</div>);
		contents.push(<div>{formatCurrency(_.get(product, 'annualPremium', ''), false)}</div>);
	}

	return (
		<div className='noBreak'>
			<h1>Prior Carrier</h1>
			<div className='printSection'>{contents}</div>
		</div>
	);
};
