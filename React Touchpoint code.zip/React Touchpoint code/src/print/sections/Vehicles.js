import _ from 'lodash';
import React from 'react';
import { toSortedPairList } from 'utils/ObjectFunctions';
import { getQuoteAddress, formatNumberWithCommas } from 'utils/BusinessFunctions';
import { convertValue, formatCurrency } from 'print/utils/FieldDisplay';

import { states } from 'data/states';
import 'print/_print.scss';

export const capVehiclesSection = (quote, deleted) => {
	let contents = [];
	let rows = [];
	let vehicles = _.get(quote, 'cap.vehicles', {});

	if (deleted) {
		vehicles = _.get(quote, 'cap.deletedVehicles', {});
	}

	if (Object.keys(vehicles).length < 1 && !deleted) {
		rows.push(
			<div className='fullWidth'>
				<b>No Vehicles Entered</b>
			</div>,
		);
	} else {
		_.forIn(toSortedPairList(vehicles), (value, key) => {
			const vehicle = value[1];
			rows = [];

			let compDedOverride = '';
			let collDedOverride = '';

			compDedOverride = convertValue(_.get(vehicle, 'otcDedOverride', ''), 'cap_otcDedOverride');
			if (compDedOverride === 'Same as policy') {
				compDedOverride = formatCurrency(_.get(quote, 'cap.compDeductible', ''), false);
			}

			collDedOverride = convertValue(_.get(vehicle, 'collDedOverride', ''), 'cap_collDedOverride');
			if (collDedOverride === 'Same as policy') {
				collDedOverride = formatCurrency(_.get(quote, 'cap.collDeductible', ''), false);
			}

			let truckType = !_.includes(['2', '16', '17', '18'], _.get(vehicle, 'vehType', '999'));

			rows.push(<div>VIN</div>);
			rows.push(<div className='wide'>{vehicle.vin}</div>);

			if (!deleted) {
				rows.push(<div>Garage Location</div>);
				rows.push(<div className='wide'>{getQuoteAddress(quote.addresses, vehicle.garagingLocation)}</div>);
			}

			rows.push(<div>Vehicle Type</div>);
			rows.push(<div>{convertValue(_.get(vehicle, 'vehType', ''), 'cap_vehType')}</div>);
			rows.push(<div>Cost New</div>);
			rows.push(<div>{formatCurrency(_.get(vehicle, 'vehCostNew', ''), false)}</div>);

			let vinVerified = _.get(vehicle, 'vinValidated', false);
			let weightLabel = vinVerified ? 'Gross Vehicle Weight' : 'Vehicle Size';
			let weight = '';

			if (truckType) {
				if (vinVerified) {
					weight =
						_.get(vehicle, 'grossVehWeight', '0') !== '0'
							? formatNumberWithCommas(_.get(vehicle, 'grossVehWeight', '')) + ' lbs'
							: '';
				} else {
					weight =
						_.get(vehicle, 'vehType', '') === 4
							? convertValue(_.get(vehicle, 'vehSize', ''), 'cap_vehSizeTrucksTractors')
							: convertValue(_.get(vehicle, 'vehSize', ''), 'cap_vehSizeTrucks');
				}

				rows.push(<div>{weightLabel}</div>);
				rows.push(<div>{weight}</div>);
				rows.push(<div>Vehicle Radius</div>);
				rows.push(<div>{convertValue(_.get(vehicle, 'vehRadius', ''), 'cap_vehRadius')}</div>);
			}

			if (truckType & !deleted) {
				rows.push(<div>Secondary Class Code</div>);
				rows.push(
					<div className='wide'>
						{convertValue(_.get(vehicle, 'secondaryClassCode', ''), 'cap_secondaryClassCodes')}
					</div>,
				);
			}

			if (!deleted) {
				rows.push(<div>Liability Limit</div>);
				rows.push(<div>{convertValue(_.get(quote, 'cap.liabilityLimit', 'No'), 'cap_liabilityLimit')}</div>);
				rows.push(<div>UM/UIM Coverage</div>);
				rows.push(<div>{convertValue(_.get(vehicle, 'umUimCoverage', ''), '')}</div>);

				rows.push(<div>Comprehensive Coverage</div>);
				rows.push(<div>{convertValue(_.get(vehicle, 'otcCoverage', ''), '')}</div>);
				rows.push(<div>Collision Coverage</div>);
				rows.push(<div>{convertValue(_.get(vehicle, 'collCoverage', ''))}</div>);

				if (_.get(vehicle, 'otcCoverage', 'N') === 'Y' || _.get(vehicle, 'collCoverage', 'N') === 'Y') {
					rows.push(<div>Comp Deductible Override</div>);
					rows.push(<div>{compDedOverride}</div>);
					rows.push(<div>Coll Deductible Override</div>);
					rows.push(<div>{collDedOverride}</div>);
				}

				rows.push(<div>PIP Coverage</div>);
				rows.push(<div>{_.get(quote, 'cap.symbols.pip', '0') === '0' ? 'No' : 'Yes'}</div>);
				rows.push(<div>Additional PIP Coverage</div>);
				rows.push(<div>{convertValue(_.get(vehicle, 'additionalPIPCoverage', 'N'), '')}</div>);

				rows.push(<div>Med Pay</div>);
				rows.push(<div>{formatCurrency(_.get(quote, 'cap.medPayLimit', 'No'), false)}</div>);
				rows.push(<div>Leased Vehicle</div>);
				rows.push(<div>{convertValue(_.get(vehicle, 'leasedVeh', ''))}</div>);
			}

			let vehicleDescriptionFull = '';
			vehicleDescriptionFull += _.get(vehicle, 'vehYear', '') + ' ';
			vehicleDescriptionFull += _.get(vehicle, 'vehMake', '') + ' ';
			vehicleDescriptionFull += _.get(vehicle, 'vehModel', '') + ' ';

			if (!_.isObject(vehicle.description)) {
				vehicleDescriptionFull += _.get(vehicle, 'description', '');
			}

			contents.push(
				<div className='noBreak'>
					<h4>{vehicleDescriptionFull.toUpperCase()}</h4>
					<div className='printSection'>{rows}</div>
				</div>,
			);
		});
	}

	if (!deleted) {
		return (
			<div className='noBreak'>
				<h1>Vehicles</h1>
				<div>{contents}</div>
			</div>
		);
	} else if (contents.length > 0) {
		return (
			<div className='noBreak'>
				<br />
				<br />
				<div className='fullWidth redBottomBorder'>
					<h4Red>Deleted Vehicles</h4Red>
				</div>
				<div>{contents}</div>
			</div>
		);
	} else {
		return <div></div>;
	}
};
