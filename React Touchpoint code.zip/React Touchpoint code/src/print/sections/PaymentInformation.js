import _ from 'lodash';
import { convertValue, formatCurrency } from 'print/utils/FieldDisplay';
import React from 'react';
import { isAccountBill } from 'utils/FieldDisplay';
import { isBlank } from 'utils/StringFunctions';
import productNamesJson from 'data/ProductNames';

const { productNames } = productNamesJson;

export const paymentInformationSection = (quote, product) => {
	const billing = _.get(quote, 'billing', {});
	const cashSlip = _.get(billing, 'cashSlip', {});

	let paymentList = [];

	if (billing) {
		let showAccountBill = isAccountBill(quote, quote);

		if (!billing.billingType) {
			//payment info isn't available yet

			paymentList.push(
				<div className='noBreak'>
					<h1>Payment Information</h1>
					<div>
						<div>
							<b>
								<br />
								No Payment Information is Available Until Quote is Submitted
							</b>
						</div>
					</div>
				</div>,
			);

			return paymentList;
		}

		//Billing Details Header
		paymentList.push(
			<div className='fullWidth'>
				<h4>Billing Details</h4>
			</div>,
		);

		//Billing Details Info
		paymentList.push(
			<div className='printSection'>
				<div>Billing Type</div>
				<div>{convertValue(_.get(billing, 'billingType', ''), 'billing_billingType')}</div>
				<div>Existing Account with CIG</div>
				<div>{convertValue(_.get(billing, 'existingAccountBill', ''))}</div>
				{showAccountBill ? <div>Account</div> : ''}
				{showAccountBill ? <div>{_.get(billing, 'accountBillNumber', '')}</div> : ''}
			</div>,
		);

		//Down Payment Information Header
		paymentList.push(<h4>Down Payment Information</h4>);
		paymentList.push(<div> </div>);

		let downPaymentInformation = [];

		downPaymentInformation.push(<div>Down Payment - {productNames[product]}</div>);
		downPaymentInformation.push(<div>{formatCurrency(_.get(billing, `${product}DownPaymentAmount`, ''), true)}</div>);

		if (!isBlank(_.get(cashSlip, `${product}SlipNumber`, ''))) {
			downPaymentInformation.push(<div>Cash Slip</div>);
			downPaymentInformation.push(<div>{_.get(cashSlip, `${product}SlipNumber`, '')}</div>);
		}

		//Down Payment Information
		paymentList.push(
			<div className='printSection'>
				<div>Down Payment Method</div>
				<div>{convertValue(_.get(quote, 'billing.downPaymentMethod', ''), 'billing_downPaymentMethod')}</div>
				{downPaymentInformation}
			</div>,
		);

		return (
			<div className='noBreak'>
				<h1>Payment Information</h1>
				<div>{paymentList}</div>
			</div>
		);
	}
};
