import _ from 'lodash';
import React from 'react';

export const attachmentsSection = (attachments) => {
	let rows = [];

	if (!attachments) {
		rows.push(
			<div className='printSection'>
				<div>
					<b>No Attachments Found</b>
				</div>
			</div>,
		);
	} else {
		_.forEach(attachments, (element, index) => {
			rows.push(
				<div className='attachmentsSection'>
					<div>Name</div>
					<div>{element.name}</div>
					<div>Type</div>
					<div>{element.mimeType}</div>
				</div>,
			);
		});
	}

	return (
		<div className='noBreak'>
			<h1>Attachments</h1>
			<div>{rows}</div>
		</div>
	);
};
