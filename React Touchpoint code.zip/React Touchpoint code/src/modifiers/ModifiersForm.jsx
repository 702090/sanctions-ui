import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { CheckboxGroup } from 'components/shared/form/CheckboxGroup';
import { DataDisplay } from 'components/shared/form/DataDisplay';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputTextArea } from 'components/shared/form/inputs/InputTextArea';
import { RadioButton } from 'components/shared/form/RadioButton';
import { Select } from 'components/shared/form/Select';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { OptionalSection } from 'components/shared/sections/OptionalSection';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import productNamesJson from 'data/ProductNames';
import selectOptionsJson from 'data/SelectOptions';
import statesJson from 'data/states';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import { ModifierCharacteristics } from 'modifiers/ModifierCharacteristics';
import modifierRuleRangesJson from 'modifiers/ModifierRuleRanges';
import ModifierRules from 'modifiers/ModifierRules';
import React, { Component } from 'react';
import { distillLocations } from 'utils/BusinessFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import { logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { validate } from 'validation/Validate';

const {
	modifier_characteristics,
	modifier_indicators,
	modifier_judgement,
	wcp_smallDeductible1,
	wcp_smallDeductible1_AL_GA,
	wcp_smallDeductible1_AR,
	wcp_smallDeductible1_IA_NE_SD,
	wcp_smallDeductible1_IL,
	wcp_smallDeductible1_KS,
	wcp_smallDeductible1_KY_MS_TN,
	wcp_smallDeductible1_MO,
	wcp_smallDeductible1_NM,
	wcp_smallDeductible1_OK,
	wcp_smallDeductible1_TX,
	wcp_smallDeductible2,
	wcp_smallDeductible2_AR,
	wcp_smallDeductible2_IA,
	wcp_smallDeductible2_KS,
	wcp_smallDeductible2_SD,
	wcp_smallDeductible2_TX,
} = selectOptionsJson;
const { cap_modifier_ranges, sfg_modifier_ranges, wcp_modifier_ranges } = modifierRuleRangesJson;
const { productNames } = productNamesJson;
const { states } = statesJson;

export default class ModifiersForm extends Component {
	static contextType = QuoteContext;

	dirty = false;

	initialValues = {
		sfg: {
			modifiers: {},
		},
		cap: {
			modifiers: {},
		},
		wcp: {
			modifiers: {},
		},
	};

	sfgStates = [];
	capStates = [];
	wcpStates = [];
	newIrpmStates = ['AL', 'AR', 'GA', 'IA', 'IL', 'KS', 'KY', 'MO', 'MS', 'OK', 'SD', 'TN', 'TX'];

	// wcpSmallDeductible2States = ['AR', 'SD', 'IA', 'KS', 'TX'];
	wcpSmallDeductible2States = ['TX'];
	wcpBlanketWaiverStates = ['TX'];
	// wcpBlanketWaiverStates = [
	// 	'AR',
	// 	'IA',
	// 	'KS',
	// 	'MO',
	// 	'NE',
	// 	'NM',
	// 	'OK',
	// 	'SD',
	// 	'TX',
	// ];

	componentDidMount() {
		// If the form is not empty, trigger validation
		runRulesOnLoad(this.formProps, this.formProps.initialValues, ['']);
	}

	getSmallDeductibleListOptions(state) {
		let options = '';
		switch (state) {
			case 'AR':
				options = wcp_smallDeductible1_AR;
				break;
			case 'AL':
			case 'GA':
				options = wcp_smallDeductible1_AL_GA;
				break;
			case 'IL':
				options = wcp_smallDeductible1_IL;
				break;
			case 'KS':
				options = wcp_smallDeductible1_KS;
				break;
			case 'KY':
			case 'MS':
			case 'TN':
				options = wcp_smallDeductible1_KY_MS_TN;
				break;
			case 'MO':
				options = wcp_smallDeductible1_MO;
				break;
			case 'OK':
				options = wcp_smallDeductible1_OK;
				break;
			case 'IA':
			case 'NE':
			case 'SD':
				options = wcp_smallDeductible1_IA_NE_SD;
				break;
			case 'NM':
				options = wcp_smallDeductible1_NM;
				break;
			case 'TX':
				options = wcp_smallDeductible1_TX;
				break;
			default:
				options = wcp_smallDeductible1;
		}
		return options;
	}

	getSmallDeductible2ListOptions(state) {
		let options = '';
		switch (state) {
			case 'AR':
				options = wcp_smallDeductible2_AR;
				break;
			case 'IA':
				options = wcp_smallDeductible2_IA;
				break;
			case 'KS':
				options = wcp_smallDeductible2_KS;
				break;
			case 'SD':
				options = wcp_smallDeductible2_SD;
				break;
			case 'TX':
				options = wcp_smallDeductible2_TX;
				break;
			default:
				options = wcp_smallDeductible2;
		}
		return options;
	}

	cleanRemovedAddresses() {
		const updatedQuote = duplicate(this.context.quote);
		let cleaned = false;
		_.forIn(_.get(updatedQuote, 'sfg.modifiers', {}), (stateList, st) => {
			if (!_.includes(this.sfgStates, st)) {
				_.unset(updatedQuote, `sfg.modifiers.${st}`);
				cleaned = true;
			}
		});
		_.forIn(_.get(updatedQuote, 'wcp.modifiers', {}), (stateList, st) => {
			if (!_.includes(this.wcpStates, st)) {
				_.unset(updatedQuote, `wcp.modifiers.${st}`);
				cleaned = true;
			}
		});
		_.forIn(_.get(updatedQuote, 'cap.modifiers', {}), (stateList, st) => {
			if (!_.includes(this.capStates, st)) {
				_.unset(updatedQuote, `cap.modifiers.${st}`);
				cleaned = true;
			}
		});

		if (cleaned) {
			this.context.updateQuote(updatedQuote, this.props);
		}

		return cleaned;
	}

	UNSAFE_componentWillMount() {
		const quote = _.get(this.context, 'quote');
		const distilledLocations = distillLocations(quote);
		this.sfgStates = distilledLocations.states;
		this.capStates = distilledLocations.capStates;
		this.wcpStates = distilledLocations.wcpStates;
		this.sfgStates.forEach((state) => {
			let irpm = {};
			let modifierRanges = sfg_modifier_ranges;

			_.forIn(_.get(modifierRanges, `${state}.irpm`, {}), (characteristicObj, characteristic) => {
				_.set(irpm, `${characteristic}.modifier`, '');
				_.set(irpm, `${characteristic}.justification`, '');
			});

			this.initialValues.sfg.modifiers[state] = _.merge(
				{
					comments: '',
					indicators: [],
					irpm,
					judgement: '',
					scheduleModifier: '',
					selectedCharacteristics: [],
				},
				_.get(quote, `sfg.modifiers.${state}`),
			);
		});

		this.wcpStates.forEach((state) => {
			let irpm = {};
			let modifierRanges = wcp_modifier_ranges;

			_.forIn(_.get(modifierRanges, `${state}.irpm`, {}), (characteristicObj, characteristic) => {
				_.set(irpm, `${characteristic}.modifier`, '');
				_.set(irpm, `${characteristic}.justification`, '');
			});

			this.initialValues.wcp.modifiers[state] = _.merge(
				{
					comments: '',
					indicators: [],
					irpm,
					judgement: '',
					scheduleModifier: '',
					selectedCharacteristics: [],
					blanketWaiver: '',
					blanketWaiverFlat: '',
					flexibleRatingAdjustment: '',
					smallDeductible1: '',
					smallDeductible2: '',
				},
				_.get(quote, `wcp.modifiers.${state}`),
			);
		});

		this.capStates.forEach((state) => {
			let irpm = {};
			let physicalDamageIrpm = {};
			let modifierRanges = cap_modifier_ranges;

			_.forIn(_.get(modifierRanges, `${state}.irpm`, {}), (characteristicObj, characteristic) => {
				_.set(irpm, `${characteristic}.modifier`, '');
				_.set(irpm, `${characteristic}.justification`, '');
			});

			_.forIn(_.get(modifierRanges, `${state}.physicalDamageIrpm`, {}), (characteristicObj, characteristic) => {
				_.set(physicalDamageIrpm, `${characteristic}.modifier`, '');
				_.set(physicalDamageIrpm, `${characteristic}.justification`, '');
			});

			this.initialValues.cap.modifiers[state] = _.merge(
				{
					comments: '',
					physicalDamageComments: '',
					indicators: [],
					physicalDamageIndicators: [],
					irpm,
					physicalDamageIrpm,
					judgement: '',
					physicalDamageJudgement: '',
					scheduleModifier: '',
					physicalDamageScheduleModifier: '',
					selectedCharacteristics: [],
					selectedPhysicalCharacteristics: [],
				},
				_.get(quote, `cap.modifiers.${state}`),
			);
		});

		this.cleaned = this.cleanRemovedAddresses();
	}

	calculateModifier(product, state, values, setFieldValue, modifierType) {
		// do not default total because if a value exists Insurity requires irpm worksheet information
		// leave the initialization of total as undefined
		let total;
		const modIrpm = `${modifierType}Irpm`;
		const selectedCharacteristics =
			modifierType === 'physicalDamage'
				? values[product].modifiers[state].selectedPhysicalCharacteristics
				: values[product].modifiers[state].selectedCharacteristics;

		const irpm = modifierType
			? duplicate(values[product].modifiers[state][modIrpm])
			: duplicate(values[product].modifiers[state].irpm);

		_.forIn(irpm, (type) => {
			if (isBlank(type.modifier)) {
				type.modifier = 1;
			}

			total = (total || 1) + type.modifier - 1;
		});

		if (modifierType) {
			const modScheduleModifier = `${modifierType}ScheduleModifier`;
			values[product].modifiers[state][modScheduleModifier] =
				total && !isBlank(selectedCharacteristics) ? total.toFixed(2) : '';
		} else {
			values[product].modifiers[state].scheduleModifier =
				total && !isBlank(selectedCharacteristics) ? total.toFixed(2) : '';
		}
	}

	removeCharacteristic = (characteristic, formikProps, modifierType) => {
		const modIrpm = `${modifierType}Irpm`;
		let characteristics =
			modifierType === 'physicalDamage'
				? formikProps.values[characteristic.product].modifiers[characteristic.state].selectedPhysicalCharacteristics
				: formikProps.values[characteristic.product].modifiers[characteristic.state].selectedCharacteristics;

		// removes the characteristic from the selected array
		characteristics = characteristics.filter((option) => option !== characteristic.option);

		// if (isBlank(characteristics)) {
		// 	characteristics = [];
		// } else {
		_.set(
			formikProps,
			modifierType === 'physicalDamage'
				? `values.${characteristic.product}.modifiers.${characteristic.state}.selectedPhysicalCharacteristics`
				: `values.${characteristic.product}.modifiers.${characteristic.state}.selectedCharacteristics`,
			characteristics,
		);
		// }

		// removes the saved characteristic
		if (modifierType === 'physicalDamage') {
			_.set(
				formikProps,
				`values.${characteristic.product}.modifiers.${characteristic.state}.${modIrpm}.${characteristic.option}`,
				{ modifier: '', justification: '' },
			);
		} else {
			_.set(
				formikProps,
				`values.${characteristic.product}.modifiers.${characteristic.state}.irpm.${characteristic.option}`,
				{ modifier: '', justification: '' },
			);
		}

		this.dirty = true;
		this.forceUpdate();
	};

	appendJustification = (characteristic, values, value, modifierType) => {
		let modIrpm = modifierType ? modifierType + 'Irpm' : modifierType;
		const modCharacteristic = modifierType
			? values[characteristic.product].modifiers[characteristic.state][modIrpm][characteristic.option]
			: values[characteristic.product].modifiers[characteristic.state].irpm[characteristic.option];
		let justification = modCharacteristic.justification;
		let searchString = new RegExp(',?\\s?' + value);

		const add = !_.includes(modCharacteristic.justificationsSelected, value);

		if (add) {
			if (justification && justification.length > 0) {
				justification = justification.concat(', ', value);
			} else {
				justification = value;
			}
		} else {
			justification = justification.replace(searchString, '');
			if (justification.startsWith(',')) {
				justification = justification.replace(', ', '');
			}
		}

		_.set(modCharacteristic, 'justification', justification);
	};

	render() {
		return (
			<Formik
				render={(formikProps) => {
					this.dirty = formikProps.dirty || this.dirty;
					this.formProps = formikProps;
					return (
						<Form id='screen'>
							<PageSection
								className='modifierSection'
								title={productNames.sfg}
								name='section_sfg_modifiers'
								errors={formikProps.errors}
							>
								{this.sfgStates.map((state) => {
									const stateName = states[state];
									const selectedCharacteristics = formikProps.values.sfg.modifiers[state].selectedCharacteristics || [];
									const filteredCharacteristics = _.get(modifier_characteristics, `${state}.bpp`, []).filter(
										(option) => !_.includes(selectedCharacteristics, option.value),
									);

									return (
										<PageSection title={stateName} errors={formikProps.errors} key={state}>
											<div className='flexFieldsLong modifierStateCharacteristic'>
												<Field
													key={state}
													name={`sfg.modifiers.${state}.scheduleModifier`}
													label='Schedule Modifier'
													component={_.includes(this.newIrpmStates, state) ? DataDisplay : InputNumber}
													decimalScale={2}
													width='tiny'
													maxLength='4'
													optional={selectedCharacteristics.length > 0 ? false : true}
												/>
												{_.includes(this.newIrpmStates, state) && (
													<div className='addCoverage'>
														<Field
															name={`sfg.modifiers.${state}.sfgModifierCharacteristics`}
															label='Characteristics'
															component={Select}
															options={filteredCharacteristics}
															search
														/>
														<SimpleButton
															content='Add Characteristic'
															id='AddCharacteristic'
															primary
															onClick={() => {
																const data = formikProps.values.sfg.modifiers[state].sfgModifierCharacteristics || '';
																if (!isBlank(data)) {
																	if (selectedCharacteristics) {
																		selectedCharacteristics.push(data);
																	} else {
																		selectedCharacteristics = [data];
																	}
																}

																formikProps.values.sfg.modifiers[state].sfgModifierCharacteristics = '';
																_.set(
																	formikProps,
																	`values.sfg.modifiers.${state}.selectedCharacteristics`,
																	selectedCharacteristics,
																);
																this.forceUpdate();
															}}
														/>
													</div>
												)}
											</div>
											{selectedCharacteristics.map((characteristic) => {
												let title;

												switch (characteristic) {
													case 'management':
														title = 'Management';
														break;
													case 'location':
														title = 'Location';
														break;
													case 'buildingFeatures':
														title = 'Building Features';
														break;
													case 'premisesAndEquipment':
														title = 'Premises And Equipment';
														break;
													case 'employees':
														title = 'Employees';
														break;
													case 'protection':
														title = 'Protection';
														break;
													default:
														break;
												}

												return (
													<ModifierCharacteristics
														characteristic={{
															title,
															product: 'sfg',
															state,
															option: characteristic,
														}}
														key={title}
														values={formikProps.values}
														setFieldValue={formikProps.setFieldValue}
														removeCharacteristic={(option) => this.removeCharacteristic(option, formikProps)}
														calculateModifier={() => {
															this.calculateModifier('sfg', state, formikProps.values, formikProps.setFieldValue);
														}}
														appendJustification={this.appendJustification}
													/>
												);
											})}

											{selectedCharacteristics.length > 0 && (
												<React.Fragment>
													<Field
														name={`sfg.modifiers.${state}.indicators`}
														label='Based on a review of the information contained in the: '
														options={modifier_indicators}
														component={CheckboxGroup}
													/>
													{_.includes(formikProps.values.sfg.modifiers[state].indicators, 'other') && (
														<Field
															name={`sfg.modifiers.${state}.comments`}
															label='Comments:'
															component={InputTextArea}
															fieldDisplay={true}
															maxLength={200}
														/>
													)}
													<Field
														name={`sfg.modifiers.${state}.judgement`}
														label='I judge this risk to be: '
														component={RadioButton}
														options={modifier_judgement}
														width='large'
													/>
												</React.Fragment>
											)}
										</PageSection>
									);
								})}
							</PageSection>
							{!isBlank(this.capStates) && (
								<PageSection
									className='modifierSection'
									title={productNames.cap}
									name='section_cap_modifiers'
									errors={formikProps.errors}
								>
									{this.capStates.map((state) => {
										const stateName = states[state];
										const selectedCharacteristics =
											formikProps.values.cap.modifiers[state].selectedCharacteristics || [];
										const filteredCharacteristics = _.get(modifier_characteristics, `${state}.cap`, []).filter(
											(option) =>
												!_.includes(
													[
														...selectedCharacteristics,
														// Dispersion is only for physical damage
														'dispersionValuesInsured',
													],
													option.value,
												),
										);
										const selectedPhysicalCharacteristics =
											formikProps.values.cap.modifiers[state].selectedPhysicalCharacteristics || [];
										const filteredPhysicalCharacteristics = _.get(modifier_characteristics, `${state}.cap`, []).filter(
											(option) => !_.includes(selectedPhysicalCharacteristics, option.value),
										);

										return (
											<PageSection title={stateName} errors={formikProps.errors} key={state}>
												<div className='flexFieldsLong modifierStateCharacteristic'>
													<Field
														name={
															_.includes(this.newIrpmStates, state)
																? `cap.modifiers.${state}.scheduleModifier`
																: `cap.modifiers.${state}.liabilityModifications`
														}
														label={'Liability Modifications'}
														component={_.includes(this.newIrpmStates, state) ? DataDisplay : InputNumber}
														decimalScale={2}
														width='tiny'
														maxLength='4'
														optional={selectedCharacteristics.length > 0 ? false : true}
													/>
													{_.includes(this.newIrpmStates, state) && (
														<div className='addCoverage'>
															<Field
																name={`cap.modifiers.${state}.capModifierCharacteristics`}
																label='Characteristics'
																component={Select}
																options={filteredCharacteristics}
																search
															/>
															<SimpleButton
																content='Add Characteristic'
																id='AddCharacteristic'
																primary
																onClick={() => {
																	const data = formikProps.values.cap.modifiers[state].capModifierCharacteristics || '';
																	if (!isBlank(data)) {
																		if (selectedCharacteristics) {
																			selectedCharacteristics.push(data);
																		} else {
																			selectedCharacteristics = [data];
																		}
																	}

																	formikProps.values.cap.modifiers[state].capModifierCharacteristics = '';
																	_.set(
																		formikProps,
																		`values.cap.modifiers.${state}.selectedCharacteristics`,
																		selectedCharacteristics,
																	);
																	this.forceUpdate();
																}}
															/>
														</div>
													)}
												</div>
												{selectedCharacteristics.map((characteristic) => {
													let title;
													switch (characteristic) {
														case 'management':
															title = 'Management';
															break;
														case 'employees':
															title = 'Employees';
															break;
														case 'equipment':
															title = 'Equipment';
															break;
														case 'safetyOrganization':
															title = 'Safety Organization';
															break;
														default:
															break;
													}

													return (
														<ModifierCharacteristics
															characteristic={{
																title,
																product: 'cap',
																state,
																option: characteristic,
															}}
															key={title}
															values={formikProps.values}
															setFieldValue={formikProps.setFieldValue}
															removeCharacteristic={(option) => this.removeCharacteristic(option, formikProps)}
															calculateModifier={() => {
																this.calculateModifier('cap', state, formikProps.values, formikProps.setFieldValue);
															}}
															appendJustification={this.appendJustification}
														/>
													);
												})}

												{selectedCharacteristics.length > 0 && (
													<React.Fragment>
														<Field
															name={`cap.modifiers.${state}.indicators`}
															label='Based on a review of the information contained in the: '
															options={modifier_indicators}
															component={CheckboxGroup}
														/>
														{_.includes(formikProps.values.cap.modifiers[state].indicators, 'other') && (
															<Field
																name={`cap.modifiers.${state}.comments`}
																label='Comments:'
																component={InputTextArea}
																fieldDisplay={true}
																maxLength={200}
															/>
														)}
														<Field
															name={`cap.modifiers.${state}.judgement`}
															label='I judge this risk to be: '
															component={RadioButton}
															options={modifier_judgement}
															width='large'
														/>
													</React.Fragment>
												)}
												<div className='flexFieldsLong modifierStateCharacteristic'>
													<Field
														name={
															_.includes(this.newIrpmStates, state)
																? `cap.modifiers.${state}.physicalDamageScheduleModifier`
																: `cap.modifiers.${state}.physicalDamageModifications`
														}
														label={'Physical Damage Modifications'}
														component={_.includes(this.newIrpmStates, state) ? DataDisplay : InputNumber}
														decimalScale={2}
														width='tiny'
														maxLength='4'
														optional={selectedPhysicalCharacteristics.length > 0 ? false : true}
													/>
													{_.includes(this.newIrpmStates, state) && (
														<div className='addCoverage'>
															<Field
																name={`cap.modifiers.${state}.capPhysicalDamageCharacteristics`}
																label='Characteristics'
																component={Select}
																options={filteredPhysicalCharacteristics}
																search
															/>
															<SimpleButton
																content='Add Characteristic'
																id='AddCharacteristic'
																primary
																onClick={() => {
																	const data =
																		formikProps.values.cap.modifiers[state].capPhysicalDamageCharacteristics || '';
																	if (!isBlank(data)) {
																		if (selectedPhysicalCharacteristics) {
																			selectedPhysicalCharacteristics.push(data);
																		} else {
																			selectedPhysicalCharacteristics = [data];
																		}
																	}

																	formikProps.values.cap.modifiers[state].capPhysicalDamageCharacteristics = '';
																	_.set(
																		formikProps,
																		`values.cap.modifiers.${state}.selectedPhysicalCharacteristics`,
																		selectedPhysicalCharacteristics,
																	);
																	this.forceUpdate();
																}}
															/>
														</div>
													)}
												</div>
												{selectedPhysicalCharacteristics.map((characteristic) => {
													let title;

													switch (characteristic) {
														case 'management':
															title = 'Management';
															break;
														case 'employees':
															title = 'Employees';
															break;
														case 'equipment':
															title = 'Equipment';
															break;
														case 'safetyOrganization':
															title = 'Safety Organization';
															break;
														case 'dispersionValuesInsured':
															title = 'Dispersion or Concentration of Values Insured';
															break;
														default:
															break;
													}

													return (
														<ModifierCharacteristics
															characteristic={{
																title,
																product: 'cap',
																state,
																option: characteristic,
															}}
															key={title}
															values={formikProps.values}
															setFieldValue={formikProps.setFieldValue}
															removeCharacteristic={(option) =>
																this.removeCharacteristic(option, formikProps, 'physicalDamage')
															}
															calculateModifier={() => {
																this.calculateModifier(
																	'cap',
																	state,
																	formikProps.values,
																	formikProps.setFieldValue,
																	'physicalDamage',
																);
															}}
															modifierType='physicalDamage'
															appendJustification={this.appendJustification}
														/>
													);
												})}

												{selectedPhysicalCharacteristics.length > 0 && (
													<React.Fragment>
														<Field
															name={`cap.modifiers.${state}.physicalDamageIndicators`}
															label='Based on a review of the information contained in the: '
															options={modifier_indicators}
															component={CheckboxGroup}
														/>
														{_.includes(formikProps.values.cap.modifiers[state].physicalDamageIndicators, 'other') && (
															<Field
																name={`cap.modifiers.${state}.physicalDamageComments`}
																label='Comments:'
																component={InputTextArea}
																fieldDisplay={true}
																maxLength={200}
															/>
														)}
														<Field
															name={`cap.modifiers.${state}.physicalDamageJudgement`}
															label='I judge this risk to be: '
															component={RadioButton}
															options={modifier_judgement}
															width='large'
														/>
													</React.Fragment>
												)}
											</PageSection>
										);
									})}
								</PageSection>
							)}
							{!isBlank(this.wcpStates) && (
								<PageSection
									className='modifierSection'
									title={productNames.wcp}
									name='section_wcp_modifiers'
									errors={formikProps.errors}
								>
									{this.wcpStates.map((state) => {
										const stateName = states[state];
										const smallDedutibleName = _.includes(this.wcpSmallDeductible2States, state)
											? 'Small Deductible 1'
											: 'Small Deductible';
										const smallDeductible1Options = this.getSmallDeductibleListOptions(state);
										const smallDeductible2Options = this.getSmallDeductible2ListOptions(state);
										const selectedCharacteristics =
											formikProps.values.wcp.modifiers[state].selectedCharacteristics || [];

										const filteredCharacteristics = _.get(modifier_characteristics, `${state}.wcp`, []).filter(
											(option) => !_.includes(selectedCharacteristics, option.value),
										);

										return (
											<PageSection title={stateName} errors={formikProps.errors} key={state}>
												<div className='flexFieldsLong modifierStateCharacteristic'>
													{state !== 'NE' && (
														<Field
															name={`wcp.modifiers.${state}.scheduleModifier`}
															label={'Schedule Modifier'}
															component={_.includes(this.newIrpmStates, state) ? DataDisplay : InputNumber}
															decimalScale={2}
															width='tiny'
															maxLength='4'
															optional={selectedCharacteristics.length > 0 ? false : true}
														/>
													)}
													{_.includes(this.newIrpmStates, state) && (
														<div className='addCoverage'>
															<Field
																name={`wcp.modifiers.${state}.wcpModifierCharacteristics`}
																label='Characteristics'
																component={Select}
																options={filteredCharacteristics}
																search
															/>
															<SimpleButton
																content='Add Characteristic'
																id='WCPAddCharacteristic'
																primary
																onClick={() => {
																	const data = formikProps.values.wcp.modifiers[state].wcpModifierCharacteristics || '';
																	if (!isBlank(data)) {
																		if (selectedCharacteristics) {
																			selectedCharacteristics.push(data);
																		} else {
																			selectedCharacteristics = [data];
																		}
																	}

																	formikProps.values.wcp.modifiers[state].wcpModifierCharacteristics = '';
																	_.set(
																		formikProps,
																		`values.wcp.modifiers.${state}.selectedCharacteristics`,
																		selectedCharacteristics,
																	);
																	this.forceUpdate();
																}}
															/>
														</div>
													)}
												</div>
												{selectedCharacteristics.map((characteristic) => {
													let title;

													switch (characteristic) {
														case 'premises':
															title = 'Premises';
															break;
														case 'classificationPeculiarities':
															title = 'Classification Peculiarities';
															break;
														case 'medicalFacilities':
															title = 'Medical Facilities';
															break;
														case 'safetyDevices':
															title = 'Safety Devices';
															break;
														case 'employees':
															title = 'Employees';
															break;
														case 'managementCooperationWithInsuranceCarrier':
															title = 'Management: Cooperation With Insurance Carrier';
															break;
														case 'managementSafetyOrganization':
															title = 'Management: Safety Organization';
															break;
														default:
															break;
													}

													return (
														<ModifierCharacteristics
															characteristic={{
																title,
																product: 'wcp',
																state,
																option: characteristic,
															}}
															key={title}
															values={formikProps.values}
															setFieldValue={formikProps.setFieldValue}
															removeCharacteristic={(option) => this.removeCharacteristic(option, formikProps)}
															calculateModifier={() => {
																this.calculateModifier('wcp', state, formikProps.values, formikProps.setFieldValue);
															}}
															appendJustification={this.appendJustification}
														/>
													);
												})}

												{selectedCharacteristics.length > 0 && (
													<React.Fragment>
														<Field
															name={`wcp.modifiers.${state}.indicators`}
															label='Based on a review of the information contained in the: '
															options={modifier_indicators}
															component={CheckboxGroup}
														/>
														{_.includes(formikProps.values.wcp.modifiers[state].indicators, 'other') && (
															<Field
																name={`wcp.modifiers.${state}.comments`}
																label='Comments:'
																component={InputTextArea}
																fieldDisplay={true}
																maxLength={200}
															/>
														)}
														<Field
															name={`wcp.modifiers.${state}.judgement`}
															label='I judge this risk to be: '
															component={RadioButton}
															options={modifier_judgement}
															width='large'
														/>
													</React.Fragment>
												)}

												{_.includes(this.wcpBlanketWaiverStates, state) && (
													<React.Fragment>
														<OptionalSection
															name={`wcp.modifiers.${state}.group_blanket_modifiers`}
															errors={formikProps.errors}
															text='Only one Blanket modifer option can be entered.'
															touched={
																_.get(formikProps.touched, `wcp.modifiers.${state}.blanketWaiver`, false) ||
																_.get(formikProps.touched, `wcp.modifiers.${state}.blanketWaiver`, false)
															}
														>
															{state === 'TX' && (
																<Field
																	name={`wcp.modifiers.${state}.blanketWaiver`}
																	label={'Blanket Waiver'}
																	component={RadioButton}
																	optional
																/>
															)}

															{state !== 'TX' && false && (
																<React.Fragment>
																	<Field
																		name={`wcp.modifiers.${state}.blanketWaiver`}
																		label={'Blanket Waiver'}
																		component={InputNumber}
																		decimalScale={2}
																		fixedDecimalScale
																		width='small'
																		maxLength='4'
																		optional
																	/>
																	<Field
																		name={`wcp.modifiers.${state}.blanketWaiverFlat`}
																		label={'Blanket Waiver (FlatCharge)'}
																		component={InputNumber}
																		width='small'
																		maxLength='6'
																		optional
																	/>
																</React.Fragment>
															)}
														</OptionalSection>
													</React.Fragment>
												)}
												{state === 'NE' && (
													<Field
														name={`wcp.modifiers.${state}.flexibleRatingAdjustment`}
														label={'Flexible Rating Adjustment'}
														component={InputNumber}
														decimalScale={2}
														width='tiny'
														maxLength='4'
														optional
													/>
												)}

												{state !== 'TX' && false && (
													<React.Fragment>
														<Field
															name={`wcp.modifiers.${state}.smallDeductible1`}
															label={smallDedutibleName}
															component={Select}
															options={smallDeductible1Options}
															width='tiny'
															optionalSelect
														/>
														{_.includes(this.wcpSmallDeductible2States, state) && (
															<Field
																name={`wcp.modifiers.${state}.smallDeductible2`}
																label={'Small Deductible 2'}
																component={Select}
																options={smallDeductible2Options}
																width='small'
																optionalSelect
															/>
														)}
													</React.Fragment>
												)}
												{state === 'TX' && (
													<React.Fragment>
														{!_.isNumber(_.get(this.context, 'quote.rates.wcp', '')) && (
															<Field
																name='wcpSmallDeductible'
																label='Small Deductible'
																value='The Small Deductible is not available until you rate this quote as there is a minimum premium applicable.'
																component={DataDisplay}
															/>
														)}
														{_.isNumber(_.get(this.context, 'quote.rates.wcp', '')) && (
															<React.Fragment>
																<Field
																	name={`wcp.modifiers.${state}.smallDeductible1`}
																	label={smallDedutibleName}
																	component={Select}
																	options={smallDeductible1Options}
																	width='tiny'
																	optionalSelect
																/>
																{_.includes(this.wcpSmallDeductible2States, state) && (
																	<Field
																		name={`wcp.modifiers.${state}.smallDeductible2`}
																		label={'Small Deductible 2'}
																		component={Select}
																		options={smallDeductible2Options}
																		width='small'
																		optionalSelect
																	/>
																)}
															</React.Fragment>
														)}
													</React.Fragment>
												)}
											</PageSection>
										);
									})}
								</PageSection>
							)}
							<NavigationButtons
								formikProps={formikProps}
								back
								location={this.props.location}
								history={this.props.history}
							/>
						</Form>
					);
				}}
				initialValues={this.initialValues}
				onSubmit={(values, formikActions) => {
					//*This is needed because blanking out values would not save that field change to the quote
					const valuesWithRequiredStructure = duplicate(ModifierRules.requiredStructure(this.context.quote, values));
					_.merge(valuesWithRequiredStructure, values);
					return this.context.onSubmit(
						valuesWithRequiredStructure,
						this.dirty || this.cleaned,
						false,
						false,
						this.props,
					);
				}}
				validate={(values) => {
					const validResults = validate(
						values,
						ModifierRules.rules(this.context.quote, values),
						duplicate(ModifierRules.requiredStructure(this.context.quote, values)),
					);
					logPageErrors(validResults, this.formProps.touched, 'all');

					return validResults;
				}}
			/>
		);
	}
}
