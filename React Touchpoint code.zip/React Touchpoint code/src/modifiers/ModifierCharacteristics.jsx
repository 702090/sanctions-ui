import { RemoveCoverageButton } from 'components/shared/buttons/RemoveCoverageButton';
import { CheckboxGroup } from 'components/shared/form/CheckboxGroup';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputTextArea } from 'components/shared/form/inputs/InputTextArea';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import selectOptionsJson from 'data/SelectOptions';
import { Field } from 'formik';
import React from 'react';

const {
	modifier_building_features_justifications,
	modifier_employees_justifications,
	modifier_equipment_justifications,
} = selectOptionsJson;

export const ModifierCharacteristics = ({
	characteristic,
	values,
	setFieldValue,
	removeCharacteristic,
	calculateModifier,
	appendJustification,
	modifierType,
}) => {
	const { title, product, state, option } = characteristic;
	const modifierPath = modifierType
		? `${product}.modifiers.${state}.${modifierType}Irpm`
		: `${product}.modifiers.${state}.irpm`;
	const options = ['buildingFeatures', 'equipment', 'employees'];
	let optionJustifications;

	switch (option) {
		case 'buildingFeatures':
			optionJustifications = modifier_building_features_justifications;
			break;
		case 'employees':
			optionJustifications = modifier_employees_justifications;
			break;
		case 'equipment':
			optionJustifications = modifier_equipment_justifications;
			break;
		default:
			break;
	}

	return (
		<QuoteContext.Consumer>
			{(context) => (
				<PageSection
					className='characteristicsSection'
					title={title}
					name={
						modifierType
							? `section_${product}_${state}_${modifierType}irpm_${option}`
							: `section_${product}_${state}_irpm_${option}`
					}
				>
					<RemoveCoverageButton
						onClick={(event) => {
							removeCharacteristic(characteristic, values, modifierType);
							calculateModifier(product, state, values, setFieldValue, modifierType);
						}}
					/>
					<div className='flexFieldsLong modifierStateCharacteristic'>
						<Field
							name={`${modifierPath}.${option}.modifier`}
							label='Modifier'
							decimalScale={2}
							width='tiny'
							maxLength='4'
							component={InputNumber}
							additionalOnBlur={() => {
								calculateModifier(product, state, values, setFieldValue, modifierType);
							}}
						/>
						<Field
							name={`${modifierPath}.${option}.justification`}
							label='Justification'
							subLabel='(max 250 characters)'
							component={InputTextArea}
							maxLength={250}
							width='medium'
							className='modifierJustification'
						/>
						{options.includes(option) && (
							<Field
								name={`${modifierPath}.${option}.justificationsSelected`}
								label='Reasons'
								component={CheckboxGroup}
								options={optionJustifications}
								width='tiny'
								optional
								additionalOnChange={(value) => appendJustification(characteristic, values, value, modifierType)}
							/>
						)}
					</div>
				</PageSection>
			)}
		</QuoteContext.Consumer>
	);
};
