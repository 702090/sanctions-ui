import { requiredQuestionMessage } from 'data/FieldVisibility';
import _ from 'lodash';
import modifierRulesRangesJson from 'modifiers/ModifierRuleRanges';
import { isEmployee } from 'utils/BusinessFunctions';
import { isBlank, isBlankZ } from 'utils/StringFunctions';

const { cap_modifier_ranges, sfg_modifier_ranges, wcp_modifier_ranges } = modifierRulesRangesJson;

class ModifierRules {
	static requiredStructure(quote, values) {
		let outputStructure = {
			section_sfg_modifiers: '',
			section_cap_modifiers: '',
			section_wcp_modifiers: '',
			sfg: { modifiers: {} },
			cap: { modifiers: {} },
			wcp: { modifiers: {} },
		};

		_.forIn(_.get(values, 'sfg.modifiers', {}), (states, st) => {
			let irpm = {};
			let modifierRanges = sfg_modifier_ranges;

			_.forIn(_.get(modifierRanges, `${st}.irpm`, {}), (characteristicObj, characteristic) => {
				_.set(irpm, `${characteristic}.modifier`, '');
				_.set(irpm, `${characteristic}.justification`, '');
			});

			outputStructure.sfg.modifiers[st] = {
				comments: '',
				indicators: [],
				irpm,
				judgement: '',
				scheduleModifier: '',
				selectedCharacteristics: [],
			};
		});

		if (_.includes(quote.products, 'wcp')) {
			_.forIn(_.get(values, 'wcp.modifiers', {}), (states, st) => {
				let irpm = {};
				let modifierRanges = wcp_modifier_ranges;

				_.forIn(_.get(modifierRanges, `${st}.irpm`, {}), (characteristicObj, characteristic) => {
					_.set(irpm, `${characteristic}.modifier`, '');
					_.set(irpm, `${characteristic}.justification`, '');
				});

				outputStructure.wcp.modifiers[st] = {
					comments: '',
					indicators: [],
					irpm,
					judgement: '',
					selectedCharacteristics: [],
					scheduleModifier: '',
					group_blanket_modifiers: '',
					blanketWaiver: '',
					blanketWaiverFlat: '',
					flexibleRatingAdjustment: '',
					smallDeductible1: '',
					smallDeductible2: '',
				};
			});
		}

		if (_.includes(quote.products, 'cap')) {
			_.forIn(_.get(values, 'cap.modifiers', {}), (states, st) => {
				let irpm = {};
				let physicalDamageIrpm = {};
				let modifierRanges = cap_modifier_ranges;

				_.forIn(_.get(modifierRanges, `${st}.irpm`, {}), (characteristicObj, characteristic) => {
					_.set(irpm, `${characteristic}.modifier`, '');
					_.set(irpm, `${characteristic}.justification`, '');
				});

				_.forIn(_.get(modifierRanges, `${st}.physicalDamageIrpm`, {}), (characteristicObj, characteristic) => {
					_.set(physicalDamageIrpm, `${characteristic}.modifier`, '');
					_.set(physicalDamageIrpm, `${characteristic}.justification`, '');
				});

				outputStructure.cap.modifiers[st] = {
					comments: '',
					physicalDamageComments: '',
					indicators: [],
					physicalDamageIndicators: [],
					irpm,
					physicalDamageIrpm,
					judgement: '',
					physicalDamageJudgement: '',
					scheduleModifier: '',
					physicalDamageScheduleModifier: '',
					selectedCharacteristics: [],
					selectedPhysicalCharacteristics: [],
				};
			});
		}
		return outputStructure;
	}

	static rules(quote, values) {
		// use values for current page validation
		// use quote for external page validation
		let sfgModifiersAdded = false;
		const sfgModifiers = _.get(values, 'sfg.modifiers', {});
		_.forIn(
			sfgModifiers,
			(stateModifier) =>
				(sfgModifiersAdded =
					sfgModifiersAdded ||
					(!isBlank(_.get(stateModifier, 'scheduleModifier')) && _.get(stateModifier, 'scheduleModifier') !== 1)),
		);
		const rate = _.get(quote, 'rates.sfg', '');
		let sfgModifierMessage =
			'Safeguard premium must be over $1,000 for modifiers to apply. Please remove or edit the modifiers for this quote.';
		if (!isEmployee()) {
			sfgModifierMessage = 'There is a problem with the modifiers on this quote, please contact your underwriter';
		}

		const irpmRules = (product, state, selectedCharacteristics, modifierType) => {
			let modifierRanges;
			const modIrpm = `${modifierType}Irpm`;

			switch (product) {
				case 'sfg':
					modifierRanges = sfg_modifier_ranges;
					break;
				case 'cap':
					modifierRanges = cap_modifier_ranges;
					break;
				case 'wcp':
					modifierRanges = wcp_modifier_ranges;
					break;
				default:
					break;
			}

			let rulesStructure = {};
			const calculatedIrpm = modifierType ? modIrpm : 'irpm';

			_.forIn(modifierRanges, (rangeStateObj, rangeState) => {
				_.forIn(rangeStateObj[calculatedIrpm], (characteristicObj, characteristic) => {
					const min = modifierType
						? modifierRanges[state][modIrpm][characteristic].min
						: modifierRanges[state][calculatedIrpm][characteristic].min;
					const max = modifierType
						? modifierRanges[state][modIrpm][characteristic].max
						: modifierRanges[state][calculatedIrpm][characteristic].max;

					_.set(rulesStructure, `${characteristic}.modifier`, [
						[
							(value) => {
								return !(
									selectedCharacteristics.length > 0 &&
									_.includes(selectedCharacteristics, characteristic) &&
									(isBlank(value) || value < min || value > max)
								);
							},
							`This modifier must be between ${min} and ${max}.`,
						],
					]);
					_.set(rulesStructure, `${characteristic}.justification`, [
						[
							(value) => {
								return !(
									selectedCharacteristics.length > 0 &&
									_.includes(selectedCharacteristics, characteristic) &&
									isBlank(value)
								);
							},
							requiredQuestionMessage,
						],
					]);
				});
			});

			return rulesStructure;
		};

		return {
			section_sfg_modifiers: [
				[
					(value) => !sfgModifiersAdded || isBlank(rate) || rate === 'error' || _.toNumber(rate) > 1000,
					sfgModifierMessage,
				],
			],
			sfg: {
				modifiers: {
					AL: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= sfg_modifier_ranges.AL.scheduleModifier.min &&
										value <= sfg_modifier_ranges.AL.scheduleModifier.max),
								`This modifier must be between ${sfg_modifier_ranges.AL.scheduleModifier.min} and ${sfg_modifier_ranges.AL.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('sfg', 'AL', _.get(values, 'sfg.modifiers.AL.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.AL.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.sfg.modifiers.AL.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.AL.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					AR: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= sfg_modifier_ranges.AR.scheduleModifier.min &&
										value <= sfg_modifier_ranges.AR.scheduleModifier.max),
								`This modifier must be between ${sfg_modifier_ranges.AR.scheduleModifier.min} and ${sfg_modifier_ranges.AR.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('sfg', 'AR', _.get(values, 'sfg.modifiers.AR.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.AR.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.sfg.modifiers.AR.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.AR.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					GA: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= sfg_modifier_ranges.GA.scheduleModifier.min &&
										value <= sfg_modifier_ranges.GA.scheduleModifier.max),
								`This modifier must be between ${sfg_modifier_ranges.GA.scheduleModifier.min} and ${sfg_modifier_ranges.GA.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('sfg', 'GA', _.get(values, 'sfg.modifiers.GA.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.GA.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.sfg.modifiers.GA.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.GA.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					IA: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= sfg_modifier_ranges.IA.scheduleModifier.min &&
										value <= sfg_modifier_ranges.IA.scheduleModifier.max),
								`This modifier must be between ${sfg_modifier_ranges.IA.scheduleModifier.min} and ${sfg_modifier_ranges.IA.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('sfg', 'IA', _.get(values, 'sfg.modifiers.IA.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.IA.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.sfg.modifiers.IA.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.IA.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					IL: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= sfg_modifier_ranges.IL.scheduleModifier.min &&
										value <= sfg_modifier_ranges.IL.scheduleModifier.max),
								`This modifier must be between ${sfg_modifier_ranges.IL.scheduleModifier.min} and ${sfg_modifier_ranges.IL.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('sfg', 'IL', _.get(values, 'sfg.modifiers.IL.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.IL.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.sfg.modifiers.IL.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.IL.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					KS: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= sfg_modifier_ranges.KS.scheduleModifier.min &&
										value <= sfg_modifier_ranges.KS.scheduleModifier.max),
								`This modifier must be between ${sfg_modifier_ranges.KS.scheduleModifier.min} and ${sfg_modifier_ranges.KS.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('sfg', 'KS', _.get(values, 'sfg.modifiers.KS.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.KS.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.sfg.modifiers.KS.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.KS.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					KY: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= sfg_modifier_ranges.KY.scheduleModifier.min &&
										value <= sfg_modifier_ranges.KY.scheduleModifier.max),
								`This modifier must be between ${sfg_modifier_ranges.KY.scheduleModifier.min} and ${sfg_modifier_ranges.KY.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('sfg', 'KY', _.get(values, 'sfg.modifiers.KY.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.KY.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.sfg.modifiers.KY.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.KY.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					MO: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= sfg_modifier_ranges.MO.scheduleModifier.min &&
										value <= sfg_modifier_ranges.MO.scheduleModifier.max),
								`This modifier must be between ${sfg_modifier_ranges.MO.scheduleModifier.min} and ${sfg_modifier_ranges.MO.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('sfg', 'MO', _.get(values, 'sfg.modifiers.MO.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.MO.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.sfg.modifiers.MO.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.MO.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					MS: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= sfg_modifier_ranges.MS.scheduleModifier.min &&
										value <= sfg_modifier_ranges.MS.scheduleModifier.max),
								`This modifier must be between ${sfg_modifier_ranges.MS.scheduleModifier.min} and ${sfg_modifier_ranges.MS.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('sfg', 'MS', _.get(values, 'sfg.modifiers.MS.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.MS.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.sfg.modifiers.MS.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.MS.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					NE: {
						scheduleModifier: [
							[
								(value) => isBlankZ(value) || (value >= 0.8 && value <= 1.4),
								'This modifier must be between 0.8 and 1.4.',
							],
						],
					},
					OK: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= sfg_modifier_ranges.OK.scheduleModifier.min &&
										value <= sfg_modifier_ranges.OK.scheduleModifier.max),
								`This modifier must be between ${sfg_modifier_ranges.OK.scheduleModifier.min} and ${sfg_modifier_ranges.OK.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('sfg', 'OK', _.get(values, 'sfg.modifiers.OK.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.OK.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.sfg.modifiers.OK.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.OK.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					SD: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= sfg_modifier_ranges.SD.scheduleModifier.min &&
										value <= sfg_modifier_ranges.SD.scheduleModifier.max),
								`This modifier must be between ${sfg_modifier_ranges.SD.scheduleModifier.min} and ${sfg_modifier_ranges.SD.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('sfg', 'SD', _.get(values, 'sfg.modifiers.SD.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.SD.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.sfg.modifiers.SD.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.SD.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					TN: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= sfg_modifier_ranges.TN.scheduleModifier.min &&
										value <= sfg_modifier_ranges.TN.scheduleModifier.max),
								`This modifier must be between ${sfg_modifier_ranges.TN.scheduleModifier.min} and ${sfg_modifier_ranges.TN.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('sfg', 'TN', _.get(values, 'sfg.modifiers.TN.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.TN.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.sfg.modifiers.TN.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.TN.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					TX: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= sfg_modifier_ranges.TX.scheduleModifier.min &&
										value <= sfg_modifier_ranges.TX.scheduleModifier.max),
								`This modifier must be between ${sfg_modifier_ranges.TX.scheduleModifier.min} and ${sfg_modifier_ranges.TX.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('sfg', 'TX', _.get(values, 'sfg.modifiers.TX.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.TX.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.sfg.modifiers.TX.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'sfg.modifiers.TX.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
				},
			},
			cap: {
				modifiers: {
					AL: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.AL.scheduleModifier.min &&
										value <= cap_modifier_ranges.AL.scheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.AL.scheduleModifier.min} and ${cap_modifier_ranges.AL.scheduleModifier.max}.`,
							],
						],
						physicalDamageScheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.AL.physicalDamageScheduleModifier.min &&
										value <= cap_modifier_ranges.AL.physicalDamageScheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.AL.physicalDamageScheduleModifier.min} and ${cap_modifier_ranges.AL.physicalDamageScheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('cap', 'AL', _.get(values, 'cap.modifiers.AL.selectedCharacteristics', [])),
						physicalDamageIrpm: irpmRules(
							'cap',
							'AL',
							_.get(values, 'cap.modifiers.AL.selectedPhysicalCharacteristics', []),
							'physicalDamage',
						),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.AL.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageIndicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.AL.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.AL.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						physicalDamageComments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.AL.physicalDamageIndicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.AL.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageJudgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.AL.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					AR: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.AR.scheduleModifier.min &&
										value <= cap_modifier_ranges.AR.scheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.AR.scheduleModifier.min} and ${cap_modifier_ranges.AR.scheduleModifier.max}.`,
							],
						],
						physicalDamageScheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.AR.physicalDamageScheduleModifier.min &&
										value <= cap_modifier_ranges.AR.physicalDamageScheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.AR.physicalDamageScheduleModifier.min} and ${cap_modifier_ranges.AR.physicalDamageScheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('cap', 'AR', _.get(values, 'cap.modifiers.AR.selectedCharacteristics', [])),
						physicalDamageIrpm: irpmRules(
							'cap',
							'AR',
							_.get(values, 'cap.modifiers.AR.selectedPhysicalCharacteristics', []),
							'physicalDamage',
						),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.AR.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageIndicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.AR.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.AR.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						physicalDamageComments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.AR.physicalDamageIndicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.AR.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageJudgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.AR.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					GA: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.GA.scheduleModifier.min &&
										value <= cap_modifier_ranges.GA.scheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.GA.scheduleModifier.min} and ${cap_modifier_ranges.GA.scheduleModifier.max}.`,
							],
						],
						physicalDamageScheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.GA.physicalDamageScheduleModifier.min &&
										value <= cap_modifier_ranges.GA.physicalDamageScheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.GA.physicalDamageScheduleModifier.min} and ${cap_modifier_ranges.GA.physicalDamageScheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('cap', 'GA', _.get(values, 'cap.modifiers.GA.selectedCharacteristics', [])),
						physicalDamageIrpm: irpmRules(
							'cap',
							'GA',
							_.get(values, 'cap.modifiers.GA.selectedPhysicalCharacteristics', []),
							'physicalDamage',
						),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.GA.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageIndicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.GA.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.GA.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						physicalDamageComments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.GA.physicalDamageIndicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.GA.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageJudgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.GA.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					IA: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.IA.scheduleModifier.min &&
										value <= cap_modifier_ranges.IA.scheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.IA.scheduleModifier.min} and ${cap_modifier_ranges.IA.scheduleModifier.max}.`,
							],
						],
						physicalDamageScheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.IA.physicalDamageScheduleModifier.min &&
										value <= cap_modifier_ranges.IA.physicalDamageScheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.IA.physicalDamageScheduleModifier.min} and ${cap_modifier_ranges.IA.physicalDamageScheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('cap', 'IA', _.get(values, 'cap.modifiers.IA.selectedCharacteristics', [])),
						physicalDamageIrpm: irpmRules(
							'cap',
							'IA',
							_.get(values, 'cap.modifiers.IA.selectedPhysicalCharacteristics', []),
							'physicalDamage',
						),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.IA.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageIndicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.IA.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.IA.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						physicalDamageComments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.IA.physicalDamageIndicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.IA.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageJudgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.IA.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					IL: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.IL.scheduleModifier.min &&
										value <= cap_modifier_ranges.IL.scheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.IL.scheduleModifier.min} and ${cap_modifier_ranges.IL.scheduleModifier.max}.`,
							],
						],
						physicalDamageScheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.IL.physicalDamageScheduleModifier.min &&
										value <= cap_modifier_ranges.IL.physicalDamageScheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.IL.physicalDamageScheduleModifier.min} and ${cap_modifier_ranges.IL.physicalDamageScheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('cap', 'IL', _.get(values, 'cap.modifiers.IL.selectedCharacteristics', [])),
						physicalDamageIrpm: irpmRules(
							'cap',
							'IL',
							_.get(values, 'cap.modifiers.IL.selectedPhysicalCharacteristics', []),
							'physicalDamage',
						),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.IL.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageIndicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.IL.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.IL.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						physicalDamageComments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.IL.physicalDamageIndicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.IL.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageJudgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.IL.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					KS: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.KS.scheduleModifier.min &&
										value <= cap_modifier_ranges.KS.scheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.KS.scheduleModifier.min} and ${cap_modifier_ranges.KS.scheduleModifier.max}.`,
							],
						],
						physicalDamageScheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.KS.physicalDamageScheduleModifier.min &&
										value <= cap_modifier_ranges.KS.physicalDamageScheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.KS.physicalDamageScheduleModifier.min} and ${cap_modifier_ranges.KS.physicalDamageScheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('cap', 'KS', _.get(values, 'cap.modifiers.KS.selectedCharacteristics', [])),
						physicalDamageIrpm: irpmRules(
							'cap',
							'KS',
							_.get(values, 'cap.modifiers.KS.selectedPhysicalCharacteristics', []),
							'physicalDamage',
						),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.KS.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageIndicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.KS.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.KS.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						physicalDamageComments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.KS.physicalDamageIndicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.KS.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageJudgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.KS.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					KY: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.KY.scheduleModifier.min &&
										value <= cap_modifier_ranges.KY.scheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.KY.scheduleModifier.min} and ${cap_modifier_ranges.KY.scheduleModifier.max}.`,
							],
						],
						physicalDamageScheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.KY.physicalDamageScheduleModifier.min &&
										value <= cap_modifier_ranges.KY.physicalDamageScheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.KY.physicalDamageScheduleModifier.min} and ${cap_modifier_ranges.KY.physicalDamageScheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('cap', 'KY', _.get(values, 'cap.modifiers.KY.selectedCharacteristics', [])),
						physicalDamageIrpm: irpmRules(
							'cap',
							'KY',
							_.get(values, 'cap.modifiers.KY.selectedPhysicalCharacteristics', []),
							'physicalDamage',
						),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.KY.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageIndicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.KY.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.KY.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						physicalDamageComments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.KY.physicalDamageIndicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.KY.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageJudgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.KY.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					MO: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.MO.scheduleModifier.min &&
										value <= cap_modifier_ranges.MO.scheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.MO.scheduleModifier.min} and ${cap_modifier_ranges.MO.scheduleModifier.max}.`,
							],
						],
						physicalDamageScheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.MO.physicalDamageScheduleModifier.min &&
										value <= cap_modifier_ranges.MO.physicalDamageScheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.MO.physicalDamageScheduleModifier.min} and ${cap_modifier_ranges.MO.physicalDamageScheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('cap', 'MO', _.get(values, 'cap.modifiers.MO.selectedCharacteristics', [])),
						physicalDamageIrpm: irpmRules(
							'cap',
							'MO',
							_.get(values, 'cap.modifiers.MO.selectedPhysicalCharacteristics', []),
							'physicalDamage',
						),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.MO.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageIndicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.MO.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.MO.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						physicalDamageComments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.MO.physicalDamageIndicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.MO.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageJudgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.MO.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					MS: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.MS.scheduleModifier.min &&
										value <= cap_modifier_ranges.MS.scheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.MS.scheduleModifier.min} and ${cap_modifier_ranges.MS.scheduleModifier.max}.`,
							],
						],
						physicalDamageScheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.MS.physicalDamageScheduleModifier.min &&
										value <= cap_modifier_ranges.MS.physicalDamageScheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.MS.physicalDamageScheduleModifier.min} and ${cap_modifier_ranges.MS.physicalDamageScheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('cap', 'MS', _.get(values, 'cap.modifiers.MS.selectedCharacteristics', [])),
						physicalDamageIrpm: irpmRules(
							'cap',
							'MS',
							_.get(values, 'cap.modifiers.MS.selectedPhysicalCharacteristics', []),
							'physicalDamage',
						),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.MS.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageIndicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.MS.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.MS.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						physicalDamageComments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.MS.physicalDamageIndicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.MS.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageJudgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.MS.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					NE: {
						liabilityModifications: [
							[
								(value) => isBlankZ(value) || (value >= 0.6 && value <= 1.4),
								'This modifier must be between 0.6 and 1.4.',
							],
						],
						physicalDamageModifications: [
							[
								(value) => isBlankZ(value) || (value >= 0.6 && value <= 1.4),
								'This modifier must be between 0.6 and 1.4.',
							],
						],
					},
					NM: {
						liabilityModifications: [
							[
								(value) => isBlankZ(value) || (value >= 0.75 && value <= 1.25),
								'This modifier must be between 0.75 and 1.25.',
							],
						],
						physicalDamageModifications: [
							[
								(value) => isBlankZ(value) || (value >= 0.75 && value <= 1.25),
								'This modifier must be between 0.75 and 1.25.',
							],
						],
					},
					OK: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.OK.scheduleModifier.min &&
										value <= cap_modifier_ranges.OK.scheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.OK.scheduleModifier.min} and ${cap_modifier_ranges.OK.scheduleModifier.max}.`,
							],
						],
						physicalDamageScheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.OK.physicalDamageScheduleModifier.min &&
										value <= cap_modifier_ranges.OK.physicalDamageScheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.OK.physicalDamageScheduleModifier.min} and ${cap_modifier_ranges.OK.physicalDamageScheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('cap', 'OK', _.get(values, 'cap.modifiers.OK.selectedCharacteristics', [])),
						physicalDamageIrpm: irpmRules(
							'cap',
							'OK',
							_.get(values, 'cap.modifiers.OK.selectedPhysicalCharacteristics', []),
							'physicalDamage',
						),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.OK.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageIndicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.OK.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.OK.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						physicalDamageComments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.OK.physicalDamageIndicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.OK.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageJudgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.OK.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					SD: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.SD.scheduleModifier.min &&
										value <= cap_modifier_ranges.SD.scheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.SD.scheduleModifier.min} and ${cap_modifier_ranges.SD.scheduleModifier.max}.`,
							],
						],
						physicalDamageScheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.SD.physicalDamageScheduleModifier.min &&
										value <= cap_modifier_ranges.SD.physicalDamageScheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.SD.physicalDamageScheduleModifier.min} and ${cap_modifier_ranges.SD.physicalDamageScheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('cap', 'SD', _.get(values, 'cap.modifiers.SD.selectedCharacteristics', [])),
						physicalDamageIrpm: irpmRules(
							'cap',
							'SD',
							_.get(values, 'cap.modifiers.SD.selectedPhysicalCharacteristics', []),
							'physicalDamage',
						),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.SD.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageIndicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.SD.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.SD.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						physicalDamageComments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.SD.physicalDamageIndicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.SD.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageJudgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.SD.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					TN: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.TN.scheduleModifier.min &&
										value <= cap_modifier_ranges.TN.scheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.TN.scheduleModifier.min} and ${cap_modifier_ranges.TN.scheduleModifier.max}.`,
							],
						],
						physicalDamageScheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= cap_modifier_ranges.TN.physicalDamageScheduleModifier.min &&
										value <= cap_modifier_ranges.TN.physicalDamageScheduleModifier.max),
								`This modifier must be between ${cap_modifier_ranges.TN.physicalDamageScheduleModifier.min} and ${cap_modifier_ranges.TN.physicalDamageScheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('cap', 'TN', _.get(values, 'cap.modifiers.TN.selectedCharacteristics', [])),
						physicalDamageIrpm: irpmRules(
							'cap',
							'TN',
							_.get(values, 'cap.modifiers.TN.selectedPhysicalCharacteristics', []),
							'physicalDamage',
						),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.TN.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageIndicators: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.TN.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.TN.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						physicalDamageComments: [
							[
								(value) => !(isBlank(value) && _.includes(values.cap.modifiers.TN.physicalDamageIndicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.TN.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						physicalDamageJudgement: [
							[
								(value) =>
									!(_.get(values, 'cap.modifiers.TN.selectedPhysicalCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					},
					TX: {
						liabilityModifications: [
							[
								(value) => isBlankZ(value) || (value >= 0.6 && value <= 1.4),
								'This modifier must be between 0.6 and 1.4.',
							],
						],
						physicalDamageModifications: [
							[
								(value) => isBlankZ(value) || (value >= 0.6 && value <= 1.4),
								'This modifier must be between 0.6 and 1.4.',
							],
						],
					},
				},
			},
			wcp: {
				modifiers: {
					AL: {
						group_blanket_modifiers: [
							[
								(value) =>
									isBlankZ(values.wcp.modifiers.AL.blanketWaiver) ||
									isBlankZ(values.wcp.modifiers.AL.blanketWaiverFlat),
								'You can not have both Blanket Waiver and Blanket Waiver (FlatCharge)',
							],
						],
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= wcp_modifier_ranges.AL.scheduleModifier.min &&
										value <= wcp_modifier_ranges.AL.scheduleModifier.max),
								`This modifier must be between ${wcp_modifier_ranges.AL.scheduleModifier.min} and ${wcp_modifier_ranges.AL.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('wcp', 'AL', _.get(values, 'wcp.modifiers.AL.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'wcp.modifiers.AL.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.wcp.modifiers.AL.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) => {
									return !(_.get(values, 'wcp.modifiers.AL.selectedCharacteristics', []).length > 0 && isBlank(value));
								},
								requiredQuestionMessage,
							],
						],
						blanketWaiver: [
							[
								(value) => isBlankZ(value) || (value >= 1 && value <= 9.999),
								'This modifier must be between 1 and 9.999.',
							],
						],
						blanketWaiverFlat: [
							[
								(value) => isBlankZ(value) || (value >= 0 && value <= 99999),
								'This modifier must be between 0 and 99,999.',
							],
						],
					},
					AR: {
						group_blanket_modifiers: [
							[
								(value) =>
									isBlankZ(values.wcp.modifiers.AR.blanketWaiver) ||
									isBlankZ(values.wcp.modifiers.AR.blanketWaiverFlat),
								'You can not have both Blanket Waiver and Blanket Waiver (FlatCharge)',
							],
						],
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= wcp_modifier_ranges.AR.scheduleModifier.min &&
										value <= wcp_modifier_ranges.AR.scheduleModifier.max),
								`This modifier must be between ${wcp_modifier_ranges.AR.scheduleModifier.min} and ${wcp_modifier_ranges.AR.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('wcp', 'AR', _.get(values, 'wcp.modifiers.AR.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'wcp.modifiers.AR.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.wcp.modifiers.AR.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) => {
									return !(_.get(values, 'wcp.modifiers.AR.selectedCharacteristics', []).length > 0 && isBlank(value));
								},
								requiredQuestionMessage,
							],
						],
						blanketWaiver: [
							[
								(value) => isBlankZ(value) || (value >= 1 && value <= 9.999),
								'This modifier must be between 1 and 9.999.',
							],
						],
						blanketWaiverFlat: [
							[
								(value) => isBlankZ(value) || (value >= 0 && value <= 99999),
								'This modifier must be between 0 and 99,999.',
							],
						],
					},
					GA: {
						group_blanket_modifiers: [
							[
								(value) =>
									isBlankZ(values.wcp.modifiers.GA.blanketWaiver) ||
									isBlankZ(values.wcp.modifiers.GA.blanketWaiverFlat),
								'You can not have both Blanket Waiver and Blanket Waiver (FlatCharge)',
							],
						],
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= wcp_modifier_ranges.GA.scheduleModifier.min &&
										value <= wcp_modifier_ranges.GA.scheduleModifier.max),
								`This modifier must be between ${wcp_modifier_ranges.GA.scheduleModifier.min} and ${wcp_modifier_ranges.GA.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('wcp', 'GA', _.get(values, 'wcp.modifiers.GA.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'wcp.modifiers.GA.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.wcp.modifiers.GA.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) => {
									return !(_.get(values, 'wcp.modifiers.GA.selectedCharacteristics', []).length > 0 && isBlank(value));
								},
								requiredQuestionMessage,
							],
						],
						blanketWaiver: [
							[
								(value) => isBlankZ(value) || (value >= 1 && value <= 9.999),
								'This modifier must be between 1 and 9.999.',
							],
						],
						blanketWaiverFlat: [
							[
								(value) => isBlankZ(value) || (value >= 0 && value <= 99999),
								'This modifier must be between 0 and 99,999.',
							],
						],
					},
					IA: {
						group_blanket_modifiers: [
							[
								(value) =>
									isBlankZ(values.wcp.modifiers.IA.blanketWaiver) ||
									isBlankZ(values.wcp.modifiers.IA.blanketWaiverFlat),
								'You can not have both Blanket Waiver and Blanket Waiver (FlatCharge)',
							],
						],
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= wcp_modifier_ranges.IA.scheduleModifier.min &&
										value <= wcp_modifier_ranges.IA.scheduleModifier.max),
								`This modifier must be between ${wcp_modifier_ranges.IA.scheduleModifier.min} and ${wcp_modifier_ranges.IA.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('wcp', 'IA', _.get(values, 'wcp.modifiers.IA.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'wcp.modifiers.IA.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.wcp.modifiers.IA.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) => {
									return !(_.get(values, 'wcp.modifiers.IA.selectedCharacteristics', []).length > 0 && isBlank(value));
								},
								requiredQuestionMessage,
							],
						],
						blanketWaiver: [
							[
								(value) => isBlankZ(value) || (value >= 1 && value <= 9.999),
								'This modifier must be between 1 and 9.999.',
							],
						],
						blanketWaiverFlat: [
							[
								(value) => isBlankZ(value) || (value >= 0 && value <= 99999),
								'This modifier must be between 0 and 99,999.',
							],
						],
					},
					IL: {
						group_blanket_modifiers: [
							[
								(value) =>
									isBlankZ(values.wcp.modifiers.IL.blanketWaiver) ||
									isBlankZ(values.wcp.modifiers.IL.blanketWaiverFlat),
								'You can not have both Blanket Waiver and Blanket Waiver (FlatCharge)',
							],
						],
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= wcp_modifier_ranges.IL.scheduleModifier.min &&
										value <= wcp_modifier_ranges.IL.scheduleModifier.max),
								`This modifier must be between ${wcp_modifier_ranges.IL.scheduleModifier.min} and ${wcp_modifier_ranges.IL.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('wcp', 'IL', _.get(values, 'wcp.modifiers.IL.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'wcp.modifiers.IL.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.wcp.modifiers.IL.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) => {
									return !(_.get(values, 'wcp.modifiers.IL.selectedCharacteristics', []).length > 0 && isBlank(value));
								},
								requiredQuestionMessage,
							],
						],
						blanketWaiver: [
							[
								(value) => isBlankZ(value) || (value >= 1 && value <= 9.999),
								'This modifier must be between 1 and 9.999.',
							],
						],
						blanketWaiverFlat: [
							[
								(value) => isBlankZ(value) || (value >= 0 && value <= 99999),
								'This modifier must be between 0 and 99,999.',
							],
						],
					},
					KS: {
						group_blanket_modifiers: [
							[
								(value) =>
									isBlankZ(values.wcp.modifiers.KS.blanketWaiver) ||
									isBlankZ(values.wcp.modifiers.KS.blanketWaiverFlat),
								'You can not have both Blanket Waiver and Blanket Waiver (FlatCharge)',
							],
						],
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= wcp_modifier_ranges.KS.scheduleModifier.min &&
										value <= wcp_modifier_ranges.KS.scheduleModifier.max),
								`This modifier must be between ${wcp_modifier_ranges.KS.scheduleModifier.min} and ${wcp_modifier_ranges.KS.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('wcp', 'KS', _.get(values, 'wcp.modifiers.KS.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'wcp.modifiers.KS.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.wcp.modifiers.KS.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) => {
									return !(_.get(values, 'wcp.modifiers.KS.selectedCharacteristics', []).length > 0 && isBlank(value));
								},
								requiredQuestionMessage,
							],
						],
						blanketWaiver: [
							[
								(value) => isBlankZ(value) || (value >= 1 && value <= 9.999),
								'This modifier must be between 1 and 9.999.',
							],
						],
						blanketWaiverFlat: [
							[
								(value) => isBlankZ(value) || (value >= 0 && value <= 99999),
								'This modifier must be between 0 and 99,999.',
							],
						],
					},
					KY: {
						group_blanket_modifiers: [
							[
								(value) =>
									isBlankZ(values.wcp.modifiers.KY.blanketWaiver) ||
									isBlankZ(values.wcp.modifiers.KY.blanketWaiverFlat),
								'You can not have both Blanket Waiver and Blanket Waiver (FlatCharge)',
							],
						],
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= wcp_modifier_ranges.KY.scheduleModifier.min &&
										value <= wcp_modifier_ranges.KY.scheduleModifier.max),
								`This modifier must be between ${wcp_modifier_ranges.KY.scheduleModifier.min} and ${wcp_modifier_ranges.KY.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('wcp', 'KY', _.get(values, 'wcp.modifiers.KY.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'wcp.modifiers.KY.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.wcp.modifiers.KY.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) => {
									return !(_.get(values, 'wcp.modifiers.KY.selectedCharacteristics', []).length > 0 && isBlank(value));
								},
								requiredQuestionMessage,
							],
						],
						blanketWaiver: [
							[
								(value) => isBlankZ(value) || (value >= 1 && value <= 9.999),
								'This modifier must be between 1 and 9.999.',
							],
						],
						blanketWaiverFlat: [
							[
								(value) => isBlankZ(value) || (value >= 0 && value <= 99999),
								'This modifier must be between 0 and 99,999.',
							],
						],
					},
					MO: {
						group_blanket_modifiers: [
							[
								(value) =>
									isBlankZ(values.wcp.modifiers.MO.blanketWaiver) ||
									isBlankZ(values.wcp.modifiers.MO.blanketWaiverFlat),
								'You can not have both Blanket Waiver and Blanket Waiver (FlatCharge)',
							],
						],
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= wcp_modifier_ranges.MO.scheduleModifier.min &&
										value <= wcp_modifier_ranges.MO.scheduleModifier.max),
								`This modifier must be between ${wcp_modifier_ranges.MO.scheduleModifier.min} and ${wcp_modifier_ranges.MO.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('wcp', 'MO', _.get(values, 'wcp.modifiers.MO.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'wcp.modifiers.MO.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.wcp.modifiers.MO.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) => {
									return !(_.get(values, 'wcp.modifiers.MO.selectedCharacteristics', []).length > 0 && isBlank(value));
								},
								requiredQuestionMessage,
							],
						],
						blanketWaiver: [
							[
								(value) => isBlankZ(value) || (value >= 1 && value <= 9.999),
								'This modifier must be between 1 and 9.999.',
							],
						],
						blanketWaiverFlat: [
							[
								(value) => isBlankZ(value) || (value >= 0 && value <= 99999),
								'This modifier must be between 0 and 99,999.',
							],
						],
					},
					MS: {
						group_blanket_modifiers: [
							[
								(value) =>
									isBlankZ(values.wcp.modifiers.MS.blanketWaiver) ||
									isBlankZ(values.wcp.modifiers.MS.blanketWaiverFlat),
								'You can not have both Blanket Waiver and Blanket Waiver (FlatCharge)',
							],
						],
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= wcp_modifier_ranges.MS.scheduleModifier.min &&
										value <= wcp_modifier_ranges.MS.scheduleModifier.max),
								`This modifier must be between ${wcp_modifier_ranges.MS.scheduleModifier.min} and ${wcp_modifier_ranges.MS.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('wcp', 'MS', _.get(values, 'wcp.modifiers.MS.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'wcp.modifiers.MS.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.wcp.modifiers.MS.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) => {
									return !(_.get(values, 'wcp.modifiers.MS.selectedCharacteristics', []).length > 0 && isBlank(value));
								},
								requiredQuestionMessage,
							],
						],
						blanketWaiver: [
							[
								(value) => isBlankZ(value) || (value >= 1 && value <= 9.999),
								'This modifier must be between 1 and 9.999.',
							],
						],
						blanketWaiverFlat: [
							[
								(value) => isBlankZ(value) || (value >= 0 && value <= 99999),
								'This modifier must be between 0 and 99,999.',
							],
						],
					},
					NE: {
						group_blanket_modifiers: [
							[
								(value) =>
									isBlankZ(values.wcp.modifiers.NE.blanketWaiver) ||
									isBlankZ(values.wcp.modifiers.NE.blanketWaiverFlat),
								'You can not have both Blanket Waiver and Blanket Waiver (FlatCharge)',
							],
						],
						scheduleModifier: [
							[
								(value) => isBlankZ(value) || (value >= 0.6 && value <= 1.4),
								'This modifier must be between 0.6 and 1.4.',
							],
						],
						blanketWaiver: [
							[
								(value) => isBlankZ(value) || (value >= 1 && value <= 9.999),
								'This modifier must be between 1 and 9.999.',
							],
						],
						flexibleRatingAdjustment: [
							[
								(value) => isBlankZ(value) || (value >= 0.6 && value <= 1.4),
								'This modifier must be between 0.6 and 1.4.',
							],
						],
					},
					NM: {
						group_blanket_modifiers: [
							[
								(value) =>
									isBlankZ(values.wcp.modifiers.NM.blanketWaiver) ||
									isBlankZ(values.wcp.modifiers.NM.blanketWaiverFlat),
								'You can not have both Blanket Waiver and Blanket Waiver (FlatCharge)',
							],
						],
						scheduleModifier: [
							[
								(value) => isBlankZ(value) || (value >= 0.75 && value <= 1.25),
								'This modifier must be between 0.75 and 1.25.',
							],
						],
						blanketWaiver: [
							[
								(value) => isBlankZ(value) || (value >= 1 && value <= 9.999),
								'This modifier must be between 1 and 9.999.',
							],
						],
						blanketWaiverFlat: [
							[
								(value) => isBlankZ(value) || (value >= 0 && value <= 99999),
								'This modifier must be between 0 and 99,999.',
							],
						],
					},
					OK: {
						group_blanket_modifiers: [
							[
								(value) =>
									isBlankZ(values.wcp.modifiers.OK.blanketWaiver) ||
									isBlankZ(values.wcp.modifiers.OK.blanketWaiverFlat),
								'You can not have both Blanket Waiver and Blanket Waiver (FlatCharge)',
							],
						],
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= wcp_modifier_ranges.OK.scheduleModifier.min &&
										value <= wcp_modifier_ranges.OK.scheduleModifier.max),
								`This modifier must be between ${wcp_modifier_ranges.OK.scheduleModifier.min} and ${wcp_modifier_ranges.OK.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('wcp', 'OK', _.get(values, 'wcp.modifiers.OK.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'wcp.modifiers.OK.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.wcp.modifiers.OK.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) => {
									return !(_.get(values, 'wcp.modifiers.OK.selectedCharacteristics', []).length > 0 && isBlank(value));
								},
								requiredQuestionMessage,
							],
						],
						blanketWaiver: [
							[
								(value) => isBlankZ(value) || (value >= 1 && value <= 9.999),
								'This modifier must be between 1 and 9.999.',
							],
						],
						blanketWaiverFlat: [
							[
								(value) => isBlankZ(value) || (value >= 0 && value <= 99999),
								'This modifier must be between 0 and 99,999.',
							],
						],
					},
					SD: {
						group_blanket_modifiers: [
							[
								(value) =>
									isBlankZ(values.wcp.modifiers.SD.blanketWaiver) ||
									isBlankZ(values.wcp.modifiers.SD.blanketWaiverFlat),
								'You can not have both Blanket Waiver and Blanket Waiver (FlatCharge)',
							],
						],
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= wcp_modifier_ranges.SD.scheduleModifier.min &&
										value <= wcp_modifier_ranges.SD.scheduleModifier.max),
								`This modifier must be between ${wcp_modifier_ranges.SD.scheduleModifier.min} and ${wcp_modifier_ranges.SD.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('wcp', 'SD', _.get(values, 'wcp.modifiers.SD.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'wcp.modifiers.SD.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.wcp.modifiers.SD.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) => {
									return !(_.get(values, 'wcp.modifiers.SD.selectedCharacteristics', []).length > 0 && isBlank(value));
								},
								requiredQuestionMessage,
							],
						],
						blanketWaiver: [
							[
								(value) => isBlankZ(value) || (value >= 1 && value <= 9.999),
								'This modifier must be between 1 and 9.999.',
							],
						],
						blanketWaiverFlat: [
							[
								(value) => isBlankZ(value) || (value >= 0 && value <= 99999),
								'This modifier must be between 0 and 99,999.',
							],
						],
					},
					TN: {
						group_blanket_modifiers: [
							[
								(value) =>
									isBlankZ(values.wcp.modifiers.TN.blanketWaiver) ||
									isBlankZ(values.wcp.modifiers.TN.blanketWaiverFlat),
								'You can not have both Blanket Waiver and Blanket Waiver (FlatCharge)',
							],
						],
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= wcp_modifier_ranges.TN.scheduleModifier.min &&
										value <= wcp_modifier_ranges.TN.scheduleModifier.max),
								`This modifier must be between ${wcp_modifier_ranges.TN.scheduleModifier.min} and ${wcp_modifier_ranges.TN.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('wcp', 'TN', _.get(values, 'wcp.modifiers.TN.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'wcp.modifiers.TN.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.wcp.modifiers.TN.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) => {
									return !(_.get(values, 'wcp.modifiers.TN.selectedCharacteristics', []).length > 0 && isBlank(value));
								},
								requiredQuestionMessage,
							],
						],
						blanketWaiver: [
							[
								(value) => isBlankZ(value) || (value >= 1 && value <= 9.999),
								'This modifier must be between 1 and 9.999.',
							],
						],
						blanketWaiverFlat: [
							[
								(value) => isBlankZ(value) || (value >= 0 && value <= 99999),
								'This modifier must be between 0 and 99,999.',
							],
						],
					},
					TX: {
						scheduleModifier: [
							[
								(value) =>
									isBlankZ(value) ||
									(value >= wcp_modifier_ranges.TX.scheduleModifier.min &&
										value <= wcp_modifier_ranges.TX.scheduleModifier.max),
								`This modifier must be between ${wcp_modifier_ranges.TX.scheduleModifier.min} and ${wcp_modifier_ranges.TX.scheduleModifier.max}.`,
							],
						],
						irpm: irpmRules('wcp', 'TX', _.get(values, 'wcp.modifiers.TX.selectedCharacteristics', [])),
						indicators: [
							[
								(value) =>
									!(_.get(values, 'wcp.modifiers.TX.selectedCharacteristics', []).length > 0 && isBlank(value)),
								requiredQuestionMessage,
							],
						],
						comments: [
							[
								(value) => !(isBlank(value) && _.includes(values.wcp.modifiers.TX.indicators, 'other')),
								requiredQuestionMessage,
							],
						],
						judgement: [
							[
								(value) => {
									return !(_.get(values, 'wcp.modifiers.TX.selectedCharacteristics', []).length > 0 && isBlank(value));
								},
								requiredQuestionMessage,
							],
						],
						smallDeductible1: [
							[
								(value) => isBlank(value) || _.toNumber(_.get(quote, 'rates.wcp', '')) >= 5000,
								'Cannot add small deductible with premium less than $5,000.',
							],
						],
					},
				},
			},
		};
	}

	static name() {
		return 'modifiers';
	}

	static referrals(context, values) {
		return {};
	}
}
export default ModifierRules;
