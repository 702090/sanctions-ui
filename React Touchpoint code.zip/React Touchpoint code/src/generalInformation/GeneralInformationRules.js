import { getFieldDisplayArray, requiredQuestionMessage } from 'data/FieldVisibility';
import { validEmail } from 'helper/Validation';
import _ from 'lodash';
import { daysFromNow, isValidDate } from 'utils/DateFunctions';
import { isCompany, isNotCompany } from 'utils/FieldDisplay';
import { getVisibility } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';

export default class GeneralInformationRules {
	static requiredStructure = {
		newVenture: '',
		numberYearsExperience: '',
		effectiveDate: '',
		businessType: '',
		insuredName: {
			first: '',
			last: '',
			company: '',
		},
		address: {
			fullAddress: '',
		},
		personEnteringRisk: '',
		personEnteringRiskEmail: '',
	};

	static rules(quote, values, visibility) {
		// use values for current page validation
		// use quote for external page validation
		if (values && !visibility) {
			visibility = getVisibility(getFieldDisplayArray('generalInformation'), quote, values);
		}
		return {
			newVenture: [[(value) => !isBlank(value), requiredQuestionMessage]],
			numberYearsExperience: [
				[(value) => !visibility['numberYearsExperience'] || !isBlank(value), requiredQuestionMessage],
			],
			effectiveDate: [
				[(value) => !isBlank(value), 'Effective Date is required.'],
				[(value) => isValidDate(value), 'You must enter a valid date.'],
			],
			businessType: [[(value) => !isBlank(value), 'Business Type is required.']],
			insuredName: {
				first: [[(value) => !(isBlank(value) && isNotCompany(quote, values)), 'Insured first name is required.']],
				last: [[(value) => !(isBlank(value) && isNotCompany(quote, values)), 'Insured last name is required.']],
				company: [[(value) => !(isBlank(value) && isCompany(quote, values)), 'Company name is required.']],
			},
			address: {
				fullAddress: [
					[(value) => !isBlank(value), 'Address is required.'],
					[(value) => _.get(values, 'address.zip', '') !== '00000', 'This address must include a valid zipcode.'],
					[
						(value) =>
							_.get(values, 'address.ruralRoute') ||
							((_.get(values, 'address.poBox') ||
								(!isBlank(_.get(values, 'address.streetNumber', '')) &&
									!isBlank(_.get(values, 'address.streetName', '')))) &&
								!isBlank(_.get(values, 'address.city', '')) &&
								!isBlank(_.get(values, 'address.state', ''))),

						'Please make sure you have entered a street address or PO box with a city and state',
					],
				],
			},
			personEnteringRisk: [[(value) => !isBlank(value), 'Person Entering Risk is required.']],
			personEnteringRiskEmail: [
				[(value) => !isBlank(value), 'An email address of the person entering risk is required'],
				[(value) => isBlank(value) || validEmail(value), 'Must be a valid email address ex. name@address.com'],
			],
		};
	}

	static referrals(context, values, visibility) {
		return {
			numberYearsExperience: [[(value) => isBlank(value) || value >= 3, 'TGI04']],
			effectiveDate: [
				[(value) => daysFromNow(value) > -8, 'TGI01'],
				[(value) => daysFromNow(value) < 61, 'TGI02'],
			],
			address: {
				fullAddress: [
					[
						(value) =>
							isBlank(value) || context.serviceStatus.addressValidation || _.get(values, 'address.validated', false),
						'TGI03',
					],
				],
			},
			geoCodeFailed: [[(value) => !_.get(context, 'quote.geoCodeFailed'), 'TGI05']],
		};
	}
	static name() {
		return 'generalInformation';
	}
}
