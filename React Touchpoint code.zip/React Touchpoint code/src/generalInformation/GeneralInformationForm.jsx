import { DatePicker } from 'components/shared/form/DatePicker';
import { callAddressValidation } from 'components/shared/form/inputs/Addresses';
import { InputAddress } from 'components/shared/form/inputs/InputAddress';
import { InputCompanyName } from 'components/shared/form/inputs/InputCompanyName';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputText } from 'components/shared/form/inputs/InputText';
import { RadioButton } from 'components/shared/form/RadioButton';
import { RadioToggle } from 'components/shared/form/RadioToggle';
import { Select } from 'components/shared/form/Select';
import { InformationMessage } from 'components/shared/messages/InformationMessage';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import selectOptionsJson from 'data/SelectOptions';
import { Field, Form, Formik } from 'formik';
import GeneralInformationRules from 'generalInformation/GeneralInformationRules';
import { getProductsToCall } from 'helper/Clue';
import { runAllRules } from 'helper/Validation';
import _ from 'lodash';
import React, { useContext } from 'react';
import { downpaymentStatus } from 'services/downpaymentService';
import { insurityCall } from 'services/insurityService';
import logger from 'services/logService';
import { saveQuote } from 'services/quoteService';
import { ReferralList } from 'sidebar/Referrals';
import { call360Valuation, cleanBuildingInterests, isEmployee } from 'utils/BusinessFunctions';
import { formatDate } from 'utils/DateFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import { cleanValues, getVisibility, logPageErrors, parseAddress, runRulesOnLoad } from 'utils/ScreenFunctions';
import { cleanInput, isBlank, isBlankR } from 'utils/StringFunctions';
import { replaceReferrals } from 'validation/RunReferrals';
import { checkReferrals, validateNew } from 'validation/Validate';

const { businessType } = selectOptionsJson;

const GeneralInformationForm = (props) => {
	const context = useContext(QuoteContext);
	const { quote, sessionID, handleRoofReport } = context;

	localStorage.setItem('quoteId', quote.id);

	let visibility = {};
	let dirty = false;
	let formProps;

	if (_.includes(['b', 'c'], _.get(quote, 'status', ''))) {
		props.history.push('/quote/issue/submitted');
	}

	React.useEffect(() => {
		async function load() {
			await logger.logInfo(quote.quoteNumber, '***** Quote opened *****');
			context.updateServiceStatus('runningRequiredServices', true);
			const slipInfo = await downpaymentStatus(quote);

			if (_.get(slipInfo, 'paymentStatus', '') === 'Approval' || _.get(slipInfo, 'status', '') === 'Approval') {
				if (isBlankR(quote.referrals)) {
					quote.status = 'b';
				} else {
					quote.status = 'c';
				}
				saveQuote(quote);
				context.updateServiceStatus('runningRequiredServices', false);
				props.history.push('/quote/issue/submitted');
			}

			// check to see if any requried service needs to run again
			runRequiredServices();

			// If the form is not empty, trigger validation
			runRulesOnLoad(formProps, formProps.initialValues, [
				'effectiveDate',
				'personEnteringRisk',
				'personEnteringRiskEmail',
				'address.fullAddress',
			]);

			replaceReferrals(context);
			context.updateServiceStatus('runningRequiredServices', false);
		}
		// This is to clean up any older quotes with buildings that have an invalid AI code
		cleanBuildingInterests({ currentContext: context, props });
		load();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	React.useEffect(() => {
		// run all Rules after the left nav is built
		runAllRules(
			props,
			context.quote,
			context.navigation,
			context.checkNavProducts,
			context.updateNav,
			context.serviceStatus,
		);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [context.navigation]);

	const runRequiredServices = () => {
		_.forIn(_.get(quote, 'sfg.locations', {}), (loc, locId) => {
			const roofReport = _.get(loc, 'veriskRoofReport', {});
			const locAddress = _.get(quote, `addresses.${locId}`);
			if (
				isBlank(roofReport) ||
				roofReport.response === 'pending' ||
				(!isBlank(roofReport.ErrorMessage) &&
					roofReport.ErrorMessage !== 'Product not available for the requested property')
			) {
				handleRoofReport(locAddress, locId);
			}

			_.forIn(_.get(loc, 'buildings', {}), (bldg, bldgId) => {
				const {
					ancillaryBuilding,
					ancillaryDescription,
					buildingLimit,
					buildingValuation,
					classId,
					constructionType,
					constructionYear,
					numberOfStories,
					roofType,
					sprinkler,
					squareFootage,
					prefillData,
				} = bldg;

				if (isBlank(_.get(prefillData, 'verisk360.valuationId', ''))) {
					let canCallVerisk360 = true;

					if (
						(ancillaryBuilding === 'Y' && isBlank(ancillaryDescription)) ||
						isBlank(buildingLimit) ||
						isBlank(buildingValuation) ||
						isBlank(classId) ||
						isBlank(constructionType) ||
						isBlank(constructionYear) ||
						isBlank(numberOfStories) ||
						isBlank(roofType) ||
						isBlank(sprinkler) ||
						isBlank(squareFootage)
					) {
						canCallVerisk360 = false;
					}

					if (canCallVerisk360) {
						call360Valuation(context, quote, locId, bldg, bldgId, props);
					}
				}
			});
		});
	};

	const handleCompanySelect = (values, setFieldValue) => {
		if (_.get(values, 'gmaps.name')) {
			const address = parseAddress(values, 'address', setFieldValue);
			callAddressValidation(address, context.optionModal, 'address', formProps, false, context);
			setFieldValue('insuredName.company', cleanInput(values.gmaps.name), true);
		} else {
			setFieldValue('insuredName.company', cleanInput(values), true);
		}
	};

	const getAddress = () => {
		let address = { fullAddress: '' };

		if (quote.addresses && quote.addresses[1]) {
			address = quote.addresses[1];
		} else if (quote.address) {
			address = quote.address;
		}
		quote.address = address;
		return address;
	};

	const initialValues = {
		blockAgentEdit: quote.blockAgentEdit,
		underwriterReferralOverride: quote.underwriterReferralOverride,
		newVenture: quote.newVenture,
		numberYearsExperience: quote.numberYearsExperience,
		effectiveDate: quote.effectiveDate || formatDate(),
		underwriterReferralOverride: quote.underwriterReferralOverride,
		businessType: quote.businessType || '',
		insuredName: quote.insuredName || {
			first: '',
			last: '',
			company: '',
			dba: '',
		},
		address: getAddress(),
		personEnteringRisk: quote.personEnteringRisk || localStorage.getItem('personEnteringRisk') || '',
		personEnteringRiskEmail: quote.personEnteringRiskEmail || localStorage.getItem('personEnteringRiskEmail') || '',
	};

	// TODO: possibly move this to Clue.js in helpers
	const clueCallCheck = (values, mailingAddress, insuredName) => {
		let clueProducts = [];

		// If the address or insured name changes we need to order CLUE
		if (
			(!isBlank(mailingAddress) && mailingAddress.fullAddress !== values.address.fullAddress) ||
			(!isBlank(insuredName) &&
				(insuredName.company !== values.insuredName.company ||
					insuredName.first !== values.insuredName.first ||
					insuredName.last !== values.insuredName.last))
		) {
			clueProducts = getProductsToCall(context, quote);
		}

		return clueProducts;
	};

	const updateBlockAgent = (newValue) => {
		if (quote.blockAgentEdit !== newValue) {
			_.set(quote, 'blockAgentEdit', newValue);
			saveQuote(quote);
		}
	};

	const updateUnderwriterOverride = (underwriterReferralOverride) => {
		if (quote.underwriterReferralOverride && !underwriterReferralOverride) {
			_.set(quote, 'underwriterReferralOverride', false);
			_.unset(quote, 'transactionData.uroDate');
			_.unset(quote, 'transactionData.uroChangedBy');
			_.unset(quote, 'transactionData.uroReferrals');
			saveQuote(quote);
		} else if (!quote.underwriterReferralOverride && underwriterReferralOverride) {
			const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));
			const referralList = ReferralList({ quote });
			const savedReferralList = [];

			referralList.forEach((referral) => {
				const key = _.get(referral, 'key');

				if (key) {
					savedReferralList.push(key);
				}
			});
			_.set(quote, 'underwriterReferralOverride', true);
			_.set(quote, 'transactionData.uroDate', new Date());
			_.set(quote, 'transactionData.uroChangedBy', agent.userId);
			_.set(quote, 'transactionData.uroReferrals', savedReferralList);
			saveQuote(quote);
		}
	};

	return (
		<Formik
			render={(formikProps) => {
				formProps = formikProps;
				dirty = formikProps.dirty;
				visibility = getVisibility(getFieldDisplayArray('generalInformation'), quote, formikProps.values);
				cleanValues(formikProps.values, visibility);
				return (
					<Form id='screen'>
						<InformationMessage
							message='There are services running in the background. Please allow them to finish before continuing.'
							fieldDisplay={context.serviceStatus.runningRequiredServices}
						/>
						<PageSection className='formSection' title='Quote Information'>
							{isEmployee() ? (
								<React.Fragment>
									<Field
										name='blockAgentEdit'
										label='Block Agent Edit'
										toggle
										component={RadioToggle}
										fieldDisplay={visibility['blockAgentEdit']}
										additionalOnChange={updateBlockAgent(formikProps.values.blockAgentEdit)}
									/>
									<Field
										name='underwriterReferralOverride'
										label='I have reviewed the referrals and approve all of the items.'
										toggle
										component={RadioToggle}
										fieldDisplay={visibility['underwriterReferralOverride']}
										additionalOnChange={updateUnderwriterOverride(formikProps.values.underwriterReferralOverride)}
									/>
								</React.Fragment>
							) : (
								''
							)}
							<Field name='newVenture' label='Is this a new venture?' component={RadioButton} />
							<Field
								name='numberYearsExperience'
								label='Number of years experience in this type of operation?'
								component={InputNumber}
								fieldDisplay={visibility['numberYearsExperience']}
								width='tiny'
							/>
							<Field name='effectiveDate' label='Effective Date' component={DatePicker} />
							<Field name='personEnteringRisk' label='Person Entering Risk' component={InputText} maxLength='50' />
							<Field
								name='personEnteringRiskEmail'
								label='Email of Person Entering Risk'
								component={InputText}
								maxLength='50'
							/>
						</PageSection>
						<PageSection className='formSection' title='Insured Information'>
							<Field name='businessType' label='Business Type' component={Select} options={businessType} />
							<Field
								name='insuredName.first'
								label='Insured First Name'
								component={InputText}
								fieldDisplay={visibility['insuredName.first']}
								maxLength='20'
								width='small'
							/>
							<Field
								name='insuredName.last'
								label='Insured Last Name'
								component={InputText}
								fieldDisplay={visibility['insuredName.last']}
								maxLength='60'
							/>
							<Field
								name='insuredName.company'
								label='Company Name'
								component={InputCompanyName}
								className='geo'
								additionalOnChange={handleCompanySelect}
								fieldDisplay={visibility['insuredName.company']}
								maxLength='60'
							/>
							<Field name='insuredName.dba' label='DBA' optional component={InputText} maxLength='60' />
							<Field
								name='address.fullAddress'
								label='Mailing Address'
								component={InputAddress}
								className='geo'
								addressName='address'
								additionalOnChange={parseAddress}
								formikProps={formikProps}
							/>
						</PageSection>
						<NavigationButtons
							formikProps={formikProps}
							back={false}
							location={props.location}
							history={props.history}
							disableNext={context.serviceStatus.runningRequiredServices}
						/>
					</Form>
				);
			}}
			initialValues={initialValues}
			onSubmit={async (values, formikActions) => {
				if (!context.serviceStatus.addressValidation && !context.serviceStatus.runningRequiredServices) {
					cleanValues(values, visibility);

					values.effectiveDate = formatDate(values.effectiveDate, 'iso');

					const quoteCopy = duplicate(quote);
					const addresses = _.get(quoteCopy, 'addresses', {});
					const insuredName = _.get(quoteCopy, 'insuredName', {});
					const id = 1;

					if (!addresses[id]) {
						addresses[id] = {};
					}

					// Check to see if the address has changed and call CLUE if it has
					const clueProducts = clueCallCheck(values, addresses[id], insuredName);

					addresses[id] = values.address;
					quoteCopy.addresses = { ...addresses };
					if (isBlank(_.get(quoteCopy, 'personEnteringRisk', ''))) {
						localStorage.setItem('personEnteringRisk', values.personEnteringRisk);
					}
					if (isBlank(_.get(quoteCopy, 'personEnteringRiskEmail', ''))) {
						localStorage.setItem('personEnteringRiskEmail', values.personEnteringRiskEmail);
						formikActions.setFieldTouched('personEnteringRiskEmail', true, true);
					}

					// This needs to be the last thing done before the return
					_.merge(quoteCopy, values);

					if (isBlank(quoteCopy.customerNumber) || !_.isEqual(initialValues.insuredName, quoteCopy.insuredName)) {
						const customerArray = await insurityCall(quoteCopy, 'customerNumber');
						if (customerArray.length > 1) {
							const fieldOptions = [];
							customerArray.forEach((c) => {
								fieldOptions.push({
									value: c.customerNumber,
									text: `${c.customerNumber} - ${c.name} [${c.address}]`,
								});
							});

							context.optionModal.current.handleOpen(
								{
									field: {
										name: 'CustomerOptions',
										label:
											'Multiple matching Customer Numbers were found. Please choose the correct Customer Number below.',
										component: RadioButton,
										options: fieldOptions,
										width: 'massive',
									},
								},
								(v, sfv, fv) => {
									values.customerNumber = v;
									return context.onSubmit(values, true, false, clueProducts, props);
								},
							);
						} else {
							values.customerNumber = customerArray[0].customerNumber;
							return context.onSubmit(values, true, false, clueProducts, props);
						}
					} else {
						return context.onSubmit(values, dirty, false, clueProducts, props);
					}
				}
			}}
			validate={(values) => {
				checkReferrals(context, values, GeneralInformationRules);
				const validResults = validateNew(quote, values, GeneralInformationRules, visibility);
				logPageErrors(validResults, formProps.touched, 'all');
				return validResults;
			}}
		/>
	);
};

export default GeneralInformationForm;
