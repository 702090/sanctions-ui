import '@testing-library/jest-dom';
import { act, cleanup, fireEvent, render, screen, waitFor, getAllByRole } from '@testing-library/react';
import MockDate from 'mockdate';
import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import renderer from 'react-test-renderer';
import GeneralInformationForm from '../GeneralInformationForm';
/* eslint-disable testing-library/no-unnecessary-act */

describe('Quote Information Section', () => {
	let resultComponent;
	const testDate = '08/26/2022';
	const runRequiredServices = jest.fn();

	let testUseEffect;

	const mockUseEffect = () => {
		testUseEffect.mockImplementationOnce(() => {});
	};

	const renderComponent = (component) => {
		return render(<BrowserRouter>{component}</BrowserRouter>);
	};
	beforeEach(async () => {
		MockDate.set(testDate);
		testUseEffect = jest.spyOn(React, 'useEffect');
		mockUseEffect();
		mockUseEffect();
		window.localStorage.clear();
	});

	afterEach(() => {
		jest.clearAllMocks();
		MockDate.reset();
		cleanup;
	});
	afterAll(() => {
		jest.clearAllMocks();
		jest.useRealTimers();
	});
	describe('GeneralInformationForm', () => {
		describe('Quote Information testing', () => {
			test('render Business Information component', () => {
				const { asFragment } = render(<GeneralInformationForm handleSubmit={jest.fn()} handleCancel={jest.fn()} />);
				expect(asFragment()).toMatchSnapshot();
			});
			test('Quote Information Title', () => {
				renderComponent(<GeneralInformationForm />);
				const quoteInformation = screen.getByRole('heading', { name: 'Quote Information' });
				expect(quoteInformation).toBeInTheDocument();
			});
			test('Block Agent Edit', () => {
				renderComponent(<GeneralInformationForm />);
				const blockAgentEdit = screen.queryByText(/Block Agent Edit/i);
				expect(blockAgentEdit).not.toBeInTheDocument();
			});
			test('effective date value test', () => {
				renderComponent(<GeneralInformationForm />);
				const effectiveDateText = screen.getByRole('textbox', { name: /effective date/i });
				fireEvent.change(effectiveDateText, { target: { value: '08/26/2022' } });
				expect(effectiveDateText).toBeInTheDocument();
			});
			test('should render efective date ', () => {
				renderComponent(<GeneralInformationForm />);
				const effectiveDate = screen.getByRole('textbox', { name: /effective date/i });
				expect(effectiveDate).toHaveValue(testDate);
			});
		});
	});

	describe('TP-Unit Test-Safeguard-Policy Information', () => {
		test('By defult the "next button is "Black"', () => {
			renderComponent(<GeneralInformationForm />);
			const btnNext = screen.getByRole('button', {
				name: /Next/i,
			});
			expect(btnNext).toBeInTheDocument();
			expect(btnNext).toHaveClass('ui primary button');
		});

		test('not filling required values in the form when click on "next button is "red" and unresponsive. ', async () => {
			renderComponent(<GeneralInformationForm />);
			const btnNext = screen.getByRole('button', {
				name: /Next/i,
			});
			await act(async () => {
				fireEvent.click(btnNext);
			});
			expect(btnNext).toHaveClass('ui primary button error');
		});

		test('After filling out the form the next button turns "blue" and the "next" responsive.', async () => {
			const { container } = render(<GeneralInformationForm />);
			const newVentureYes = screen.getByLabelText('Yes');
			await act(async () => {
				fireEvent.click(newVentureYes);
			});
			await waitFor(async () => {
				await expect(newVentureYes).toBeChecked();
			});
			await waitFor(async () => {
				await expect(screen.getByText('Number of years experience in this type of operation?')).toBeInTheDocument();
			});
			let yearsInput = screen.getByRole('textbox', {
				name: /Number of years experience in this type of operation?/i,
			});
			await act(async () => {
				fireEvent.change(yearsInput, { target: { value: '5' } });
			});
			await waitFor(async () => {
				expect(
					screen.getByRole('textbox', {
						name: /Number of years experience in this type of operation?/i,
					}),
				).toHaveValue('5');
			});
			const personRisk = screen.getByLabelText('Person Entering Risk');
			await act(async () => {
				fireEvent.change(personRisk, { target: { value: 'abc' } });
			});
			await waitFor(async () => {
				expect(screen.getByLabelText('Person Entering Risk')).toHaveValue('abc');
			});
			const emailOfPersonEnteringRisk = screen.getByRole('textbox', {
				name: /email of person entering risk/i,
			});
			await act(async () => {
				fireEvent.change(emailOfPersonEnteringRisk, { target: { value: 'abc@gmail.com' } });
				fireEvent.blur(emailOfPersonEnteringRisk);
			});
			await waitFor(async () => {
				expect(
					screen.getByRole('textbox', {
						name: /email of person entering risk/i,
					}),
				).toHaveValue('abc@gmail.com');
			});

			const selectBusinessType = getBusinessType();
			await act(async () => {
				fireEvent.click(selectBusinessType);
			});
			const dropdownOptions = getAllByRole(selectBusinessType, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[1]);
			});
			let selectedValue = selectBusinessType.children[0];
			expect(selectedValue).toHaveTextContent('CORPORATION');

			const cpName = getCompanyName(container);
			await act(async () => {
				fireEvent.change(cpName, { target: { value: 'Denver International Airport' } });
			});

			await waitFor(async () => {
				expect(getCompanyName(container)).toHaveValue('Denver International Airport');
			});

			const getFullAddress = getMailingAddress(container);

			await act(async () => {
				fireEvent.change(getFullAddress, { target: { value: '8500 Pena Blvd Denver CO 80249-6205' } });
			});

			await waitFor(async () => {
				await expect(getFullAddress).toHaveValue('8500 Pena Blvd Denver CO 80249-6205');
			});

			const btnNext = screen.getByRole('button', {
				name: /Next/i,
			});
			await act(async () => {
				await fireEvent.click(btnNext);
			});
			await expect(btnNext).toHaveClass('ui primary button');
		});
	});

	describe('Quote Information fields', () => {
		test('should render Venture is visible', () => {
			renderComponent(<GeneralInformationForm />);
			const newVentureLabel = screen.getByText('Is this a new venture?');
			expect(newVentureLabel).toBeInTheDocument();
		});

		test('New Venture is defaulted to no value to select', () => {
			renderComponent(<GeneralInformationForm />);
			const newVentureYes = screen.getByLabelText('Yes');
			const newVentureNo = screen.getByLabelText('No');
			expect(newVentureYes).not.toBeChecked();
			expect(newVentureNo).not.toBeChecked();
		});

		test('Selected Yes', async () => {
			jest.useFakeTimers();
			renderComponent(<GeneralInformationForm />);
			const newVentureYes = screen.getByLabelText('Yes');
			const newVentureNo = screen.getByLabelText('No');
			await act(async () => {
				fireEvent.click(newVentureYes);
			});
			await waitFor(async () => {
				await expect(newVentureYes).toBeChecked();
			});
			expect(newVentureNo).not.toBeChecked();
		});

		test('if Selected Yes, Number of years experience in this type of operation? should be visible', async () => {
			renderComponent(<GeneralInformationForm />);
			const newVentureYes = screen.getByLabelText('Yes');
			const newVentureNo = screen.getByLabelText('No');
			fireEvent.click(newVentureYes);
			await waitFor(async () => {
				expect(screen.getByText('Number of years experience in this type of operation?')).not.toBeChecked();
			});
			expect(newVentureYes).toBeChecked();
			expect(newVentureNo).not.toBeChecked();
		});

		test('Selected No', async () => {
			renderComponent(<GeneralInformationForm />);
			const newVentureYes = screen.getByLabelText('Yes');
			const newVentureNo = screen.getByLabelText('No');
			fireEvent.click(newVentureNo);

			await waitFor(async () => {
				expect(newVentureYes).not.toBeChecked();
			});
			expect(newVentureNo).toBeChecked();
		});

		test('if Selected No radio button Number of years experience in this type of operation? field should not be visible', async () => {
			renderComponent(<GeneralInformationForm />);
			const newVentureYes = screen.getByLabelText('Yes');
			const newVentureNo = screen.getByLabelText('No');
			fireEvent.click(newVentureNo);
			const noYearsOfExp = screen.queryByText('Number of years experience in this type of operation?');
			expect(noYearsOfExp).not.toBeInTheDocument();
			await waitFor(async () => {
				await expect(newVentureYes).not.toBeChecked();
				await expect(newVentureNo).toBeChecked();
			});
		});
	});
	describe('Number of years experience in this type of operation? field testing', () => {
		test("should not visible 'Number of years experience in this type of operation?' field when page renders", () => {
			renderComponent(<GeneralInformationForm />);
			const noYearsOfExp = screen.queryByText('Number of years experience in this type of operation?');
			expect(noYearsOfExp).not.toBeInTheDocument();
		});
		test('When selecting "Yes" to the field "Is this a new venture?" this field becomes visible', async () => {
			renderComponent(<GeneralInformationForm />);
			const newVentureYes = screen.getByLabelText('Yes');
			await act(async () => {
				fireEvent.click(newVentureYes);
			});
			await waitFor(async () => {
				await expect(screen.getByText('Number of years experience in this type of operation?')).toBeInTheDocument();
			});
		});

		test('Default value for this field should be blank', async () => {
			renderComponent(<GeneralInformationForm />);
			const newVentureYes = screen.getByLabelText('Yes');
			await act(async () => {
				fireEvent.click(newVentureYes);
			});
			await waitFor(async () => {
				await expect(screen.getByText('Number of years experience in this type of operation?')).toBeInTheDocument();
			});
			const yearsInput = screen.getByRole('textbox', {
				name: /Number of years experience in this type of operation?/i,
			});
			expect(yearsInput).toBeInTheDocument();
			expect(yearsInput).toHaveValue('');
		});

		test('Typing a number in this field should change the value to be that number', async () => {
			renderComponent(<GeneralInformationForm />);
			const newVentureYes = screen.getByLabelText('Yes');
			await act(async () => {
				fireEvent.click(newVentureYes);
			});
			await waitFor(async () => {
				await expect(screen.getByText('Number of years experience in this type of operation?')).toBeInTheDocument();
			});
			let yearsInput = screen.getByRole('textbox', {
				name: /Number of years experience in this type of operation?/i,
			});
			await act(async () => {
				fireEvent.change(yearsInput, { target: { value: '123' } });
			});
			await waitFor(async () => {
				expect(
					screen.getByRole('textbox', {
						name: /Number of years experience in this type of operation?/i,
					}),
				).toHaveValue('123');
			});
		});

		test('Clicking on the field and then clicking off the field (onBlur) with no value input causes a required error message to be displayed', async () => {
			renderComponent(<GeneralInformationForm />);
			const newVentureYes = screen.getByLabelText('Yes');
			await act(async () => {
				fireEvent.click(newVentureYes);
			});
			await waitFor(async () => {
				await expect(screen.getByText('Number of years experience in this type of operation?')).toBeInTheDocument();
			});
			const yearsInput = screen.getByRole('textbox', {
				name: /Number of years experience in this type of operation?/i,
			});

			await act(async () => {
				fireEvent.change(yearsInput);
				fireEvent.blur(yearsInput);
			});
			await waitFor(async () => {
				expect(screen.getByText('An answer to this question is required.')).toHaveTextContent(
					'An answer to this question is required.',
				);
			});
		});
	});
	describe('Email of Person Entering Risk', () => {
		test('Email field should be visiable', () => {
			renderComponent(<GeneralInformationForm />);
			const emailOfPersonEnteringRisk = screen.getByLabelText('Email of Person Entering Risk');
			expect(emailOfPersonEnteringRisk).toBeInTheDocument();
		});
		test('Default value should be blank', () => {
			renderComponent(<GeneralInformationForm />);
			const emailOfPersonEnteringRisk = screen.getByLabelText('Email of Person Entering Risk');
			expect(emailOfPersonEnteringRisk).toBeEmptyDOMElement();
		});

		test('Clicking on the field and then off the field (onBlur) with no value entered should cause a required message to appear', async () => {
			renderComponent(<GeneralInformationForm />);
			const newVentureYes = screen.getByLabelText('Yes');
			const newVentureNo = screen.getByLabelText('No');
			await act(async () => {
				fireEvent.click(newVentureYes);
			});
			await waitFor(async () => {
				await expect(newVentureYes).toBeChecked();
			});
			const emailOfPerson = screen.getByLabelText('Email of Person Entering Risk');
			fireEvent.blur(emailOfPerson);
			await waitFor(async () => {
				expect(screen.getByText(/an email address of the person entering risk is required/i)).toHaveTextContent(
					'An email address of the person entering risk is required',
				);
			});
		});
		test('entering a valid email format (ex: name@address.com) value into the text box causes the required message to go away', async () => {
			renderComponent(<GeneralInformationForm />);
			const emailWithInvalid = screen.getByRole('textbox', {
				name: /email of person entering risk/i,
			});
			await act(async () => {
				fireEvent.change(emailWithInvalid, { target: { value: 'name@address.com' } });
				fireEvent.blur(emailWithInvalid);
			});

			await waitFor(async () => {
				expect(
					screen.getByRole('textbox', {
						name: /email of person entering risk/i,
					}),
				).toHaveValue('name@address.com');
			});
		});
		test('entering an invalid email format (ex: abc) value into the text box causes the invalid email message to appear', async () => {
			renderComponent(<GeneralInformationForm />);
			const newVentureYes = screen.getByLabelText('Yes');
			const newVentureNo = screen.getByLabelText('No');
			await act(async () => {
				fireEvent.click(newVentureYes);
			});
			await waitFor(async () => {
				await expect(newVentureYes).toBeChecked();
			});
			const emailOfPersonEnteringRisk = screen.getByRole('textbox', {
				name: /email of person entering risk/i,
			});
			await act(async () => {
				fireEvent.change(emailOfPersonEnteringRisk, { target: { value: 'abc' } });
				fireEvent.blur(emailOfPersonEnteringRisk);
			});
			await waitFor(() => {
				expect(screen.getByText(/Must be a valid email address ex. name@address.com/i)).toBeInTheDocument();
			});
		});

		test('Before render set localStorage variable (personEnteringRisk) with any text', async () => {
			localStorage.setItem('personEnteringRisk', 'testValue');
			renderComponent(<GeneralInformationForm />);
			expect(localStorage.getItem('personEnteringRisk')).toEqual('testValue');
		});

		test('Default value should be what is saved in the localStorage variable (personEnteringRisk)', async () => {
			localStorage.setItem('riskvalue', 'testValue');
			renderComponent(<GeneralInformationForm />);
			expect(localStorage.getItem('riskvalue')).toEqual('testValue');
			const personRisk = await screen.findAllByText(/person entering risk/i);
			expect(personRisk[0]).toBeInTheDocument();
		});
	});

	describe('Person Entering Risk field testing', () => {
		test('On render this field should be visible', () => {
			renderComponent(<GeneralInformationForm />);
			const personRisk = screen.getByLabelText('Person Entering Risk');
			expect(personRisk).toBeInTheDocument();
		});

		test('Default value should be blank', async () => {
			renderComponent(<GeneralInformationForm />);
			const personRisk = screen.getByLabelText('Person Entering Risk');
			expect(personRisk).toBeInTheDocument();
			expect(personRisk).toHaveValue('');
		});

		test('Clicking on the field and then clicking off the field (onBlur) with no value input causes a required error message to be displayed', async () => {
			renderComponent(<GeneralInformationForm />);
			const newVentureYes = screen.getByLabelText('Yes');
			const newVentureNo = screen.getByLabelText('No');
			await act(async () => {
				fireEvent.click(newVentureYes);
			});
			await waitFor(async () => {
				await expect(newVentureYes).toBeChecked();
			});
			const personRisk = screen.getByLabelText('Person Entering Risk');
			fireEvent.blur(personRisk);
			await waitFor(async () => {
				expect(screen.getByText(/Person Entering Risk is required./i)).toHaveTextContent(
					'Person Entering Risk is required.',
				);
			});
		});

		test('entering any value into the text box causes the required message to go away', async () => {
			renderComponent(<GeneralInformationForm />);
			const newVentureYes = screen.getByLabelText('Yes');
			await act(async () => {
				fireEvent.click(newVentureYes);
			});
			await waitFor(async () => {
				await expect(newVentureYes).toBeChecked();
			});
			const emailWithInvalid = screen.getByLabelText('Person Entering Risk');
			await act(async () => {
				fireEvent.change(emailWithInvalid, { target: { value: 'abc' } });
				fireEvent.blur(emailWithInvalid);
			});

			await waitFor(async () => {
				expect(
					screen.getByRole('textbox', {
						name: 'Person Entering Risk',
					}),
				).toHaveValue('abc');
			});
		});

		test('Before render set localStorage variable (personEnteringRisk) with any text', async () => {
			localStorage.setItem('personEnteringRisk', 'abc');
			renderComponent(<GeneralInformationForm />);
			expect(localStorage.getItem('personEnteringRisk')).toEqual('abc');
		});

		test('On render this field should be visible', async () => {
			const { rerender } = renderComponent(<GeneralInformationForm />);
			const input = screen.getByLabelText('Person Entering Risk');
			await act(async () => {
				fireEvent.change(input, { target: { value: 'abc' } });
			});
			localStorage.setItem('personEnteringRisk', 'abc');
			await waitFor(() => expect(input).toHaveValue('abc'));
			expect(localStorage.getItem('personEnteringRisk')).toEqual('abc');
		});
		test('On render this field should be visible', async () => {
			const { rerender } = renderComponent(<GeneralInformationForm />);
			const input = screen.getByRole('textbox', {
				name: /email of person entering risk/i,
			});
			await act(async () => {
				fireEvent.change(input, { target: { value: 'testValue@gmail.com' } });
			});
			localStorage.setItem('personEnteringRisk', 'testValue@gmail.com');
			await waitFor(() => expect(input).toHaveValue('testValue@gmail.com'));
			expect(localStorage.getItem('personEnteringRisk')).toEqual('testValue@gmail.com');
			await act(async () => {
				fireEvent.change(input, { target: { value: '' } });
			});
			localStorage.setItem('personEnteringRisk', '');
			await waitFor(() => expect(input).toHaveValue(''));
			expect(localStorage.getItem('personEnteringRisk')).toEqual('');
		});

		test('Default value should be what is saved in the localStorage variable (personEnteringRisk)', async () => {
			localStorage.setItem('personEnteringRisk', 'abc');
			renderComponent(<GeneralInformationForm />);
			expect(localStorage.getItem('personEnteringRisk')).toEqual('abc');
			const personRisk = screen.getByLabelText('Person Entering Risk');
			expect(personRisk).toHaveValue('abc');
		});
		test('CLEAR THE INPUT - NEW RENDER SCENARIO TEST', async () => {
			const { rerender } = renderComponent(<GeneralInformationForm />);
			const input = screen.getByRole('textbox', {
				name: /email of person entering risk/i,
			});
			await act(async () => {
				fireEvent.change(input, { target: { value: 'testValue@gmail.com' } });
			});
			await waitFor(async () => expect(input).toHaveValue('testValue@gmail.com'));
			rerender(<GeneralInformationForm />);
			const inputAway = screen.getByLabelText('Person Entering Risk');
			await waitFor(() => expect(inputAway).toHaveValue(''));
		});

		test('Default value should be what is saved in the localStorage variable (personEnteringRisk)', async () => {
			localStorage.setItem('riskvalue', 'testValue');
			renderComponent(<GeneralInformationForm />);
			expect(localStorage.getItem('riskvalue')).toEqual('testValue');
			const personRisk = await screen.findAllByText(/person entering risk/i);
			expect(personRisk[0]).toBeInTheDocument();
		});
	});

	describe('Insuresd First Name', () => {
		test('On render this field should not be visible', () => {
			renderComponent(<GeneralInformationForm />);
			const insured = screen.queryByText('Insured First Name');
			expect(insured).not.toBeInTheDocument();
		});

		test('Select "INDIVIDUAL" from the "Business Type" dropdown', async () => {
			renderComponent(<GeneralInformationForm />);
			const dropdown = screen.getByTestId('insured');
			await act(async () => {
				fireEvent.click(dropdown);
			});
			const dropdownOptions = getAllByRole(dropdown, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[2]);
			});
			const display = dropdown.children[0];
			await waitFor(async () => {
				expect(display).toHaveTextContent('INDIVIDUAL');
			});
		});

		test('this field should be visible', async () => {
			renderComponent(<GeneralInformationForm />);
			const dropdown = screen.getByTestId('insured');
			await act(async () => {
				fireEvent.click(dropdown);
			});
			const dropdownOptions = getAllByRole(dropdown, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[2]);
			});
			const display = dropdown.children[0];
			expect(display).toHaveTextContent('INDIVIDUAL');
			const personRisk = screen.getByLabelText('Insured First Name');
			await waitFor(async () => {
				expect(personRisk).toBeInTheDocument();
			});
		});

		test('Default value of this field is blank', async () => {
			renderComponent(<GeneralInformationForm />);
			const dropdown = screen.getByTestId('insured');
			await act(async () => {
				fireEvent.click(dropdown);
			});
			const dropdownOptions = getAllByRole(dropdown, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[2]);
			});
			const display = dropdown.children[0];
			expect(display).toHaveTextContent('INDIVIDUAL');
			const personRisk = screen.getByLabelText('Insured First Name');
			expect(personRisk).toBeInTheDocument();
			await waitFor(async () => {
				expect(personRisk).toHaveValue('');
			});
		});

		test('Clicking on the field and then off the field (onBlur) with no value entered should cause a required message to appear', async () => {
			renderComponent(<GeneralInformationForm />);
			const dropdown = screen.getByTestId('insured');
			await act(async () => {
				fireEvent.click(dropdown);
			});
			const dropdownOptions = getAllByRole(dropdown, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[2]);
			});
			const display = dropdown.children[0];
			expect(display).toHaveTextContent('INDIVIDUAL');
			const personRisk = screen.getByLabelText('Insured First Name');
			fireEvent.blur(personRisk);
			await waitFor(async () => {
				expect(screen.getByText(/Insured first name is required./i)).toHaveTextContent(
					'Insured first name is required.',
				);
			});
		});
		test('Typing anything in the field should make the required message go away', async () => {
			renderComponent(<GeneralInformationForm />);
			const dropdown = screen.getByTestId('insured');
			await act(async () => {
				fireEvent.click(dropdown);
			});
			const dropdownOptions = getAllByRole(dropdown, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[2]);
			});
			const display = dropdown.children[0];
			expect(display).toHaveTextContent('INDIVIDUAL');
			const personRisk = screen.getByLabelText('Insured First Name');
			await act(async () => {
				fireEvent.change(personRisk, { target: { value: 'abc' } });
			});
			fireEvent.blur(personRisk);
			await waitFor(async () => {
				expect(
					screen.getByRole('textbox', {
						name: 'Insured First Name',
					}),
				).toHaveValue('abc');
			});
		});
	});
	describe('Business Type', () => {
		test('On render this field should be visible', () => {
			renderComponent(<GeneralInformationForm />);
			const businessType = screen.getByText(/business type/i);
			expect(businessType).toBeInTheDocument();
		});

		test('All options should be visible', async () => {
			renderComponent(<GeneralInformationForm />);

			const selectBusinessType = getBusinessType();

			await act(async () => {
				fireEvent.click(selectBusinessType);
			});
			const dropdownOptions = getAllByRole(selectBusinessType, 'option');
			expect(dropdownOptions[0].innerHTML.includes('ASSOC., LABOR UNION, RELIGIOUS ORG.')).toBeTruthy();
			expect(dropdownOptions[1].innerHTML.includes('CORPORATION')).toBeTruthy();
			expect(dropdownOptions[2].innerHTML.includes('INDIVIDUAL')).toBeTruthy();
			expect(dropdownOptions[3].innerHTML.includes('JOINT EMPLOYER')).toBeTruthy();
			expect(dropdownOptions[4].innerHTML.includes('JOINT VENTURE')).toBeTruthy();
			expect(dropdownOptions[5].innerHTML.includes('LIMITED LIABILITY COMPANY')).toBeTruthy();
			expect(dropdownOptions[6].innerHTML.includes('LIMITED PARTNERSHIP')).toBeTruthy();
			expect(dropdownOptions[7].innerHTML.includes('PARTNERSHIP')).toBeTruthy();
			expect(dropdownOptions[8].innerHTML.includes('TRUST OR ESTATE')).toBeTruthy();
		});

		test('Selecting either [INDIVIDUAL, LIMITED PARTNERSHIP, PARTNERSHIP] will cause the "Company Name" field to be not visible', async () => {
			const { container } = renderComponent(<GeneralInformationForm />);
			const selectBusinessType = getBusinessType();
			await act(async () => {
				fireEvent.click(selectBusinessType);
			});
			const dropdownOptions = getAllByRole(selectBusinessType, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[2]);
			});
			let selectedValue = selectBusinessType.children[0];
			expect(selectedValue).toHaveTextContent('INDIVIDUAL');
			let companyName = getCompanyName(container);
			await waitFor(() => {
				expect(companyName).not.toBeInTheDocument();
			});
			await act(async () => {
				fireEvent.click(selectBusinessType);
			});
			await act(async () => {
				fireEvent.click(dropdownOptions[6]);
			});
			selectedValue = selectBusinessType.children[0];
			expect(selectedValue).toHaveTextContent('LIMITED PARTNERSHIP');
			companyName = getCompanyName(container);
			await waitFor(() => {
				expect(companyName).not.toBeInTheDocument();
			});
			await act(async () => {
				fireEvent.click(selectBusinessType);
			});
			await act(async () => {
				fireEvent.click(dropdownOptions[7]);
			});
			selectedValue = selectBusinessType.children[0];
			expect(selectedValue).toHaveTextContent('PARTNERSHIP');
			companyName = getCompanyName(container);
			await waitFor(() => {
				expect(companyName).not.toBeInTheDocument();
			});
		});

		test('Selecting either [INDIVIDUAL, LIMITED PARTNERSHIP, PARTNERSHIP] will cause the "Insured First Name" field to be visible', async () => {
			renderComponent(<GeneralInformationForm />);
			const selectBusinessType = getBusinessType();
			await act(async () => {
				fireEvent.click(selectBusinessType);
			});
			const dropdownOptions = getAllByRole(selectBusinessType, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[2]);
			});
			const selectedValue = selectBusinessType.children[0];
			expect(selectedValue).toHaveTextContent('INDIVIDUAL');
			const insuredFirstName = getInsuredFirstName();
			await waitFor(() => {
				expect(insuredFirstName).toBeInTheDocument();
			});
		});
		test('Selecting either [INDIVIDUAL, LIMITED PARTNERSHIP, PARTNERSHIP] will cause the "Insured Last Name" field to be visible', async () => {
			renderComponent(<GeneralInformationForm />);
			const selectBusinessType = getBusinessType();
			await act(async () => {
				fireEvent.click(selectBusinessType);
			});
			const dropdownOptions = getAllByRole(selectBusinessType, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[2]);
			});
			const selectedValue = selectBusinessType.children[0];
			expect(selectedValue).toHaveTextContent('INDIVIDUAL');
			const insuredLirstName = getInsuredLirstName();
			await waitFor(() => {
				expect(insuredLirstName).toBeInTheDocument();
			});
		});
		test('Selecting an option other than [INDIVIDUAL, LIMITED PARTNERSHIP, PARTNERSHIP] will cause the "Company Name" field to be visible', async () => {
			const { container } = renderComponent(<GeneralInformationForm />);
			const selectBusinessType = getBusinessType();
			await act(async () => {
				fireEvent.click(selectBusinessType);
			});
			const dropdownOptions = getAllByRole(selectBusinessType, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[3]);
			});
			let selectedValue = selectBusinessType.children[0];
			expect(selectedValue).toHaveTextContent('JOINT EMPLOYER');
			let companyName = getCompanyName(container);
			await waitFor(() => {
				expect(companyName).toBeInTheDocument();
			});

			await act(async () => {
				fireEvent.click(selectBusinessType);
			});
			await act(async () => {
				fireEvent.click(dropdownOptions[4]);
			});
			selectedValue = selectBusinessType.children[0];
			expect(selectedValue).toHaveTextContent('JOINT VENTURE');
			companyName = getCompanyName(container);
			await waitFor(() => {
				expect(companyName).toBeInTheDocument();
			});
			await act(async () => {
				fireEvent.click(selectBusinessType);
			});
			await act(async () => {
				fireEvent.click(dropdownOptions[8]);
			});
			selectedValue = selectBusinessType.children[0];
			expect(selectedValue).toHaveTextContent('TRUST OR ESTATE');
			companyName = getCompanyName(container);
			await waitFor(() => {
				expect(companyName).toBeInTheDocument();
			});
		});

		test('Selecting an option other than [INDIVIDUAL, LIMITED PARTNERSHIP, PARTNERSHIP] will cause the "Insured First Name" field to not be visible', async () => {
			renderComponent(<GeneralInformationForm />);
			const selectBusinessType = getBusinessType();
			await act(async () => {
				fireEvent.click(selectBusinessType);
			});
			const dropdownOptions = getAllByRole(selectBusinessType, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[4]);
			});
			const selectedValue = selectBusinessType.children[0];
			expect(selectedValue).toHaveTextContent('JOINT VENTURE');
			const insuredFirstName = getInsuredFirstName();
			await waitFor(() => {
				expect(insuredFirstName).not.toBeInTheDocument();
			});
		});
		test('Selecting an option other than [INDIVIDUAL, LIMITED PARTNERSHIP, PARTNERSHIP] will cause the "Insured Last Name" field to not be visible', async () => {
			renderComponent(<GeneralInformationForm />);
			const selectBusinessType = getBusinessType();
			await act(async () => {
				fireEvent.click(selectBusinessType);
			});
			const dropdownOptions = getAllByRole(selectBusinessType, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[4]);
			});
			const selectedValue = selectBusinessType.children[0];
			expect(selectedValue).toHaveTextContent('JOINT VENTURE');
			const insuredFirstName = getInsuredLirstName();
			await waitFor(() => {
				expect(insuredFirstName).not.toBeInTheDocument();
			});
		});
	});
	function getBusinessType() {
		return screen.getByTestId('insured');
	}
	function getInsuredFirstName() {
		return screen.queryByText(/Insured First Name/i);
	}
	function getInsuredLirstName() {
		return screen.queryByText(/Insured Last Name/i);
	}
	function getCompanyName(container) {
		return container.querySelector('input[name="insuredName.company"]');
	}
	function getMailingAddress(container) {
		return container.querySelector('input[name="address.fullAddress"]');
	}
	describe('Insuresd Last Name', () => {
		test('On render this field should not be visible', () => {
			renderComponent(<GeneralInformationForm />);
			const insured = screen.queryByText('Insured Last Name');
			expect(insured).not.toBeInTheDocument();
		});

		test('Select "INDIVIDUAL" from the "Business Type" dropdown', async () => {
			renderComponent(<GeneralInformationForm />);
			const dropdown = screen.getByTestId('insured');
			await act(async () => {
				fireEvent.click(dropdown);
			});
			const dropdownOptions = getAllByRole(dropdown, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[2]);
			});

			const display = dropdown.children[0];
			await waitFor(() => {
				expect(display).toHaveTextContent('INDIVIDUAL');
			});
		});

		test('this field should be visible', async () => {
			renderComponent(<GeneralInformationForm />);
			const dropdown = screen.getByTestId('insured');
			await act(async () => {
				fireEvent.click(dropdown);
			});
			const dropdownOptions = getAllByRole(dropdown, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[2]);
			});
			const display = dropdown.children[0];
			expect(display).toHaveTextContent('INDIVIDUAL');
			const personRisk = screen.getByLabelText('Insured Last Name');
			await waitFor(() => {
				expect(personRisk).toBeInTheDocument();
			});
		});

		test('Default value of this field is blank', async () => {
			renderComponent(<GeneralInformationForm />);
			const dropdown = screen.getByTestId('insured');
			await act(async () => {
				fireEvent.click(dropdown);
			});
			const dropdownOptions = getAllByRole(dropdown, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[2]);
			});
			const display = dropdown.children[0];
			expect(display).toHaveTextContent('INDIVIDUAL');
			const personRisk = screen.getByLabelText('Insured Last Name');
			expect(personRisk).toBeInTheDocument();
			await waitFor(() => {
				expect(personRisk).toHaveValue('');
			});
		});

		test('Clicking on the field and then off the field (onBlur) with no value entered should cause a required message to appear', async () => {
			renderComponent(<GeneralInformationForm />);
			const dropdown = screen.getByTestId('insured');
			await act(async () => {
				fireEvent.click(dropdown);
			});
			const dropdownOptions = getAllByRole(dropdown, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[2]);
			});
			const display = dropdown.children[0];
			expect(display).toHaveTextContent('INDIVIDUAL');
			const personRisk2 = screen.getByLabelText('Insured First Name');
			await act(async () => {
				fireEvent.blur(personRisk2);
			});
			await waitFor(async () => {
				expect(screen.getByText(/Insured first name is required./i)).toHaveTextContent(
					'Insured first name is required.',
				);
			});
		});

		test('Typing anything in the field should make the required message go away', async () => {
			renderComponent(<GeneralInformationForm />);
			const dropdown = screen.getByTestId('insured');
			await act(async () => {
				fireEvent.click(dropdown);
			});
			const dropdownOptions = getAllByRole(dropdown, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[2]);
			});
			const display = dropdown.children[0];
			expect(display).toHaveTextContent('INDIVIDUAL');
			const personRisk = screen.getByLabelText('Insured Last Name');
			await act(async () => {
				fireEvent.change(personRisk, { target: { value: 'abc' } });
				fireEvent.blur(personRisk);
			});
			await waitFor(async () => {
				expect(
					screen.getByRole('textbox', {
						name: 'Insured Last Name',
					}),
				).toHaveValue('abc');
			});
		});
	});

	describe('Test case for Company name', () => {
		test('On render this field is visible', () => {
			renderComponent(<GeneralInformationForm />);
			const companyName = screen.getByText('Company Name');
			expect(companyName).toBeInTheDocument();
		});

		test('Default company name value should be blank', async () => {
			const { container } = renderComponent(<GeneralInformationForm />);
			const location = container.querySelector('input[name="insuredName.company"]');
			expect(location).toBeInTheDocument();
			expect(location).toHaveValue('');
		});

		test('Clicking on the field and then off the field (onBlur) with no value entered should not cause a required message to appear', async () => {
			const { container } = renderComponent(<GeneralInformationForm />);
			const location = container.querySelector('input[name="insuredName.company"]');
			await act(async () => {
				fireEvent.click(location);
			});
			await act(async () => {
				fireEvent.blur(location);
			});
			const insured = screen.queryByText('Company name is required.');
			await waitFor(() => expect(insured).not.toBeInTheDocument());
		});

		test('Select "CORPORATION" from the "Business Type" dropdown', async () => {
			renderComponent(<GeneralInformationForm />);
			const dropdown = screen.getByTestId('insured');
			await act(async () => {
				fireEvent.click(dropdown);
			});
			const dropdownOptions = getAllByRole(dropdown, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[1]);
			});
			const display = dropdown.children[0];
			await waitFor(() => expect(display).toHaveTextContent('CORPORATION'));
		});

		test('Clicking on the field and then off the field (onBlur) with no value entered should cause a required message to appear', async () => {
			const { container } = renderComponent(<GeneralInformationForm />);
			const dropdown = screen.getByTestId('insured');
			await act(async () => {
				fireEvent.click(dropdown);
			});
			const dropdownOptions = getAllByRole(dropdown, 'option');
			await act(async () => {
				fireEvent.click(dropdownOptions[1]);
			});
			const display = dropdown.children[0];
			expect(display).toHaveTextContent('CORPORATION');
			const location = container.querySelector('input[name="insuredName.company"]');
			await act(async () => {
				fireEvent.click(location);
			});
			await act(async () => {
				fireEvent.blur(location);
			});
			await waitFor(async () => {
				expect(screen.getByText(/Company name is required./i)).toHaveTextContent('Company name is required.');
			});
		});

		test('Typing the words "Columbia Insurance" into the text box should display a google suggestion popup', async () => {
			renderComponent(<GeneralInformationForm />);
			const { container } = renderComponent(<GeneralInformationForm />);
			const location = container.querySelector('input[name="insuredName.company"]');
			await act(async () => {
				fireEvent.click(location);
			});
			await act(async () => {
				fireEvent.change(location, { target: { value: 'Columbia Insurance' } });
			});
			const locationOption = container.querySelector('ul[id="geosuggest__list--insuredName.company"]');
			await waitFor(() => expect(locationOption).toBeInTheDocument());
		});

		test('Clicking off the text box (onBlur) should make the google suggestion popup go away', async () => {
			const { container } = renderComponent(<GeneralInformationForm />);
			const location = container.querySelector('input[name="insuredName.company"]');
			await act(async () => {
				fireEvent.click(location);
			});
			await act(async () => {
				fireEvent.change(location, { target: { value: 'Columbia Insurance' } });
			});
			await act(async () => {
				fireEvent.blur(location);
			});
			const locationOption = container.querySelector('ul[class="geosuggest__suggests"]');
			await waitFor(() => expect(locationOption).not.toBeInTheDocument());
		});

		test('The value of the "Mailing Address" field should be blank', async () => {
			const { container } = renderComponent(<GeneralInformationForm />);
			const location = container.querySelector('input[name="address.fullAddress"]');
			expect(location).toBeInTheDocument();
			expect(location).toHaveValue('');
		});
		test('The value of the "Company Name" field should now be (Columbia Inaurance Group)', async () => {
			const { container } = renderComponent(<GeneralInformationForm />);
			function getMailingAddress(container) {
				return container.querySelector('input[name="address.fullAddress"]');
			}
			const compName = getCompanyName(container);
			await act(async () => {
				fireEvent.change(compName, {
					target: { value: 'Columbia Insurance Group' },
				});
			});
			await waitFor(async () => {
				expect(getCompanyName(container)).toHaveValue('Columbia Insurance Group');
			});
			const getFullAddress = getMailingAddress(container);
			await act(async () => {
				fireEvent.change(getFullAddress, { target: { value: '2102 Whitegate Dr Columbia MO 65202-2335' } });
			});
			await waitFor(async () => {
				await expect(getFullAddress).toHaveValue('2102 Whitegate Dr Columbia MO 65202-2335');
			});
		});
	});
});
