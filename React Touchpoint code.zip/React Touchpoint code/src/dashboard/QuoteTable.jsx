import _ from 'lodash';
import React from 'react';
import NumberFormat from 'react-number-format';
import { Pagination, Table } from 'semantic-ui-react';
import { getFullInsuredName, getProdIcon, isEmployee } from 'utils/BusinessFunctions';
import { formatDate } from 'utils/DateFunctions';

export const QuoteTable = ({
	quotes,
	handleSort,
	column,
	direction,
	activePage,
	handleLoadQuote,
	handlePaginationChange,
	filter,
}) => {
	const filteredQuotes = quotes.filter(
		(quote) =>
			quote.insuredName &&
			((quote.insuredName.last && quote.insuredName.last.toLowerCase().includes(filter.toLowerCase())) ||
				(quote.insuredName.first && quote.insuredName.first.toLowerCase().includes(filter.toLowerCase())) ||
				(quote.insuredName.company && quote.insuredName.company.toLowerCase().includes(filter.toLowerCase())) ||
				(quote.insuredName.dba && quote.insuredName.dba.toLowerCase().includes(filter.toLowerCase())) ||
				(quote.quoteNumber && quote.quoteNumber.toString().includes(filter.toLowerCase()))),
	);

	const productDisplay = (prod, quote) => {
		let rate = _.get(quote, `rates.${prod}`);
		let disp = '';
		if (prod === 'total') {
			const sfgRate = _.get(quote, 'rates.sfg');
			const capRate = _.get(quote, 'rates.cap');
			const wcpRate = _.get(quote, 'rates.wcp');
			const cupRate = _.get(quote, 'rates.cup');

			rate = 0;

			if (
				(sfgRate && sfgRate === 'error') ||
				(capRate && capRate === 'error') ||
				(wcpRate && wcpRate === 'error') ||
				(cupRate && cupRate === 'error')
			) {
				rate = 'error';
			} else if (
				rate !== 'error' &&
				((sfgRate && sfgRate === 'quoting') ||
					(capRate && capRate === 'quoting') ||
					(wcpRate && wcpRate === 'quoting') ||
					(cupRate && cupRate === 'quoting'))
			) {
				rate = 'quoting';
			} else if (!_.includes(['error', 'quoting'], rate)) {
				rate += sfgRate;
				rate += capRate || 0;
				rate += wcpRate || 0;
				rate += cupRate || 0;
			}
		}

		switch (rate) {
			case 'error':
				disp = <i className='fas fa-exclamation-square large error' />;
				break;
			case 'quoting':
				disp = <i className='fas fa-ellipsis-h' />;
				break;
			default:
				if (_.isNumber(rate)) {
					disp = <NumberFormat value={rate} displayType='text' thousandSeparator prefix='$' />;
				} else {
					disp = null;
				}
		}
		return disp;
	};

	const statusDisplay = (status, blockAgentEdit) => {
		let disp = '';
		switch (status) {
			case 'b':
			case 'c':
				disp = <i className='fas fa-file-alt leftIcon bound' alt='View/Print Documents' title='View/Print Documents' />;
				break;
			case 'u':
				if (blockAgentEdit) {
					disp = <i className='fas fa-lock leftIcon unbound' alt='Locked for Archiving' title='Locked for Archiving' />;
				} else {
					disp = <i className='fas fa-user-edit leftIcon unbound scoot' alt='Edit Quote' title='Edit Quote' />;
				}
				break;
			default:
				if (blockAgentEdit) {
					disp = <i className='fas fa-lock leftIcon edit' alt='Locked by Underwriter' title='Locked by Underwriter' />;
				} else {
					disp = <i className='fas fa-edit leftIcon edit scoot' alt='Edit Quote' title='Edit Quote' />;
				}
		}

		return disp;
	};
	const per_page = 15;
	const offset = (activePage - 1) * per_page;
	const paginatedQuotes = filteredQuotes.slice(offset, offset + per_page);
	return (
		<Table selectable sortable singleLine id='quoteList'>
			<Table.Header>
				<Table.Row>
					<Table.HeaderCell sorted={column === 'status' ? direction : null} onClick={handleSort('status')} width={1}>
						Status
					</Table.HeaderCell>
					{isEmployee() ? (
						<Table.HeaderCell
							sorted={column === 'agentNumber' ? direction : null}
							onClick={handleSort('agentNumber')}
							width={1}
						>
							Agent Number
						</Table.HeaderCell>
					) : (
						''
					)}
					<Table.HeaderCell
						sorted={column === 'insuredName' ? direction : null}
						onClick={handleSort('insuredName')}
						width={5}
					>
						Insured Name
					</Table.HeaderCell>
					<Table.HeaderCell
						sorted={column === 'effectiveDate' ? direction : null}
						onClick={handleSort('effectiveDate')}
						width={3}
					>
						Effective Date
					</Table.HeaderCell>
					<Table.HeaderCell
						sorted={column === 'quoteNumber' ? direction : null}
						onClick={handleSort('quoteNumber')}
						width={3}
					>
						Reference Number
					</Table.HeaderCell>
					<Table.HeaderCell
						sorted={column === 'policyNumber' ? direction : null}
						onClick={handleSort('policyNumber')}
						width={3}
					>
						Policy Number
					</Table.HeaderCell>
					<Table.HeaderCell textAlign='center' width={1} className='noHover'>
						{getProdIcon('sfg', 'big')}
					</Table.HeaderCell>
					<Table.HeaderCell textAlign='center' width={1} className='noHover'>
						{getProdIcon('cap', 'big')}
					</Table.HeaderCell>
					<Table.HeaderCell textAlign='center' width={1} className='noHover'>
						{getProdIcon('wcp', 'big')}
					</Table.HeaderCell>
					<Table.HeaderCell textAlign='center' width={1} className='noHover'>
						{getProdIcon('cup', 'big')}
					</Table.HeaderCell>
					<Table.HeaderCell textAlign='right' width={1} className='noHover'>
						Total Premium
					</Table.HeaderCell>
				</Table.Row>
			</Table.Header>
			<Table.Body>
				{paginatedQuotes.map((quote) => {
					return (
						<Table.Row
							key={quote.id}
							onClick={handleLoadQuote(quote.agentSubpro, quote.id, quote.blockAgentEdit, quote.status)}
						>
							<Table.Cell>{statusDisplay(quote.status, quote.blockAgentEdit)}</Table.Cell>
							{isEmployee() ? <Table.Cell>{quote.agentSubpro}</Table.Cell> : ''}
							<Table.Cell>
								<div className='insuredName'>{getFullInsuredName(quote)}</div>
								{quote.insuredName.dba}
							</Table.Cell>
							<Table.Cell>{formatDate(quote.effectiveDate, false)}</Table.Cell>
							<Table.Cell>{_.get(quote, 'quoteNumber', '')}</Table.Cell>
							<Table.Cell>{_.get(quote, 'policyNumber', '')}</Table.Cell>
							<Table.Cell textAlign='center'>{productDisplay('sfg', quote)}</Table.Cell>
							<Table.Cell textAlign='center'>{productDisplay('cap', quote)}</Table.Cell>
							<Table.Cell textAlign='center'>{productDisplay('wcp', quote)}</Table.Cell>
							<Table.Cell textAlign='center'>{productDisplay('cup', quote)}</Table.Cell>
							<Table.Cell textAlign='right'>{productDisplay('total', quote)}</Table.Cell>
						</Table.Row>
					);
				})}
			</Table.Body>
			<Table.Footer>
				<Table.Row>
					<Table.HeaderCell colSpan='11'>
						<Pagination
							activePage={activePage}
							boundaryRange={1}
							onPageChange={handlePaginationChange}
							size='mini'
							siblingRange={1}
							totalPages={Math.ceil(filteredQuotes.length / per_page)}
						/>
					</Table.HeaderCell>
				</Table.Row>
			</Table.Footer>
		</Table>
	);
};
