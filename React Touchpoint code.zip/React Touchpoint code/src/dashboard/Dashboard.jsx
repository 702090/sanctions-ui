import { parseJwt } from '@columbiainsurance/functions-js';
import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import QuoteContext from 'context/quoteContext';
import { QuoteTable } from 'dashboard/QuoteTable';
import _ from 'lodash';
import React, { Component } from 'react';
import { toast } from 'react-toastify';
import { Input } from 'semantic-ui-react';
import { getQuoteList } from 'services/quoteService';
import { getFullInsuredName, isEmployee } from 'utils/BusinessFunctions';
import ProductModal from './ProductModal';

class Dashboard extends Component {
	static contextType = QuoteContext;

	state = {
		quotes: [],
		filter: '',
		sorting: { column: null, direction: null },
		activePage: 1,
	};

	constructor() {
		super();
		this.productModal = React.createRef();
	}

	handleCreateQuote = () => {
		this.props.history.push('/quote');
	};

	handleLoadQuote = (agentSubpro, id, blockAgentEdit, status) => () => {
		if (isEmployee() || !blockAgentEdit || _.includes(['b', 'c'], status)) {
			this.props.history.push(`/quote/load/${agentSubpro}/${id}`);
		} else {
			toast.error('This quote can no longer be edited');
		}
	};

	handlePaginationChange = (e, { activePage }) => {
		this.setState({ activePage });
	};

	handleSearch = (search) => {
		this.setState({ filter: search.target.value });
	};

	handleSort = (clickedColumn) => () => {
		const { column, direction } = this.state.sorting;
		const { quotes } = this.state;

		if (column !== clickedColumn) {
			this.setState({
				activePage: 1,
				quotes: _.sortBy(
					quotes,
					[
						(quote) => {
							switch (clickedColumn) {
								case 'insuredName':
									return getFullInsuredName(quote).toLowerCase();
								case 'effectiveDate':
									return new Date(quote.effectiveDate);
								case 'quoteNumber':
									return _.get(quote, 'quoteNumber', 0);
								default:
									return quote[clickedColumn] ? quote[clickedColumn].toLowerCase() : '';
							}
						},
					],
					[clickedColumn],
				),
				sorting: {
					column: clickedColumn,
					direction: 'ascending',
				},
			});

			return;
		}

		this.setState({
			quotes: quotes.reverse(),
			sorting: {
				direction: direction === 'ascending' ? 'descending' : 'ascending',
				column: clickedColumn,
			},
		});
	};

	async componentDidMount() {
		this.context.resetQuote();
		let quotes = [];
		const agentToken = parseJwt(sessionStorage.getItem('agentToken'));

		if (isEmployee() && agentToken.agentSubpro === '55110-00001') {
			const SEGMENT_TOTAL = 6;
			const promiseArray = [];

			for (let segmentIndex = 0; segmentIndex < SEGMENT_TOTAL; segmentIndex++) {
				promiseArray.push(
					getQuoteList({
						agentToken,
						segmentIndex,
						segmentTotal: SEGMENT_TOTAL,
					}),
				);
			}
			quotes = await Promise.all(promiseArray);
			quotes = _.flatMap(quotes, (quote) => quote.data);
		} else {
			quotes = await getQuoteList({ agentToken });
			quotes = quotes.data;
		}

		quotes = _.reverse(_.sortBy(quotes, 'effectiveDate'));
		this.setState({
			quotes,
		});
	}

	render() {
		return (
			<React.Fragment>
				<ProductModal ref={this.productModal} {...this.props} />
				<div id='headerButtons'>
					<SimpleButton
						className='white'
						content='New Quote'
						id='NewQuote'
						onClick={() => {
							this.context.resetQuote();
							this.productModal.current.handleOpen(this.handleCreateQuote);
						}}
						icon='add'
					/>
					<Input id='search' name='search' icon='search' placeholder='Search...' onKeyUp={this.handleSearch} />
				</div>
				<div id='statusLegend'>
					<div className='legendItem'>
						<span className='edit'>In Progress</span>
						<span className='unBound'>Under Review</span>
						<span className='bound'>Bound</span>
					</div>
				</div>
				<QuoteTable
					quotes={this.state.quotes}
					handleSort={this.handleSort}
					{...this.state.sorting}
					activePage={this.state.activePage}
					handleLoadQuote={this.handleLoadQuote}
					handlePaginationChange={this.handlePaginationChange}
					filter={this.state.filter}
				/>
			</React.Fragment>
		);
	}
}

export default Dashboard;
