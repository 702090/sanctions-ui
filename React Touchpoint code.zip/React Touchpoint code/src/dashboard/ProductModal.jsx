import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import QuoteContext from 'context/quoteContext';
import React, { Component } from 'react';
import { Modal } from 'semantic-ui-react';
import { EditProducts } from 'sidebar/EditProducts';
import { pageAnalytics } from 'utils/ScreenFunctions';

class ProductModal extends Component {
	static contextType = QuoteContext;

	constructor() {
		super();
		this.state = {
			isOpen: false,
			options: {},
		}; // state to control the state of popup
	}

	handleOpen = (callback) => {
		this.setState({ callback, isOpen: true });
		pageAnalytics(this.props.location.pathname + '/ProductModal', true);
	};

	handleClose = (v) => {
		this.setState({ isOpen: false });
		pageAnalytics(this.props.location.pathname);
	};

	render() {
		return (
			<Modal open={this.state.isOpen}>
				<Modal.Header>Select Products to Quote</Modal.Header>
				<Modal.Content>
					<EditProducts
						quote={this.context.quote}
						updateProducts={this.context.updateProducts}
						newQuote
						{...this.props}
					/>
					<div className='prodInstruction'>
						You may add or remove products at any time by using the "Products" tab
						<br />
						found on the right hand column during the quoting process.
					</div>
				</Modal.Content>
				<Modal.Actions>
					<SimpleButton onClick={this.handleClose} content='Cancel' />
					<SimpleButton
						onClick={() => {
							this.handleClose();
							this.state.callback();
						}}
						primary
						content='Start Quote'
					/>
				</Modal.Actions>
			</Modal>
		);
	}
}

export default ProductModal;
