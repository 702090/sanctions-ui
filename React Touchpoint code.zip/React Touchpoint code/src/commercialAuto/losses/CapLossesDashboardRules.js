import { getFieldDisplayArray } from 'data/FieldVisibility';
import _ from 'lodash';
import { getVisibility } from 'utils/ScreenFunctions';

export default class CapLossesDashboardRules {
	static requiredStructure = {
		section_losses_cap: '',
		cap: { noLosses: '' },
	};

	static rules(quote, values, visibility) {
		if (!visibility) {
			visibility = getVisibility(getFieldDisplayArray('commercialAutoLosses'), quote, values);
		}

		return {
			section_losses_cap: [
				[
					(value) => {
						return !(
							_.includes(..._.get(quote, 'clueOrderRequired', []), 'cap') ||
							_.includes(..._.get(values, 'clueOrderRequired', []), 'cap')
						);
					},
					'You must come to this page',
				],
			],
			cap: {
				noLosses: [
					[
						(value) => value || !visibility.noLosses,
						'Please verify there have been no losses in the past three years. If no losses, please check the box stating this to continue with this quote.',
					],
				],
			},
		};
	}

	static referrals(context, values) {
		return {
			section_losses_cap: [
				[(value) => _.size(_.get(context, 'quote.cap.losses', {})) < 3, 'CLH01'],
				[(value) => getTotalPaidAmount(context.quote) < 10000, 'CLH02'],
			],
		};
	}

	static name() {
		return 'capLossesDashboard';
	}
}

function getTotalPaidAmount(quote) {
	const losses = _.get(quote, 'cap.losses', {});
	let totalAmountPaid = 0;

	Object.keys(losses).forEach((key) => {
		totalAmountPaid += losses[key].totalAmountPaid;
	});

	return totalAmountPaid;
}
