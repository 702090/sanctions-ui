import _ from 'lodash';
import { calculateAge } from 'utils/DateFunctions';

export default class DriverDashboardRules {
	static requiredStructure = {
		section_drivers: '',
	};

	static rules(quote, values) {
		return {
			section_drivers: [
				[(value) => Object.keys(_.get(quote, 'cap.drivers', {})).length >= 1, 'You must have at least one driver.'],
			],
		};
	}

	static referrals(context, values) {
		let driverOver80 = false;

		_.forEach(_.get(context, 'quote.cap.drivers', {}), (driver) => {
			if (calculateAge(_.get(driver, 'birthDate'), _.get(context, 'quote.effectiveDate', '')) > 80) {
				driverOver80 = true;
			}
		});

		return {
			section_drivers: [[(value) => !driverOver80, 'CAD01']],
		};
	}

	static name() {
		return 'capDriverDashboard';
	}
}
