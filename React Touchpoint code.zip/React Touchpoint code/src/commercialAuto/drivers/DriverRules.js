import ruleMessagesJson from 'data/RuleMessages';
import _ from 'lodash';
import { licenseExists } from 'utils/BusinessFunctions';
import { calculateAge, daysFromNow, isValidDate } from 'utils/DateFunctions';
import { isBlank } from 'utils/StringFunctions';

const { requiredMessageText } = ruleMessagesJson;

export default class DriverRules {
	static requiredStructure = {
		name: {
			first: '',
			last: '',
		},
		birthDate: '',
		licenseState: '',
		licenseNumber: '',
	};

	static rules(quote, values) {
		// use values for current page validation
		// use quote for external page validation
		return {
			name: {
				first: [[(value) => !isBlank(value), requiredMessageText]],
				last: [[(value) => !isBlank(value), requiredMessageText]],
			},
			birthDate: [
				[(value) => !isBlank(value), requiredMessageText],
				[(value) => isValidDate(value), 'You must enter a valid date.'],
				[(value) => daysFromNow(value) <= 0, 'Future dates are not allowed. Please verify your date is correct.'],
				[
					(value) => calculateAge(value, _.get(quote, 'effectiveDate', '')) <= 90,
					'Please contact your Underwriter for Risk Eligibility.',
				],
			],
			licenseState: [[(value) => !isBlank(value), requiredMessageText]],
			licenseNumber: [
				[(value) => !isBlank(value), requiredMessageText],
				[
					(value) => !licenseExists(quote, value, values.id),
					'The license number must be unique, and this license number is already entered for another driver.',
				],
			],
		};
	}

	static referrals(context, values) {
		return {};
	}

	static name() {
		return 'capDriver';
	}
}
