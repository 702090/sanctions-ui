import { ModalStepper } from 'components/shared/navigation/ModalStepper';
import QuoteContext from 'context/quoteContext';
import React, { Component } from 'react';
import { Modal } from 'semantic-ui-react';
import { pageAnalytics } from 'utils/ScreenFunctions';
import { replaceReferrals } from 'validation/RunReferrals';
import DriverForm from './DriverForm';

export class DriverModal extends Component {
	static contextType = QuoteContext;

	constructor() {
		super();
		this.state = {
			isOpen: false,
		};
	}

	componentDidMount() {
		this.props.onLoad();
	}

	handleOpen = (driverId, driver, callBack, location, history) => {
		this.setState({ isOpen: true, driverId, callBack, location, history });
		pageAnalytics(location.pathname + '/DriverModal', true);
	};

	handleClose = () => {
		this.state.callBack();
		replaceReferrals(this.context);
		pageAnalytics(this.state.location.pathname);
		this.setState({ isOpen: false });
	};

	render() {
		const { driverId, location, history } = this.state;
		return (
			<Modal closeIcon open={this.state.isOpen} closeOnDimmerClick={false} onClose={this.handleClose}>
				<ModalStepper currentModal='capDriver' handleClose={this.handleClose} />
				<Modal.Content>
					<DriverForm id={driverId} handleClose={this.handleClose} location={location} history={history} />
				</Modal.Content>
			</Modal>
		);
	}
}
