import DriverDashboardRules from 'commercialAuto/drivers/DriverDashboardRules';
import { DriverModal } from 'commercialAuto/drivers/DriverModal';
import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { DisplayTable } from 'components/shared/displayTable';
import { InformationMessage } from 'components/shared/messages/InformationMessage';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { toSortedPairList } from 'components/shared/navigation/NavigationFunctions';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { Form, Formik } from 'formik';
import { runAllDriverRules, runDashboardAndAllRules } from 'helper/Validation';
import _ from 'lodash';
import React, { Component } from 'react';
import { logPageErrors } from 'utils/ScreenFunctions';
import { checkReferrals } from 'validation/Validate';

export default class DriverDashboard extends Component {
	static contextType = QuoteContext;

	dirty = false;
	formProps;

	state = { sorting: { column: null, direction: null }, updated: false };

	constructor() {
		super();
		this.driverModal = React.createRef();
	}

	UNSAFE_componentWillMount() {
		const drivers = _.get(this.context.quote, 'cap.drivers', {});
		this.setState({ driverList: _.toPairs(drivers) });
	}

	handleSort = (clickedColumn, defaultDirection) => () => {
		let { column, direction } = this.state.sorting;
		let { driverList } = this.state;
		if (defaultDirection || column !== clickedColumn) {
			direction = defaultDirection || 'ascending';
			switch (clickedColumn) {
				case 'name.first':
					driverList = toSortedPairList(_.get(this.context.quote, 'cap.drivers', {}), 'name.first');
					break;
				case 'name.middle':
					driverList = toSortedPairList(_.get(this.context.quote, 'cap.drivers', {}), 'name.middle');
					break;
				case 'name.last':
					driverList = toSortedPairList(_.get(this.context.quote, 'cap.drivers', {}), 'name.last');
					break;
				case 'birthDate':
					driverList = toSortedPairList(_.get(this.context.quote, 'cap.drivers', {}), 'birthDate');
					break;
				case 'licenseState':
					driverList = toSortedPairList(_.get(this.context.quote, 'cap.drivers', {}), 'licenseState');
					break;
				case 'licenseNumber':
					driverList = toSortedPairList(_.get(this.context.quote, 'cap.drivers', {}), 'licenseNumber');
					break;
				default:
					driverList = _.toPairs(_.get(this.context.quote, 'cap.drivers', {}));
			}
		} else {
			driverList = driverList.reverse();
			direction = direction === 'ascending' ? 'descending' : 'ascending';
		}
		this.setState({
			driverList: driverList,
			sorting: {
				direction,
				column: clickedColumn,
			},
		});
	};

	handleDelete = (id) => {
		const updatedQuote = this.context.quote;
		_.unset(updatedQuote, `cap.drivers.${id}`);
		this.context.updateQuote(updatedQuote, this.props);

		this.handleSort(this.state.sorting.column, this.state.sorting.direction || true)();

		this.setState({
			driverList: _.toPairs(_.get(this.context.quote, 'cap.drivers', {})),
		});
	};

	callback = () => {
		this.handleSort(this.state.sorting.column, this.state.sorting.direction || true)();
	};

	render() {
		return (
			<>
				<DriverModal ref={this.driverModal} onLoad={() => this.setState({ locationModalLoaded: true })} />
				<Formik
					render={(formikProps) => {
						this.formProps = formikProps;
						checkReferrals(this.context, formikProps.values, DriverDashboardRules);
						return (
							<Form id='screen'>
								<InformationMessage
									message='All drivers should be entered as they do impact the quoted premium.'
									fieldDisplay
								/>
								<PageSection name='section_drivers' errors={formikProps.errors}>
									<div id='dashboardButtons' className='left'>
										<SimpleButton
											onClick={() =>
												this.driverModal.current.handleOpen(
													'NEW',
													{},
													this.callback,
													this.props.location,
													this.props.history,
												)
											}
											primary
											content='Add Driver'
										/>
									</div>
									<DisplayTable
										display={this.state.driverList}
										handleSort={this.handleSort}
										tableContent='driver'
										{...this.state.sorting}
										handleDelete={(driverId) => {
											this.handleDelete(driverId);
											formikProps.validateForm(formikProps.values);
										}}
										errors={formikProps.errors}
										callBack={this.callback}
										reference={this.driverModal}
										columns={[
											{
												name: 'name.first',
												display: 'First Name',
												truncate: 48,
											},
											{
												name: 'name.middle',
												display: 'Middle Name',
												truncate: 48,
											},
											{
												name: 'name.last',
												display: 'Last Name',
												truncate: 48,
											},
											{ name: 'birthDate', display: 'Date of Birth' },
											{
												name: 'licenseState',
												display: 'License State',
											},
											{ name: 'licenseNumber', display: 'License Number' },
											{
												name: '',
											},
										]}
										location={this.props.location}
										history={this.props.history}
									/>
								</PageSection>
								<NavigationButtons
									formikProps={formikProps}
									back
									location={this.props.location}
									history={this.props.history}
								/>
							</Form>
						);
					}}
					initialValues={{}}
					onSubmit={(values, formikActions) => {
						return this.context.onSubmit(values, this.dirty, false, false, this.props);
					}}
					validate={(values) => {
						const validResults = runDashboardAndAllRules(
							this.context.quote,
							values,
							DriverDashboardRules,
							runAllDriverRules,
						);
						logPageErrors(validResults, this.formProps.touched, 'cap');
						return validResults;
					}}
				/>
			</>
		);
	}
}
