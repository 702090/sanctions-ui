import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { SubmitButton } from 'components/shared/buttons/SubmitButton';
import { DatePicker } from 'components/shared/form/DatePicker';
import { InputText } from 'components/shared/form/inputs/InputText';
import { Select } from 'components/shared/form/Select';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import statesJson from 'data/states';
import { Field, Form, Formik } from 'formik';
import { setReorderRule } from 'helper/Clue';
import _ from 'lodash';
import React, { useContext, useEffect, useState } from 'react';
import { duplicate } from 'utils/ObjectFunctions';
import { logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { v4 as uuidv4 } from 'uuid';
import { validate } from 'validation/Validate';
import DriverRules from './DriverRules';

const { states } = statesJson;

const DriverForm = (props) => {
	const context = useContext(QuoteContext);

	let dirty = false;
	let formProps;
	const [stateOptions, setStateOptions] = useState([]);

	useEffect(() => {
		let so = [];
		_.forIn(states, (stateName, abbrev) => so.push({ text: stateName, value: abbrev }));
		setStateOptions(_.sortBy(so, ['text']));

		// If the form is not empty, trigger validation
		runRulesOnLoad(formProps, formProps.initialValues, ['id']);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	const { quote } = context;
	let { id } = props;
	return (
		<Formik
			render={(formikProps) => {
				formProps = formikProps;
				dirty = formikProps.dirty;
				if (id === 'NEW') {
					id = formikProps.values.id;
				}

				return (
					<Form id='screen'>
						<PageSection>
							<Field name='name.first' label='First Name' component={InputText} />
							<Field name='name.middle' label='Middle Name' component={InputText} optional />
							<Field name='name.last' label='Last Name' component={InputText} />
							<Field name='birthDate' label='Date of Birth' component={DatePicker} width='small' />
							<Field
								name='licenseState'
								label='License State'
								component={Select}
								options={stateOptions}
								width='medium'
								search
							/>
							<Field name='licenseNumber' label='License Number' component={InputText} width='small' />
						</PageSection>
						<SimpleButton onClick={props.handleClose} content='Cancel' type='button' />
						<SubmitButton error={Object.keys(formikProps.errors).length > 0} content='Save' />
					</Form>
				);
			}}
			initialValues={{
				id: id && id !== 'NEW' ? id : uuidv4(),
				name: {
					first: _.get(quote, `cap.drivers.${id}.name.first`, ''),
					middle: _.get(quote, `cap.drivers.${id}.name.middle`, ''),
					last: _.get(quote, `cap.drivers.${id}.name.last`, ''),
				},
				birthDate: _.get(quote, `cap.drivers.${id}.birthDate`, ''),
				licenseState: _.get(quote, `cap.drivers.${id}.licenseState`, ''),
				licenseNumber: _.get(quote, `cap.drivers.${id}.licenseNumber`, ''),
			}}
			onSubmit={(values, formikActions) => {
				if (dirty) {
					setReorderRule(context, quote, 'cap', props);
				}
				context.onDriverModalSubmit(values, dirty);
				props.handleClose();
			}}
			validate={(values) => {
				const validResults = validate(
					values,
					DriverRules.rules(quote, values),
					duplicate(DriverRules.requiredStructure),
				);
				logPageErrors(validResults, formProps.touched, 'cap');
				return validResults;
			}}
		/>
	);
};
export default DriverForm;
