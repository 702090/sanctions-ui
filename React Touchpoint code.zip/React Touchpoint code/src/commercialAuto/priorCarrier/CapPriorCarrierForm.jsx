import CapPriorCarrierRules from 'commercialAuto/priorCarrier/CapPriorCarrierRules';
import { DatePicker } from 'components/shared/form/DatePicker';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputText } from 'components/shared/form/inputs/InputText';
import { RadioButton } from 'components/shared/form/RadioButton';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { useContext, useEffect } from 'react';
import { toast } from 'react-toastify';
import http from 'services/httpService';
import { cleanValues, getVisibility, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { checkReferrals, validateNew } from 'validation/Validate';

const CapPriorCarrierForm = (props) => {
	const context = useContext(QuoteContext);

	let visibility = {};
	let dirty = false;

	let rulesOnLoad = false;
	let formProps;

	useEffect(() => {
		// If the form is not empty, trigger validation

		runRulesOnLoad(
			formProps,
			formProps.initialValues,
			['priorCarrier'],
			isBlank(_.get(context, 'quote.cap.priorCarrier', '')),
		);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	const verifyCigPolicy = (e, formikProps) => {
		const requestBody = {
			policyNumber: _.get(formikProps, 'values.cap.priorPolicyNumber', ''),
			effectiveDate: _.get(context, 'quote.effectiveDate', ''),
		};

		http
			.post(`${process.env.REACT_APP_POLICY_VERIFICATION}?auth=${sessionStorage.getItem('cigToken')}`, requestBody)
			.then((response) => {
				const priorPolicyEffectiveDate = _.get(response, 'data.originalPolicyEffdte', '');
				const priorPolicyProduct = _.get(response, 'data.originalPolicyProduct', '');
				const cancelReason = _.get(response, 'data.cancelReason', '');
				if (!isBlank(priorPolicyEffectiveDate)) {
					_.set(formikProps, 'values.cap.priorPolicyEffectiveDate', priorPolicyEffectiveDate);
					_.set(formikProps, 'values.cap.priorPolicyProduct', priorPolicyProduct);
					_.set(formikProps, 'values.cap.cancelReason', cancelReason);
					_.set(formikProps, 'values.cap.priorPolicyCigVerified', true);
				} else {
					_.unset(formikProps, 'values.cap.priorPolicyEffectiveDate');
					_.unset(formikProps, 'values.cap.priorPolicyProduct');
					_.unset(formikProps, 'values.cap.cancelReason');
					_.set(formikProps, 'values.cap.priorPolicyCigVerified', false);
				}
				formikProps.validateForm(formikProps.values);
			})
			.catch((err) => {
				toast.error('Error verifying policy.');
				console.error(err);
			});
	};

	const { quote } = context;
	return (
		<Formik
			render={(formikProps) => {
				formProps = formikProps;
				dirty = formikProps.dirty;
				visibility = getVisibility(getFieldDisplayArray('capPriorCarrier'), quote, formikProps.values);
				cleanValues(formikProps.values, visibility);
				checkReferrals(context, formikProps.values, CapPriorCarrierRules);
				if (!rulesOnLoad) {
					formikProps.validateForm(formikProps.values);
					rulesOnLoad = true;
				}
				return (
					<Form id='screen'>
						<PageSection>
							<Field
								name='cap.priorCarrier'
								label='Do you have a prior carrier?'
								component={RadioButton}
								ignoreTouched
							/>
							<Field
								name='cap.cigPriorCarrier'
								label='Is the prior carrier with Columbia Insurance Group?'
								component={RadioButton}
								fieldDisplay={visibility['cap.cigPriorCarrier']}
							/>
							<Field
								name='cap.priorPolicyNumber'
								label='Prior policy number'
								component={InputText}
								fieldDisplay={visibility['cap.priorPolicyNumber']}
								maxLength='15'
								additionalOnBlur={(e) => verifyCigPolicy(e, formikProps)}
							/>
							<Field
								name='cap.carrierName'
								label='What is the prior carrier name?'
								component={InputText}
								fieldDisplay={visibility['cap.carrierName']}
								maxLength='35'
							/>
							<Field
								name='cap.expirationDate'
								label='Expiration Date'
								component={DatePicker}
								fieldDisplay={visibility['cap.expirationDate']}
								optional
							/>
							<Field
								name='cap.annualPremium'
								label='Annual Premium'
								component={InputNumber}
								type='currency'
								fieldDisplay={visibility['cap.annualPremium']}
								maxLength='10'
								optional
							/>
						</PageSection>
						<NavigationButtons
							formikProps={formikProps}
							back
							location={props.location}
							history={props.history}
							rulesObject={CapPriorCarrierRules}
						/>
					</Form>
				);
			}}
			initialValues={{
				cap: {
					priorCarrier: _.get(quote, 'cap.priorCarrier') || '',
					cigPriorCarrier: _.get(quote, 'cap.cigPriorCarrier') || '',
					priorPolicyNumber: _.get(quote, 'cap.priorPolicyNumber') || '',
					carrierName: _.get(quote, 'cap.carrierName') || '',
					expirationDate: _.get(quote, 'cap.expirationDate') || _.get(quote, 'effectiveDate'),
					annualPremium: _.get(quote, 'cap.annualPremium') || '',
					cancelReason: _.get(quote, 'cap.cancelReason') || '',
				},
			}}
			onSubmit={(values, formikActions) => {
				cleanValues(values, visibility);

				if (dirty && _.get(values, 'cap.cigPriorCarrier') !== _.get(quote, 'cap.cigPriorCarrier')) {
					const priorPolicyProduct = _.get(values, 'cap.priorPolicyProduct');
					if (_.get(values, 'cap.cigPriorCarrier') === 'Y' && priorPolicyProduct === 'CAP') {
						_.set(quote, 'cap.san', '');
					}
				}

				return context.onSubmit(values, dirty, false, false, props, CapPriorCarrierRules);
			}}
			validate={(values) => {
				checkReferrals(context, values, CapPriorCarrierRules);
				const validResults = validateNew(quote, values, CapPriorCarrierRules, visibility);
				logPageErrors(validResults, formProps.touched, 'cap');
				return validResults;
			}}
		/>
	);
};

export default CapPriorCarrierForm;
