import ruleMessagesJson from 'data/RuleMessages';
import {
	grossVehWeight,
	hasColl,
	hasOtc,
	hasPrivatePassenger,
	seatingCapacity,
	secondaryClassCode,
	vehRadius,
	needVehSize,
} from 'utils/FieldDisplay';
import { isBlank } from 'utils/StringFunctions';
import _ from 'lodash';

const { requiredMessageText } = ruleMessagesJson;

export default class VehicleRules {
	static requiredStructure = {
		group_otc_coll: '',
		id: '',
		vehType: '',
		vin: '',
		vehYear: '',
		vehMake: '',
		vehModel: '',
		description: '',
		vehCostNew: '',
		garagingLocation: '',
		grossVehWeight: '',
		vehRadius: '',
		secondaryClassCode: '',
		umUimCoverage: '',
		otcCoverage: '',
		otcDedOverride: '',
		collCoverage: '',
		collDedOverride: '',
		pptUse: '',
		pptExperience: '',
		seatingCapacity: '',
		vehSize: '',
		lexisNexisPrefill: false,
	};

	static rules(quote, values) {
		const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));
		let writingStates = agent.writingStates;
		let garagingState = _.get(quote, `addresses.${values.garagingLocation}.state`, '');

		return {
			group_otc_coll: [
				[
					(value) => values.otcCoverage === values.collCoverage,
					'Both comprehensive and collision coverages required if one is entered.',
				],
			],
			vehType: [[(value) => !isBlank(value), requiredMessageText]],
			vin: [[(value) => !isBlank(value), requiredMessageText]],
			vehYear: [
				[(value) => !isBlank(value), requiredMessageText],
				[(value) => value >= 1908, 'Vehicle model year is too far in the past'],
				[(value) => value <= new Date().getFullYear() + 1, 'Vehicle model year cannot be in the future'],
			],
			vehMake: [[(value) => !isBlank(value), requiredMessageText]],
			vehCostNew: [[(value) => !isBlank(value), requiredMessageText]],
			garagingLocation: [
				[(value) => !isBlank(value), requiredMessageText],
				[
					(value) => _.includes(writingStates, garagingState),
					'Based on the garaging state you entered this vehicle is not eligible for coverage. Please remove this vehicle to continue with this quote.',
				],
			],
			grossVehWeight: [[(value) => !(isBlank(value) && grossVehWeight(quote, values)), requiredMessageText]],
			vehRadius: [[(value) => !(isBlank(value) && vehRadius(quote, values)), requiredMessageText]],
			secondaryClassCode: [[(value) => !(isBlank(value) && secondaryClassCode(quote, values)), requiredMessageText]],
			pptUse: [[(value) => !(isBlank(value) && hasPrivatePassenger(quote, values)), requiredMessageText]],
			pptExperience: [[(value) => !(isBlank(value) && hasPrivatePassenger(quote, values)), requiredMessageText]],
			seatingCapacity: [[(value) => !(isBlank(value) && seatingCapacity(quote, values)), requiredMessageText]],
			otcDedOverride: [[(value) => !(isBlank(value) && hasOtc(quote, values)), requiredMessageText]],
			collDedOverride: [[(value) => !(isBlank(value) && hasColl(quote, values)), requiredMessageText]],
			vehSize: [[(value) => !(isBlank(value) && needVehSize(quote, values)), requiredMessageText]],
		};
	}

	static referrals(context, values) {
		return {
			vin: [[(value) => context.serviceStatus.vinValidation || values.vinValidated, 'CVV01']],
		};
	}

	static name() {
		return 'capVehicle';
	}
}
