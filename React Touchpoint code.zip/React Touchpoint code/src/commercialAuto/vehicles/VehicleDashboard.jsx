import VehicleDashboardRules from 'commercialAuto/vehicles/VehicleDashboardRules';
import { VehicleModal } from 'commercialAuto/vehicles/VehicleModal';
import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { DisplayTable } from 'components/shared/displayTable';
import { InformationMessage } from 'components/shared/messages/InformationMessage';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { toSortedPairList } from 'components/shared/navigation/NavigationFunctions';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { Form, Formik } from 'formik';
import { runAllVehicleRules, runDashboardAndAllRules } from 'helper/Validation';
import _ from 'lodash';
import React, { Component } from 'react';
import { cleanAdditionalInterests, isEmployee } from 'utils/BusinessFunctions';
import { duplicate, handleDrop } from 'utils/ObjectFunctions';
import { logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { v4 as uuidv4 } from 'uuid';
import { checkReferrals, removeReferrals } from 'validation/Validate';

export default class VehicleDashboard extends Component {
	static contextType = QuoteContext;
	dirty = false;
	state = {
		force: false,
	};
	rulesOnLoad = false;

	constructor() {
		super();
		this.vehicleModal = React.createRef();
	}

	doDrop = (dest, src) => {
		handleDrop(dest, src, 'cap.vehicles', this);
	};

	handleDelete = (id) => {
		const updatedQuote = this.context.quote;
		//FIXME: add back when we update the Vehicle referrals to show which vehicle they apply to.
		// cleanReferrals(updatedQuote.referrals, id);
		cleanAdditionalInterests({
			quote: this.context.quote,
			propertyId: id,
		});
		const deletedVehicles = _.get(updatedQuote, 'cap.deletedVehicles', {});

		if (_.get(updatedQuote, `cap.vehicles.${id}.lexisNexisPrefill`)) {
			deletedVehicles[id] = _.get(updatedQuote, `cap.vehicles.${id}`);
			_.set(updatedQuote, 'cap.deletedVehicles', deletedVehicles);
		}

		const deletedOrder = _.get(updatedQuote, `cap.vehicles.${id}.order`);

		_.unset(updatedQuote, `cap.vehicles.${id}`);
		const updatedList = _.get(updatedQuote, 'cap.vehicles');
		_.forIn(updatedList, (veh) => {
			if (veh.order >= deletedOrder) {
				veh.order--;
			}
		});

		this.context.updateQuote(updatedQuote, this.props);
		removeReferrals(this.context, id);
		this.setState({ force: !this.state.force });
	};

	handleCopy = (id) => {
		const { quote } = this.context;
		const vehicles = _.get(quote, 'cap.vehicles');
		const oldVehicle = vehicles[id];

		const newVehicle = duplicate(oldVehicle);
		newVehicle.order = Object.keys(vehicles).length;
		_.unset(newVehicle, 'vin');
		_.unset(newVehicle, 'lexisNexisPrefill');
		_.unset(newVehicle, 'vinValidated');
		_.set(quote, `cap.vehicles.${uuidv4()}`, newVehicle);

		this.context.updateQuote(quote, this.props);
		this.formProps.validateForm();
		this.setState({ force: !this.state.force });
	};

	handleRestore = (id) => {
		const updatedQuote = this.context.quote;
		const vehicles = _.get(updatedQuote, 'cap.vehicles', {});

		const deletedVehicle = _.get(updatedQuote, `cap.deletedVehicles.${id}`, {});
		deletedVehicle.order = _.size(vehicles);
		vehicles[id] = deletedVehicle;
		_.set(updatedQuote, 'cap.vehicles', vehicles);
		_.unset(updatedQuote, `cap.deletedVehicles.${id}`);

		this.context.updateQuote(updatedQuote, this.props);
		this.setState({ force: !this.state.force });
	};

	callback = () => {
		this.rulesOnLoad = false;
		runRulesOnLoad(this.formProps, this.formProps.initialValues, ['']);
		this.setState({ force: !this.state.force });
	};

	getSymbolValue = (symbolValue) => {
		if (symbolValue) {
			if (_.includes(['', '0'], symbolValue)) {
				return <i className='fas fa-times' />;
			} else {
				return <i className='fas fa-check' />;
			}
		} else {
			return <i className='fas fa-ban' />;
		}
	};

	componentDidMount() {
		// If the form is not empty, trigger validation
		runRulesOnLoad(this.formProps, this.formProps.initialValues, ['']);
	}

	render() {
		return (
			<>
				<VehicleModal
					onSubmit={this.context.onVehicleModalSubmit}
					ref={this.vehicleModal}
					onLoad={() => this.setState({ vehicleModalLoaded: true })}
					callBack={() => {}}
				/>
				<Formik
					render={(formikProps) => {
						this.formProps = formikProps;
						this.dirty = formikProps.dirty || this.dirty;

						if (!this.rulesOnLoad && !isBlank(_.get(this.context, 'quote.cap.vehicles', {}))) {
							formikProps.validateForm(formikProps.values);
							this.rulesOnLoad = true;
						}
						let addtl = [];
						let display = toSortedPairList(_.get(this.context.quote, 'cap.vehicles', {}));
						display.forEach((veh, idx) => {
							veh = veh[1];
							addtl.push(`${veh.vehYear} ${veh.vehMake} ${veh.vehModel ? veh.vehModel : ''}`);
						});
						let addtlDeleted = [];
						let displayDeleted = toSortedPairList(_.get(this.context.quote, 'cap.deletedVehicles', {}));
						displayDeleted.forEach((veh, idx) => {
							veh = veh[1];
							addtlDeleted.push(`${veh.vehYear} ${veh.vehMake} ${veh.vehModel}`);
						});
						return (
							<Form id='screen'>
								<InformationMessage message='You can Drag & Drop the vehicles to rearrange the list' fieldDisplay />
								<PageSection name='section_vehicles' errors={formikProps.errors}>
									<div id='dashboardButtons' className='left'>
										<SimpleButton
											content='Add Vehicle'
											className='add'
											onClick={() =>
												this.vehicleModal.current.handleOpen(
													'NEW',
													{},
													this.callback,
													this.props.location,
													this.props.history,
												)
											}
										/>
									</div>
									<div id='displayLegend'>
										<div className='legendItem'>
											<i className='fas fa-check' />
											<span>Coverage selected for Vehicle</span>
										</div>
										<div className='legendItem'>
											<i className='fas fa-times' />
											<span>Coverage declined for Vehicle</span>
										</div>
										<div className='legendItem'>
											<i className='fas fa-ban' />
											<span>Coverage not available for Vehicle</span>
										</div>
									</div>
									<DisplayTable
										display={display}
										{...this.state.sorting}
										tableContent='vehicle'
										handleDelete={(vehicleId) => {
											this.handleDelete(vehicleId);
											formikProps.validateForm(formikProps.values);
										}}
										additionalData={addtl}
										handleDrop={this.doDrop}
										errors={formikProps.errors}
										callBack={this.callback}
										reference={this.vehicleModal}
										handleCopy={this.handleCopy}
										displayOrder
										columns={[
											{
												name: 'order',
												display: '#',
												width: 1,
											},
											{
												name: 'vin',
												display: 'Vehicle',
												width: 8,
												bold: true,
											},
											{
												name: 'liability',
												display: 'Liability',
												default: this.getSymbolValue(_.get(this.context, 'quote.cap.symbols.liability')),
												noSort: true,
												width: 1,
											},
											{
												name: 'pip',
												display: 'PIP',
												default: this.getSymbolValue(_.get(this.context, 'quote.cap.symbols.pip')),
												noSort: true,
												width: 1,
											},
											{
												name: 'additionalPIPCoverage',
												display: 'Adtl PIP',
												noSort: true,
												width: 1,
											},
											{
												name: 'medPay',
												display: 'MedPay',
												default: this.getSymbolValue(_.get(this.context, 'quote.cap.symbols.medPay')),
												noSort: true,
												width: 1,
											},
											{
												name: 'umUimCoverage',
												display: 'UM/UIM',
												noSort: true,
												width: 1,
											},
											{
												name: 'otcCoverage',
												display: 'Comp',
												noSort: true,
												width: 1,
											},
											{
												name: 'collCoverage',
												display: 'Collision',
												noSort: true,
												width: 1,
											},
											{
												name: '',
												copy: true,
											},
											{ name: '' },
										]}
										location={this.props.location}
										history={this.props.history}
									/>
								</PageSection>
								{isEmployee() ? (
									<PageSection>
										<DisplayTable
											display={displayDeleted}
											{...this.state.sorting}
											handleDrop={() => {}}
											errors={formikProps.errors}
											handleRestore={this.handleRestore}
											columns={[
												{
													name: 'vin',
													display: 'Deleted Vehicle - only visible by employees',
													width: 8,
												},
												{
													name: 'liability',
													display: 'Liability',
													default: this.getSymbolValue(_.get(this.context, 'quote.cap.symbols.liability')),
													noSort: true,
													width: 1,
												},
												{
													name: 'pip',
													display: 'PIP',
													default: this.getSymbolValue(_.get(this.context, 'quote.cap.symbols.pip')),
													noSort: true,
													width: 1,
												},
												{
													name: 'additionalPIPCoverage',
													display: 'Adtl PIP',
													noSort: true,
													width: 1,
												},
												{
													name: 'medPay',
													display: 'MedPay',
													default: this.getSymbolValue(_.get(this.context, 'quote.cap.symbols.medPay')),
													noSort: true,
													width: 1,
												},
												{
													name: 'umUimCoverage',
													display: 'UM/UIM',
													noSort: true,
													width: 1,
												},
												{
													name: 'otcCoverage',
													display: 'Comp',
													noSort: true,
													width: 1,
												},
												{
													name: 'collCoverage',
													display: 'Collision',
													noSort: true,
													width: 1,
												},
												{ name: '', restore: true },
											]}
										/>
									</PageSection>
								) : (
									''
								)}
								<NavigationButtons
									formikProps={formikProps}
									back
									location={this.props.location}
									history={this.props.history}
								/>
							</Form>
						);
					}}
					initialValues={{}}
					onSubmit={(values, formikActions) => {
						this.context.onSubmit(this.context.quote, this.dirty, false, false, this.props);
						this.rulesOnLoad = true;
					}}
					validate={(values) => {
						checkReferrals(this.context, values, VehicleDashboardRules);
						const validResults = runDashboardAndAllRules(
							this.context.quote,
							values,
							VehicleDashboardRules,
							runAllVehicleRules,
						);
						logPageErrors(validResults, this.formProps.touched, 'cap');
						return validResults;
					}}
				/>
			</>
		);
	}
}
