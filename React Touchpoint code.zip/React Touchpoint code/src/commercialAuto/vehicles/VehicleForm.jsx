import VehicleRules from 'commercialAuto/vehicles/VehicleRules';
import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { SubmitButton } from 'components/shared/buttons/SubmitButton';
import { DataDisplay } from 'components/shared/form/DataDisplay';
import AddressPicker from 'components/shared/form/inputs/AddressPicker';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputText } from 'components/shared/form/inputs/InputText';
import { RadioButton } from 'components/shared/form/RadioButton';
import { Select } from 'components/shared/form/Select';
import { OptionalSection } from 'components/shared/sections/OptionalSection';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import selectOptionsJson from 'data/SelectOptions';
import statesJson from 'data/states';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { useContext, useEffect, useState } from 'react';
import { validateVin } from 'services/vehicleService';
import { distillLocations, getPredState, cleanOrphanAddresses } from 'utils/BusinessFunctions';
import { grossVehWeight } from 'utils/FieldDisplay';
import { duplicate, getSet } from 'utils/ObjectFunctions';
import { cleanValues, getVisibility, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { v4 as uuidv4 } from 'uuid';
import { checkReferrals, validate } from 'validation/Validate';

const VehicleForm = (props) => {
	const context = useContext(QuoteContext);
	let visibility = {};
	let dirty = false;
	let cleaned = false;
	let formProps;
	const { states } = statesJson;
	const {
		cap_collDedOverride,
		cap_otcDedOverride,
		cap_pptExperience,
		cap_pptUse,
		cap_seatingCapacity,
		cap_secondaryClassCodes,
		cap_vehRadius,
		cap_vehSizeTrucks,
		cap_vehSizeTrucksTractors,
		cap_vehType,
	} = selectOptionsJson;

	const [stateOptions, setStateOptions] = useState([]);
	const [doneValidating, setDoneValidating] = useState(false);

	useEffect(() => {
		const { states: defaultStates } = distillLocations(context.quote);

		let currentStates = _.get(context, 'quote.cap.coverages.currentStates', defaultStates);

		if (!(currentStates instanceof Set)) {
			currentStates = getSet(currentStates);
		}

		let so = [];
		_.forIn(states, (stateName, abbrev) => so.push({ text: stateName, value: abbrev }));
		setStateOptions(_.sortBy(so, ['text']));

		// If the form is not empty, trigger validation
		runRulesOnLoad(formProps, formProps.initialValues, ['id'], isBlank(formProps.values.vin));
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	const { quote } = context;
	let { id, location, history } = props;

	const setVehicleInformation = (values, vehicle) => {
		values.vehYear = vehicle.year;
		values.vehMake = vehicle.make;
		values.vehModel = vehicle.model;
		values.description = vehicle.description;
		values.grossVehWeight = vehicle.GVW;
		values.vehCostNew = vehicle.msrp;
		values.garagingLocation = _.get(quote, `cap.coverages.${getPredState(quote)}.address`);
	};

	const doValidate = (formikProps) => {
		validateVin(formikProps.values.vin, context).then((returned) => {
			const vehicles = _.get(returned, 'data.vehicles', []);
			const { values } = formikProps;
			if (vehicles.length === 1) {
				setVehicleInformation(values, vehicles[0]);
				formikProps.setFieldValue('vinValidated', true, false);
				formikProps.setFieldValue('blankGVW', true);
			} else if (vehicles.length > 1) {
				const fieldOptions = vehicles.map((vehicle, index) => ({
					text: `${vehicle.year} ${vehicle.make} ${vehicle.model} - ${vehicle.description}`,
					value: index,
				}));

				context.optionModal.current.handleOpen(
					{
						field: {
							name: 'Vehicle Options',
							label: 'Multiple matching VINs were found. Please choose the correct VIN below.',
							component: RadioButton,
							options: fieldOptions,
							width: 'massive',
						},
					},
					(v, sfv, fv) => {
						setVehicleInformation(values, vehicles[v]);
						formikProps.setFieldValue('vinValidated', true, false);
						formikProps.setFieldValue('blankGVW', true);
					},
				);
			}

			context.updateServiceStatus('vinValidation', false);

			setDoneValidating(true);
		});
	};

	const vehicle = duplicate(_.get(quote, `cap.vehicles.${id}`, {}));
	return (
		<Formik
			render={(formikProps) => {
				formProps = formikProps;
				dirty = formikProps.dirty;
				if (id !== 'NEW') {
					setDoneValidating(true);
				}
				visibility = getVisibility(getFieldDisplayArray('vehicle'), quote, formikProps.values);
				checkReferrals(context, formikProps.values, VehicleRules, visibility);

				cleaned = cleanValues(formikProps.values, visibility);
				const { vinValidated, description } = formikProps.values;

				if (_.isArray(description)) {
					const fieldOptions = description.map((veh, index) => ({
						text: `${veh.year} ${veh.make} ${veh.model} - ${veh.description}`,
						value: index,
					}));
					context.optionModal.current.handleOpen(
						{
							field: {
								name: 'Vehicle Options',
								label: 'Multiple matching VINs were found. Please choose the correct VIN below.',
								component: RadioButton,
								options: fieldOptions,
								width: 'massive',
							},
						},
						(v, sfv, fv) => {
							setVehicleInformation(formikProps.values, description[v]);
							formikProps.setFieldValue('vinValidated', true, false);
							formikProps.setFieldValue('blankGVW', true);
						},
					);
				}

				let vehicleSizeOptions =
					_.get(formikProps.values, 'vehType', '') === '3' ? cap_vehSizeTrucks : cap_vehSizeTrucksTractors;
				formikProps.dirty = cleaned;
				return (
					<Form id='screen'>
						<PageSection>
							{!formikProps.values.vinValidated && (
								<Field
									name='vin'
									label='VIN'
									component={InputText}
									maxLength='19'
									additionalOnBlur={() => {
										doValidate(formikProps);
									}}
									width='small'
									ignoreTouched
								/>
							)}
							{doneValidating && (
								<React.Fragment>
									{formikProps.values.vinValidated && (
										<React.Fragment>
											<div className='vehDisplay'>
												<div id='vehVin'>{formikProps.values.vin}</div>
												{formikProps.values.vehYear}
												&nbsp;
												{_.upperFirst(_.lowerCase(formikProps.values.vehMake))}
												&nbsp;
												{_.words(formikProps.values.vehModel).map((word) => `${_.upperFirst(_.lowerCase(word))} `)}
												<div id='vehDisc'>
													{_.words(formikProps.values.description).map(
														(word) =>
															`${
																_.includes(['dr', 'the', 'and', 'or', 'w'], word)
																	? word
																	: _.upperFirst(_.lowerCase(word))
															} `,
													)}
												</div>
											</div>
											<Field name='vehCostNew' label='Vehicle Cost New' component={DataDisplay} type='currency' />
										</React.Fragment>
									)}
									<Field
										name='vehType'
										label='Vehicle Type'
										component={Select}
										options={cap_vehType}
										additionalOnChange={(v, sfv) => {
											if (_.includes(['5', '6', '7'], v)) {
												sfv('umUimCoverage', 'N', false);
											}
										}}
										width='medium'
									/>
									{!formikProps.values.vinValidated && doneValidating && (
										<React.Fragment>
											<Field
												name='vehYear'
												label='Vehicle Year'
												component={vinValidated ? DataDisplay : InputNumber}
												ignoreCommas
												maxLength='4'
												width='tiny'
											/>
											<div className='flexFields'>
												<Field
													name='vehMake'
													label='Vehicle Make'
													component={vinValidated ? DataDisplay : InputText}
													maxLength='36'
													width='medium'
												/>
												<Field
													name='vehModel'
													label='Vehicle Model'
													component={vinValidated ? DataDisplay : InputText}
													maxLength='36'
													optional={vinValidated ? false : true}
													width='medium'
												/>
											</div>
											<Field
												name='description'
												label='Description'
												component={vinValidated ? DataDisplay : InputText}
												maxLength='25'
												optional={vinValidated ? false : true}
												width='massive'
											/>
											<Field
												name='vehCostNew'
												label='Vehicle Cost New'
												component={vinValidated ? DataDisplay : InputNumber}
												type='currency'
												maxLength='10'
												width='small'
											/>
										</React.Fragment>
									)}
								</React.Fragment>
							)}
						</PageSection>
						<PageSection title='Vehicle Garaging'>
							<AddressPicker
								name='garagingLocation'
								label='Garaging Location'
								addLabel='Add a new garaging address.'
								maxLength='100'
								location={location}
								history={history}
								formikProps={formikProps}
							/>
						</PageSection>
						{!isBlank(_.get(formikProps.values, 'vehType', '')) &&
							_.get(formikProps.values, 'vehType', '') !== '18' &&
							_.get(formikProps.values, 'vehType', '') !== '17' && (
								<PageSection title='Vehicle Classification Information'>
									{grossVehWeight(quote, formikProps.values) && (
										<Field name='grossVehWeight' label='Gross Vehicle Weight' component={DataDisplay} suffix='lbs' />
									)}
									<Field
										name='vehSize'
										label='Vehicle Size'
										component={RadioButton}
										fieldDisplay={visibility.vehSize}
										options={vehicleSizeOptions}
									/>
									<Field
										name='seatingCapacity'
										label='Seating Capacity'
										component={RadioButton}
										fieldDisplay={visibility.seatingCapacity}
										options={cap_seatingCapacity}
									/>
									<Field
										name='vehRadius'
										label='Vehicle Radius'
										component={RadioButton}
										fieldDisplay={visibility.vehRadius}
										options={cap_vehRadius}
									/>
									<Field
										name='secondaryClassCode'
										label='Secondary Class Code'
										component={Select}
										fieldDisplay={visibility.secondaryClassCode}
										options={cap_secondaryClassCodes}
									/>
									<Field
										name='pptUse'
										label='PPT Use'
										component={RadioButton}
										fieldDisplay={visibility.pptUse}
										options={cap_pptUse}
									/>
									<Field
										name='pptExperience'
										label='PPT Experience'
										component={RadioButton}
										fieldDisplay={visibility.pptExperience}
										options={cap_pptExperience}
									/>
								</PageSection>
							)}
						<PageSection title='Coverage Indicators'>
							<Field
								name='additionalPIPCoverage'
								label='Additional PIP Coverage'
								component={RadioButton}
								fieldDisplay={visibility.additionalPIPCoverage}
							/>
							<Field
								name='umUimCoverage'
								label='UM/UIM Coverage'
								component={RadioButton}
								fieldDisplay={visibility.umUimCoverage}
								disabled={_.includes(['5', '6', '7'], formikProps.values.vehType)}
							/>
							{(visibility.otcCoverage || visibility.collCoverage) && (
								<OptionalSection
									name='group_otc_coll'
									errors={formikProps.errors}
									text='Both comprehensive and collision coverages are required if one is entered.'
									touched={
										_.get(formikProps.touched, 'otcCoverage', false) ||
										_.get(formikProps.touched, 'collCoverage', false)
									}
									vertical
								>
									<div className='verticalGroup'>
										<Field
											name='otcCoverage'
											label='Comprehensive Coverage'
											component={RadioButton}
											width='compact'
											fieldDisplay={visibility.otcCoverage}
										/>
										<Field
											name='otcDedOverride'
											label='Comprehensive Deductible Override'
											component={RadioButton}
											className='noLine'
											options={cap_otcDedOverride}
											fieldDisplay={visibility.otcDedOverride}
											width='compact'
										/>
									</div>
									<div className='verticalGroup'>
										<Field
											name='collCoverage'
											label='Collision Coverage'
											component={RadioButton}
											width='compact'
											fieldDisplay={visibility.collCoverage}
										/>
										<Field
											name='collDedOverride'
											label='Collision Deductible Override'
											component={RadioButton}
											options={cap_collDedOverride}
											fieldDisplay={visibility.collDedOverride}
											width='compact'
										/>
									</div>
								</OptionalSection>
							)}
						</PageSection>
						<PageSection title='Miscellaneous Coverage Info'>
							<Field name='leasedVeh' label='Leased Vehicle' component={RadioButton} />
						</PageSection>
						<SimpleButton content='Cancel' onClick={props.handleClose} />
						<SubmitButton content='Save' error={Object.keys(formikProps.errors).length > 0} />
					</Form>
				);
			}}
			initialValues={{
				id: id && id !== 'NEW' ? id : uuidv4(),
				order: _.get(vehicle, 'order', ''),
				vehType: _.get(vehicle, 'vehType', ''),
				vin: _.get(vehicle, 'vin', ''),
				vinValidated: _.get(vehicle, 'vinValidated', false),
				vehYear: _.get(vehicle, 'vehYear', ''),
				vehMake: _.get(vehicle, 'vehMake', ''),
				vehModel: _.get(vehicle, 'vehModel', ''),
				description: _.get(vehicle, 'description', ''),
				vehCostNew: _.get(vehicle, 'vehCostNew', ''),
				garagingLocation: _.get(
					vehicle,
					'garagingLocation',
					_.get(quote, `cap.coverages.${getPredState(quote)}.address`),
				),
				grossVehWeight: _.get(vehicle, 'grossVehWeight', ''),
				vehRadius: _.get(vehicle, 'vehRadius', ''),
				secondaryClassCode: _.get(vehicle, 'secondaryClassCode', ''),
				umUimCoverage: isBlank(_.get(vehicle, 'umUimCoverage', 'Y')) ? 'Y' : _.get(vehicle, 'umUimCoverage', 'Y'),
				otcCoverage: isBlank(_.get(vehicle, 'otcCoverage', 'Y')) ? 'Y' : _.get(vehicle, 'otcCoverage', 'Y'),
				otcDedOverride: isBlank(_.get(vehicle, 'otcDedOverride', '0')) ? '0' : _.get(vehicle, 'otcDedOverride', '0'),
				collCoverage: isBlank(_.get(vehicle, 'collCoverage', 'Y')) ? 'Y' : _.get(vehicle, 'collCoverage', 'Y'),
				collDedOverride: isBlank(_.get(vehicle, 'collDedOverride', '0')) ? '0' : _.get(vehicle, 'collDedOverride', '0'),
				leasedVeh: _.get(vehicle, 'leasedVeh', 'N'),
				pptUse: _.get(vehicle, 'pptUse', ''),
				pptExperience: _.get(vehicle, 'pptExperience', ''),
				seatingCapacity: _.get(vehicle, 'seatingCapacity', ''),
				blankGVW: _.get(vehicle, 'blankGVW', ''),
				vehSize: _.get(vehicle, 'vehSize', ''),
				additionalPIPCoverage: _.get(vehicle, 'additionalPIPCoverage', 'Y'),
				lexisNexisPrefill: _.get(vehicle, 'lexisNexisPrefill', false),
			}}
			onSubmit={(values, formikActions) => {
				if (!context.serviceStatus.vinValidation) {
					cleaned = cleanValues(values, visibility);
					cleaned = cleanOrphanAddresses(quote, values) || cleaned;
					context.onVehicleModalSubmit(duplicate(values), dirty || cleaned, props);
					props.handleClose();
				}
			}}
			validate={(values) => {
				checkReferrals(context, values, VehicleRules);
				const validResults = validate(
					values,
					VehicleRules.rules(quote, values),
					duplicate(VehicleRules.requiredStructure),
				);
				logPageErrors(validResults, formProps.touched, 'cap');
				return validResults;
			}}
		/>
	);
};
export default VehicleForm;
