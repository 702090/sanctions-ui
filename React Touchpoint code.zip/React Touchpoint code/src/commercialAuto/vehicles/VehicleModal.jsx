import { ModalStepper } from 'components/shared/navigation/ModalStepper';
import QuoteContext from 'context/quoteContext';
import React, { Component } from 'react';
import { Modal } from 'semantic-ui-react';
import { pageAnalytics } from 'utils/ScreenFunctions';
import { replaceReferrals } from 'validation/RunReferrals';
import VehicleForm from './VehicleForm';

export class VehicleModal extends Component {
	static contextType = QuoteContext;

	constructor() {
		super();
		this.state = {
			isOpen: false,
		}; // state to control the state of popup
	}

	componentDidMount() {
		this.props.onLoad();
	}

	handleOpen = (vehicleId, vehicle, callBack, location, history) => {
		this.setState({
			isOpen: true,
			vehicleId,
			callBack,
			location,
			history,
		});
		pageAnalytics(location.pathname + '/VehicleModal', true);
	};

	handleClose = () => {
		this.state.callBack();
		replaceReferrals(this.context);
		pageAnalytics(this.state.location.pathname);
		this.setState({ isOpen: false });
	};

	render() {
		const { isOpen, vehicleId, location, history } = this.state;
		return (
			<Modal closeIcon open={isOpen} closeOnDimmerClick={false} onClose={this.handleClose}>
				<ModalStepper currentModal='capVehicle' handleClose={this.handleClose} />
				<Modal.Content>
					<VehicleForm id={vehicleId} handleClose={this.handleClose} location={location} history={history} />
				</Modal.Content>
			</Modal>
		);
	}
}
