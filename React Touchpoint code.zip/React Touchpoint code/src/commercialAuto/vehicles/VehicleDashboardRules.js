import _ from 'lodash';
import { getSet } from 'utils/ObjectFunctions';

export default class VehicleDashboardRules {
	static requiredStructure = {
		section_vehicles: '',
	};

	static rules(quote, values) {
		let vehicles = _.get(quote, 'cap.vehicles', {});
		let currentStates = getSet(_.get(quote, 'cap.coverages.currentStates', new Set()));
		let garagingStates = new Set();

		_.forEach(vehicles, (vehicle) => {
			const addr = _.find(quote.addresses, (address, id) => {
				return id === vehicle.garagingLocation;
			});
			if (addr) {
				garagingStates.add(addr.state);
			}
		});

		const missingStates = _.difference(Array.from(garagingStates), Array.from(currentStates));
		return {
			section_vehicles: [
				[(value) => Object.keys(_.get(quote, 'cap.vehicles', {})).length >= 1, 'You must have at least one vehicle.'],
				[
					(value) => _.isEmpty(missingStates),
					`${missingStates.join(', ')} needs to be entered on the State Limits and Coverages page.`,
				],
				// Removed per Terry and Scott
				// [
				// 	(value) => Object.keys(_.get(quote, 'cap.vehicles', {})).length <= 20,
				// 	'The vehicle limit is 20. Please contact your underwriter.',
				// ],
			],
		};
	}

	static referrals(context, values) {
		return {
			// Removed per Terry and Scott
			// section_vehicles: [
			// 	[
			// 		(value) =>
			// 			Object.keys(_.get(context, 'quote.cap.vehicles', {})).length < 16,
			// 		'CVD01',
			// 	],
			// ],
			// TODO: For Mississippi check stacking vehicles(type 5 6 7)
			//  if (stackingVehCount > 0) {
			// 		if (stackingVehCount <= 3
			// 				&& !StringUtility.isInSet(StringUtility.cleanUpHashValue(fieldsInHashMap.get("AuCombLimit_" + state)), "75000 100000 200000 250000 300000 350000 500000")) {
			// 			messageText = "Due to the number of vehicles the " + fieldsInHashMap.get("AuCombLimit_" + state).getFieldLabel() + " must be 500,000 or less";
			// 			Rules.addError(masterDTO, capStatesByPolicy.get(0), "", ruleMessageDTOs, messageText, fieldsInHashMap.get("AuCombLimit_" + state).getFieldName());
			// 		} else if (stackingVehCount > 3 && !StringUtility.isInSet(StringUtility.cleanUpHashValue(fieldsInHashMap.get("AuCombLimit_" + state)), "300000 350000 500000 750000 1000000")) {
			// 			messageText = "Due to the number of vehicles the " + fieldsInHashMap.get("AuCombLimit_" + state).getFieldLabel() + " must be 300,000 or more";
			// 			Rules.addError(masterDTO, capStatesByPolicy.get(0), "", ruleMessageDTOs, messageText, fieldsInHashMap.get("AuCombLimit_" + state).getFieldName());
			// 		}
			//   }
		};
	}

	static name() {
		return 'capVehicleDashboard';
	}
}
