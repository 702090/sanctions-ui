import { getFieldDisplayArray, requiredQuestionMessage, updateSectionVisibility } from 'data/FieldVisibility';
import ruleMessagesJson from 'data/RuleMessages';
import _ from 'lodash';
import { formatNumberWithCommas } from 'utils/BusinessFunctions';
import { getSet } from 'utils/ObjectFunctions';
import { getVisibility } from 'utils/ScreenFunctions';
import { isBlank, isBlankZ } from 'utils/StringFunctions';

const { ifAnyMessageNotZero } = ruleMessagesJson;

export default class StateCoveragesRules {
	static requiredStructure(quote, values) {
		let outputStructure = { section_capStates: '', cap: { coverages: {} } };

		_.forIn(_.get(values, 'cap.coverages', {}), (state, st) => {
			outputStructure.cap.coverages[st] = {
				address: '',
				umCombinedSingleLimit: '',
				towingLimitDisablement: '',
				hiredNonOwn: '',
				hiredAutoLiability: '',
				otherThanCollisionAnnualCost: '',
				otherThanCollisionDeductible: '',
				collisionCostHireAmount: '',
				collisionDeductible: '',
				driveOtherCar: '',
				numberIndividualsCovered: '',
				umPdLimit: '',
				additionalPip: '',
				umDeductible: '',
				addOnCoverage: '',
				tortRejectionIndicator: '',
				pipMisc1: '',
				pipLimit: '',
			};
		});

		return outputStructure;
	}

	static rules(quote, values, visibility) {
		// use values for current page validation
		// use quote for external page validation

		let currentStatesSet = new Set();
		if (!(values.cap.coverages.currentStates instanceof Set)) {
			currentStatesSet = getSet(values.cap.coverages.currentStates);
		} else currentStatesSet = values.cap.coverages.currentStates;

		if (values && !visibility) {
			visibility = getVisibility(getFieldDisplayArray('commercialAuto'), quote, values);

			_.forEach([...currentStatesSet], (st) => {
				const updatedVis = updateSectionVisibility(quote, st, values);
				_.merge(visibility, updatedVis);
			});
		}

		let rulesToRun = buildRulesObject(quote, values, visibility, currentStatesSet);

		return rulesToRun;
	}

	static referrals(context, values) {
		return {};
	}
	static name() {
		return 'capStateCoverages';
	}
}

function buildRulesObject(quote, values, visibility, currentStatesSet) {
	const statesToTest = [...currentStatesSet];
	let stateRules = {
		section_capStates: [[(value) => !isBlank(statesToTest), 'You must have at least one state.']],
		cap: { coverages: {} },
	};
	let additionalStateRules = { cap: { coverages: {} } };
	if (statesToTest) {
		_.forEach(statesToTest, (st) => {
			stateRules.cap.coverages[st] = {
				address: [[(value) => !(isBlank(value) || value === 'NEW'), requiredQuestionMessage]],
				umCombinedSingleLimit: [
					[(value) => !(visibility['cap.umCombinedSingleLimit'] && isBlank(value)), requiredQuestionMessage],
					[
						(value) =>
							!visibility['cap.umCombinedSingleLimit'] ||
							_.toNumber(value) <= _.toNumber(_.get(quote, 'cap.liabilityLimit', 0)),
						`This value cannot be greater than $${formatNumberWithCommas(_.get(quote, 'cap.liabilityLimit', 0))}`,
					],
				],
				towingLimitDisablement: [
					[(value) => !(visibility['cap.towingLimitDisablement'] && isBlank(value)), requiredQuestionMessage],
				],
				hiredNonOwn: [
					[(value) => !(visibility['cap.hiredNonOwn'] && isBlank(value)), requiredQuestionMessage],
					[
						(value) =>
							!visibility['cap.hiredNonOwn'] ||
							(_.isFinite(_.toNumber(value)) && _.toNumber(value) % 1 === 0 && _.toNumber(value) > 0) ||
							value === 'IF ANY',
						ifAnyMessageNotZero,
					],
				],
				hiredAutoLiability: [
					[(value) => !(visibility['cap.hiredAutoLiability'] && isBlank(value))],
					[
						(value) =>
							!visibility['cap.hiredAutoLiability'] ||
							(_.isFinite(_.toNumber(value)) && _.toNumber(value) % 1 === 0 && _.toNumber(value) > 0) ||
							value === 'IF ANY',
						ifAnyMessageNotZero,
					],
				],
				otherThanCollisionAnnualCost: [
					[(value) => !(visibility['cap.otherThanCollisionAnnualCost'] && isBlank(value)), requiredQuestionMessage],
					[
						(value) =>
							!visibility['cap.otherThanCollisionAnnualCost'] ||
							(_.isFinite(_.toNumber(value)) && _.toNumber(value) % 1 === 0 && _.toNumber(value) > 0) ||
							value === 'IF ANY',
						ifAnyMessageNotZero,
					],
				],
				otherThanCollisionDeductible: [
					[(value) => !(visibility['cap.otherThanCollisionDeductible'] && isBlank(value)), requiredQuestionMessage],
				],
				collisionCostHireAmount: [
					[(value) => !(visibility['cap.collisionCostHireAmount'] && isBlank(value)), requiredQuestionMessage],
					[
						(value) =>
							!visibility['cap.collisionCostHireAmount'] ||
							(_.isFinite(_.toNumber(value)) && _.toNumber(value) % 1 === 0 && _.toNumber(value) > 0) ||
							value === 'IF ANY',
						ifAnyMessageNotZero,
					],
				],
				collisionDeductible: [
					[(value) => !(visibility['cap.collisionDeductible'] && isBlank(value)), requiredQuestionMessage],
				],
				driveOtherCar: [[(value) => !(visibility['cap.driveOtherCar'] && isBlank(value)), requiredQuestionMessage]],
				numberIndividualsCovered: [
					[
						(value) => !(visibility[`cap.coverages.${st}.numberIndividualsCovered`] && isBlank(value)),
						requiredQuestionMessage,
					],
				],
			};

			switch (st) {
				case 'AR':
					additionalStateRules.cap.coverages[st] = {
						umPdLimit: [
							[(value) => !(visibility[`cap.coverages.${st}.umDeductible`] && isBlank(value)), requiredQuestionMessage],
						],
					};
					break;
				case 'KS':
					additionalStateRules.cap.coverages[st] = {
						additionalPip: [
							[
								(value) => !(visibility[`cap.coverages.${st}.additionalPip`] && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					};
					break;
				case 'KY':
					additionalStateRules.cap.coverages[st] = {
						tortRejectionIndicator: [[(value) => !isBlank(value), requiredQuestionMessage]],
						pipMisc1: [
							[(value) => !(visibility[`cap.coverages.${st}.pipMisc1`] && isBlank(value)), requiredQuestionMessage],
						],
						additionalPip: [
							[
								(value) => !(visibility[`cap.coverages.${st}.additionalPip`] && isBlank(value)),
								requiredQuestionMessage,
							],
						],
					};
					break;
				case 'GA':
					additionalStateRules.cap.coverages[st] = {
						umDeductible: [
							[
								(value) => !(isBlankZ(value) && visibility[`cap.coverages.${st}.umDeductible`]),
								requiredQuestionMessage,
							],
						],
						addOnCoverage: [
							[
								(value) => !(isBlankZ(value) && visibility[`cap.coverages.${st}.addOnCoverage`]),
								requiredQuestionMessage,
							],
						],
					};
					break;
				case 'TX':
					additionalStateRules.cap.coverages[st] = {
						pipLimit: [
							[(value) => !(visibility[`cap.coverages.${st}.pipLimit`] && isBlank(value)), requiredQuestionMessage],
						],
					};
					break;
				default:
			}
			_.merge(stateRules, additionalStateRules);
		});
	}
	return stateRules;
}
