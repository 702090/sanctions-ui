import { StateCoverages, stateMap } from 'commercialAuto/stateCoverages/StateCoverages';
import StateCoveragesRules from 'commercialAuto/stateCoverages/StateCoveragesRules';
import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { Select } from 'components/shared/form/Select';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray, updateSectionVisibility } from 'data/FieldVisibility';
import statesJson from 'data/states';
import { Field, Form, Formik } from 'formik';
import { setReorderRule } from 'helper/Clue';
import _ from 'lodash';
import React, { Component } from 'react';
import { toast } from 'react-toastify';
import { cleanOrphanAddresses, distillLocations, getPredState } from 'utils/BusinessFunctions';
import { duplicate, getSet } from 'utils/ObjectFunctions';
import { cleanValues, getVisibility, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { validate } from 'validation/Validate';

const { states } = statesJson;

class StateCoveragesForm extends Component {
	static contextType = QuoteContext;
	state = { currentStates: [], stateOptions: [] };
	dirty = false;
	cleaned = false;
	visibility = {};

	UNSAFE_componentWillMount() {
		let defaultStates = [];
		const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));
		const stateOptions = [];

		if (isBlank(defaultStates)) {
			const { states: ds } = distillLocations(this.context.quote);
			defaultStates = ds;
		}

		let currentStates = _.get(this.context.quote, 'cap.coverages.currentStates', defaultStates);

		if (!(currentStates instanceof Set)) {
			currentStates = getSet(currentStates);
		}

		let validStates = agent.writingStates;

		if (!_.isArray(agent.writingStates)) {
			validStates = _.values(agent.writingStates);
		}

		_.forEach(validStates, (st) => {
			if (!_.get(this.context.quote, `cap.${st}`) && !currentStates.has(st)) {
				stateOptions.push({ value: st, text: states[st] });
			}
		});

		this.setState({ stateOptions, currentStates });
	}
	componentDidMount() {
		// If the form is not empty, trigger validation
		//TODO: Determine how to tell if this is the first time or not.
		const predState = getPredState(this.context.quote);
		runRulesOnLoad(
			this.formProps,
			this.formProps.initialValues,
			[''],
			isBlank(_.get(this.formProps.values, `cap.coverages.${predState}.address`, '')),
		);
	}
	componentDidUpdate() {
		// If the form is not empty, trigger validation
		//TODO: Change to only validate address field on did update.
		//* This was done because returning from new address options held a 'required field' error
		const predState = getPredState(this.context.quote);
		runRulesOnLoad(
			this.formProps,
			this.formProps.initialValues,
			[''],
			isBlank(_.get(this.formProps.values, `cap.coverages.${predState}.address`, '')),
		);
	}

	getInitialStates = () => {
		const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));
		const initialStates = {};
		let validStates = agent.writingStates;
		if (!_.isArray(agent.writingStates)) {
			validStates = _.values(agent.writingStates);
		}
		_.forEach(validStates, (st) => {
			initialStates[st] = _.get(
				this.context.quote,
				`coverages.${st}`,
				stateMap(
					_.get(this.context, 'quote.cap.coverages', {}),
					st,
					_.get(this.context, 'quote.cap.liabilityLimit', ''),
				),
			);
		});
		initialStates.currentStates = getSet(
			_.get(this.context, 'quote.cap.coverages.currentStates', this.state.currentStates),
		);
		return initialStates;
	};

	removeCoverage = (st, formikProps, hideToast) => {
		let { currentStates } = this.state;
		if (!(currentStates instanceof Set)) {
			currentStates = getSet(currentStates);
		}
		currentStates.delete(st);

		formikProps.values.cap.coverages.currentStates = currentStates;

		this.visibility = getVisibility(getFieldDisplayArray('commercialAuto'), this.context.quote, formikProps.values);

		formikProps.validateForm(formikProps.values);
		if (!hideToast) {
			toast.success('State Removed!');
		}

		this.context.savePageValues(formikProps.values);
	};

	cleanStateAddresses = (st, values, sfv) => {
		const addressId = _.toString(_.get(values, `cap.coverages.${st}.address`, ''));
		//If the stored location ID is now tied to a different state, clear the addressID saved
		if (!isBlank(addressId) && _.get(this.context.quote, `addresses.${addressId}.state`) !== st) {
			sfv(`cap.coverages.${st}.address`, '', true);
		}
	};

	render() {
		const { quote } = this.context;
		return (
			<Formik
				render={(formikProps) => {
					this.formProps = formikProps;
					this.dirty = formikProps.dirty;
					this.visibility = getVisibility(
						getFieldDisplayArray('commercialAuto'),
						this.context.quote,
						formikProps.values,
					);
					this.cleaned = cleanValues(formikProps.values, this.visibility);
					_.forEach([...this.state.currentStates], (st) => {
						this.cleanStateAddresses(st, formikProps.values, formikProps.setFieldValue);
						const updatedVis = updateSectionVisibility(quote, st, formikProps.values);
						_.merge(this.visibility, updatedVis);
						this.cleaned = cleanValues(formikProps.values, updatedVis) || this.cleaned;
					});

					formikProps.dirty = this.cleaned;

					return (
						<Form id='screen'>
							<PageSection className='addCoverage' name='section_capStates' errors={formikProps.errors}>
								<Field name='state' label='Add New State' component={Select} options={this.state.stateOptions} />
								<SimpleButton
									content='Add Coverage'
									id='AddCoverage'
									primary
									onClick={() => {
										const data = formikProps.values.state || '';
										if (!isBlank(data)) {
											let { currentStates } = this.state;
											currentStates.add(data);
											formikProps.values.cap.coverages.currentStates = currentStates;
											this.setState({ currentStates });
											formikProps.validateForm(formikProps.values);
											formikProps.values.state = '';
										}
									}}
								/>
							</PageSection>
							{[...this.state.currentStates].map((st) => (
								<StateCoverages
									key={st}
									state={st}
									visibility={this.visibility}
									removeCoverage={(state, hideToast) => this.removeCoverage(state, formikProps, hideToast)}
									sectionVisibility={updateSectionVisibility(quote, st, formikProps.values)}
									liabilityLimit={_.get(quote, 'cap.liabilityLimit', 0)}
									location={this.props.location}
									history={this.props.history}
								/>
							))}
							<NavigationButtons
								formikProps={formikProps}
								back
								location={this.props.location}
								history={this.props.history}
								rulesObject={StateCoveragesRules}
							/>
						</Form>
					);
				}}
				initialValues={
					quote.cap
						? {
								cap: {
									...quote.cap,
									coverages: this.getInitialStates(),
								},
						  }
						: {}
				}
				onSubmit={(values, formikActions) => {
					this.cleaned = cleanValues(values, this.visibility) || this.cleaned;
					this.cleaned = cleanOrphanAddresses(quote, values) || this.cleaned;

					// Check to see if the address has changed so we need to call CLUE
					let clueRequired = false;

					_.forEach([...this.state.currentStates], (st) => {
						const updatedVis = updateSectionVisibility(this.context.quote, st, values);
						_.merge(this.visibility, updatedVis);
						this.cleaned = cleanValues(values, updatedVis, this.cleaned) || this.cleaned;
						this.cleanStateAddresses(st, values, formikActions.setFieldValue);

						clueRequired =
							clueRequired ||
							_.get(quote, `cap.coverages.${st}.address`, '') !== _.get(values, `cap.coverages.${st}.address`, '');
					});

					// TODO: is there a cleaner way?
					if (clueRequired) {
						setReorderRule(this.context, this.context.quote, 'cap', this.props);
					}

					return this.context.onSubmit(
						values,
						this.dirty || this.cleaned,
						false,
						false,
						this.props,
						StateCoveragesRules,
					);
				}}
				validate={(values) => {
					const validResults = validate(
						values,
						StateCoveragesRules.rules(quote, values, this.visibility),
						duplicate(StateCoveragesRules.requiredStructure(quote, values)),
					);
					logPageErrors(validResults, this.formProps.touched, 'cap');
					return validResults;
				}}
			/>
		);
	}
}

export default StateCoveragesForm;
