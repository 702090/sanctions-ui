import { RemoveCoverageButton } from 'components/shared/buttons/RemoveCoverageButton';
import AddressPicker from 'components/shared/form/inputs/AddressPicker';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputText } from 'components/shared/form/inputs/InputText';
import { RadioButton } from 'components/shared/form/RadioButton';
import { Select } from 'components/shared/form/Select';
import { PageSection } from 'components/shared/sections/PageSection';
import selectOptionsJson from 'data/SelectOptions';
import { Field } from 'formik';
import _ from 'lodash';
import React from 'react';
import { isBlank } from 'utils/StringFunctions';

const {
	cap_additionalPipKS,
	cap_additionalPipKY,
	cap_collisionDeductible,
	cap_otherThanCollisionDeductible,
	cap_pipDeductible,
	cap_pipLimit,
	cap_pipMisc1,
	cap_towingLimitDisablement,
	cap_umCombinedSingleLimit,
	cap_umCSL_AL_AR_GA_MS_OK,
	cap_umCSL_IA_NE,
	cap_umCSL_IL,
	cap_umCSL_KS_MO,
	cap_umCSL_SD,
	cap_umCSL_TN,
	cap_umCSL_TX,
	cap_umDeductible,
	cap_umPdLimit,
} = selectOptionsJson;

export const StateCoverages = ({
	state,
	visibility,
	removeCoverage,
	sectionVisibility,
	liabilityLimit,
	location,
	history,
}) => {
	//! ! There is an overall map in select options. Make sure all new states values are included in this
	//! ! and make a new mapping for the individual state
	//! ! may be able to eliminated many of these because Tony said there's not many that are different by state
	let umCSLOptions = cap_umCombinedSingleLimit;
	switch (state) {
		case 'AL':
		case 'AR':
		case 'GA':
		case 'MS':
		case 'OK':
			umCSLOptions = cap_umCSL_AL_AR_GA_MS_OK;
			break;
		case 'KY':
			umCSLOptions = _.filter(umCSLOptions, ['value', liabilityLimit]);
			break;
		case 'KS':
		case 'MO':
			umCSLOptions = cap_umCSL_KS_MO;
			break;
		case 'TN':
			umCSLOptions = cap_umCSL_TN;
			break;
		case 'IL':
			umCSLOptions = cap_umCSL_IL;
			break;
		case 'IA':
		case 'NE':
			umCSLOptions = cap_umCSL_IA_NE;
			break;
		case 'SD':
			umCSLOptions = cap_umCSL_SD;
			break;
		case 'TX':
			umCSLOptions = cap_umCSL_TX;
			break;
		default:
	}

	// UM CSL options can't be greater than the Liability Limit on the Symbols page
	// KY must be same as the liability limit with no option to change
	umCSLOptions = _.filter(umCSLOptions, (option) => {
		return _.toNumber(liabilityLimit) >= _.toNumber(option.value);
	});

	// cap.coverages.${state}.umCombinedSingleLimit - AuCombLimit
	// cap.coverages.${state}.towingLimitDisablement - AuStTowingLimit
	// cap.coverages.${state}.hiredNonOwn - AuNOwnEmplCnt
	// not shown AuTypeLimit -always 1
	// cap.coverages.${state}.hiredAutoLiability - AuExcessHiredAmt
	// cap.coverages.${state}.otherThanCollisionAnnualCost - AuOTCCostHireAmt
	// cap.coverages.${state}.otherThanCollisionDeductible - AuOTCDedAmt
	// cap.coverages.${state}.collisionCostHireAmount - AuCollCostHireAmt
	// cap.coverages.${state}.collisionDeductible - AuCollHireDedAmt
	// cap.coverages.${state}.driveOtherCar - AuDriveOtherCar
	// cap.coverages.${state}.numberIndividualsCovered - AuIndivCovCnt
	// cap.coverages.${state}.tortRejectionIndicator AuTortLimitationRejectInd
	// cap.coverages.${state}.pipMisc1 AuPIPMisc1Ind
	// cap.coverages.${state}.pipDeductible AuPIPDedLimit
	// cap.coverages.${state}.pipLimit AuNoFltPIPThrshAmt

	return (
		<PageSection className='stateSection' title={state} biggerHeader>
			<img className='flag' alt={`${state}_flag`} src={require(`images/flags/${state.toLowerCase()}.png`)} />
			<PageSection>
				<AddressPicker
					name={`cap.coverages.${state}.address`}
					label='State Address'
					addLabel='Add a new state address'
					state={state}
					location={location}
					history={history}
				/>
			</PageSection>
			{(visibility['cap.umCombinedSingleLimit'] || visibility['cap.towingLimitDisablement']) && (
				<React.Fragment>
					<PageSection title='Limits' />
					<Field
						name={`cap.coverages.${state}.umCombinedSingleLimit`}
						label='Uninsured Motorist Combined Single Limit'
						fieldDisplay={visibility['cap.umCombinedSingleLimit']}
						component={Select}
						options={umCSLOptions}
						disabled={state === 'KY'}
					/>
					<Field
						name={`cap.coverages.${state}.towingLimitDisablement`}
						label='Towing Limit per Disablement'
						fieldDisplay={visibility['cap.towingLimitDisablement']}
						component={RadioButton}
						options={cap_towingLimitDisablement}
					/>
				</React.Fragment>
			)}
			{visibility['cap.hiredNonOwn'] && (
				<React.Fragment>
					<PageSection title='Hired/NonOwn' />
					<Field
						name={`cap.coverages.${state}.hiredNonOwn`}
						label='Non Owned Auto Liability - Number of Employees'
						fieldDisplay={visibility['cap.hiredNonOwn']}
						component={InputText}
						maxLength='6'
						width='tiny'
					/>
					<Field
						name={`cap.coverages.${state}.hiredAutoLiability`}
						label='Hired Auto Liability '
						fieldDisplay={visibility['cap.hiredAutoLiability']}
						component={InputText}
						maxLength='6'
						width='tiny'
					/>
				</React.Fragment>
			)}

			{visibility['cap.otherThanCollisionAnnualCost'] && (
				<React.Fragment>
					<PageSection title='Hired Physical Damage' />
					<Field
						name={`cap.coverages.${state}.otherThanCollisionAnnualCost`}
						label='Other than Collision Annual Cost of Hire'
						fieldDisplay={visibility['cap.otherThanCollisionAnnualCost']}
						component={InputText}
						maxLength='7'
						width='tiny'
					/>
					<Field
						name={`cap.coverages.${state}.otherThanCollisionDeductible`}
						label='Other than Collision Deductible'
						fieldDisplay={visibility['cap.otherThanCollisionDeductible']}
						component={RadioButton}
						options={cap_otherThanCollisionDeductible}
					/>
					<Field
						name={`cap.coverages.${state}.collisionCostHireAmount`}
						label='Collision Cost of Hire Amount'
						fieldDisplay={visibility['cap.collisionCostHireAmount']}
						component={InputText}
						maxLength='7'
						width='tiny'
					/>
					<Field
						name={`cap.coverages.${state}.collisionDeductible`}
						label='Collision Deductible'
						fieldDisplay={visibility['cap.collisionDeductible']}
						component={RadioButton}
						options={cap_collisionDeductible}
					/>
				</React.Fragment>
			)}

			{(visibility['cap.driveOtherCar'] ||
				((state === 'AR' || state === 'GA') && visibility['cap.umCombinedSingleLimit']) ||
				state === 'KY') && (
				<React.Fragment>
					<PageSection title='Optional Coverages' />
					<Field
						name={`cap.coverages.${state}.driveOtherCar`}
						label='Would you like to add Drive Other Car Coverage?'
						fieldDisplay={visibility['cap.driveOtherCar']}
						component={RadioButton}
					/>
					<Field
						name={`cap.coverages.${state}.numberIndividualsCovered`}
						label='How many individuals are covered?'
						fieldDisplay={sectionVisibility[`cap.coverages.${state}.numberIndividualsCovered`]}
						component={InputNumber}
						maxLength='3'
						width='tiny'
					/>
					{state === 'AR' && (
						<React.Fragment>
							<Field
								name={`cap.coverages.${state}.umPdLimit`}
								label='UM PD Limit'
								component={RadioButton}
								options={cap_umPdLimit}
								fieldDisplay={visibility['cap.coverages.AR.umPdLimit']}
							/>
						</React.Fragment>
					)}
					{state === 'GA' && (
						<React.Fragment>
							<Field
								name={`cap.coverages.${state}.umDeductible`}
								label='UM Deductible'
								component={RadioButton}
								options={cap_umDeductible}
								fieldDisplay={visibility['cap.coverages.GA.umDeductible']}
							/>
							<Field
								name={`cap.coverages.${state}.addOnCoverage`}
								label='Add On Coverage'
								component={RadioButton}
								fieldDisplay={visibility['cap.coverages.GA.addOnCoverage']}
							/>
						</React.Fragment>
					)}
					{state === 'KY' && (
						<React.Fragment>
							<Field
								name={`cap.coverages.${state}.tortRejectionIndicator`}
								label='Tort Rejection Indicator'
								component={RadioButton}
							/>
						</React.Fragment>
					)}
				</React.Fragment>
			)}

			{(sectionVisibility[`cap.coverages.${state}.additionalPip`] ||
				sectionVisibility[`cap.coverages.${state}.pipLimit`] ||
				state === 'KY') && (
				<React.Fragment>
					<PageSection title='PIP' />
					{state === 'KY' && (
						<React.Fragment>
							<Field
								name={`cap.coverages.${state}.pipMisc1`}
								label='PIP Misc 1'
								component={RadioButton}
								fieldDisplay={sectionVisibility[`cap.coverages.${state}.pipMisc1`]}
								options={cap_pipMisc1}
							/>
							<Field
								name={`cap.coverages.${state}.pipDeductible`}
								label='PIP Deductible'
								component={RadioButton}
								options={cap_pipDeductible}
								optional
							/>
						</React.Fragment>
					)}
					{state === 'TX' && (
						<React.Fragment>
							<Field
								name={`cap.coverages.${state}.pipLimit`}
								label='PIP Limit'
								component={RadioButton}
								fieldDisplay={sectionVisibility[`cap.coverages.${state}.pipLimit`]}
								options={cap_pipLimit}
							/>
						</React.Fragment>
					)}
					<Field
						name={`cap.coverages.${state}.additionalPip`}
						label='Additional PIP'
						fieldDisplay={sectionVisibility[`cap.coverages.${state}.additionalPip`]}
						component={RadioButton}
						options={state === 'KY' ? cap_additionalPipKY : cap_additionalPipKS}
					/>
				</React.Fragment>
			)}

			<RemoveCoverageButton
				onClick={(event) => {
					removeCoverage(state);
				}}
			/>
		</PageSection>
	);
};

export const stateMap = (coverages, st, liabilityLimit) => ({
	address: _.get(coverages, `${st}.address`, ''),
	umCombinedSingleLimit: st === 'KY' ? liabilityLimit : _.get(coverages, `${st}.umCombinedSingleLimit`, ''),
	towingLimitDisablement: _.get(coverages, `${st}.towingLimitDisablement`, ''),
	hiredNonOwn: _.get(coverages, `${st}.hiredNonOwn`, 'IF ANY'),
	hiredAutoLiability: _.get(coverages, `${st}.hiredAutoLiability`, 'IF ANY'),
	otherThanCollisionAnnualCost: _.get(coverages, `${st}.otherThanCollisionAnnualCost`, 'IF ANY'),
	otherThanCollisionDeductible: _.get(coverages, `${st}.otherThanCollisionDeductible`, '100'),
	collisionCostHireAmount: _.get(coverages, `${st}.collisionCostHireAmount`, 'IF ANY'),
	collisionDeductible: _.get(coverages, `${st}.collisionDeductible`, ''),
	driveOtherCar: _.get(coverages, `${st}.driveOtherCar`, ''),
	numberIndividualsCovered: _.get(coverages, `${st}.numberIndividualsCovered`, ''),
	additionalPip: _.get(coverages, `${st}.additionalPip`, ''),
	umDeductible: isBlank(_.get(coverages, `${st}.umDeductible`, '1'))
		? '1'
		: _.get(coverages, `${st}.umDeductible`, '1'),
	addOnCoverage: isBlank(_.get(coverages, `${st}.addOnCoverage`, 'Y'))
		? 'Y'
		: _.get(coverages, `${st}.addOnCoverage`, 'Y'),
	umPdLimit: _.get(coverages, `${st}.umPdLimit`, ''),
	tortRejectionIndicator: _.get(coverages, `${st}.tortRejectionIndicator`, 'N'),
	pipMisc1: _.get(coverages, `${st}.pipMisc1`, '1'),
	pipDeductible: _.get(coverages, `${st}.pipDeductible`, ''),
	pipLimit: isBlank(_.get(coverages, `${st}.pipLimit`, '2500')) ? '2500' : _.get(coverages, `${st}.pipLimit`, '2500'),
});
