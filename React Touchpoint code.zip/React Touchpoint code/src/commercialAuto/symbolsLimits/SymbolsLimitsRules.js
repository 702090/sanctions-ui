import { getFieldDisplayArray, requiredQuestionMessage } from 'data/FieldVisibility';
import _ from 'lodash';
import { hasMedPaySymbol } from 'utils/FieldDisplay';
import { getVisibility } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';

export default class SymbolsLimitsRules {
	static requiredStructure = {
		cap: {
			registrationAddress: '',
			symbols: {
				liability: '',
				comp: '',
				coll: '',
				pip: '',
			},
			medPay: '',
			medPayLimit: '',
			compDeductible: '',
			collDeductible: '',
		},
	};

	static rules(quote, values, visibility) {
		// use values for current page validation
		// use quote for external page validation
		if (values && !visibility) {
			visibility = getVisibility(getFieldDisplayArray('commercialAuto'), quote, values);
		}

		let restaurant = false;

		_.forIn(_.get(quote, 'sfg.locations', {}), (location, locId) => {
			_.forIn((quote, `sfg.locations.${locId}.buildings`, {}), (building) => {
				if (_.includes(['8', '9'], building.occupancyType)) {
					restaurant = true;
				}
			});
		});

		return {
			cap: {
				registrationAddress: [[(value) => !isBlank(value) && value !== 'NEW', requiredQuestionMessage]],
				compDeductible: [[(value) => !(visibility['cap.compDeductible'] && isBlank(value)), requiredQuestionMessage]],
				collDeductible: [[(value) => !(visibility['cap.collDeductible'] && isBlank(value)), requiredQuestionMessage]],
				symbols: {
					liability: [
						[
							(value) => !(restaurant && value !== '7'),
							'Policies with a restaurant may only choose Liability Symbol 7',
						],
					],
					comp: [
						[
							(value) =>
								(_.includes(value, '8') && _.includes(values.cap.symbols.coll, '8')) ||
								(!_.includes(value, '8') && !_.includes(values.cap.symbols.coll, '8')),
							'If either Comprehensive Symbol or Collision Symbol has symbol 8, they must both have symbol 8. Please check your entry and try again.',
						],
						[
							(value) =>
								(_.includes(value, '0') && _.includes(values.cap.symbols.coll, '0')) ||
								(!_.includes(value, '0') && !_.includes(values.cap.symbols.coll, '0')),
							'If either Comprehensive Symbol or Collision Symbol has been selected, they must both be selected. Please check your entry and try again.',
						],
					],
					coll: [
						[
							(value) =>
								(_.includes(value, '8') && _.includes(values.cap.symbols.comp, '8')) ||
								(!_.includes(value, '8') && !_.includes(values.cap.symbols.comp, '8')),
							'If either Comprehensive Symbol or Collision Symbol has symbol 8, they must both have symbol 8. Please check your entry and try again.',
						],
						[
							(value) =>
								(_.includes(value, '0') && _.includes(values.cap.symbols.comp, '0')) ||
								(!_.includes(value, '0') && !_.includes(values.cap.symbols.comp, '0')),
							'If either Comprehensive Symbol or Collision Symbol has been selected, they must both be selected. Please check your entry and try again.',
						],
					],
					pip: [[(value) => !(visibility['cap.symbols.pip'] && isBlank(value)), requiredQuestionMessage]],
				},
				medPayLimit: [[(value) => !(isBlank(value) && hasMedPaySymbol(quote, values)), requiredQuestionMessage]],
			},
		};
	}
	static referrals(context, values) {
		return {};
	}
	static name() {
		return 'capSymbolsLimits';
	}
}
