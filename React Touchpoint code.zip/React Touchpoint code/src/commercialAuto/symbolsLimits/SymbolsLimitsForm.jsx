import SymbolsLimitsRules from 'commercialAuto/symbolsLimits/SymbolsLimitsRules';
import AddressPicker from 'components/shared/form/inputs/AddressPicker';
import { RadioButton } from 'components/shared/form/RadioButton';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import selectOptionsJson from 'data/SelectOptions';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { Component } from 'react';
import { retrieveVehiclePrefill } from 'services/vehicleService';
import { cleanOrphanAddresses, getAllAddresses, getFirstLocation, getFullInsuredName } from 'utils/BusinessFunctions';
import { duplicate, getSet } from 'utils/ObjectFunctions';
import { cleanValues, getVisibility, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { validate } from 'validation/Validate';

const {
	cap_collDeductible,
	cap_compDeductible,
	cap_liabilityLimit,
	cap_medPayLimit,
	cap_symbols_additionalPip,
	cap_symbols_coll,
	cap_symbols_coll_PremierSymbol,
	cap_symbols_comp,
	cap_symbols_comp_PremierSymbol,
	cap_symbols_liability,
	cap_symbols_medPay,
	cap_symbols_pip,
	cap_symbols_pip_TX,
	cap_symbols_tow,
	cap_symbols_umUIM,
} = selectOptionsJson;

export default class SymbolsLimitsForm extends Component {
	static contextType = QuoteContext;

	dirty = false;
	visibility = {};
	predState = '';
	texasState = false;
	sfgCoverages = new Set();
	selectOptionUM = [];
	pipStateOptions = [];
	compOptions = [];
	liabilityOptions = [];
	medPayLimitOptions = [];
	additionalPipStateOptions = [];
	restaurant = false;

	updateCompCollSymbols = (premier, setFieldValue, values) => {
		// update the values here if Premier is changed to Yes and symbols were 7,8
		if (premier === 'Y' && values.cap.symbols.comp === '7,8') {
			setFieldValue('cap.symbols.comp', '7', false);
		}
		if (premier === 'Y' && values.cap.symbols.coll === '7,8') {
			setFieldValue('cap.symbols.coll', '7', false);
		}
	};

	getPipOptions = (value) => {
		this.pipStateOptions = this.predState === 'TX' ? cap_symbols_pip_TX : cap_symbols_pip;
		if (value !== '1') {
			this.pipStateOptions = _.filter(this.pipStateOptions, (option) => {
				return option.value !== '5';
			});
		}
		return this.pipStateOptions;
	};

	getAdditionalPipOptions = (value) => {
		this.additionalPipStateOptions = cap_symbols_additionalPip;
		if (value !== '1') {
			this.additionalPipStateOptions = _.filter(this.additionalPipStateOptions, (option) => {
				return option.value !== '5';
			});
		}
		return this.additionalPipStateOptions;
	};

	UNSAFE_componentWillMount() {
		const firstLocation = getFirstLocation(this.context.quote);
		this.predState = _.get(this.context, `quote.addresses.${firstLocation}.state`);
		this.texasState = this.predState === 'TX';

		this.selectOptionUM = duplicate(cap_symbols_umUIM);
		// adding 'No coverage options' when conditions met
		if (!_.includes(['IL', 'MO', 'NE', 'SD'], this.predState)) {
			this.selectOptionUM.push({ value: '0', text: 'No Coverage' });
		}

		this.liabilityOptions = cap_symbols_liability;
		const currentCoverages = getSet(_.get(this.context.quote, 'sfg.coverages.currentCoverages', []));

		_.forIn(_.get(this.context.quote, 'sfg.locations', {}), (location, locId) => {
			_.forIn(_.get(this.context.quote, `sfg.locations.${locId}.buildings`, {}), (building) => {
				if (_.includes(['8', '9'], building.occupancyType)) {
					this.restaurant = true;
				}
			});
		});

		if (currentCoverages.has('HIRE') || currentCoverages.has('NOWN') || this.restaurant) {
			this.liabilityOptions = _.filter(this.liabilityOptions, (option) => {
				return option.value === '7';
			});
		}

		this.medPayLimitOptions = cap_medPayLimit;
		if (this.texasState) {
			this.medPayLimitOptions = _.filter(this.medPayLimitOptions, (option) => {
				return option.value !== '2000';
			});
		} else {
			this.medPayLimitOptions = _.filter(this.medPayLimitOptions, (option) => {
				return option.value !== '2500';
			});
		}

		this.pipStateOptions = this.getPipOptions(_.get(this.context.quote, 'cap.symbols.liability', '7'));
		if (_.includes(['KS', 'KY'], this.predState)) {
			this.additionalPipStateOptions = this.getAdditionalPipOptions(
				_.get(this.context.quote, 'cap.symbols.liability', '7'),
			);
		}

		this.sfgCoverages = _.get(this.context.quote, 'sfg.coverages.currentCoverages', new Set());
		if (!(this.sfgCoverages instanceof Set)) {
			this.sfgCoverages = getSet(this.sfgCoverages);
		}

		//Clear out selection if selected address is no longer in the option list
		const addressList = getAllAddresses(_.get(this.context, 'quote.addresses', { 1: { fullAddress: '' } }));
		let cleanArray = true;
		_.forIn(addressList, (address) => {
			if (address.value === _.get(this.context, 'quote.cap.registrationAddress', '')) {
				cleanArray = false;
			}
		});
		if (cleanArray) {
			_.set(this.context, 'quote.cap.registrationAddress', '');
		}
	}
	componentDidMount() {
		// If the form is not empty, trigger validation

		runRulesOnLoad(
			this.formProps,
			this.formProps.initialValues,
			[''],
			isBlank(_.get(this.formProps.values, 'cap.registrationAddress', '')),
		);
	}

	render() {
		const { quote } = this.context;
		let { location, history } = this.props;
		return (
			<Formik
				render={(formikProps) => {
					this.formProps = formikProps;
					const compSymbolOptions =
						_.get(formikProps, 'values.cap.premier') === 'Y' ? cap_symbols_comp_PremierSymbol : cap_symbols_comp;
					const collSymbolOptions =
						_.get(formikProps, 'values.cap.premier') === 'Y' ? cap_symbols_coll_PremierSymbol : cap_symbols_coll;

					this.dirty = formikProps.dirty;

					if (
						this.restaurant &&
						!this.dirty &&
						!(
							_.get(this.context, 'quote.cap.liability.symbols.liability') === '7' ||
							formikProps.values.cap.symbols.liability === '7'
						)
					) {
						this.formProps.setFieldValue('cap.symbols.liability', '7');
						this.dirty = true;
					}

					this.visibility = getVisibility(getFieldDisplayArray('commercialAuto'), quote, formikProps.values);

					cleanValues(formikProps.values, this.visibility);
					return (
						<Form id='screen'>
							<PageSection title='Vehicle Registration'>
								<AddressPicker
									name='cap.registrationAddress'
									label='At which address are your vehicles registered?'
									addLabel='Add registration address'
									location={location}
									history={history}
								/>
							</PageSection>

							<PageSection title='Policy Coverage Information'>
								<Field
									name='cap.premier'
									label='Premier Endorsement'
									component={RadioButton}
									additionalOnChange={this.updateCompCollSymbols}
								/>
							</PageSection>
							<PageSection title='Covered Auto Symbols'>
								<Field
									name='cap.symbols.liability'
									label='Liability Symbol'
									component={RadioButton}
									options={this.liabilityOptions}
									additionalOnChange={(value) => {
										this.getPipOptions(value);
										this.getAdditionalPipOptions(value);
									}}
								/>
								<Field
									name='cap.liabilityLimit'
									label='Liability Limit'
									component={RadioButton}
									options={cap_liabilityLimit}
									multiColumn='2'
									width='small'
								/>
								<div className='flexFields'>
									<Field
										name='cap.symbols.umUIM'
										label='UM/UIM Symbol'
										component={RadioButton}
										options={this.selectOptionUM}
									/>
								</div>
								<div className='flexFields'>
									<Field
										name='cap.symbols.pip'
										label='PIP Symbol'
										component={RadioButton}
										options={this.pipStateOptions}
										fieldDisplay={this.visibility['cap.symbols.pip']}
										optional={this.texasState}
									/>
								</div>
								<div className='flexFields'>
									<Field
										name='cap.symbols.additionalPip'
										label='Additional PIP Symbol'
										component={RadioButton}
										options={this.additionalPipStateOptions}
										optional
										fieldDisplay={this.visibility['cap.symbols.additionalPip']}
									/>
								</div>
								<div className='flexFields'>
									<Field
										name='cap.symbols.medPay'
										label='Med Pay Symbol'
										component={RadioButton}
										optional={this.texasState}
										options={cap_symbols_medPay}
									/>
									<Field
										name='cap.medPayLimit'
										label='Med Pay Limit'
										component={RadioButton}
										options={this.medPayLimitOptions}
										fieldDisplay={this.visibility['cap.medPayLimit']}
										multiColumn='2'
										width='small'
									/>
								</div>
								<div className='flexFields'>
									<Field
										name='cap.symbols.comp'
										label='Comprehensive Symbol'
										component={RadioButton}
										options={compSymbolOptions}
									/>
									<Field
										name='cap.compDeductible'
										label='Comprehensive Deductible'
										component={RadioButton}
										options={cap_compDeductible}
										fieldDisplay={this.visibility['cap.compDeductible']}
										multiColumn='2'
										width='small'
									/>
								</div>
								<div className='flexFields'>
									<Field
										name='cap.symbols.coll'
										label='Collision Symbol'
										component={RadioButton}
										options={collSymbolOptions}
									/>
									<Field
										name='cap.collDeductible'
										label='Collision Deductible'
										component={RadioButton}
										options={cap_collDeductible}
										fieldDisplay={this.visibility['cap.collDeductible']}
										multiColumn='2'
										width='small'
									/>
								</div>
								<div className='flexFields'>
									<Field
										name='cap.symbols.tow'
										label='Towing Symbol'
										component={RadioButton}
										options={cap_symbols_tow}
										fieldDisplay={this.visibility['cap.symbols.tow']}
										optional
									/>
								</div>
							</PageSection>
							<NavigationButtons
								formikProps={formikProps}
								back
								location={this.props.location}
								history={this.props.history}
							/>
						</Form>
					);
				}}
				initialValues={
					quote.cap
						? {
								cap: {
									...quote.cap,
									registrationAddress: _.get(quote, 'cap.registrationAddress', ''),
									symbols: {
										liability: _.get(
											quote,
											'cap.symbols.liability',
											(this.sfgCoverages.has('HIRE') && this.sfgCoverages.has('NOWN')) || this.restaurant
												? '7'
												: '7,8,9',
										),
										umUIM: _.get(quote, 'cap.symbols.umUIM', '7'),
										pip: _.get(quote, 'cap.symbols.pip', this.texasState ? '0' : '7'),
										additionalPip: _.get(quote, 'cap.symbols.additionalPip', '0'),
										medPay: _.get(quote, 'cap.symbols.medPay', this.texasState ? '0' : '7'),
										comp: _.get(quote, 'cap.symbols.comp', '7'),
										coll: _.get(quote, 'cap.symbols.coll', '7'),
										tow: _.get(quote, 'cap.symbols.tow', '0'),
									},
									premier: _.get(quote, 'cap.premier', 'Y'),
									liabilityLimit: _.get(quote, 'cap.liabilityLimit', '1000000'),
									medPayLimit: _.get(quote, 'cap.medPayLimit', this.texasState ? '' : '5000'),
									compDeductible: _.get(quote, 'cap.compDeductible', '500'),
									collDeductible: _.get(quote, 'cap.collDeductible', '500'),
								},
						  }
						: {}
				}
				onSubmit={(values, formikActions) => {
					let cleaned = cleanValues(values, this.visibility);
					cleaned = cleanOrphanAddresses(quote, values) || cleaned;
					retrieveVehiclePrefill(
						quote,
						getFullInsuredName(quote),
						_.get(quote, `addresses.${values.cap.registrationAddress}`, {
							fullAddress: '',
						}),
						this.context.updateQuote,
						this.context,
					);

					// Check to see if the address has changed so we need to call CLUE
					const clueRequired =
						_.get(quote, 'cap.registrationAddress', '') !== _.get(values, 'cap.registrationAddress', '');

					return this.context.onSubmit(
						values,
						this.dirty || cleaned,
						false,
						clueRequired ? 'cap' : clueRequired,
						this.props,
					);
				}}
				validate={(values) => {
					const validResults = validate(
						values,
						SymbolsLimitsRules.rules(quote, values, this.visibility),
						duplicate(SymbolsLimitsRules.requiredStructure),
					);
					logPageErrors(validResults, this.formProps.touched, 'cap');
					return validResults;
				}}
			/>
		);
	}
}
