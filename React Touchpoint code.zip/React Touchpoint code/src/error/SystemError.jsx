import React, { Component } from 'react';
import 'App.scss';
import _ from 'lodash';

class SystemError extends Component {
	state = {};

	render() {
		return (
			<React.Fragment>
				<div id='screen'>
					<div id='rate'>
						<div id='totalRate'>
							<div id='systemError'>
								<h1>System Error!!</h1>
								<div id='errorRate'>
									<img id='surprisedRed' alt='Surprised Alien' src={require('images/surprisedAlienRed.png')} />
								</div>
								<div id='errorRate'>
									<h2>{sessionStorage.getItem('TPSystemError')}</h2>
								</div>
								<br />
								<div id='errorRate'>
									<h4> Please contact the Service Desk at 800-877-3579 extension 1850</h4>
								</div>
							</div>
						</div>
					</div>
				</div>
			</React.Fragment>
		);
	}
}

export default SystemError;
