import React, { Component } from 'react';

class ErrorTemplate extends Component {
	state = {};

	render() {
		return (
			<React.Fragment>
				<h1>ACCESS DENIED</h1>
			</React.Fragment>
		);
	}
}

export default ErrorTemplate;
