import ConfirmModal from 'components/shared/modals/ConfirmModal';
import { EntryModal } from 'components/shared/modals/EntryModal';
import { OptionModal } from 'components/shared/modals/OptionModal';
import { getPage } from 'components/shared/navigation/NavigationFunctions';
import QuoteContext from 'context/quoteContext';
import {
	reducer,
	UPDATE_NAV,
	UPDATE_QUOTE,
	UPDATE_QUOTE_STATUS,
	UPDATE_RATE,
	UPDATE_SERVICE_STATUS,
} from 'context/reducers';
import { runAllRules } from 'helper/Validation';
import _ from 'lodash';
import React, { useContext, useReducer, useRef } from 'react';
import { toast } from 'react-toastify';
import BuildingRules from 'safeguard/locationDashboard/building/BuildingRules';
import SfgLocationRules from 'safeguard/locationDashboard/location/SfgLocationRules';
import callClue from 'services/clueService';
import { getUnderlyingPolicies, insurityCall } from 'services/insurityService';
import { saveQuote } from 'services/quoteService';
import Sockette from 'sockette';
import {
	additionalFormsRequired,
	call360Valuation,
	callRoofReportAPI,
	cleanAdditionalInterests,
	fillinFormsRequired,
	isEmployee,
	newAddressVerisk360,
	roofQuestionsRequired,
	setRetrievedUnderlyingPolicyData,
	shouldUpdatePDDeductible,
} from 'utils/BusinessFunctions';
import { duplicate, getSet } from 'utils/ObjectFunctions';
import { mergeFieldStructure } from 'utils/ScreenFunctions';
import { isBlank, isBlankZ } from 'utils/StringFunctions';
import { v4 as uuidv4 } from 'uuid';
import { runCapReferrals, runCupReferrals, runWcpReferrals } from 'validation/RunReferrals';
import { removeProductReferrals } from 'validation/Validate';

const GlobalState = (prop) => {
	const context = useContext(QuoteContext);
	const optionModal = useRef(null);
	const entryModal = React.createRef();
	const confirmModal = React.createRef();
	const { navigation, quote, rate, serviceStatus, quoteStatus } = context;

	const [socket, setSocket] = React.useState();
	const [sessionID, setSessionID] = React.useState(uuidv4());
	const [socketMessage, setSocketMessage] = React.useState();
	const [quoteState, dispatchQuote] = useReducer(reducer, quote);
	const [navState, dispatchNav] = useReducer(reducer, navigation);
	const [rateState, dispatchRate] = useReducer(reducer, rate);
	const [statusTracker, dispatchStatus] = useReducer(reducer, serviceStatus);
	const [quoteStatusState, dispatchQuoteStatus] = useReducer(reducer, quoteStatus);

	if (!socket) {
		let ws = new Sockette(`wss://${process.env.REACT_APP_WEBSOCKET_DOMAIN}?sessionID=${sessionID}`, {
			onopen: (e) => {
				console.info('connected', e);
			},
			onmessage: (e) => {
				console.info('onmessage', e);
				setSocketMessage(_.get(e, 'data', ''));
			},
			onclose: (e) => {
				console.info('Closed!', e);
				setSocket(false);
			},
		});
		setSocket(ws);
	}

	React.useEffect(() => {
		if (!isBlank(socketMessage)) {
			const returnJSON = JSON.parse(socketMessage);
			if (returnJSON.messageType === 'VeriskRoofReport') {
				handleRoofReport({}, '', returnJSON.message);
			}
			setSocketMessage('');
		}
	}, [socketMessage]);

	const updateNav = (nav) => {
		dispatchNav({ type: UPDATE_NAV, nav });
	};

	const resetQuote = () => {
		updateQuoteState({
			products: ['sfg'],
			rates: { sfg: 'quoting' },
		});
		resetRating(true);
	};

	const updateQuoteState = async (qte) => {
		dispatchQuote({ type: UPDATE_QUOTE, quote: qte });
	};

	const updateQuoteStatus = async (status) => {
		dispatchQuoteStatus({ type: UPDATE_QUOTE_STATUS, status });
	};

	const updateQuote = async (qte, props, noSave) => {
		const passedValidation = props
			? runAllRules(props, qte, context.navigation, checkNavProducts, updateNav, serviceStatus)
			: true;
		if ((props || (qte && qte.id)) && !noSave) {
			await saveQuote(qte);
		}
		updateQuoteState(qte);
		return passedValidation;
	};

	const resetRating = (initial) => {
		updateRate({
			done: new Set(),
			doneRating: initial,
			errorMessages: {},
			totalRate: 0,
			hasCap: _.includes(quoteState.products, 'cap'),
			hasWcp: _.includes(quoteState.products, 'wcp'),
			hasCup: _.includes(quoteState.products, 'cup'),
			status: {
				sfg: 'r',
				cap: 'p',
				wcp: 'p',
				cup: 'p',
			},
			sfgRate: '',
			capRate: '',
			wcpRate: '',
			cupRate: '',
		});
	};
	const updateRate = (rte) => {
		dispatchRate({ type: UPDATE_RATE, rate: rte });
	};

	const updateServiceStatus = (serviceName, flag) => {
		dispatchStatus({
			type: UPDATE_SERVICE_STATUS,
			serviceStatus: context.serviceStatus,
			serviceName,
			flag,
		});
	};

	const checkNavProducts = (products, props, blockUpdate) => {
		const initNav = _.cloneDeep(navigation);
		context.navigation.navItems.forEach((navItem) => {
			if (navItem.product && products.has(navItem.product)) {
				navItem.visible = true;
			} else if (navItem.product) {
				navItem.visible = false;
			}

			if (navItem.url === '/quote/modifiers' && isEmployee()) {
				navItem.visible = true;
			}

			navItem.children &&
				navItem.children.forEach((childNav) => {
					if (childNav.product && products.has(childNav.product)) {
						childNav.visible = true;
					} else if (childNav.url === '/quote/issue/fillinForms') {
						if (fillinFormsRequired(quoteState)) {
							childNav.visible = true;
						} else {
							childNav.visible = false;
						}
					} else if (childNav.url === '/quote/issue/additionalForms') {
						if (additionalFormsRequired(quoteState)) {
							childNav.visible = true;
						} else {
							childNav.visible = false;
						}
					} else if (childNav.url === '/quote/issue/additionalQuestions') {
						if (roofQuestionsRequired(quoteState)) {
							childNav.visible = true;
						} else {
							childNav.visible = false;
						}
					} else if (childNav.url.includes('priorCarrier')) {
						if (_.get(quoteState, 'newVenture') !== 'Y') {
							childNav.visible = true;
						} else {
							childNav.visible = false;
						}
					} else if (childNav.product) {
						childNav.visible = false;
					}
				});
		});

		if (!_.isEqual(initNav, context.navigation) && !blockUpdate) {
			updateNav(navigation);
		}
		if (!blockUpdate) {
			runAllRules(props, quoteState, context.navigation, checkNavProducts, updateNav, serviceStatus);
		}
	};

	/**
	 * Takes the form values and saves a new quote to the database
	 * !!Do not use for Modals!!
	 * @param {Object} values The values from the form
	 */
	const savePageValues = async (values, pushToInsurity, clueProducts, props, rulesObject) => {
		let passedValidation = true;
		let noSave = false;
		let fieldStructure = {};
		if (props && props.rulesObject) {
			rulesObject = props.rulesObject;
		}
		if (rulesObject) {
			fieldStructure = mergeFieldStructure(rulesObject, values);

			//This is required for an object with a nested array of objects
			if (props && props.location.pathname === '/quote/safeguard/coverages') {
				fieldStructure = _.mergeWith({}, duplicate(values), duplicate(fieldStructure), function (v, f) {
					if (_.isArray(v)) {
						return (f = v);
					}
				});
			}
		}
		if (props && props.location.pathname === '/quote/modifiers') {
			_.unset(quoteState, 'sfg.modifiers');
			_.unset(quoteState, 'wcp.modifiers');
			_.unset(quoteState, 'cap.modifiers');
		}

		const updatedQuote = _.merge(quoteState, fieldStructure, values);
		insurityCall(updatedQuote, pushToInsurity);
		if (clueProducts) {
			callClue(updatedQuote, clueProducts);
		}

		if (props && props.location.pathname === '/quote/issue/billingInformation') {
			noSave = true;
		}

		passedValidation = await updateQuote(updatedQuote, props, noSave);

		return passedValidation;
	};

	const onSubmit = async (values, dirty, insurityPush, clueProducts, props, rulesObject) => {
		console.info('quoteState', quoteState); //! We want to keep this until we go to production !//
		try {
			let passedValidation = true;
			if (dirty) {
				passedValidation = await savePageValues(values, insurityPush, clueProducts, props, rulesObject);
			} else {
				passedValidation = runAllRules(
					props,
					quoteState,
					context.navigation,
					checkNavProducts,
					updateNav,
					serviceStatus,
				);
			}
			if (passedValidation) {
				if (
					_.includes(_.get(quoteState, 'products', ['sfg']), 'cup') &&
					!isBlank(_.get(quoteState, 'customerNumber', '')) &&
					!_.get(quoteState, 'cup', {}).retrievedUnderlyingPolicies
				) {
					_.set(quoteState, 'cup.retrievedUnderlyingPolicies', {});
					getUnderlyingPolicies({
						customerNumber: quoteState.customerNumber,
						effectiveDate: quoteState.effectiveDate,
					})
						.then(({ data: returnData }) => {
							setRetrievedUnderlyingPolicyData(returnData, quoteState, context.updateQuote, props);
						})
						.catch(() => {});
				}
				const moveToPage = getPage(
					props.location.pathname,
					props.location.pathname === '/quote/issue/billingInformation' &&
						_.get(values, 'billing.downPaymentMethod', '') === 'ICard'
						? 'cardPayment'
						: 'next',
					context.navigation.navItems,
				);
				props.history.push(moveToPage);
			}
		} catch (err) {
			toast.error('Your quote could not be saved.');
			console.error(err);
		}
	};

	const onBack = (values, dirty, insurityPush, props, rulesObject) => {
		if (dirty) {
			savePageValues(values, insurityPush, false, props, rulesObject);
			runAllRules(props, quoteState, context.navigation, checkNavProducts, updateNav, serviceStatus);
		}
		props.history.push(getPage(props.location.pathname, 'back', context.navigation.navItems));
	};

	const onLocModalSave = async (values, dirty, props) => {
		if (dirty) {
			const updatedQuote = quoteState;
			// account for "duplicate" named fields on this modal and the main quote
			const address = values.addressL;
			const addresses = _.get(updatedQuote, 'addresses', {});
			const id = values.id ? values.id : uuidv4();
			const businessDescription = _.get(values, 'prefillData.verisk.businessDescription');

			if (!addresses[id]) {
				addresses[id] = {};
			}

			// Check to see if the address has changed so we need to call CLUE or Verisk360
			const addressChanged = addresses[id].fullAddress !== address.fullAddress;
			const clueRequired = isBlank(addresses[id]) || addressChanged;

			// Check to see if we need to call roof report
			const roofReportError = _.get(values, 'veriskRoofReport.ErrorMessage', '');
			const roofReportRequired =
				isBlank(addresses[id]) ||
				addresses[id].fullAddress !== address.fullAddress ||
				(!isBlank(roofReportError) && roofReportError !== 'Product not available for the requested property');

			addresses[id] = address;
			const sfgLocations = _.get(updatedQuote, 'sfg.locations', {});

			let newLocation = sfgLocations[id] || {
				order: Object.keys(sfgLocations).length + 1,
			};
			_.merge(newLocation, SfgLocationRules.requiredStructure, values);
			newLocation = _.omit(newLocation, ['id', 'addressL']);

			if (roofReportRequired) {
				handleRoofReport(address, id);
			}

			sfgLocations[id] = { ...newLocation };
			_.set(updatedQuote, 'sfg.locations', sfgLocations);
			_.set(updatedQuote, 'addresses', addresses);
			if (sfgLocations[id].order === 1 && !isBlank(businessDescription)) {
				_.set(updatedQuote, 'businessDescription', businessDescription);
			}

			if (clueRequired) {
				callClue(updatedQuote, ['sfg']);
			}

			const existingBuildings = _.get(updatedQuote, `sfg.locations.${id}.buildings`, {});
			if (addressChanged && !isBlank(existingBuildings)) {
				newAddressVerisk360({ context, quote: updatedQuote, locId: id, existingBuildings, props });
			}

			try {
				updateQuote(updatedQuote, props);
			} catch (err) {
				toast.error('Your quote could not be saved.');
				console.error(err);
			}
		}
	};

	const handleRoofReport = async (locationAddress, locationID, message) => {
		const locations = _.get(quoteState, 'sfg.locations', {});
		if (message) {
			const matchingLocation = _.find(locations, (o) => {
				return _.get(o, 'veriskRoofReport.ProMetrixTaskId', {}) === message.ProMetrixTaskId;
			});
			_.set(matchingLocation, 'veriskRoofReport', message);
			updateQuote({
				...quoteState,
			});
		} else {
			const roofReport = await callRoofReportAPI(sessionID, locationAddress, quoteState, locationID);
			if (locationID) {
				_.set(quoteState, `sfg.locations.${locationID}.veriskRoofReport`, roofReport);
				updateQuote({ ...quoteState });
			}
		}
	};

	const onBldgModalSave = async (values, dirty, props, currentContext) => {
		if (dirty) {
			const buildings = _.get(quoteState, `sfg.locations.${values.locationId}.buildings`, {});

			const { locationId } = values;
			const id = values.id ? values.id : uuidv4();
			if (shouldUpdatePDDeductible({ values, quote: quoteState, bldgId: id })) {
				quoteState.sfg.pdDeductibleType = values.pdDeductibleType;
				quoteState.sfg.pdDeductible = values.pdDeductible;
			}
			if (!isBlank(values.percentSubcontracting)) {
				quoteState.sfg.percentSubcontracting = values.percentSubcontracting;
			}
			values = _.omit(values, ['locationId', 'pdDeductibleType', 'pdDeductible', 'id', 'percentSubcontracting']);
			if (!buildings[id]) {
				buildings[id] = {};
			}
			const newBuilding = buildings[id] || {};
			values.order = newBuilding.order ? newBuilding.order : Object.keys(buildings).length;
			// checkbox items need to be unset
			_.unset(newBuilding, 'additionalInsuredType');
			const cleanValues = _.merge(duplicate(BuildingRules.requiredStructure), values);
			_.merge(newBuilding, cleanValues);
			buildings[id] = { ...newBuilding };

			if (!isBlank(values.buildingLimit)) {
				call360Valuation(currentContext, quoteState, locationId, buildings[id], id, props);
			}

			_.set(quoteState, `sfg.locations.${locationId}.buildings`, buildings);
			cleanAdditionalInterests({ quote: quoteState, propertyId: locationId, bldgId: id });

			try {
				updateQuote(quoteState, props);
			} catch (err) {
				toast.error('Your quote could not be saved.');
				console.error(err);
			}
		}
	};

	const onLossHistoryModalSave = async (values, dirty, product, props, rulesObject) => {
		if (dirty) {
			let fieldStructure = {};
			if (props && props.rulesObject) {
				rulesObject = props.rulesObject;
			}
			if (rulesObject) {
				fieldStructure = mergeFieldStructure(rulesObject, values);
			}

			const id = values.id ? values.id : uuidv4();

			const productLosses = _.get(quoteState, `${product}.losses`, {});
			const productSave = _.get(quoteState, `${product}`, {});
			productSave.productNoLosses = false;
			_.set(quoteState, `${product}`, productSave);
			const newLossHistory = productLosses[id] || {};

			newLossHistory.totalAmountPaid = _.sum([
				Number(_.get(values, 'coverage1AmountPaid', 0)),
				Number(_.get(values, 'coverage2AmountPaid', 0)),
				Number(_.get(values, 'coverage3AmountPaid', 0)),
				Number(_.get(values, 'coverage4AmountPaid', 0)),
				Number(_.get(values, 'coverage6AmountPaid', 0)),
				Number(_.get(values, 'coverage5AmountPaid', 0)),
			]);
			newLossHistory.totalReserveAmount = _.sum([
				Number(_.get(values, 'coverage1ReserveAmount', 0)),
				Number(_.get(values, 'coverage2ReserveAmount', 0)),
				Number(_.get(values, 'coverage3ReserveAmount', 0)),
				Number(_.get(values, 'coverage4ReserveAmount', 0)),
				Number(_.get(values, 'coverage5ReserveAmount', 0)),
				Number(_.get(values, 'coverage6ReserveAmount', 0)),
			]);

			_.merge(newLossHistory, fieldStructure, values);
			productLosses[id] = { ...newLossHistory };
			_.set(quoteState, `${product}.losses`, productLosses);

			try {
				updateQuote(quoteState, props);
			} catch (err) {
				toast.error('Your quote could not be saved.');
				console.error(err);
			}
		}
	};

	const onAdditionalInterestModalSave = async (values, dirty, pushToInsurity, props) => {
		if (dirty) {
			const id = values.id ? values.id : uuidv4();
			const additionalInterests = _.get(quoteState, 'additionalInterests', {});

			const newAdditionalInterest = additionalInterests[id] || {};

			// checkbox items need to be unset
			_.unset(newAdditionalInterest, 'interestBuilding');
			_.unset(newAdditionalInterest, 'interestVehicle');
			_.merge(newAdditionalInterest, values);
			additionalInterests[id] = { ...newAdditionalInterest };
			_.set(quoteState, 'additionalInterests', additionalInterests);

			insurityCall(quoteState, pushToInsurity);

			try {
				updateQuote(quoteState, props);
			} catch (err) {
				toast.error('Your quote could not be saved.');
				console.error(err);
			}
		}
	};

	const onBldQstnModalSave = async (values, dirty, props) => {
		if (dirty) {
			const building = _.get(quoteState, `sfg.locations.${values.locationId}.buildings.${values.id}`);
			building.questions = { ...values.questions };
			try {
				updateQuote(quoteState, props);
			} catch (err) {
				toast.error('Your quote could not be saved.');
				console.error(err);
			}
		}
	};

	const onBldgCovgModalSave = async (values, dirty, props) => {
		if (dirty) {
			const building = _.get(quoteState, `sfg.locations.${values.locationId}.buildings.${values.id}`);
			building.coverages = { ...values.coverages };
			try {
				updateQuote(quoteState, props);
			} catch (err) {
				toast.error('Your quote could not be saved.');
				console.error(err);
			}
		}
	};

	const onLocCovgModalSave = async (values, dirty, props) => {
		if (dirty) {
			const location = _.get(quoteState, `sfg.locations.${values.id}`);
			location.coverages = { ...values.coverages };
			try {
				updateQuote(quoteState, props);
			} catch (err) {
				toast.error('Your quote could not be saved.');
				console.error(err);
			}
		}
	};

	const updateProducts = (product, toggle, props, newQuote, ctx) => {
		const products = getSet(quoteState.products);
		if (toggle) {
			products.add(product);
			_.set(quoteState, `rates.${product}`, 'quoting');

			switch (product) {
				case 'cap':
					runCapReferrals(ctx);
					break;
				case 'wcp':
					runWcpReferrals(ctx);
					break;
				case 'cup':
					runCupReferrals(ctx);
					break;
				default:
			}
		} else {
			products.delete(product);
			_.unset(quoteState, `rates.${product}`);
			removeProductReferrals(quoteState, product);
		}
		_.set(quoteState, 'products', [...products]);

		checkNavProducts(products, props);
		updateQuote(quoteState, props, newQuote);

		if (
			product === 'cup' &&
			_.includes([...products], 'cup') &&
			!isBlank(_.get(quoteState, 'customerNumber', '')) &&
			!_.get(quoteState, 'cup', {}).retrievedUnderlyingPolicies
		) {
			getUnderlyingPolicies(quoteState, updateQuote, props);
		}
	};

	const onWcpClassCodeModalSave = async (values, dirty, pushToInsurity, props, rulesObject) => {
		if (dirty) {
			let fieldStructure = {};
			if (props && props.rulesObject) {
				rulesObject = props.rulesObject;
			}
			if (rulesObject) {
				fieldStructure = mergeFieldStructure(rulesObject, values);
			}

			const id = values.id ? values.id : uuidv4();
			const wcpClassCodes = _.get(quoteState, 'wcp.classCodes', {});
			// delete values.id;
			const newWcpClassCode = wcpClassCodes[id] || {};

			// Check to see if the address has changed so we need to call CLUE
			const clueRequired = newWcpClassCode.location !== values.location;

			// checkbox items need to be unset
			_.unset(newWcpClassCode, 'locations');
			_.merge(newWcpClassCode, fieldStructure, values);
			wcpClassCodes[id] = { ...newWcpClassCode };
			_.set(quoteState, 'wcp.classCodes', wcpClassCodes);

			if (clueRequired) {
				callClue(quoteState, ['wcp']);
			}

			try {
				updateQuote(quoteState, props);
			} catch (err) {
				toast.error('Your quote could not be saved.');
				console.error(err);
			}
		}
	};

	const onDriverModalSave = (values, dirty, props) => {
		if (dirty) {
			const currQuote = quoteState;
			const id = values.id ? values.id : uuidv4();
			delete values.id;
			const drivers = _.get(currQuote, 'cap.drivers', {});

			drivers[id] = { ...values };
			_.set(currQuote, 'cap.drivers', drivers);

			try {
				updateQuote(currQuote, props);
			} catch (err) {
				toast.error('Your quote could not be saved.');
				console.error(err);
			}
		}
	};

	const onVehicleModalSave = async (values, dirty, props) => {
		if (dirty) {
			const currQuote = quoteState;
			const id = values.id ? values.id : uuidv4();
			delete values.id;
			const vehicles = _.get(currQuote, 'cap.vehicles', {});

			if (isBlankZ(_.get(values, 'order', ''))) {
				values.order = Object.keys(vehicles).length;
			}

			vehicles[id] = { ...values };
			_.set(currQuote, 'cap.vehicles', vehicles);

			try {
				updateQuote(currQuote, props);
			} catch (err) {
				toast.error('Your quote could not be saved.');
				console.error(err);
			}
		}
	};
	const onWcpOfficersModalSave = async (values, dirty, props, pushToInsurity) => {
		if (dirty) {
			const currQuote = quoteState;
			const id = values.id ? values.id : uuidv4();
			delete values.id;
			const officers = _.get(currQuote, 'wcp.officers', {});

			values.order = values.order ? values.order : Object.keys(officers).length + 1;
			officers[id] = { ...values };
			_.set(currQuote, 'wcp.officers', officers);

			insurityCall(currQuote, pushToInsurity);

			try {
				updateQuote(currQuote, props);
			} catch (err) {
				toast.error('Your quote could not be saved.');
				console.error(err);
			}
		}
	};

	return (
		<QuoteContext.Provider
			value={{
				...context,
				quote: quoteState,
				sessionID,
				rate: rateState,
				serviceStatus: statusTracker,
				quoteStatus: quoteStatusState,
				optionModal,
				entryModal,
				confirmModal,
				updateRate,
				updateQuote,
				updateQuoteState,
				updateServiceStatus,
				updateQuoteStatus,
				resetQuote,
				resetRating,
				updateNav,
				updateProducts,
				checkNavProducts,
				navigation: navState,
				onSubmit,
				savePageValues,
				onBack,
				handleRoofReport,
				onModalSubmit: onLocModalSave,
				onLocCovgModalSubmit: onLocCovgModalSave,
				onBldgModalSubmit: onBldgModalSave,
				onLossHistoryModalSubmit: onLossHistoryModalSave,
				onBldgCovgModalSubmit: onBldgCovgModalSave,
				onBldQstnModalSubmit: onBldQstnModalSave,
				onAdditionalInterestModalSubmit: onAdditionalInterestModalSave,
				onWcpClassCodeModalSubmit: onWcpClassCodeModalSave,
				onDriverModalSubmit: onDriverModalSave,
				onVehicleModalSubmit: onVehicleModalSave,
				onWcpOfficersModalSubmit: onWcpOfficersModalSave,
			}}
		>
			<OptionModal ref={optionModal} />
			<EntryModal ref={entryModal} />
			<ConfirmModal ref={confirmModal} />
			{prop.children}
		</QuoteContext.Provider>
	);
};

export default GlobalState;
