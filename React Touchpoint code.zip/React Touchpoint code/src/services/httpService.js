import axios from 'axios';
import _ from 'lodash';
import { toast } from 'react-toastify';
import logger from 'services/logService';
import { pageEvent } from 'utils/ScreenFunctions';
import { getCognitoToken } from '@columbiainsurance/functions-js';

axios.interceptors.request.use(
	function (config) {
		config.metadata = { startTime: new Date() };
		sessionStorage.removeItem('TPSystemError');
		console.groupCollapsed('HTTP Service');
		console.info('config.url', config.url);

		if (config.url.indexOf('?') >= 0) {
			config.url = config.url + '&ts=' + Date.now();
		} else {
			config.url = config.url + '?ts=' + Date.now();
		}

		// ! EACH AWS ENDPOINT WILL NEED TO BE IN THIS CONDITION ! //
		if (config.url.toLowerCase().indexOf(process.env.REACT_APP_AWS_API_DOMAIN) >= 0) {
			let authorizationToken = '';
			let apiKey = '';

			if (
				config.url.indexOf(process.env.REACT_APP_ADDRESS_VALIDATION) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_ADDRESS_PARSE) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_S3_SAVE) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_S3_GET) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_S3_DELETE) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_DATACUBES_COMPANY_ID) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_DATACUBES_PROPERTY_INFO) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_EMAIL_PATH) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_GEOCODE) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_KENTUCKY_TAX) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_NUMBER_GENERATOR) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_MERGEPDF) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_VERISK_UNIQUE_ID) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_VERISK_PROPERTY_INFO) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_RULES_URL) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_CAP_COMPANY_PLACEMENT_URL) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_NCCI_ORDER_INFO) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_VERISK_360_VALUATION_XML) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_VERISK_360_VALUATION_PDF) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_VERISK_ROOF_REPORT) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_LOGGER) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_VALIDATE_ACCOUNT_ROUTING_NUMBER) >= 0
			) {
				authorizationToken = sessionStorage.getItem('authorizationToken');
				getCognitoToken(authorizationToken, sessionStorage.getItem('authorizationRefresh'))
					.then((cognitoToken) => {
						if (authorizationToken !== cognitoToken) {
							authorizationToken = cognitoToken;
							sessionStorage.setItem('authorizationToken', cognitoToken);
						}
					})
					.catch((err) => {
						console.error('Error getCognitoToken', err);
					});
			} else {
				authorizationToken = sessionStorage.getItem('cigToken');
			}

			if (
				config.url.indexOf(process.env.REACT_APP_VERISK_UNIQUE_ID) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_VERISK_PROPERTY_INFO) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_VERISK_360_VALUATION_XML) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_VERISK_360_VALUATION_PDF) >= 0 ||
				config.url.indexOf(process.env.REACT_APP_VERISK_ROOF_REPORT) >= 0
			) {
				apiKey = process.env.REACT_APP_VERISK_API_KEY;
			} else if (config.url.indexOf(process.env.REACT_APP_NCCI_ORDER_INFO) >= 0) {
				apiKey = process.env.REACT_APP_NCCI_API_KEY;
			}

			config.headers = {
				Authorization: authorizationToken,
				'x-api-key': apiKey,
			};
		}

		console.groupEnd('HTTP Service');

		return config;
	},
	function (err) {
		return Promise.reject(err);
	},
);

axios.interceptors.response.use(
	(response) => {
		if (response.status && response.status >= 400) {
			console.info('Error response', response);
		}

		pageEvent(
			'APICall',
			response.config.url.split('?')[0].split('/').slice(0, 6).join('/'),
			new Date() - response.config.metadata.startTime,
		);

		return response;
	},
	(error) => {
		const clientError = error.response && error.response.status >= 400 && error.response.status < 500;

		if (!clientError) {
			logger.log(error);
			toast.error('An unexpected error occurred!');
			console.info('error1' + error);

			sessionStorage.setItem('TPSystemError', _.get(error, 'response.data.errors', error));
			//alert('error1 ' + error);
		} else if (error.response) {
			console.info('error2', error);
			//alert('error2 ' + error);
			if (error.response.status === 403) {
				return (window.location.href = '/accessdenied');
			}
		}
		if (error.config) {
			pageEvent(
				'APICall',
				error.config.url.split('?')[0].split('/').slice(0, 6).join('/'),
				error.config.metadata.endTime - error.config.metadata.startTime,
			);
		}

		return Promise.reject(error);
	},
);

export default {
	get: axios.get,
	post: axios.post,
	put: axios.put,
	delete: axios.delete,
};
