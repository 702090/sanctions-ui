import { toast } from 'react-toastify';
import http from 'services/httpService';

export async function validateAddress(addressData) {
	try {
		const { data: validatedAddress } = await http.post(`${process.env.REACT_APP_ADDRESS_VALIDATION}`, addressData);
		return validatedAddress;
	} catch (e) {
		toast.error('Could not validate Address');
		console.error('error', e);
		return {};
	}
}

export async function parseAddress(addressData) {
	try {
		const { data: parsedAddress } = await http.post(`${process.env.REACT_APP_ADDRESS_PARSE}`, { address: addressData });
		return parsedAddress;
	} catch (e) {
		toast.error('Could not validate Address');
		console.error('error', e);
		return {};
	}
}

export async function geocodeAddress(addressData) {
	try {
		const { data: geocodedAddress } = await http.post(`${process.env.REACT_APP_GEOCODE}`, addressData);

		return geocodedAddress;
	} catch (e) {
		toast.error('Could not geocode Address');
		console.error('error', e);
		return {};
	}
}

export async function getkentuckyTax(addressData) {
	try {
		const { data: kentuckyTax } = await http.post(`${process.env.REACT_APP_KENTUCKY_TAX}`, addressData);

		return kentuckyTax;
	} catch (e) {
		toast.error('Could not geocode Address');
		console.error('error', e);
		return {};
	}
}
