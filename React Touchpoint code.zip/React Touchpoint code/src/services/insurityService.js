import { parseJwt } from '@columbiainsurance/functions-js';
import _ from 'lodash';
import { toast } from 'react-toastify';
import http from 'services/httpService';
import { isEmployee } from 'utils/BusinessFunctions';
import { isBlank } from 'utils/StringFunctions';

const getBaseUrlParameters = () => {
	const agent = parseJwt(sessionStorage.getItem('agentToken'));
	return `auth=${sessionStorage.getItem('cigToken')}&env=${process.env.REACT_APP_ENVIRONMENT_NAME}&logLevel=${
		process.env.REACT_APP_LOG_LEVEL
	}&user=${agent.userId}`;
};

/**
 *
 * @param {string} city
 * @param {string} state 2 letter abreviation
 * @param {number} zip 5 digit zip
 * @param {number} effectiveDate Date in milliseconds
 * @return JSON object of Protection Class Codes
 */
export async function getProtectionClassCodes(city, state, zip, effectiveDate) {
	try {
		if (city && state && zip && effectiveDate) {
			const baseUrlParams = getBaseUrlParameters();
			const { data: protectionClassCodes } = await http.get(
				`${process.env.REACT_APP_PROTECTION_CLASS_LOOKUP}?city=${city}&state=${state}&zip=${zip}&effdte=${effectiveDate}&${baseUrlParams}`,
			);
			return protectionClassCodes;
		}
		return [];
	} catch (e) {
		toast.error(`Could not retrieve protection classes for ${city}, ${state} ${zip}`);
		return [];
	}
}

/**
 *
 * @param {string} city
 * @param {string} state 2 letter abreviation
 * @param {number} zip 5 digit zip
 * @param {string} county Date in milliseconds
 * @param {number} effectiveDate Date in milliseconds
 * @return JSON object of Protection Class Codes
 */
export async function getCounties(city, state, zip, county, effectiveDate) {
	try {
		if (city && state && zip && effectiveDate) {
			const baseUrlParams = getBaseUrlParameters();
			const { data: counties } = await http.get(
				`${process.env.REACT_APP_COUNTY_LOOKUP}?city=${city}&state=${state}&zip=${zip}&county=${county}&effdte=${effectiveDate}&${baseUrlParams}`,
			);
			return counties;
		}
		return [];
	} catch (e) {
		toast.error(
			`Could not retrieve county for ${city}, ${state} ${zip} ${county}&auth=${sessionStorage.getItem('cigToken')}`,
		);
		return [];
	}
}

export async function rateQuote(quoteData) {
	try {
		// TODO: add logic to only send the specific product
		const baseUrlParams = getBaseUrlParameters();
		const { data: returnRate } = await http.post(`${process.env.REACT_APP_RATE_CALL}?${baseUrlParams}`, quoteData);

		return returnRate;
	} catch (e) {
		toast.error('Could not rate quote');
		console.error('error', e);
		return {};
	}
}

export async function insurityCall(quoteData, type) {
	let endpoint;
	let emptyReturn = {};
	switch (type) {
		case 'contact':
			endpoint = process.env.REACT_APP_CONTACT_TRANSFER;
			break;
		case 'interest':
			endpoint = process.env.REACT_APP_ADDITIONAL_INTEREST_TRANSFER;
			break;
		case 'officers':
			endpoint = process.env.REACT_APP_OFFICERS_TRANSFER;
			break;
		case 'customerNumber':
			endpoint = process.env.REACT_APP_CUSTOMER_NUMBER_LOOKUP;
			emptyReturn = [];
			break;
		default:
	}
	if (!isBlank(endpoint)) {
		try {
			const baseUrlParams = getBaseUrlParameters();
			const { data: returnRate } = await http.post(`${endpoint}?${baseUrlParams}`, quoteData);

			return returnRate;
		} catch (e) {
			toast.error(`Could not transfer ${type}`);
			console.error('error', e);
			return emptyReturn;
		}
	}
}

export function insurityProposal(quote, product) {
	const proposalRequest = {
		agent: quote.agentSubpro,
		sfgSan: !product || product === 'sfg' ? quote.sfg.san : '',
		capSan: _.includes(quote.products, 'cap') && (!product || product === 'cap') ? quote.cap.san : '',
		wcpSan: _.includes(quote.products, 'wcp') && (!product || product === 'wcp') ? quote.wcp.san : '',
		cupSan: _.includes(quote.products, 'cup') && (!product || product === 'cup') ? quote.cup.san : '',
		quoteNumber: quote.quoteNumber,
		isEmployee: isEmployee(),
	};
	try {
		const baseUrlParams = getBaseUrlParameters();
		return http.post(`${process.env.REACT_APP_INSURITY_PROPOSAL}?${baseUrlParams}`, proposalRequest);
	} catch (e) {
		toast.error('An error has occurred generating proposal.');
		console.error('error', e);
		return {
			insurityMessages: [{ message: 'An error has occurred generating proposal.' }],
		};
	}
}

export function getUnderlyingPolicies(underlyingRequest) {
	try {
		const baseUrlParams = getBaseUrlParameters();
		return http.post(`${process.env.REACT_APP_UNDERLYING_POLICY_LOOKUP}?${baseUrlParams}`, underlyingRequest);
	} catch (e) {
		toast.error('An error has occurred retrieving underlying policies.');
		console.error('error', e);
		return {
			insurityMessages: [{ message: 'An error has occurred retrieving underlying policies.' }],
		};
	}
}

export async function sendFillinForms(quote, product) {
	const baseUrlParams = getBaseUrlParameters();
	try {
		return http.post(`${process.env.REACT_APP_FILLIN_FORM_TRANSFER}?${baseUrlParams}`, { product, quote });
	} catch (error) {
		console.error('error', error);
		return {
			insurityMessages: [{ message: 'An error has occurred sending additional fillin form information.' }],
		};
	}
}
