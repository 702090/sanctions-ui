import http from 'services/httpService';

export async function isAccountValid(accountNumber) {
	const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));

	const accountValidRequest = {
		acctno: accountNumber,
		agent: agent.number,
		subpro: agent.subpro,
	};

	const { data: isAcountValid } = await http.post(
		`${process.env.REACT_APP_ACCOUNT_VERIFY}?auth=${sessionStorage.getItem('cigToken')}`,
		accountValidRequest,
	);

	return isAcountValid.validAccount;
}
