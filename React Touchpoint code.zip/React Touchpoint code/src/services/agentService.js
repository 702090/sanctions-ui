import http from 'services/httpService';

const touchpointEndpoint = process.env.REACT_APP_AGENT_LOOKUP;

export async function getAgentToken(agentSubpro, loginUser) {
	const { data: agentToken } = await http.get(
		`${touchpointEndpoint}?agentSubpro=${agentSubpro}&loginUser=${loginUser}&auth=${sessionStorage.getItem(
			'cigToken',
		)}`,
	);
	return agentToken;
}
