import _ from 'lodash';
import { toast } from 'react-toastify';
import http from 'services/httpService';
import { saveQuote } from 'services/quoteService';
import { distillLocations, getFullInsuredName } from 'utils/BusinessFunctions';
import { isBlank } from 'utils/StringFunctions';

function addressAlreadyAdded(addressList, addressData) {
	let addressExists = false;

	_.forIn(addressList, (address) => {
		if (
			address.city === addressData.city &&
			address.state === addressData.state &&
			address.streetName === addressData.streetName &&
			address.streetNumber === addressData.streetNumber &&
			address.unit === addressData.unit &&
			address.zip === addressData.zip
		) {
			addressExists = true;
		}
	});

	return addressExists;
}

function deleteLossData(quote, product) {
	// remove all losses that are from LexisNexis
	const manualLosses = _.pickBy(_.get(quote, `${product}.losses`, {}), (loss) => loss.fromLexisNexis !== true);
	const lexisNexisLosses = _.pickBy(_.get(quote, `${product}.losses`, {}), (loss) => loss.fromLexisNexis === true);

	if (isBlank(manualLosses)) {
		_.unset(quote, `${product}.losses`);
		if (isBlank(_.get(quote, `${product}.noLosses`)) && !isBlank(lexisNexisLosses)) {
			_.set(quote, `${product}.noLosses`, true);
		}
	} else {
		_.set(quote, `${product}.losses`, manualLosses);
	}
	// remove all LossMessages
	_.unset(quote, `${product}.lossMessages`);
}

function buildLossRequest(quote, product) {
	let lossRequest = {};

	deleteLossData(quote, product);

	switch (product) {
		case 'sfg':
			lossRequest.sfg = {
				company: '02',
				policyNumber: `BPPQT${`000000000${quote.quoteNumber}`.slice(-10)}`,
				addressData: [],
			};
			break;
		case 'cap':
			lossRequest.cap = {
				company: '02',
				policyNumber: `CAPQT${`000000000${quote.quoteNumber}`.slice(-10)}`,
				mailingAddress: {},
				addressData: [],
				driverData: [],
			};
			break;
		case 'cup':
			lossRequest.cup = {
				company: '09',
				policyNumber: `CUPQT${`000000000${quote.quoteNumber}`.slice(-10)}`,
				addressData: [],
			};
			break;
		case 'wcp':
			lossRequest.wcp = {
				company: '02',
				policyNumber: `WCPQT${`000000000${quote.quoteNumber}`.slice(-10)}`,
				addressData: [],
			};
			break;
		default:
			break;
	}

	const distilledLocations = distillLocations(quote);

	// loop over address and apply them to each applicable product
	_.forIn(quote.addresses, (address, id) => {
		const addressData = {
			zip: address.zip,
			streetName: address.streetName,
			streetNumber: address.streetNumber,
			city: address.city,
			state: address.state,
			unit: address.unit || '',
		};
		// Update to only set the one product we want CLUE on
		if (id === '1') {
			_.get(lossRequest, 'sfg.addressData', []).push(addressData);
			if (product === 'cap') {
				_.set(lossRequest, 'cap.mailingAddress', addressData);
				_.get(lossRequest, 'cap.addressData', []).push(addressData);
			}
			_.get(lossRequest, 'cup.addressData', []).push(addressData);
			_.get(lossRequest, 'wcp.addressData', []).push(addressData);
		}

		/* SFG */
		if (_.get(quote, `sfg.locations.${id}`, false)) {
			if (!addressAlreadyAdded(_.get(lossRequest, 'sfg.addressData', []), addressData)) {
				_.get(lossRequest, 'sfg.addressData', []).push(addressData);
			}
		}

		/* CAP */
		if (product === 'cap') {
			if (_.get(quote, 'cap.registrationAddress', '') === id) {
				if (!addressAlreadyAdded(_.get(lossRequest, 'cap.addressData', []), addressData)) {
					_.get(lossRequest, 'cap.addressData', []).push(addressData);
				}
			}
			distilledLocations.capStates.forEach((state) => {
				if (_.get(quote, `cap.coverages.${state}.address`, '') === id) {
					if (!addressAlreadyAdded(_.get(lossRequest, 'cap.addressData', []), addressData)) {
						_.get(lossRequest, 'cap.addressData', []).push(addressData);
					}
				}
			});

			_.forIn(quote.cap.drivers, (driver) => {
				const driverData = {
					firstName: _.get(driver, 'name.first', ''),
					lastName: _.get(driver, 'name.last', ''),
					birthDate: _.get(driver, 'birthDate', ''),
					licenseState: _.get(driver, 'licenseState', ''),
					licenseNumber: _.get(driver, 'licenseNumber', ''),
				};

				if (
					_.findIndex(_.get(lossRequest, 'cap.driverData', []), (o) => {
						return o.driver.licenseNumber == driverData.licenseNumber;
					}) < 0
				) {
					_.get(lossRequest, 'cap.driverData', []).push({ driver: driverData });
				}
			});
		}

		/* CUP */
		//TODO: UPDATE WITH CUP LOCATIONS
		if (_.get(quote, `cup.locations.${id}`, false)) {
			if (!addressAlreadyAdded(_.get(lossRequest, 'cup.addressData', []), addressData)) {
				_.get(lossRequest, 'cup.addressData', []).push(addressData);
			}
		}

		/* WCP */
		distilledLocations.wcpLocations.forEach((locationId) => {
			if (locationId === id) {
				if (!addressAlreadyAdded(_.get(lossRequest, 'wcp.addressData', []), addressData)) {
					_.get(lossRequest, 'wcp.addressData', []).push(addressData);
				}
			}
		});
	});

	return lossRequest;
}
/**
 * @param  {object} quote
 * @param  {String[]} products
 */
async function callClue(quote, products) {
	if (products && products.length > 0) {
		const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));

		// Change product variables to only have one product
		let lossRequest = {
			branch: agent.branch,
			businessName: getFullInsuredName(quote),
			dba: _.get(quote, 'insuredName.dba', ''),
			effectiveDate: quote.effectiveDate.replace(new RegExp('-', 'g'), ''),
		};

		_.forEach(products, (prod) => {
			// build lossRequest for each product
			_.merge(lossRequest, buildLossRequest(quote, prod));
		});

		try {
			const { data: returnLosses } = await http.post(
				`${process.env.REACT_APP_CLUE_CALL}?auth=${sessionStorage.getItem('cigToken')}`,
				lossRequest,
			);

			_.mergeWith(quote, returnLosses, (objValue, srcValue) => {
				if (!isBlank(srcValue)) {
					return _.merge(objValue, srcValue);
				}
			});

			await saveQuote(quote);
		} catch (error) {
			toast.error('Could not get retrieve claim data from CLUE.');
			console.error('Error calling clue.', error);
		}
	}
}

export default callClue;
