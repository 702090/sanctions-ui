import _ from 'lodash';
import http from 'services/httpService';
import { displayQuoteNumber, getFullInsuredName, isEmployee } from 'utils/BusinessFunctions';

const getRequest = (quote) => {
	const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));

	let routingNumber = '';
	let bankAccountNumber = '';
	let checkingSavings = '';

	if (_.get(quote, 'billing.bankAccountSame', '') === 'Y') {
		routingNumber = _.get(quote, 'billing.bankRoutingNumber', '');
		bankAccountNumber = _.get(quote, 'billing.bankAccountNumber', '');
		checkingSavings = _.get(quote, 'billing.bankAccountType', '');
	} else {
		routingNumber = _.get(quote, 'billing.downPayment.routingNumber', '');
		bankAccountNumber = _.get(quote, 'billing.downPayment.accountNumber', '');
		checkingSavings = _.get(quote, 'billing.downPayment.bankAccountType', '');
	}

	const cardRequest = {
		userName: agent.userId,
		userType: isEmployee() ? 'Employee' : 'Agent',
		agent: agent.number,
		subpro: agent.subpro,
		insuredName: getFullInsuredName(quote),
		sourceApp: 'TP',
		routingNumber: routingNumber,
		accountNumber: bankAccountNumber,
		checkingSavings: checkingSavings,
		payments: {
			SFG: {
				quoteNumber: displayQuoteNumber(quote, 'BPP'),
				downPayment: _.get(quote, 'billing.sfgDownPaymentAmount', 0),
			},
			CAP: {
				quoteNumber: displayQuoteNumber(quote, 'CAP'),
				downPayment: _.get(quote, 'billing.capDownPaymentAmount', 0),
			},
			WCP: {
				quoteNumber: displayQuoteNumber(quote, 'WCP'),
				downPayment: _.get(quote, 'billing.wcpDownPaymentAmount', 0),
			},
			CUP: {
				quoteNumber: displayQuoteNumber(quote, 'CUP'),
				downPayment: _.get(quote, 'billing.cupDownPaymentAmount', 0),
			},
		},
	};
	return cardRequest;
};

const getCashSlipReturn = (slipInfo) => {
	const cashSlip = {
		status: slipInfo.status || slipInfo.paymentStatus,
		sfgSlipNumber: _.get(slipInfo, 'payments.sfg.cashSlip', ''),
		sfgDownPayment: _.get(slipInfo, 'payments.sfg.downPayment', ''),
		capSlipNumber: _.get(slipInfo, 'payments.cap.cashSlip', ''),
		capDownPayment: _.get(slipInfo, 'payments.cap.downPayment', ''),
		wcpSlipNumber: _.get(slipInfo, 'payments.wcp.cashSlip', ''),
		wcpDownPayment: _.get(slipInfo, 'payments.wcp.downPayment', ''),
		cupSlipNumber: _.get(slipInfo, 'payments.cup.cashSlip', ''),
		cupDownPayment: _.get(slipInfo, 'payments.cup.downPayment', ''),
		paymentType: slipInfo.paymentTender,
		bankMessage: slipInfo.bankMessage,
	};

	return cashSlip;
};

export async function downpaymentCheck(quote) {
	const request = getRequest(quote);

	const { data: slipInfo } = await http.post(
		`${process.env.REACT_APP_CHECK_DOWNPAYMENT}?auth=${sessionStorage.getItem('cigToken')}`,
		request,
	);

	const cashSlip = getCashSlipReturn(slipInfo);

	return cashSlip;
}

export async function downpaymentCard(quote) {
	const request = getRequest(quote);

	const { data: cardUrl } = await http.post(
		`${process.env.REACT_APP_CARD_DOWNPAYMENT}?auth=${sessionStorage.getItem('cigToken')}`,
		request,
	);

	return cardUrl;
}

export async function downpaymentStatus(quote) {
	const request = getRequest(quote);
	const { data: slipInfo } = await http.post(
		`${process.env.REACT_APP_DOWNPAYMENT_STATUS}?auth=${sessionStorage.getItem('cigToken')}`,
		request,
	);

	const cashSlip = getCashSlipReturn(slipInfo);

	return cashSlip;
}

export async function cashSlipStatus(referenceNo) {
	const request = { referenceNo: referenceNo };

	const { data: slipInfo } = await http.post(
		`${process.env.REACT_APP_CASH_SLIP_STATUS}?auth=${sessionStorage.getItem('cigToken')}`,
		request,
	);

	const cashSlip = getCashSlipReturn(slipInfo);

	return cashSlip;
}

export async function validateBankAccountRoutingNumber(payload) {
	try {
		const { data } = await http.post(
			`${process.env.REACT_APP_VALIDATE_ACCOUNT_ROUTING_NUMBER}?auth=${sessionStorage.getItem('cigToken')}`,
			payload,
		);
		return data;
	} catch (err) {
		console.error('validifi error', err);
		// if invalid parameters were sent, we want to stop submission
		if (err.response.status === 400) {
			const returnJSON = { valid: false, ...err.response.data.errors[0] };
			if (returnJSON.message.toLowerCase().includes('routing')) {
				returnJSON.routingNumber = returnJSON.message;
			}
			if (returnJSON.message.toLowerCase().includes('bank')) {
				returnJSON.bankAccount = returnJSON.message;
			}
			return returnJSON;
		}
		// if it blows up on WINS or validifi, don't want to stop payment
		return { valid: true };
	}
}
