import { quoteToArrays } from '@columbiainsurance/json-js';
import _ from 'lodash';
import http from 'services/httpService';
import { ReferralList } from 'sidebar/Referrals';
import { duplicate, removeEmpty } from 'utils/ObjectFunctions';

const config = {
	lossMessages: [],
	classCodes: [],
	locations: [],
	buildings: [],
	addresses: [],
	vehicles: [],
	coverages: ['sfg', 'sfg.locations', 'sfg.locations.buildings', 'cap'],
	drivers: [],
	reviews: [],
	losses: [],
	referrals: [],
	officers: [],
	employeesByLocation: [],
};
const defaultArrays = {
	currentCoverages: [],
	deletedCoverages: [],
	products: [],
};

export async function allowSTP(quote) {
	let quoteCopy = duplicate(quote);
	_.unset(quoteCopy, 'transactionData');
	_.unset(quoteCopy, 'billing');

	quoteCopy.referrals = ReferralList({ quote: quoteCopy });

	const touchPointQuote = JSON.stringify(quoteToArrays(JSON.stringify(removeEmpty(quoteCopy)), config, defaultArrays));

	const request = {
		TouchPointPolicy: touchPointQuote,
	};

	const { data: result } = await http.post(`${process.env.REACT_APP_RULES_URL}`, request);

	let blockSTP = false;
	let messages;

	if (_.get(result, 'Error') || _.get(result, 'Done', '') === '') {
		blockSTP = true;

		let errorMessage = _.get(result, 'Error.Error', '');

		if (errorMessage === '') {
			errorMessage = result;
		}

		// Complete the body of the email
		const emailBody = `<div style="font-family: Arial">An error occured running rules.<br/><br/>
    <table>
      <tr>
        <td td width="150"><b>Environment:</b></td>
        <td>${process.env.REACT_APP_ENVIRONMENT_NAME}</td>
      </tr>
      <tr>
        <td><b>Agent Subpro:</b></td>
        <td>${quote.agentSubpro}</td>
      </tr>
      <tr>
        <td><b>Quote ID:</b></td>
        <td>${quote.id}</td>
      </tr>
      <tr>
        <td><b>Reference Number:</b></td>
        <td>${quote.quoteNumber}</td>
      </tr>
      <tr>
        <td><b>Error:</b></td>
        <td>${errorMessage}</td>
			</tr>
			<tr>
				<td><b>JSON:</b></td>
				<td>${touchPointQuote}</td>
			</tr>
    </table></div>`;

		const email = {
			to: 'webdev@colinsgrp.com',
			subject: `TouchPoint rules engine error ${process.env.REACT_APP_ENVIRONMENT_NAME}`,
			message: emailBody,
		};

		http.post(process.env.REACT_APP_EMAIL_PATH, email);
	} else {
		messages = _.compact(result.Done.Results);

		_.forEach(messages, (message) => {
			if (message.block > 0) {
				blockSTP = true;
			}
		});
	}

	const ruleResult = { blockSTP, messages };

	return ruleResult;
}

export async function capCompanyPlacement(quote) {
	let quoteCopy = duplicate(quote);
	// We don't need these fields so we're removing them
	_.unset(quoteCopy, 'billing');
	_.unset(quoteCopy, 'referrals');
	_.unset(quoteCopy, 'rates.product.sfg');
	_.unset(quoteCopy, 'rates.product.wcp');
	_.unset(quoteCopy, 'rates.product.cup');

	// This is to prevent Decisions from erroring if the quote hasn't been rated yet
	if (_.includes(quote.products, 'cap') && _.isString(_.get(quoteCopy, 'rates.product.cap', ''))) {
		quoteCopy.rates.cap = 0;
	}

	const touchPointQuote = JSON.stringify(quoteToArrays(JSON.stringify(removeEmpty(quoteCopy)), config, defaultArrays));

	const request = {
		TouchPointPolicy: touchPointQuote,
	};

	const { data: result } = await http.post(`${process.env.REACT_APP_CAP_COMPANY_PLACEMENT_URL}`, request);

	return result;
}
