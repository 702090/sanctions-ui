import { isBlank, parseJwt } from '@columbiainsurance/functions-js';
import _ from 'lodash';
import http from 'services/httpService';
import { ReferralList } from 'sidebar/Referrals';

export async function insertArchiveRecord(quote) {
	const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));
	const referrals = ReferralList({ quote });

	const useAppUnderwriter = (quote.sfg?.cigPriorCarrier ?? 'N') === 'Y';

	const archiveRequest = {
		quoteId: quote.id,
		agentSubpro: quote.agentSubpro,
		agencyName: agent.name,
		branch: agent.branch,
		underwriterEmail:
			useAppUnderwriter || isBlank(agent.appUnderwriterEmail) ? agent.underwriterEmail : agent.appUnderwriterEmail,
		underwriterNumber:
			useAppUnderwriter || isBlank(agent.appUnderwriterNumber) ? agent.underwriterNumber : agent.appUnderwriterNumber,
		referrals,
		territoryManagerNumber: agent.territoryManagerNumber,
	};

	http.post(
		`${process.env.REACT_APP_INSERT_ARCHIVE_RECORD}&auth=${sessionStorage.getItem('cigToken')}&user=${agent.userId}`,
		archiveRequest,
	);
}

export async function getNewPolicyNumber() {
	const { data: returnData } = await http.post(
		`${process.env.REACT_APP_POLICYNUMBER_GENERATOR}?auth=${sessionStorage.getItem('cigToken')}`,
	);

	return returnData;
}

export async function getNewAccountBillNumber(quoteData) {
	const { data: returnData } = await http.post(
		`${process.env.REACT_APP_ACCOUNT_BILL_NUMBER}?auth=${sessionStorage.getItem('cigToken')}`,
		quoteData,
	);
	return returnData;
}

export async function mvrRecord(san) {
	return callEndpoint('REACT_APP_MVR_REPORT', { san });
}

export async function convertPolicy(san, environment, quoteNumber, logLevel) {
	return callEndpoint('REACT_APP_CONVERT_POLICY', { san, environment, quoteNumber, logLevel });
}

export async function bindPolicy(bindingData) {
	const { data } = await callEndpoint('REACT_APP_INSURITY_BIND', bindingData);
	return data;
}

export async function newbindPolicy(agent, quote, product, san, environment, quoteNumber, logLevel) {
	return callEndpoint('REACT_APP_INSURITY_BIND', {
		agent,
		quote,
		product,
		san,
		environment,
		quoteNumber,
		logLevel,
	});
}

export async function issuePolicy(san, environment, quoteNumber, logLevel) {
	return callEndpoint('REACT_APP_ISSUE_POLICY', { san, environment, quoteNumber, logLevel });
}

export async function loadWFile(san) {
	return callEndpoint('REACT_APP_LOAD_W_FILE', { san }).then((result) => {
		const messages = _.get(result, 'data.insurityMessages', []);
		if (messages.length > 0) {
			return Promise.reject({ message: messages[0].message });
		} else {
			return Promise.resolve(result);
		}
	});
}

export async function runWinsEdits(fullPolicyNumber, effectiveDate) {
	return callEndpoint('REACT_APP_RUN_WINS_EDITS', {
		fullPolicyNumber,
		effectiveDate,
	}).then((result) => {
		if (_.get(result, 'data.passed', true)) {
			return Promise.resolve(result);
		} else {
			return Promise.reject({ message: 'WINS Edits failed.' });
		}
	});
}

export async function getWriteStpToWINS(fullPolicyNumber, effectiveDate) {
	return callEndpoint('REACT_APP_INSERT_STP_RECORD', {
		fullPolicyNumber,
		effectiveDate,
	});
}

export async function getPolicyDec(fullPolicyNumber, documentUid, quoteNumber) {
	return callEndpoint('REACT_APP_GET_POLICY_DEC', {
		fullPolicyNumber,
		documentUid,
		quoteNumber,
		environment: process.env.REACT_APP_ENVIRONMENT_NAME,
		logLevel: process.env.REACT_APP_LOG_LEVEL,
	});
}

export async function savePolicyDec(fileName, fileData) {
	return callEndpoint('REACT_APP_S3_SAVE', {
		s3Bucket: process.env.REACT_APP_STP_DOCUMENT_BUCKET,
		fileName,
		fileData,
		mimeType: 'application/pdf',
	});
}

export async function callEndpoint(endpoint, payload) {
	const agent = parseJwt(sessionStorage.getItem('agentToken'));
	return http
		.post(`${process.env[endpoint]}?auth=${sessionStorage.getItem('cigToken')}&user=${agent.userId}`, payload)
		.then((result) => {
			if (result.data.errors) {
				return Promise.reject({ message: result.data.errors });
			} else {
				return Promise.resolve(result.data);
			}
		});
}
