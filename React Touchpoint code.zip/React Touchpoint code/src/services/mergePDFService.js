import http from 'services/httpService';

export async function mergePDFs(pdfs) {
	const pdfEndpoint = process.env.REACT_APP_MERGEPDF;
	const postData = {
		pdfs: pdfs,
	};
	try {
		return await http.post(pdfEndpoint, postData);
	} catch (e) {
		console.error('Error in mergePDF', e);
		return {};
	}
}
