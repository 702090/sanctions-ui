import { toast } from 'react-toastify';
import http from 'services/httpService';

export async function saveAttachment(attachmentData) {
	try {
		const { data: result } = await http.post(`${process.env.REACT_APP_S3_SAVE}`, attachmentData);
		return result;
	} catch (e) {
		toast.error('Could not upload file');
		console.error('error', e);
		return {};
	}
}

export async function getAttachment(attachmentData) {
	try {
		const { data: result } = await http.get(
			`${process.env.REACT_APP_S3_GET}/${attachmentData.s3Bucket}/${attachmentData.fileName}`,
		);

		return result;
	} catch (e) {
		toast.error('Could not get file');
		console.error('error', e);
		return {};
	}
}
export async function deleteAttachment(attachmentData) {
	try {
		const { data: result } = await http.delete(
			`${process.env.REACT_APP_S3_DELETE}/${attachmentData.s3Bucket}/${attachmentData.fileName}`,
		);

		return result;
	} catch (e) {
		toast.error('Could not upload attachment');
		console.error('error', e);
		return {};
	}
}
