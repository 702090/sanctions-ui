import _ from 'lodash';
import http from 'services/httpService';
import { isBlank } from 'utils/StringFunctions';
import { v4 as uuidv4 } from 'uuid';

const touchpointEndpoint = process.env.REACT_APP_API_PATH;
const numberGeneratorEndpoint = process.env.REACT_APP_NUMBER_GENERATOR;

export async function getQuoteList(options) {
	const { agentToken, segmentIndex, segmentTotal } = options;

	const segmentParameters =
		segmentIndex !== undefined && segmentTotal ? `&segment=${segmentIndex}&segmentTotal=${segmentTotal}` : '';
	// const { data: quotes } =
	return http.get(`${touchpointEndpoint}?agentSubpro=${agentToken.agentSubpro}${segmentParameters}`);
}

export async function getQuote(agentSubpro, id) {
	const { data: quote } = await http.get(`${touchpointEndpoint}/${agentSubpro}/${id}`);
	return quote;
}

export async function saveQuote(quote) {
	if (!quote.quoteNumber) {
		const data = await http.get(`${numberGeneratorEndpoint}/TPS`);
		quote.quoteNumber = _.get(data, 'data.item.number');
	}
	if (quote.address) {
		if (!quote.addresses) {
			_.set(quote, 'addresses', {});
		}
		// Assign mailing address to the addresses object with Id of 1
		quote.addresses[1] = quote.address;
		_.unset(quote, 'address');
	}

	// Save transaction data
	const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));
	if (isBlank(_.get(quote, 'transactionData', {}))) {
		_.set(quote, 'transactionData.createdDate', new Date());
		_.set(quote, 'transactionData.createdBy', agent.userId);
	}
	_.set(quote, 'transactionData.modifiedDate', new Date());
	_.set(quote, 'transactionData.modifiedBy', agent.userId);

	if (!quote.id) {
		quote.id = uuidv4();
		return await http.post(touchpointEndpoint, quote);
	}
	return await http.put(`${touchpointEndpoint}/${quote.agentSubpro}/${quote.id}`, quote);
}
