import _ from 'lodash';
import { toast } from 'react-toastify';
import http from 'services/httpService';
import { getPredState } from 'utils/BusinessFunctions';
import { v4 as uuidv4 } from 'uuid';

export async function retrieveVehiclePrefill(quote, lastName, address, updateQuote, context) {
	const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));
	const street = address.streetNumber + ' ' + address.streetName + ' ' + (address.unit ? address.unit : '');
	const prefillRequest = {
		branch: agent.branch,
		policyId: quote.quoteNumber,
		lastName,
		street,
		city: address.city,
		state: address.state,
		zip: address.zip,
	};
	const { data: returnVehicles } = await http.post(
		`${process.env.REACT_APP_VEHICLE_PREFILL}?auth=${sessionStorage.getItem('cigToken')}`,
		prefillRequest,
	);
	const existingVehicles = _.get(quote, 'cap.vehicles', {});
	const deletedVehicles = _.get(quote, 'cap.deletedVehicles', {});
	_.get(returnVehicles, 'vehiclesReturn', []).forEach((vehicle) => {
		let vehicleMatch = false;
		_.forIn(existingVehicles, (exVehicle, id) => {
			if (exVehicle.vin === vehicle.vin) {
				vehicleMatch = true;
			}
		});
		_.forIn(deletedVehicles, (exVehicle, id) => {
			if (exVehicle.vin === vehicle.vin) {
				vehicleMatch = true;
			}
		});
		!vehicleMatch &&
			validateVin(vehicle.vin, context).then((returned) => {
				const vehicles = _.get(returned, 'data.vehicles', []);
				const vinValidated = vehicles.length > 0;
				const order = !existingVehicles ? 0 : Object.keys(existingVehicles).length;

				if (vehicles.length > 0) {
					existingVehicles[uuidv4()] = {
						vin: vehicles[0].vin,
						vinValidated,
						vehYear: vehicles[0].year,
						vehMake: vehicles[0].make,
						vehModel: vehicles[0].model,
						description: vehicles.length === 1 ? vehicles[0].description : vehicles,
						grossVehWeight: vehicles[0].GVW,
						vehCostNew: vehicles[0].msrp,
						garagingLocation: _.get(quote, `cap.coverages.${getPredState(quote)}.address`),
						order,
						lexisNexisPrefill: true,
					};
				} else {
					existingVehicles[uuidv4()] = {
						vin: vehicle.vin,
						vinValidated,
						vehYear: vehicle.year,
						vehMake: vehicle.make,
						vehModel: vehicle.model,
						description: vehicle.description,
						grossVehWeight: vehicle.GVW,
						vehCostNew: vehicle.msrp,
						garagingLocation: _.get(quote, `cap.coverages.${getPredState(quote)}.address`),
						order,
						lexisNexisPrefill: true,
					};
				}
			});
	});

	context.updateServiceStatus('vinValidation', false);
	_.set(quote, 'cap.vehicles', existingVehicles);
	updateQuote(quote);
}

export function validateVin(vin, context) {
	context.updateServiceStatus('vinValidation', true);
	try {
		return http.get(process.env.REACT_APP_VIN_VALIDATOR, {
			params: { vin: vin, auth: sessionStorage.getItem('cigToken') },
		});
	} catch (error) {
		toast.error('An error has occurred validating the vin.');
		console.error('error', error);
	}
}
