import http from 'services/httpService';
import { toast } from 'react-toastify';

export function getReceipt(quote) {
	try {
		return http.get(`${process.env.REACT_APP_RECEIPT}/${quote.agentSubpro}/${quote.id}`);
	} catch (e) {
		toast.error('Could not retrieve receipt');
		return [];
	}
}
