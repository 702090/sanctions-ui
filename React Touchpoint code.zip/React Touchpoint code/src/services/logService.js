import { captureException, init } from '@sentry/browser';
import http from 'services/httpService';

init({
	dsn: process.env.REACT_APP_SENTRY_URL,
	environment: process.env.REACT_APP_ENVIRONMENT_NAME === 'qa' ? 'test' : process.env.REACT_APP_ENVIRONMENT_NAME,
});

function log(error) {
	captureException(error);
}

async function logCloudWatch(logType, quoteNumber, message) {
	if (quoteNumber) {
		try {
			const logObject = {
				type: 'TouchPointLogs',
				name: `Quote - ${quoteNumber}`,
				message: `${new Date()} ${message}`,
				level: logType,
			};

			const { data: returnData } = await http.put(`${process.env.REACT_APP_LOGGER}`, logObject);

			return returnData;
		} catch (error) {
			console.error('ERROR!!!! Could not log request', error);
			logCloudWatch(logType, quoteNumber, message);
		}
	}
}

async function logError(quoteNumber, message) {
	return await logCloudWatch('error', quoteNumber, message, 0);
}

async function logInfo(quoteNumber, message) {
	if (['info', 'debug'].includes(process.env.REACT_APP_LOG_LEVEL)) {
		return await logCloudWatch('info', quoteNumber, message, 0);
	}
}

async function logDebug(quoteNumber, message) {
	if (['debug'].includes(process.env.REACT_APP_LOG_LEVEL)) {
		return await logCloudWatch('debug', quoteNumber, message, 0);
	}
}

export default {
	init,
	log,
	logInfo,
	logError,
	logDebug,
};
