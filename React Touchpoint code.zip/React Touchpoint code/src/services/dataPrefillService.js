import { Buffer } from 'buffer';
import _ from 'lodash';
import { toast } from 'react-toastify';
import http from 'services/httpService';

export async function getCompanyId(service, locationAddress, insuredName) {
	const requestBody = {};
	let url = '';

	if (service === 'verisk') {
		url = process.env.REACT_APP_VERISK_UNIQUE_ID;
	} else if (service === 'datacubes') {
		url = process.env.REACT_APP_DATACUBES_COMPANY_ID;
	}
	requestBody.businessName = insuredName;
	requestBody.address = locationAddress.streetNumber + ' ' + locationAddress.streetName;
	requestBody.unit = locationAddress.unit;
	requestBody.city = locationAddress.city;
	requestBody.state = locationAddress.state;
	requestBody.zip = locationAddress.zip;

	try {
		let companyId = '';
		const { data: returnData } = await http.post(`${url}`, requestBody);

		let companyObject = {};

		if (service === 'verisk') {
			if (returnData.MatchType === 'Error') {
				//TODO: do somehting to notify in-house that an error occurred getting verisk information
			} else if (returnData.MatchType === 'Exact') {
				companyObject.buildingPrefillOnly = false;
				if (returnData.BopBusinesses.length === 1) {
					companyObject.companyId = _.get(returnData, 'BopBusinesses[0].UniqueIdentifier', '');
				} else {
					let iCount = 0;
					let holdCompanyId;
					_.forEach(_.get(returnData, 'BopBusinesses', []), (business) => {
						if (_.startsWith(business.UniqueIdentifier, 'I')) {
							iCount += 1;
							holdCompanyId = business.UniqueIdentifier;
						}
					});
					companyObject.companyId = holdCompanyId;
					if (iCount > 1) {
						// We will still use building prefill if Verisk has more than one "i" account
						companyObject.buildingPrefillOnly = true;
					}
				}
			}
		} else if (service === 'datacubes') {
			companyObject.errorMessage = _.get(returnData, 'errorMessage', '');
			companyObject.companyId = _.get(returnData, 'company_id', '');
			companyObject.relevanceScore = _.get(returnData, 'search_relevance_score', '');
			companyObject.bestMatchFields = _.get(returnData, 'best_matched_fields_from_query', []);
		}

		return companyObject;
	} catch (e) {
		toast.error(`Could not get ${service} Company Id`);
		console.error('error', e);
		return { noReturnData: true };
	}
}

export async function getPropertyData(service, companyId) {
	let url = '';
	if (service === 'verisk') {
		url = process.env.REACT_APP_VERISK_PROPERTY_INFO;
	} else if (service === 'datacubes') {
		url = process.env.REACT_APP_DATACUBES_PROPERTY_INFO;
	}
	try {
		const { data: returnData } = await http.get(`${url}/${companyId}`);

		return returnData;
	} catch (e) {
		toast.error(`Could not get ${service} Property Data`);
		console.error('error', e);
		return {};
	}
}

export async function getNCCIData(fein, effectiveDate) {
	try {
		const { data: returnData } = await http.post(`${process.env.REACT_APP_NCCI_ORDER_INFO}`, {
			fein,
			effectiveDate,
		});
		_.set(returnData, 'orderKey', Buffer.from(fein + effectiveDate).toString('base64'));
		return returnData;
	} catch (e) {
		toast.error(`Could not get NCCI data for ${fein}`);
		console.error('error', e);
		return {
			noReturnData: true,
			RiskReturnv2: {
				RiskHeaderInformation: {
					ResponseCode: '2',
					ResponseMessage: {
						'a:string': 'A connection to the NCCI resource could not be established.',
					},
				},
			},
		};
	}
}

export async function getVerisk360Valuation(requestBody) {
	try {
		const { data: returnData } = await http.post(process.env.REACT_APP_VERISK_360_VALUATION_XML, requestBody);
		return returnData;
	} catch (e) {
		toast.error('Error calling Verisk 360 service.');
		console.error('Verisk 360 Error: ', e);
		return { noReturnData: true };
	}
}

export async function getVeriskRoofReport(requestBody) {
	try {
		const { data: returnData } = await http.post(process.env.REACT_APP_VERISK_ROOF_REPORT, requestBody);
		return returnData;
	} catch (e) {
		toast.error('Error calling Verisk Roof Report service.');
		console.error('Verisk Roof Report Error: ', e);
		return { ErrorMessage: 'Error retrieving Verisk roof report.' };
	}
}

export async function getVerisk360PDF(valuationId) {
	const url = process.env.REACT_APP_VERISK_360_VALUATION_PDF;
	try {
		const { data: returnData } = await http.get(`${url}/${valuationId}`);
		return returnData;
	} catch (e) {
		toast.error('Error calling Verisk 360 PDF service.');
		console.error('Verisk 360 PDF Error: ', e);
		return {};
	}
}
