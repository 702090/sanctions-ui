import _ from 'lodash';
import spected from 'spected';
import { duplicate } from 'utils/ObjectFunctions';
import { isBlank } from 'utils/StringFunctions';

function getErrorsFromValidationResult(validationResult, parentName) {
	const FIRST_ERROR = 0;
	return Object.keys(validationResult).reduce((errors, field) => {
		if (typeof validationResult[field] === 'object' && !Array.isArray(validationResult[field])) {
			const validationResults = getErrorsFromValidationResult(validationResult[field], field);

			const returnValue = {};

			if (!isBlank(validationResults)) {
				returnValue[field] = validationResults;
			}
			return { ...errors, ...returnValue };
		}
		if (_.startsWith(field, 'section_')) {
			return validationResult[field] !== true ? { ...errors, [field]: validationResult[field] } : errors;
		}
		return validationResult[field] !== true ? { ...errors, [field]: validationResult[field][FIRST_ERROR] } : errors;
	}, {});
}

export function validate(values, validationRules, requiredStructure) {
	_.merge(requiredStructure, values);
	const valid = spected(validationRules, requiredStructure);
	return getErrorsFromValidationResult(valid);
}

export function validateNew(quote, values, ruleClass, visibility, extraData) {
	const structure = getStructure(ruleClass, quote, values);
	const valid = spected(ruleClass.rules(quote, values, visibility, extraData), _.merge(duplicate(structure), values));
	return getErrorsFromValidationResult(valid);
}

function getStructure(ruleClass, quote, values) {
	let structure;
	switch (ruleClass.name()) {
		case 'sfgPolicyCoverages':
		case 'additionalQuestions':
		case 'wcpPolicyInformation':
			structure = duplicate(ruleClass.requiredStructure(quote, values));
			break;
		default:
			structure = duplicate(ruleClass.requiredStructure);
	}
	return structure;
}
export function checkReferrals(context, values, ruleClass, visibility, extraData) {
	const structure = getStructure(ruleClass, context.quote, values);
	const valuesToTest = _.merge(duplicate(structure), values);

	const spectedReferrals = spected(
		ruleClass.referrals(context, values, visibility, extraData),
		duplicate(valuesToTest),
	);

	let modalId = '';
	if (values) {
		if (values.locationId) {
			modalId = `${values.locationId}.${values.id}`;
		} else {
			modalId = values.id;
		}
	}

	parseReferrals(spectedReferrals, context.quote, modalId, structure);

	return spectedReferrals;
}

function parseReferrals(input, quote, modalId, requiredStructure, fieldAncestry) {
	let referralAtLevelOrBelow = false;
	let fieldPath = '';
	_.forIn(input, (referral, fieldName) => {
		fieldPath = `referrals${fieldAncestry ? `.${fieldAncestry}` : ''}.${fieldName}`;

		if (_.isArray(referral)) {
			//referral level
			_.set(quote, fieldPath + (modalId ? `.${modalId}` : ''), referral);
			referralAtLevelOrBelow = true;
		} else if (_.isObject(referral)) {
			//intermediate level
			if (
				parseReferrals(
					referral,
					quote,
					modalId,
					requiredStructure,
					(fieldAncestry ? `${fieldAncestry}.` : '') + fieldName,
				)
			) {
				referralAtLevelOrBelow = true;
			} else {
				//no children have referrals, I can be removed
				if (isBlank(_.get(quote, fieldPath))) {
					_.unset(quote, fieldPath);
				} else {
					referralAtLevelOrBelow = true;
				}
			}
		} else {
			//no referral
			if (
				isBlank(_.get(quote, fieldPath + (modalId ? `.${modalId}` : ''))) ||
				((_.get(requiredStructure, (fieldAncestry ? fieldAncestry + '.' : '') + fieldName) === '' ||
					fieldAncestry === 'questions' ||
					fieldAncestry === 'policyQuestions') &&
					referral === true)
			) {
				_.unset(quote, fieldPath + (modalId ? `.${modalId}` : ''));
			} else {
				referralAtLevelOrBelow = true;
			}
		}
	});
	return referralAtLevelOrBelow;
}

export function removeReferrals(context, id, basePath, subId) {
	let retrievalPath = 'quote.referrals';
	if (!isBlank(basePath)) {
		retrievalPath += '.' + basePath;
	}
	removeReferralsR(_.get(context, retrievalPath), id, subId);
}

function removeReferralsR(referrals, id, subId) {
	let referralAtLevelOrBelow = false;
	_.forIn(referrals, (referral, fieldName) => {
		if (_.isArray(referral) && fieldName !== id) {
			referralAtLevelOrBelow = true;
		} else {
			if (fieldName === id) {
				if (subId) {
					//check children for subId
					//check return from recursion for referralAtLevelOrBelow
					if (removeReferralsR(referral, subId)) {
						referralAtLevelOrBelow = true;
					} else {
						_.unset(referrals, fieldName);
					}
				} else {
					//remove self
					_.unset(referrals, fieldName);
				}
			} else {
				if (!_.isString(referral)) {
					//check children for id
					//check return from recursion for referralAtLevelOrBelow
					if (removeReferralsR(referral, id, subId)) {
						referralAtLevelOrBelow = true;
					} else {
						if (isBlank(referral[fieldName])) {
							_.unset(referrals, fieldName);
						}
					}
				}
			}
		}
	});
	return referralAtLevelOrBelow;
}

export function removeProductReferrals(quote, prod) {
	let letter = '';
	switch (prod) {
		case 'cap':
			letter = 'C';
			break;
		case 'wcp':
			letter = 'W';
			break;
		case 'cup':
			letter = 'U';
			break;
		default:
	}
	removeProductReferralsR(_.get(quote, 'referrals', {}), letter);
}

function removeProductReferralsR(referrals, letter) {
	let referralAtLevelOrBelow = false;
	_.forIn(referrals, (referral, fieldName) => {
		if (_.isArray(referral)) {
			if (_.startsWith(referral[0], letter)) {
				_.unset(referrals, fieldName);
			} else {
				referralAtLevelOrBelow = true;
			}
		} else {
			if (removeProductReferralsR(referral, letter)) {
				referralAtLevelOrBelow = true;
			} else {
				if (isBlank(referral[fieldName])) {
					_.unset(referrals, fieldName);
				}
			}
		}
	});
	return referralAtLevelOrBelow;
}
