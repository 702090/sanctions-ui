import DriverDashboardRules from 'commercialAuto/drivers/DriverDashboardRules';
import DriverRules from 'commercialAuto/drivers/DriverRules';
import CapLossesDashboardRules from 'commercialAuto/losses/CapLossesDashboardRules';
import CapLossRules from 'commercialAuto/losses/CapLossRules';
import CapPriorCarrierRules from 'commercialAuto/priorCarrier/CapPriorCarrierRules';
import StateCoveragesRules from 'commercialAuto/stateCoverages/StateCoveragesRules';
import SymbolsLimitsRules from 'commercialAuto/symbolsLimits/SymbolsLimitsRules';
import VehicleDashboardRules from 'commercialAuto/vehicles/VehicleDashboardRules';
import VehicleRules from 'commercialAuto/vehicles/VehicleRules';
import CupLossesDashboardRules from 'commercialUmbrella/losses/CupLossesDashboardRules';
import CupLossRules from 'commercialUmbrella/losses/CupLossRules';
import CupPolicyInformationRules from 'commercialUmbrella/policyInformation/CupPolicyInformationRules';
import CupPriorCarrierRules from 'commercialUmbrella/priorCarrier/CupPriorCarrierRules';
import UnderlyingPoliciesRules from 'commercialUmbrella/underlyingPolicies/UnderlyingPoliciesRules';
import GeneralInformationRules from 'generalInformation/GeneralInformationRules';
import PolicyQuestionRules from 'issue/policyQuestions/PolicyQuestionRules';
import _ from 'lodash';
import BuildingRules from 'safeguard/locationDashboard/building/BuildingRules';
import BuildingCoveragesRules from 'safeguard/locationDashboard/buildingCoverages/BuildingCoveragesRules';
import BuildingQuestionRules from 'safeguard/locationDashboard/buildingQuestions/BuildingQuestionRules';
import SfgLocationRules from 'safeguard/locationDashboard/location/SfgLocationRules';
import SfgLocationCoverageRules from 'safeguard/locationDashboard/locationCoverage/SfgLocationCoverageRules';
import SfgLocationDashboardRules from 'safeguard/locationDashboard/SfgLocationDashboardRules';
import SfgLossesDashboardRules from 'safeguard/losses/SfgLossesDashboardRules';
import SfgLossRules from 'safeguard/losses/SfgLossRules';
import SfgPolicyCoveragesRules from 'safeguard/policyCoverages/SfgPolicyCoveragesRules';
import SfgPolicyInformationRules from 'safeguard/policyInformation/SfgPolicyInformationRules';
import SfgPriorCarrierRules from 'safeguard/priorCarrier/SfgPriorCarrierRules';
import { ReferralList } from 'sidebar/Referrals';
import { duplicate } from 'utils/ObjectFunctions';
import { isBlank } from 'utils/StringFunctions';
import { checkReferrals } from 'validation/Validate';
import WcpLossesDashboardRules from 'workcomp/losses/WcpLossesDashboardRules';
import WcpLossRules from 'workcomp/losses/WcpLossRules';
import WcpClassCodeRules from 'workcomp/policyInformation/WcpClassCodeRules';
import WcpPolicyInformationRules from 'workcomp/policyInformation/WcpPolicyInformationRules';
import WcpPriorCarrierRules from 'workcomp/priorCarrier/WcpPriorCarrierRules';

export function runAllReferrals(context) {
	const fullQuote = duplicate(context.quote);
	if (fullQuote.addresses) {
		fullQuote.address = fullQuote.addresses[1];

		checkReferrals(context, fullQuote, GeneralInformationRules);
		const products = _.get(context, 'quote.products', ['sfg']);
		runSfgReferrals(context);
		if (_.includes(products, 'cap')) {
			runCapReferrals(context);
		}
		if (_.includes(products, 'wcp')) {
			runWcpReferrals(context);
		}
		if (_.includes(products, 'cup')) {
			runCupReferrals(context);
		}

		checkReferrals(context, context.quote, PolicyQuestionRules);
	}
}

export function checkOverrideReferrals(quote) {
	if (_.get(quote, 'underwriterReferralOverride', false)) {
		let referralCodes = [];
		let savedReferralCodes = _.get(quote, 'transactionData.uroReferrals', []);
		const referralList = ReferralList({ quote });

		referralList.forEach((referral) => {
			const key = _.get(referral, 'key');
			if (key) {
				referralCodes.push(key);
			}
		});

		if (!isBlank(_.difference(referralCodes, savedReferralCodes))) {
			_.unset(quote, 'transactionData.uroChangedBy');
			_.unset(quote, 'transactionData.uroDate');
			_.unset(quote, 'transactionData.uroReferrals');
			_.set(quote, 'underwriterReferralOverride', false);
		}
	}
}

export function replaceReferrals(context) {
	_.unset(context, 'quote.referrals');
	runAllReferrals(context);
}

export function runSfgReferrals(context) {
	checkReferrals(context, context.quote, SfgPolicyInformationRules);
	checkReferrals(context, context.quote, SfgLocationDashboardRules);
	_.forIn(_.get(context, 'quote.sfg.locations', {}), (location, locId) => {
		const fullLocation = duplicate(location);
		fullLocation.id = locId;
		fullLocation.addressL = _.get(context, `quote.addresses.${locId}`);

		checkReferrals(context, fullLocation, SfgLocationRules);
		checkReferrals(context, fullLocation, SfgLocationCoverageRules);

		_.forIn(location.buildings, (building, bldgId) => {
			const fullBuilding = duplicate(building);
			fullBuilding.locationId = locId;
			fullBuilding.id = bldgId;

			checkReferrals(context, fullBuilding, BuildingRules);
			checkReferrals(context, fullBuilding, BuildingQuestionRules);
			checkReferrals(context, fullBuilding, BuildingCoveragesRules);
		});
	});
	checkReferrals(context, context.quote, SfgPolicyCoveragesRules);
	checkReferrals(context, context.quote, SfgPriorCarrierRules);
	checkReferrals(context, context.quote, SfgLossesDashboardRules);
	_.forIn(_.get(context, 'quote.sfg.losses', {}), (loss, lossId) => {
		const fullLoss = duplicate(loss);
		fullLoss.id = lossId;
		checkReferrals(context, fullLoss, SfgLossRules);
	});
}

export function runCapReferrals(context) {
	checkReferrals(context, context.quote, SymbolsLimitsRules);
	checkReferrals(context, context.quote, StateCoveragesRules);
	checkReferrals(context, context.quote, DriverDashboardRules);
	_.forIn(_.get(context, 'quote.cap.drivers', {}), (driver, driverId) => {
		const fullDriver = duplicate(driver);
		fullDriver.id = driverId;
		checkReferrals(context, fullDriver, DriverRules);
	});
	checkReferrals(context, context.quote, VehicleDashboardRules);
	_.forIn(_.get(context, 'quote.cap.vehicles', {}), (vehicle, vehId) => {
		const fullVehicle = duplicate(vehicle);
		fullVehicle.id = vehId;
		checkReferrals(context, fullVehicle, VehicleRules);
	});
	checkReferrals(context, context.quote, CapPriorCarrierRules);
	checkReferrals(context, context.quote, CapLossesDashboardRules);
	_.forIn(_.get(context, 'quote.cap.losses', {}), (loss, lossId) => {
		const fullLoss = duplicate(loss);
		fullLoss.id = lossId;
		checkReferrals(context, fullLoss, CapLossRules);
	});
}

export function runWcpReferrals(context) {
	checkReferrals(context, context.quote, WcpPolicyInformationRules);
	_.forIn(_.get(context, 'quote.wcp.classCodes', {}), (classCode, classId) => {
		const fullCode = duplicate(classCode);
		fullCode.id = classId;
		checkReferrals(context, fullCode, WcpClassCodeRules);
	});
	checkReferrals(context, context.quote, WcpPriorCarrierRules);
	checkReferrals(context, context.quote, WcpLossesDashboardRules);
	_.forIn(_.get(context, 'quote.wcp.losses', {}), (loss, lossId) => {
		const fullLoss = duplicate(loss);
		fullLoss.id = lossId;
		checkReferrals(context, fullLoss, WcpLossRules);
	});
}

export function runCupReferrals(context) {
	checkReferrals(context, context.quote, CupPolicyInformationRules);
	checkReferrals(context, context.quote, UnderlyingPoliciesRules);
	checkReferrals(context, context.quote, CupPriorCarrierRules);
	checkReferrals(context, context.quote, CupLossesDashboardRules);
	_.forIn(_.get(context, 'quote.cup.losses', {}), (loss, lossId) => {
		const fullLoss = duplicate(loss);
		fullLoss.id = lossId;
		checkReferrals(context, fullLoss, CupLossRules);
	});
}
