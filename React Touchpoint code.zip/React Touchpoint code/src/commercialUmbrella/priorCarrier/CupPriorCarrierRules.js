import { getFieldDisplayArray } from 'data/FieldVisibility';
import _ from 'lodash';
import { isValidDate } from 'utils/DateFunctions';
import { getVisibility } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';

class CupPriorCarrierRules {
	static requiredStructure = {
		cup: {
			priorCarrier: '',
			cigPriorCarrier: '',
			priorPolicyNumber: '',
			carrierName: '',
		},
	};

	static optionalStructure = {
		cup: {
			expirationDate: '',
			annualPremium: '',
		},
	};

	static rules(quote, values, visibility) {
		// use values for current page validation
		// use quote for external page validation
		if (values && !visibility) {
			visibility = getVisibility(getFieldDisplayArray('cupPriorCarrier'), quote, values);
		}

		// Rules won't apply if this is a new venture
		if (_.get(quote, 'newVenture') === 'Y') {
			return {};
		}

		return {
			cup: {
				priorCarrier: [[(value) => !isBlank(value), 'Prior Carrier is required.']],
				cigPriorCarrier: [
					[(value) => !isBlank(value) || !visibility['cup.cigPriorCarrier'], 'CIG Prior Carrier is required.'],
				],
				priorPolicyNumber: [
					[(value) => !isBlank(value) || !visibility['cup.priorPolicyNumber'], 'Prior Policy Number is required.'],
					[
						(value) => _.get(values, 'cup.priorPolicyCigVerified', true) || !visibility['cup.priorPolicyNumber'],
						'The prior policy number you entered is not a valid Columbia policy number.  Please provide a valid number or remove Prior Insurance Coverage.',
					],
				],
				carrierName: [[(value) => !isBlank(value) || !visibility['cup.carrierName'], 'Carrier Name is required.']],
				expirationDate: [[(value) => isBlank(value) || isValidDate(value), 'You must enter a valid date.']],
			},
		};
	}

	static referrals(context, values) {
		return {
			cup: {
				priorCarrier: [[(value) => value !== 'N', 'UMI01']],
				priorPolicyNumber: [
					[
						(value) => !_.includes(['N1', 'N2', 'N3', 'N4', '02', '05', '06'], _.get(values, 'cup.cancelReason', '')),
						'UMI02',
					],
				],
			},
		};
	}

	static name() {
		return 'cupPriorCarrier';
	}
}

export default CupPriorCarrierRules;
