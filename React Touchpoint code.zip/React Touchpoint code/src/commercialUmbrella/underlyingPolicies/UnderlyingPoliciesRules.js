import { getFieldDisplayArray } from 'data/FieldVisibility';
import ruleMessagesJson from 'data/RuleMessages.json';
import _ from 'lodash';
import { daysFromDate } from 'utils/DateFunctions';
import { manualEntry } from 'utils/FieldDisplay';
import { getVisibility } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';

const { requiredMessageText, requiredMessageTextNotZero } = ruleMessagesJson;

class UnderlyingPoliciesRules {
	static requiredStructure = {
		section_cap: '',
		section_wcp: '',
		cup: {
			underlyingPolicies: {
				sfg: {
					driverCount: '',
				},
				cap: {
					driverCount: '',
				},
				wcp: {
					manual: '',
					carrier: '',
					policyNumber: '',
					effectiveDate: '',
					expirationDate: '',
					limitPerAccident: '',
					biPerPerson: '',
					liabilityMedicalAggLimit: '',
				},
			},
		},
	};

	static rules(quote, values, visibility) {
		if (values && !visibility) {
			visibility = getVisibility(getFieldDisplayArray('underlyingPolicies'), quote, values);
		}

		let autoEligibility = [];
		if (_.get(values, 'cup.underlyingPolicies.cap') || _.includes(_.get(quote, 'products', ['sfg']), 'cap')) {
			this.commercialAutoEligibility(quote, values, autoEligibility);
		}

		let wcpEligibility = [];
		if (
			!isBlank(_.get(values, 'cup.underlyingPolicies.wcp.carrier')) ||
			_.includes(_.get(quote, 'products', ['sfg']), 'wcp')
		) {
			this.commercialWcpEligibility(quote, values, wcpEligibility);
		}

		return {
			section_cap: autoEligibility,
			section_wcp: wcpEligibility,
			cup: {
				underlyingPolicies: {
					sfg: {
						driverCount: [
							[
								(value) => !(visibility['cup.underlyingPolicies.sfg.driverCount'] && isBlank(value)),
								requiredMessageTextNotZero,
							],
						],
					},
					wcp: {
						carrier: [[(value) => !(manualEntry(quote, values) && isBlank(value)), requiredMessageText]],
						policyNumber: [[(value) => !(manualEntry(quote, values) && isBlank(value)), requiredMessageText]],
						effectiveDate: [
							[(value) => !(manualEntry(quote, values) && isBlank(value)), requiredMessageText],
							[
								(value) =>
									!manualEntry(quote, values) ||
									value !== _.get(values, 'cup.underlyingPolicies.wcp.expirationDate', ''),
								'Effective Date and Expiration Date cannot be on the same date.',
							],
						],
						expirationDate: [
							[(value) => !(manualEntry(quote, values) && isBlank(value)), requiredMessageText],
							[
								(value) =>
									!manualEntry(quote, values) ||
									value !== _.get(values, 'cup.underlyingPolicies.wcp.effectiveDate', ''),
								'Effective Date and Expiration Date cannot be on the same date.',
							],
							[
								(value) =>
									!manualEntry(quote, values) ||
									daysFromDate(_.get(values, 'cup.underlyingPolicies.wcp.effectiveDate', ''), value) <= 0,
								'Expiration Date cannot come before the Effective Date. Please verify your date is correct.',
							],
						],
					},
				},
			},
		};
	}

	static commercialAutoEligibility(quote, values, autoEligibility) {
		let capLiabilityLimit;
		let vehicleCount;
		let hasHeavy = false;

		if (_.includes(_.get(quote, 'products', ['sfg']), 'cap')) {
			capLiabilityLimit = _.get(quote, 'cap.liabilityLimit', 0);
			_.forEach(_.get(quote, 'cap.vehicles', {}), (vehicle) => {
				if (vehicle.vehType === '4') {
					hasHeavy = true;
				}
			});
			vehicleCount = _.size(_.get(quote, 'cap.vehicles', {}));
		} else {
			capLiabilityLimit = _.get(values, 'cup.underlyingPolicies.cap.limitPerAccident'); // something else in there pathwise
			hasHeavy = _.get(values, 'cup.underlyingPolicies.cap.heavyVehicle');
			vehicleCount = _.get(values, 'cup.underlyingPolicies.cap.vehicleCount', 0);
		}

		if (vehicleCount <= 10 && !hasHeavy && capLiabilityLimit < 500000) {
			autoEligibility.push([
				() => false,
				'This quote is not eligible for Commercial Umbrella due to the Commercial Auto Liability Limit being less than $500,000.',
			]);
		} else if ((vehicleCount > 10 || hasHeavy) && capLiabilityLimit < 1000000) {
			autoEligibility.push([
				() => false,
				'This quote is not eligible for Commercial Umbrella due the Commercial Auto Liability Limit being less than $1,000,000.',
			]);
		}
	}

	static commercialWcpEligibility(quote, values, wcpEligibility) {
		let contractorsOccupancy = false;
		let limitPerAccident = 0;
		let diseasePolicyLimit = 0;
		let diseaseEmployeeLimit = 0;
		const underlyingWcpPolicy = _.get(values, 'cup.underlyingPolicies.wcp', {});

		_.forIn(_.get(quote, 'sfg.locations', {}), (location) => {
			_.forIn(location.buildings, (building) => {
				if (building.occupancyType === '10') {
					contractorsOccupancy = true;
				}
			});
		});

		if (_.includes(_.get(quote, 'products', ['sfg']), 'wcp')) {
			let limits = _.split(_.get(quote, 'wcp.employersLiability', ''), '/');
			limitPerAccident = _.toNumber(limits[0]);
			diseasePolicyLimit = _.toNumber(limits[1]);
			diseaseEmployeeLimit = _.toNumber(limits[2]);
		} else {
			limitPerAccident = _.toNumber(underlyingWcpPolicy.limitPerAccident);
			diseasePolicyLimit = _.toNumber(underlyingWcpPolicy.biPerPerson);
			diseaseEmployeeLimit = _.toNumber(underlyingWcpPolicy.liabilityMedicalAggLimit);
		}

		if (contractorsOccupancy) {
			if (!(limitPerAccident >= 500000 && diseasePolicyLimit >= 500000 && diseaseEmployeeLimit >= 500000)) {
				wcpEligibility.push([
					() => false,
					'This quote is not eligible for Commercial Umbrella due to the Workers Compensation limits being less than $500,000/$500,000/$500,000',
				]);
			}
		} else {
			if (!(limitPerAccident >= 100000 && diseasePolicyLimit >= 500000 && diseaseEmployeeLimit >= 100000)) {
				wcpEligibility.push([
					() => false,
					'This quote is not eligible for Commercial Umbrella due to the Workers Compensation limits being less than $100,000/$500,000/$100,000',
				]);
			}
		}
	}

	static referrals(context, values, visibility) {
		return {};
	}

	static name() {
		return 'UnderlyingPoliciesForm';
	}
}
export default UnderlyingPoliciesRules;
