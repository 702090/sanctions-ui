import UnderlyingPoliciesRules from 'commercialUmbrella/underlyingPolicies/UnderlyingPoliciesRules';
import { RemoveCoverageButton } from 'components/shared/buttons/RemoveCoverageButton';
import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { DataDisplay } from 'components/shared/form/DataDisplay';
import { DatePicker } from 'components/shared/form/DatePicker';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputText } from 'components/shared/form/inputs/InputText';
import { RadioButton } from 'components/shared/form/RadioButton';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import productNamesJson from 'data/ProductNames';
import selectOptionsJson from 'data/SelectOptions';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { useContext, useEffect, useState } from 'react';
import { getUnderlyingPolicies } from 'services/insurityService';
import { setRetrievedUnderlyingPolicyData } from 'utils/BusinessFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import { cleanValues, getVisibility, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { checkReferrals, validateNew } from 'validation/Validate';

const UnderlyingPoliciesForm = (props) => {
	const context = useContext(QuoteContext);
	const { quote } = context;

	let visibility = {};
	let formProps;

	const { cup_biPerPerson, cup_liabilityMedicalAggLimit, cup_limitPerAccident } = selectOptionsJson;
	const { productNames } = productNamesJson;

	const [retrieving, setRetrieving] = useState(false);

	useEffect(() => {
		const formUnderlyingPolicies = _.get(formProps, 'values.cup.underlyingPolicies', {});
		const retrievedUnderlyingPolicies = duplicate(_.get(quote, 'cup.retrievedUnderlyingPolicies', {}));

		setCapData(formUnderlyingPolicies, retrievedUnderlyingPolicies);
		setWcpData(formUnderlyingPolicies, retrievedUnderlyingPolicies);

		// If the form is not empty, trigger validation
		runRulesOnLoad(formProps, formProps.initialValues, ['']);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [
		quote.products,
		// eslint-disable-next-line react-hooks/exhaustive-deps
		_.get(quote, 'cup.retrievedUnderlyingPolicies'),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		_.get(formProps, 'values.cup.underlyingPolicies.cap'),
		// eslint-disable-next-line react-hooks/exhaustive-deps
		retrieving,
	]);

	const setCapData = (formUnderlyingPolicies, retrievedUnderlyingPolicies) => {
		if (_.includes(quote.products, 'cap')) {
			_.set(formUnderlyingPolicies, 'cap', {
				carrier: 'Columbia Mutual Insurance Co',
				driverCount: Object.keys(_.get(quote, 'cap.drivers', {})).length,
				vehicleCount: Object.keys(_.get(quote, 'cap.vehicles', {})).length,
			});
		} else if (!isBlank(_.get(retrievedUnderlyingPolicies, 'cap', {}))) {
			_.set(formUnderlyingPolicies, 'cap', _.get(retrievedUnderlyingPolicies, 'cap', {}));
		} else {
			// _.unset(formProps, 'values.cup.underlyingPolicies.cap');
			_.unset(formUnderlyingPolicies, 'cap');
		}
	};

	const setWcpData = (formUnderlyingPolicies, retrievedUnderlyingPolicies) => {
		if (_.includes(quote.products, 'wcp')) {
			_.set(formUnderlyingPolicies, 'wcp', {
				carrier: 'Columbia Mutual Insurance Co',
			});
		} else if (!isBlank(_.get(retrievedUnderlyingPolicies, 'wcp', {}))) {
			_.set(formUnderlyingPolicies, 'wcp', _.get(retrievedUnderlyingPolicies, 'wcp', {}));
		} else if (isBlank(_.get(formUnderlyingPolicies, 'wcp', {}))) {
			_.set(formUnderlyingPolicies, 'wcp', {
				manual: 'N',
			});
		}
	};

	const removePolicy = (product) => {
		_.unset(formProps, `values.cup.underlyingPolicies.${product}`);
		_.unset(quote, `cup.underlyingPolicies.${product}`);
		_.unset(quote, `cup.retrievedUnderlyingPolicies.${product}`);

		if (product === 'wcp') {
			const formUnderlyingPolicies = _.get(formProps, 'values.cup.underlyingPolicies', {});
			_.set(formUnderlyingPolicies, 'wcp', {
				manual: 'N',
			});
		}
		context.updateQuote(quote);
	};

	return (
		<Formik
			render={(formikProps) => {
				formProps = formikProps;
				visibility = getVisibility(getFieldDisplayArray('underlyingPolicies'), quote, formikProps.values);
				cleanValues(formikProps.values, visibility);
				checkReferrals(context, formikProps.values, UnderlyingPoliciesRules, visibility);

				return (
					<Form id='screen'>
						<SimpleButton
							id='retrievePolicies'
							primary
							content={retrieving ? <span className='withElipsis'>Retrieving Policies</span> : 'Retrieve Policies'}
							disabled={retrieving}
							onClick={() => {
								setRetrieving(true);

								getUnderlyingPolicies({
									customerNumber: quote.customerNumber,
									effectiveDate: quote.effectiveDate,
								})
									.then(({ data: returnData }) => {
										setRetrievedUnderlyingPolicyData(returnData, quote, context.updateQuote, props);
										setRetrieving(false);
									})
									.catch(() => {
										setRetrieving(false);
									});
							}}
						/>
						<PageSection className='stateSection' title={productNames.sfg}>
							<Field
								name='sfgCarrier'
								label='Carrier'
								value='Columbia Mutual Insurance Co'
								component={DataDisplay}
								horizontal
							/>
							{!isBlank(_.get(quote, 'sfg.umbrellaData.liabilityPremium')) && (
								<Field
									name='sfgUL Premium'
									label='Liability Premium *'
									value={_.get(quote, 'sfg.umbrellaData.liabilityPremium')}
									type='currency'
									component={DataDisplay}
									horizontal
								/>
							)}
							<Field
								name='sfgLiabilityLimit'
								label='Liability Limit'
								value={_.get(quote, 'sfg.liabilityLimit')}
								type='currency'
								component={DataDisplay}
								horizontal
							/>
							<Field
								name='sfgLiabilityMedicalAggLimit'
								label='Liability/Medical Agg Limit'
								value={_.get(quote, 'sfg.productAggLimit')}
								type='currency'
								component={DataDisplay}
								horizontal
							/>
							<Field
								name='sfgProductsAggregate'
								label='Products Aggregate'
								value={_.get(quote, 'sfg.productAggLimit')}
								type='currency'
								component={DataDisplay}
								horizontal
							/>
							<Field
								name='sfgCoverageType'
								label='Coverage Type'
								value='Occurrence'
								component={DataDisplay}
								horizontal
							/>
							<Field
								name='cup.underlyingPolicies.sfg.driverCount'
								label='Number of Drivers'
								component={InputNumber}
								fieldDisplay={visibility['cup.underlyingPolicies.sfg.driverCount']}
								width='tiny'
							/>
							{!isBlank(_.get(quote, 'sfg.umbrellaData.liabilityPremium')) && <div>* Subject to change at rating</div>}
						</PageSection>

						{_.includes(quote.products, 'cap') && (
							<PageSection
								className='stateSection'
								title={productNames.cap}
								name='section_cap'
								errors={formikProps.errors}
							>
								<Field
									name='capCarrier'
									label='Carrier'
									value='Columbia Mutual Insurance Co'
									component={DataDisplay}
									horizontal
								/>
								<Field
									name='cup.underlyingPolicies.cap.driverCount'
									label='Number of Drivers'
									component={DataDisplay}
									horizontal
								/>
								<Field
									name='capLiabilityLimit'
									label='Liability Limit'
									value={_.get(quote, 'cap.liabilityLimit')}
									component={DataDisplay}
									type='currency'
									horizontal
								/>
								{!isBlank(_.get(quote, 'cap.umbrellaData.biPerPerson')) && (
									<Field
										name='capBiPerPerson'
										label='BI Per Person *'
										value={_.get(quote, 'cap.umbrellaData.biPerPerson')}
										component={DataDisplay}
										type='currency'
										horizontal
									/>
								)}
								{!isBlank(_.get(quote, 'cap.umbrellaData.biPerAccident')) && (
									<Field
										name='capBiPerAccident'
										label='BI Per Accident *'
										value={_.get(quote, 'cap.umbrellaData.biPerAccident')}
										component={DataDisplay}
										type='currency'
										horizontal
									/>
								)}
								{!isBlank(_.get(quote, 'cap.umbrellaData.pdPerAccident')) && (
									<Field
										name='capPdPerAccident'
										label='PD Per Accident *'
										value={_.get(quote, 'cap.umbrellaData.pdPerAccident')}
										component={DataDisplay}
										type='currency'
										horizontal
									/>
								)}
								{!isBlank(_.get(quote, 'cap.umbrellaData.liabilitySymbol')) && (
									<Field
										name='capLiabilitySymbol'
										label='Hired / Non-Owned *'
										value={_.get(quote, 'cap.umbrellaData.liabilitySymbol')}
										component={DataDisplay}
										horizontal
									/>
								)}
								<Field
									name='vehicleCount'
									label='Number of All Vehicles'
									value={_.get(formikProps, 'values.cup.underlyingPolicies.cap.vehicleCount')}
									component={DataDisplay}
									horizontal
								/>
								{!isBlank(_.get(quote, 'cap.umbrellaData.lightExposureAmount')) && (
									<Field
										name='capLightExposureAmount'
										label='Number of PPT,Light,and Medium Vehicles *'
										value={_.get(quote, 'cap.umbrellaData.lightExposureAmount')}
										component={DataDisplay}
										horizontal
									/>
								)}
								{!isBlank(_.get(quote, 'cap.umbrellaData.lightPremiumAmount')) && (
									<Field
										name='capLightPremiumAmount'
										label='PPT,Light,and Medium Vehicles Premium *'
										value={_.get(quote, 'cap.umbrellaData.lightPremiumAmount')}
										component={DataDisplay}
										type='currency'
										horizontal
									/>
								)}
								{!isBlank(_.get(quote, 'cap.umbrellaData.heavyExposureAmount')) && (
									<Field
										name='capHeavyExposureAmount'
										label='Number Of Heavy Vehicles *'
										value={_.get(quote, 'cap.umbrellaData.heavyExposureAmount')}
										component={DataDisplay}
										horizontal
									/>
								)}
								{!isBlank(_.get(quote, 'cap.umbrellaData.heavyPremiumAmount')) && (
									<Field
										name='capHeavyPremiumAmount'
										label='Heavy Vehicles Premium *'
										value={_.get(quote, 'cap.umbrellaData.heavyPremiumAmount')}
										component={DataDisplay}
										type='currency'
										horizontal
									/>
								)}
								{!isBlank(_.get(quote, 'cap.umbrellaData.extraHeavyExposureAmount')) && (
									<Field
										name='capExtraHeavyExposureAmount'
										label='Number of Extra Heavy Truck Tractor Vehicles *'
										value={_.get(quote, 'cap.umbrellaData.extraHeavyExposureAmount')}
										component={DataDisplay}
										horizontal
									/>
								)}
								{!isBlank(_.get(quote, 'cap.umbrellaData.extraHeavyPremiumAmount')) && (
									<Field
										name='capExtraHeavyPremiumAmount'
										label='Extra Heavy Truck Tractor Vehicles Premium *'
										value={_.get(quote, 'cap.umbrellaData.extraHeavyPremiumAmount')}
										component={DataDisplay}
										type='currency'
										horizontal
									/>
								)}
								{(!isBlank(_.get(quote, 'cap.umbrellaData.biPerPerson')) ||
									!isBlank(_.get(quote, 'cap.umbrellaData.biPerAccident')) ||
									!isBlank(_.get(quote, 'cap.umbrellaData.pdPerAccident')) ||
									!isBlank(_.get(quote, 'cap.umbrellaData.lightExposureAmount')) ||
									!isBlank(_.get(quote, 'cap.umbrellaData.lightPremiumAmount')) ||
									!isBlank(_.get(quote, 'cap.umbrellaData.heavyExposureAmount')) ||
									!isBlank(_.get(quote, 'cap.umbrellaData.heavyPremiumAmount')) ||
									!isBlank(_.get(quote, 'cap.umbrellaData.extraHeavyExposureAmount')) ||
									!isBlank(_.get(quote, 'cap.umbrellaData.extraHeavyPremiumAmount'))) && (
									<div>* Subject to change at rating</div>
								)}
							</PageSection>
						)}
						{!_.includes(quote.products, 'cap') &&
							!isBlank(_.get(quote, 'cup.underlyingPolicies.cap', {})) &&
							_.get(quote, 'cup.underlyingPolicies.cap.retrieved', false) && (
								<PageSection
									className='stateSection'
									title={productNames.cap}
									name='section_cap'
									errors={formikProps.errors}
								>
									<Field
										name='capCarrier'
										label='Carrier'
										value={_.get(quote, 'cup.underlyingPolicies.cap.carrier')}
										component={DataDisplay}
										horizontal
									/>
									<Field
										name='capPolicyNumber'
										label='Policy Number'
										value={_.get(quote, 'cup.underlyingPolicies.cap.policyNumber')}
										component={DataDisplay}
										horizontal
									/>
									<Field
										name='capEffectiveDate'
										label='Effective Date'
										value={_.get(quote, 'cup.underlyingPolicies.cap.effectiveDate')}
										component={DataDisplay}
										horizontal
									/>
									<Field
										name='capExpirationDate'
										label='Expiration Date'
										value={_.get(quote, 'cup.underlyingPolicies.cap.expirationDate')}
										component={DataDisplay}
										horizontal
									/>
									<Field
										name='capDriverCount'
										label='Number of Drivers'
										value={_.get(quote, 'cup.underlyingPolicies.cap.driverCount')}
										component={DataDisplay}
										horizontal
									/>
									<Field
										name='capLiabilityLimit'
										label='Liability Limit'
										value={_.get(quote, 'cup.underlyingPolicies.cap.limitPerAccident')}
										component={DataDisplay}
										type='currency'
										horizontal
									/>
									{!isBlank(_.get(quote, 'cup.underlyingPolicies.cap.biPerPerson')) && (
										<Field
											name='capBiPerPerson'
											label='BI Per Person'
											value={_.get(quote, 'cup.underlyingPolicies.cap.biPerPerson')}
											component={DataDisplay}
											type='currency'
											horizontal
										/>
									)}
									{!isBlank(_.get(quote, 'cup.underlyingPolicies.cap.biPerAccident')) && (
										<Field
											name='capBiPerAccident'
											label='BI Per Accident'
											value={_.get(quote, 'cup.underlyingPolicies.cap.biPerAccident')}
											component={DataDisplay}
											type='currency'
											horizontal
										/>
									)}
									{!isBlank(_.get(quote, 'cup.underlyingPolicies.cap.pdPerAccident')) && (
										<Field
											name='capPdPerAccident'
											label='PD Per Accident'
											value={_.get(quote, 'cup.underlyingPolicies.cap.pdPerAccident')}
											component={DataDisplay}
											type='currency'
											horizontal
										/>
									)}
									{!isBlank(_.get(quote, 'cup.underlyingPolicies.cap.liabilitySymbol')) && (
										<Field
											name='capLiabilitySymbol'
											label='Hired / Non-Owned'
											value={_.get(quote, 'cup.underlyingPolicies.cap.liabilitySymbol')}
											component={DataDisplay}
											horizontal
										/>
									)}
									<Field
										name='capVehicleCount'
										label='Number of All Vehicles'
										value={_.get(quote, 'cup.underlyingPolicies.cap.vehicleCount')}
										component={DataDisplay}
										horizontal
									/>
									{!isBlank(_.get(quote, 'cup.underlyingPolicies.cap.lightExposureAmount')) && (
										<Field
											name='capLightExposureAmount'
											label='Number of PPT,Light,and Medium Vehicles'
											value={_.get(quote, 'cup.underlyingPolicies.cap.lightExposureAmount')}
											component={DataDisplay}
											horizontal
										/>
									)}
									{!isBlank(_.get(quote, 'cup.underlyingPolicies.cap.lightPremiumAmount')) && (
										<Field
											name='capLightPremiumAmount'
											label='PPT,Light,and Medium Vehicles Premium'
											value={_.get(quote, 'cup.underlyingPolicies.cap.lightPremiumAmount')}
											component={DataDisplay}
											type='currency'
											horizontal
										/>
									)}
									{!isBlank(_.get(quote, 'cup.underlyingPolicies.cap.heavyExposureAmount')) && (
										<Field
											name='capHeavyExposureAmount'
											label='Number Of Heavy Vehicles'
											value={_.get(quote, 'cup.underlyingPolicies.cap.heavyExposureAmount')}
											component={DataDisplay}
											horizontal
										/>
									)}
									{!isBlank(_.get(quote, 'cup.underlyingPolicies.cap.heavyPremiumAmount')) && (
										<Field
											name='capHeavyPremiumAmount'
											label='Heavy Vehicles Premium'
											value={_.get(quote, 'cup.underlyingPolicies.cap.heavyPremiumAmount')}
											component={DataDisplay}
											type='currency'
											horizontal
										/>
									)}
									{!isBlank(_.get(quote, 'cup.underlyingPolicies.cap.extraHeavyExposureAmount')) && (
										<Field
											name='capExtraHeavyExposureAmount'
											label='Number of Extra Heavy Truck Tractor Vehicles'
											value={_.get(quote, 'cup.underlyingPolicies.cap.extraHeavyExposureAmount')}
											component={DataDisplay}
											horizontal
										/>
									)}
									{!isBlank(_.get(quote, 'cup.underlyingPolicies.cap.extraHeavyPremiumAmount')) && (
										<Field
											name='capExtraHeavyPremiumAmount'
											label='Extra Heavy Truck Tractor Vehicles Premium'
											value={_.get(quote, 'cup.underlyingPolicies.cap.extraHeavyPremiumAmount')}
											component={DataDisplay}
											type='currency'
											horizontal
										/>
									)}
									<RemoveCoverageButton
										onClick={(event) => {
											removePolicy('cap');
										}}
									/>
								</PageSection>
							)}
						{_.includes(quote.products, 'wcp') && (
							<PageSection
								className='stateSection'
								title={productNames.wcp}
								name='section_wcp'
								errors={formikProps.errors}
							>
								<Field
									name='wcpCarrier'
									label='Carrier'
									value='Columbia Mutual Insurance Co'
									component={DataDisplay}
									horizontal
								/>
								<Field
									name='wcpLimitPerAccident'
									label='Limit Per Accident'
									value={_.get(quote, 'wcp.employersLiability').split('/')[0]}
									component={DataDisplay}
									type='currency'
									horizontal
								/>
								<Field
									name='wcpDiseasePolicyLimit'
									label='Disease Policy Limit'
									value={_.get(quote, 'wcp.employersLiability').split('/')[1]}
									component={DataDisplay}
									type='currency'
									horizontal
								/>
								<Field
									name='wcpDiseasePerEmployee'
									label='Disease Per Employee'
									value={_.get(quote, 'wcp.employersLiability').split('/')[2]}
									component={DataDisplay}
									type='currency'
									horizontal
								/>
							</PageSection>
						)}
						{!_.includes(quote.products, 'wcp') &&
							!isBlank(_.get(quote, 'cup.underlyingPolicies.wcp', {})) &&
							_.get(quote, 'cup.underlyingPolicies.wcp.retrieved', false) && (
								<PageSection
									className='stateSection'
									title={productNames.wcp}
									name='section_wcp'
									errors={formikProps.errors}
								>
									<Field
										name='wcpCarrier'
										label='Carrier'
										value={_.get(quote, 'cup.underlyingPolicies.wcp.carrier')}
										component={DataDisplay}
										horizontal
									/>
									<Field
										name='wcpPolicyNumber'
										label='Policy Number'
										value={_.get(quote, 'cup.underlyingPolicies.wcp.policyNumber')}
										component={DataDisplay}
										horizontal
									/>
									<Field
										name='wcpLimitPerAccident'
										label='Limit Per Accident'
										value={_.get(quote, 'cup.underlyingPolicies.wcp.limitPerAccident')}
										component={DataDisplay}
										type='currency'
										horizontal
									/>
									<Field
										name='wcpDiseasePolicyLimit'
										label='Disease Policy Limit'
										value={_.get(quote, 'cup.underlyingPolicies.wcp.biPerPerson')}
										component={DataDisplay}
										type='currency'
										horizontal
									/>
									<Field
										name='wcpDiseasePerEmployee'
										label='Disease Per Employee'
										value={_.get(quote, 'cup.underlyingPolicies.wcp.liabilityMedicalAggLimit')}
										component={DataDisplay}
										type='currency'
										horizontal
									/>
									<RemoveCoverageButton
										onClick={(event) => {
											removePolicy('wcp');
										}}
									/>
								</PageSection>
							)}
						{!_.includes(quote.products, 'wcp') &&
							(isBlank(_.get(quote, 'cup.underlyingPolicies.wcp', {})) ||
								(!isBlank(_.get(quote, 'cup.underlyingPolicies.wcp', {})) &&
									!_.get(quote, 'cup.underlyingPolicies.wcp.retrieved', false))) && (
								<PageSection
									className='stateSection'
									title={productNames.wcp}
									name='section_wcp'
									errors={formikProps.errors}
								>
									<Field
										name='cup.underlyingPolicies.wcp.manual'
										label='Would you like to add a Workers Compensation Policy?'
										component={RadioButton}
										additionalOnChange={(v, sfv, fv) => {
											if (v === 'Y') {
												sfv('cup.underlyingPolicies.wcp.limitPerAccident', '100000', false);
												sfv('cup.underlyingPolicies.wcp.biPerPerson', '500000', false);
												sfv('cup.underlyingPolicies.wcp.liabilityMedicalAggLimit', '100000');
											}
										}}
									/>
									{_.get(formikProps, 'values.cup.underlyingPolicies.wcp.manual', 'N') === 'Y' && (
										<>
											<Field name='cup.underlyingPolicies.wcp.carrier' label='Carrier' component={InputText} />
											<Field
												name='cup.underlyingPolicies.wcp.policyNumber'
												label='Policy Number'
												component={InputText}
												maxLength='20'
												width='meduim'
											/>
											<div className='flexFields'>
												<Field
													name='cup.underlyingPolicies.wcp.effectiveDate'
													label='Effective Date'
													component={DatePicker}
													width='small'
												/>
												<Field
													name='cup.underlyingPolicies.wcp.expirationDate'
													label='Expiration Date'
													component={DatePicker}
													width='small'
												/>
											</div>
											<Field
												name='cup.underlyingPolicies.wcp.limitPerAccident'
												label='Limit Per Accident'
												component={RadioButton}
												options={cup_limitPerAccident}
											/>
											<Field
												name='cup.underlyingPolicies.wcp.biPerPerson'
												label='BI Per Person'
												component={RadioButton}
												options={cup_biPerPerson}
											/>
											<Field
												name='cup.underlyingPolicies.wcp.liabilityMedicalAggLimit'
												label='Liability / Medical Agg Limit'
												component={RadioButton}
												options={cup_liabilityMedicalAggLimit}
											/>
										</>
									)}
								</PageSection>
							)}
						<NavigationButtons
							formikProps={formikProps}
							back
							location={props.location}
							history={props.history}
							rulesObject={UnderlyingPoliciesRules}
						/>
					</Form>
				);
			}}
			initialValues={
				quote.cup
					? {
							cup: {
								...quote.cup,
								underlyingPolicies: {
									sfg: {
										carrier: _.get(quote, 'cup.underlyingPolicies.sfg.carrier', 'Columbia Mutual Insurance Co'),
										driverCount: _.get(quote, 'cup.underlyingPolicies.sfg.driverCount', ''),
									},
									cap: {
										carrier: _.get(quote, 'cup.underlyingPolicies.cap.carrier', 'Columbia Mutual Insurance Co'),
										driverCount: _.includes(quote.products, 'cap')
											? Object.keys(_.get(quote, 'cap.drivers', {})).length
											: _.get(quote, 'cup.retrievedUnderlyingPolicies.cap.drivers', 0),
										vehicleCount: _.includes(quote.products, 'cap')
											? Object.keys(_.get(quote, 'cap.vehicles', {})).length
											: _.get(quote, 'cup.retrievedUnderlyingPolicies.cap.vehicleCount', 0),
									},
									wcp: {
										manual: _.get(quote, 'cup.underlyingPolicies.wcp.manual', 'N'),
										carrier: _.get(quote, 'cup.underlyingPolicies.wcp.carrier', 'Columbia Mutual Insurance Co'),
										policyNumber: _.get(quote, 'cup.underlyingPolicies.wcp.policyNumber', ''),
										effectiveDate: _.get(quote, 'cup.underlyingPolicies.wcp.effectiveDate', ''),
										expirationDate: _.get(quote, 'cup.underlyingPolicies.wcp.expirationDate', ''),
										limitPerAccident: _.includes(quote.products, 'wcp')
											? ''
											: _.get(
													quote,
													'cup.retrievedUnderlyingPolicies.wcp.limitPerAccident',
													_.get(quote, 'cup.underlyingPolicies.wcp.limitPerAccident', '100000'),
											  ),
										biPerPerson: _.includes(quote.products, 'wcp')
											? ''
											: _.get(
													quote,
													'cup.retrievedUnderlyingPolicies.wcp.biPerPerson',
													_.get(quote, 'cup.underlyingPolicies.wcp.biPerPerson', '500000'),
											  ),
										liabilityMedicalAggLimit: _.includes(quote.products, 'wcp')
											? ''
											: _.get(
													quote,
													'cup.retrievedUnderlyingPolicies.wcp.liabilityMedicalAggLimit',
													_.get(quote, 'cup.underlyingPolicies.wcp.liabilityMedicalAggLimit', '100000'),
											  ),
									},
								},
							},
					  }
					: {}
			}
			onSubmit={(values, formikActions) => {
				cleanValues(values, visibility);
				context.onSubmit(values, true, false, false, props, UnderlyingPoliciesRules);
			}}
			validate={(values) => {
				checkReferrals(context, values, UnderlyingPoliciesRules, visibility);
				const validResults = validateNew(quote, values, UnderlyingPoliciesRules, visibility);
				logPageErrors(validResults, formProps.touched, 'cup');

				return validResults;
			}}
		/>
	);
};

export default UnderlyingPoliciesForm;
