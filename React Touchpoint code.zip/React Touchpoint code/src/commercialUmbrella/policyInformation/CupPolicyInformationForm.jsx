import CupPolicyInformationRules from 'commercialUmbrella/policyInformation/CupPolicyInformationRules';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { RadioButton } from 'components/shared/form/RadioButton';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { OptionalSection } from 'components/shared/sections/OptionalSection';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import coveragesListJson from 'data/CoveragesList';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import selectOptionsJson from 'data/SelectOptions';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { useContext, useEffect } from 'react';
import { duplicate, getSet } from 'utils/ObjectFunctions';
import { cleanValues, getVisibility, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { checkReferrals, validate } from 'validation/Validate';

let visibility = {};

const CupPolicyInformationForm = (props) => {
	const context = useContext(QuoteContext);
	const { quote } = context;

	let dirty = false;
	let formProps;

	const { sfg_professional_liability } = coveragesListJson;
	const { cup_umbrellaLimit } = selectOptionsJson;

	useEffect(() => {
		// If the form is not empty, trigger validation
		if (_.get(quote, 'sfg.coverages.TRSM.included', '') === 'N') {
			formProps.setFieldValue('cup.federalTerrorism', 'N');
		}

		_.intersection([...getSet(_.get(quote, 'sfg.coverages.currentCoverages', {}))], sfg_professional_liability).length >
		0
			? formProps.setFieldValue('cup.professionalLiability', 'Y')
			: formProps.setFieldValue('cup.professionalLiability', 'N');

		runRulesOnLoad(formProps, formProps.initialValues, ['']);

		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	return (
		<Formik
			render={(formikProps) => {
				formProps = formikProps;
				dirty = formikProps.dirty;
				visibility = getVisibility(getFieldDisplayArray('commercialUmbrella'), quote, formikProps.values);
				cleanValues(formikProps.values, visibility);
				checkReferrals(context, formikProps.values, CupPolicyInformationRules, visibility);

				return (
					<Form id='screen'>
						<PageSection name='section_umbrellaPolicy' errors={formikProps.errors} ignoreTouched>
							<Field
								name='cup.umbrellaLimit'
								label='Umbrella Limit'
								component={RadioButton}
								options={cup_umbrellaLimit}
							/>
							<Field
								name='cup.restaurantLiquor'
								label='Restaurants w/Liquor Sales greater than 25%'
								component={RadioButton}
								fieldDisplay={visibility['cup.restaurantLiquor']}
								ignoreTouched
							/>
							<Field
								name='cup.underlyingLiability'
								label='Underlying liability loss greater than $150,000 in the past 3 years'
								component={RadioButton}
								ignoreTouched
							/>
							<Field
								name='cup.payrollExposure'
								label='Payroll Exposure'
								component={InputNumber}
								type='currency'
								maxLength='11'
								width='small'
							/>
						</PageSection>
						<PageSection title='Receipts' name='section_receipts' errors={formikProps.errors}>
							<OptionalSection
								name='group_receipts'
								errors={formikProps.errors}
								text='You must fill in either Contracting Manufacturing or All Other Receipts, but not both.'
								touched={
									_.get(formikProps.touched, 'cup.contractingManufacturing', false) ||
									_.get(formikProps.touched, 'cup.allOther', false)
								}
							>
								<Field
									name='cup.contractingManufacturing'
									label='Contracting/Manufacturing Receipts Exposure'
									component={InputNumber}
									type='currency'
									maxLength='10'
									width='small'
								/>
								<Field
									name='cup.allOther'
									label='All Other Receipts Exposure'
									component={InputNumber}
									type='currency'
									maxLength='10'
									width='small'
								/>
							</OptionalSection>
						</PageSection>
						<PageSection title='Optional Coverages'>
							<Field
								name='cup.federalTerrorism'
								label='Federal Terrorism'
								component={RadioButton}
								disabled={_.get(quote, 'sfg.coverages.TRSM.included', '') === 'N'}
							/>
							<Field name='cup.professionalLiability' label='Professional Liability' component={RadioButton} disabled />
							<Field
								name='cup.clergyProfessionalCount'
								label='Number of Clergy Professional'
								fieldDisplay={visibility['cup.clergyProfessionalCount']}
								component={InputNumber}
								maxLength='3'
								width='tiny'
							/>
							<Field
								name='cup.barbersBeuticiansCount'
								label='Number of Barbers/Beauticians'
								fieldDisplay={visibility['cup.barbersBeuticiansCount']}
								component={InputNumber}
								maxLength='3'
								width='tiny'
							/>
							<Field
								name='cup.veterinariansCount'
								label='Number of Veterinarians'
								fieldDisplay={visibility['cup.veterinariansCount']}
								component={InputNumber}
								maxLength='3'
								width='tiny'
							/>
							<Field
								name='cup.funeralDirectorsMorticiansCount'
								label='Number of Funeral Directors/Morticians'
								fieldDisplay={visibility['cup.funeralDirectorsMorticiansCount']}
								component={InputNumber}
								maxLength='3'
								width='tiny'
							/>
							<Field
								name='cup.pharmacistsCount'
								label='Number of Pharmacists'
								fieldDisplay={visibility['cup.pharmacistsCount']}
								component={InputNumber}
								maxLength='3'
								width='tiny'
							/>
							<Field
								name='cup.printersEOCount'
								label="Number of Printer's Errors & Omissions"
								fieldDisplay={visibility['cup.printersEOCount']}
								component={InputNumber}
								maxLength='3'
								width='tiny'
							/>
							<Field
								name='cup.condoDirectorsOfficersCount'
								label='Number of Condominium - Directors and Officers'
								fieldDisplay={visibility['cup.condoDirectorsOfficersCount']}
								component={InputNumber}
								maxLength='3'
								width='tiny'
							/>
							<Field
								name='cup.opticiansOptometristsCount'
								label='Number of Opticians/Optometrists'
								fieldDisplay={visibility['cup.opticiansOptometristsCount']}
								component={InputNumber}
								maxLength='3'
								width='tiny'
							/>
							<Field
								name='cup.seniorCitizensCount'
								label='Number of Senior Citizens Housing Directors & Officers'
								fieldDisplay={visibility['cup.seniorCitizensCount']}
								component={InputNumber}
								maxLength='3'
								width='tiny'
							/>
						</PageSection>
						<NavigationButtons
							formikProps={formikProps}
							back
							location={props.location}
							history={props.history}
							rulesObject={CupPolicyInformationRules}
						/>
					</Form>
				);
			}}
			initialValues={
				quote.cup
					? {
							cup: {
								...quote.cup,
								umbrellaLimit: _.get(quote, 'cup.umbrellaLimit', '1000000'),
								restaurantLiquor: _.get(quote, 'cup.restaurantLiquor', ''),
								underlyingLiability: _.get(quote, 'cup.underlyingLiability', ''),
								payrollExposure: _.get(quote, 'cup.payrollExposure', ''),
								contractingManufacturing: _.get(quote, 'cup.contractingManufacturing', ''),
								allOther: _.get(quote, 'cup.allOther', ''),
								federalTerrorism: _.get(quote, 'cup.federalTerrorism', 'Y'),
								professionalLiability: _.get(quote, 'cup.professionalLiability', ''),
								clergyProfessionalCount: _.get(quote, 'cup.clergyProfessionalCount', ''),
								barbersBeuticiansCount: _.get(quote, 'cup.barbersBeuticiansCount', ''),
								veterinariansCount: _.get(quote, 'cup.veterinariansCount', ''),
								funeralDirectorsMorticiansCount: _.get(quote, 'cup.funeralDirectorsMorticiansCount', ''),
								pharmacistsCount: _.get(quote, 'cup.pharmacistsCount', ''),
								printersEOCount: _.get(quote, 'cup.printersEOCount', ''),
								condoDirectorsOfficersCount: _.get(quote, 'cup.condoDirectorsOfficersCount', ''),
								opticiansOptometristsCount: _.get(quote, 'cup.opticiansOptometristsCount', ''),
								seniorCitizensCount: _.get(quote, 'cup.seniorCitizensCount', ''),
							},
					  }
					: {}
			}
			onSubmit={(values, formikActions) => {
				context.onSubmit(values, dirty, false, false, props, CupPolicyInformationRules);
			}}
			validate={(values) => {
				checkReferrals(context, values, CupPolicyInformationRules, visibility);
				const validResults = validate(
					values,
					CupPolicyInformationRules.rules(quote, values),
					duplicate(CupPolicyInformationRules.requiredStructure),
				);
				logPageErrors(validResults, formProps.touched, 'cup');
				return validResults;
			}}
		/>
	);
};

export default CupPolicyInformationForm;
