import { getFieldDisplayArray } from 'data/FieldVisibility';
import ruleMessagesJson from 'data/RuleMessages';
import _ from 'lodash';
import { getVisibility } from 'utils/ScreenFunctions';
import { isBlank, isBlankZ } from 'utils/StringFunctions';

const { requiredMessageText } = ruleMessagesJson;

class CupPolicyInformationRules {
	static requiredStructure = {
		section_umbrellaPolicy: '',
		section_receipts: '',
		group_receipts: '',
		cup: {
			umbrellaLimit: '',
			restaurantLiquor: '',
			underlyingLiability: '',
			payrollExposure: '',
			contractingManufacturing: '',
			allOther: '',
			federalTerrorism: '',
			professionalLiability: '',
			clergyProfessionalCount: '',
			barbersBeuticiansCount: '',
			veterinariansCount: '',
			funeralDirectorsMorticiansCount: '',
			pharmacistsCount: '',
			printersEOCount: '',
			condoDirectorsOfficersCount: '',
			opticiansOptometristsCount: '',
			seniorCitizensCount: '',
		},
	};

	static rules(quote, values, visibility) {
		if (values && !visibility) {
			visibility = getVisibility(getFieldDisplayArray('commercialUmbrella'), quote, values);
		}

		return {
			section_umbrellaPolicy: [
				[
					(value) => _.size(_.get(quote, 'sfg.locations', {})) < 25,
					'Please remove Commercial Umbrella from your quote due to the number of Safeguard locations. You must contact your underwriter for an umbrella quote.',
				],
				[
					(value) => _.get(quote, 'sfg.liabilityLimit', '') >= 500000,
					'This quote is not elibible for Commercial Umbrella because the Safeguard Liability Limit is less than $500,000',
				],
			],
			section_receipts: [
				[
					(value) =>
						isBlank(_.get(values, 'cup.contractingManufacturing', '')) ||
						_.toNumber(_.get(values, 'cup.contractingManufacturing', '0')) <= 10000000,
					'Please remove Commercial Umbrella from your quote due to Contracting/Manufacturing receipts exposure greater than $10,000,000. You must contact your underwriter for an umbrella quote.',
				],
				[
					(value) =>
						isBlank(_.get(values, 'cup.allOther', '')) || _.toNumber(_.get(values, 'cup.allOther', '')) <= 20000000,
					'Please remove Commercial Umbrella from your quote due to All Other receipts exposure greater than $20,000,000. You must contact your underwriter for an umbrella quote.',
				],
			],
			group_receipts: [
				[
					(value) =>
						!(isBlank(_.get(values, 'cup.contractingManufacturing', '')) && isBlank(_.get(values, 'cup.allOther', ''))),
					'At least one receipt exposure is required',
				],
				[
					(value) =>
						!(
							_.toNumber(_.get(values, 'cup.contractingManufacturing', '')) > 0 &&
							_.toNumber(_.get(values, 'cup.allOther', '')) > 0
						),
					'You must fill in either Contracting Manufacturing or All Other Receipts, but not both.',
				],
			],
			cup: {
				umbrellaLimit: [[(value) => !isBlank(value), requiredMessageText]],
				restaurantLiquor: [[(value) => !isBlank(value) || !visibility['cup.restaurantLiquor'], requiredMessageText]],
				underlyingLiability: [[(value) => !isBlank(value), requiredMessageText]],
				payrollExposure: [[(value) => !isBlankZ(value), requiredMessageText]],
				contractingManufacturing: [[(value) => value <= 10000000, '*']],
				allOther: [[(value) => value <= 20000000, '*']],
				federalTerrorism: [[(value) => !isBlank(value), requiredMessageText]],
				professionalLiability: [[(value) => !isBlank(value), requiredMessageText]],
				clergyProfessionalCount: [
					[(value) => !isBlank(value) || !visibility['cup.clergyProfessionalCount'], requiredMessageText],
				],
				barbersBeuticiansCount: [
					[(value) => !isBlank(value) || !visibility['cup.barbersBeuticiansCount'], requiredMessageText],
				],
				veterinariansCount: [
					[(value) => !isBlank(value) || !visibility['cup.veterinariansCount'], requiredMessageText],
				],
				funeralDirectorsMorticiansCount: [
					[(value) => !isBlank(value) || !visibility['cup.funeralDirectorsMorticiansCount'], requiredMessageText],
				],
				pharmacistsCount: [[(value) => !isBlank(value) || !visibility['cup.pharmacistsCount'], requiredMessageText]],
				printersEOCount: [[(value) => !isBlank(value) || !visibility['cup.printersEOCount'], requiredMessageText]],
				condoDirectorsOfficersCount: [
					[(value) => !isBlank(value) || !visibility['cup.condoDirectorsOfficersCount'], requiredMessageText],
				],
				opticiansOptometristsCount: [
					[(value) => !isBlank(value) || !visibility['cup.opticiansOptometristsCount'], requiredMessageText],
				],
				seniorCitizensCount: [
					[(value) => !isBlank(value) || !visibility['cup.seniorCitizensCount'], requiredMessageText],
				],
			},
		};
	}

	static referrals(context, values) {
		return {
			cup: {
				underlyingLiability: [[(value) => value !== 'Y', 'UMP01']],
				restaurantLiquor: [[(value) => value !== 'Y', 'UMP02']],
				umbrellaLimit: [[(value) => value <= 1000000, 'UMP03']],
			},
		};
	}

	static name() {
		return 'CupPolicyInformationForm';
	}
}
export default CupPolicyInformationRules;
