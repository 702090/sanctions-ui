import { differenceInYears } from 'date-fns';
import { daysFromDate, daysFromNow, isValidDate } from 'utils/DateFunctions';
import { isBlank } from 'utils/StringFunctions';

class CupLossRules {
	static requiredStructure = {
		dateOfClaim: '',
		dateReported: '',
		status: '',
		lossDescription: '',
		section_payments: '',
	};

	static optionalStructure = {
		coverage1AmountPaid: '',
		coverage1ReserveAmount: '',
		coverage2AmountPaid: '',
		coverage2ReserveAmount: '',
		coverage3AmountPaid: '',
		coverage3ReserveAmount: '',
	};

	static rules(quote, values) {
		// use values for current page validation
		// use quote for external page validation
		return {
			dateOfClaim: [
				[(value) => !isBlank(value), 'Date of Claim is required.'],
				[(value) => isValidDate(value), 'You must enter a valid date.'],
				[
					(value) => differenceInYears(new Date(quote.effectiveDate), new Date(value)) < 3,
					'Valid ranges are from effective date to 3 years in the past. Please verify your date is correct.',
				],
				[(value) => daysFromNow(value) <= 0, 'Future dates are not allowed. Please verify your date is correct.'],
			],
			dateReported: [
				[(value) => !isBlank(value), 'Date Reported is required.'],
				[(value) => isValidDate(value), 'You must enter a valid date.'],
				[
					(value) => differenceInYears(new Date(quote.effectiveDate), new Date(value)) < 3,
					'Valid ranges are from effective date to 3 years in the past. Please verify your date is correct.',
				],
				[(value) => daysFromNow(value) <= 0, 'Future dates are not allowed. Please verify your date is correct.'],
				[
					(value) => daysFromDate(values.dateOfClaim, value) <= 0,
					'Date Reported cannot come before the Date of Claim. Please verify your date is correct.',
				],
			],
			status: [[(value) => !isBlank(value), 'Claim Status is required.']],
			lossDescription: [[(value) => !isBlank(value), 'Loss Description is required.']],
			section_payments: [
				[
					(value) =>
						!(
							(isBlank(values.coverage1AmountPaid) || values.coverage1AmountPaid === 0) &&
							(isBlank(values.coverage1ReserveAmount) || values.coverage1ReserveAmount === 0) &&
							(isBlank(values.coverage2AmountPaid) || values.coverage2AmountPaid === 0) &&
							(isBlank(values.coverage2ReserveAmount) || values.coverage2ReserveAmount === 0) &&
							(isBlank(values.coverage3AmountPaid) || values.coverage3AmountPaid === 0) &&
							values.status !== 'CN'
						),
					'Must enter at least one payment or reserve amount.',
				],
			],
		};
	}

	static referrals(context, values) {
		return {};
	}

	static name() {
		return 'cupLossHistory';
	}
}

export default CupLossRules;
