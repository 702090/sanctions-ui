import CupLossesDashboardRules from 'commercialUmbrella/losses/CupLossesDashboardRules';
import { CupLossModal } from 'commercialUmbrella/losses/CupLossModal';
import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { DisplayTable } from 'components/shared/displayTable';
import { RadioToggle } from 'components/shared/form/RadioToggle';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { toSortedPairList } from 'components/shared/navigation/NavigationFunctions';
import { PageSection } from 'components/shared/sections/PageSection';
import { Spinner } from 'components/shared/wait/Spinner';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import { Field, Form, Formik } from 'formik';
import { dashboardClueCall } from 'helper/Clue';
import { runAllCupLossRules } from 'helper/Validation';
import _ from 'lodash';
import React, { Component } from 'react';
import { saveQuote } from 'services/quoteService';
import { duplicate } from 'utils/ObjectFunctions';
import { cleanValues, getVisibility, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { getClaimStatus } from 'utils/StringFunctions';
import { checkReferrals, validate } from 'validation/Validate';

export default class CupLossesDashboard extends Component {
	static contextType = QuoteContext;

	visibility = {};
	dirty = false;
	formProps = {};

	state = { sorting: { column: null, direction: null }, updated: false };

	constructor() {
		super();
		this.lossHistory = React.createRef();
	}

	async UNSAFE_componentWillMount() {
		const losses = _.get(this.context.quote, 'cup.losses', {});
		await dashboardClueCall(this.context, this.props, 'cup');
		this.setState({ losses, lossList: _.toPairs(losses), updated: true });
	}

	componentDidMount() {
		// If the form is not empty, trigger validation
		runRulesOnLoad(this.formProps, this.formProps.initialValues, ['']);
	}

	componentDidUpdate() {
		if (!this.state.updated) {
			const losses = _.get(this.context.quote, 'cup.losses', {});
			this.setState({ losses, updated: true, lossList: _.toPairs(losses) });
		}
	}

	handleSort = (clickedColumn, defaultDirection) => () => {
		const { quote } = this.context;
		let { column, direction } = this.state.sorting;
		let { lossList } = this.state;
		if (defaultDirection || column !== clickedColumn) {
			direction = defaultDirection || 'ascending';
			switch (clickedColumn) {
				case 'dateOfClaim':
					lossList = toSortedPairList(_.get(quote, 'cup.losses', {}), 'dateOfClaim');
					break;
				case 'status':
					lossList = toSortedPairList(_.get(quote, 'cup.losses', {}), 'status');
					break;
				case 'totalAmountPaid':
					lossList = toSortedPairList(_.get(quote, 'cup.losses', {}), 'totalAmountPaid');
					break;
				case 'totalReserveAmount':
					lossList = toSortedPairList(_.get(quote, 'cup.losses', {}), 'totalReserveAmount');
					break;
				default:
					lossList = _.toPairs(_.get(quote, 'cup.losses', {}));
			}
		} else {
			lossList = lossList.reverse();
			direction = direction === 'ascending' ? 'descending' : 'ascending';
		}
		this.setState({
			lossList,
			sorting: {
				direction,
				column: clickedColumn,
			},
		});
	};

	handleDelete = (id) => {
		const updatedQuote = this.context.quote;
		const newLosses = _.pickBy(this.state.losses, (loss) => loss.id !== id);

		_.set(updatedQuote, 'cup.losses', newLosses);
		saveQuote(updatedQuote);
		this.formProps.validateForm(this.formProps.values);

		this.context.quote = updatedQuote;
		// this.setState({ losses, lossList: _.toPairs(losses) });
		this.setState({ losses: newLosses, lossList: _.toPairs(newLosses) });
	};

	callback = () => {
		this.rulesOnLoad = false;
		runRulesOnLoad(this.formProps, this.formProps.initialValues, ['']);
		this.handleSort(this.state.sorting.column, this.state.sorting.direction || true)();
	};

	render() {
		const { quote } = this.context;
		let errorStructure = {};
		return this.context.serviceStatus.clue ? (
			<React.Fragment>
				<PageSection title='Losses' name='section_losses_cup'>
					<Spinner label='Searching for Losses...' />
				</PageSection>
			</React.Fragment>
		) : (
			<React.Fragment>
				<CupLossModal onSubmit={this.context.onLossHistoryModalSubmit} ref={this.lossHistory} />
				<Formik
					render={(formikProps) => {
						this.formProps = formikProps;
						this.dirty = formikProps.dirty;
						this.visibility = getVisibility(
							getFieldDisplayArray('commercialUmbrellaLosses'),
							quote,
							formikProps.values,
						);
						cleanValues(formikProps.values, this.visibility);
						checkReferrals(this.context, formikProps.values, CupLossesDashboardRules, this.visibility);

						// TODO: NATE, I don't like how I did this. There should be a better way
						/*
                This is here because when you delete a loss then click next, the next button puts that loss back onto the quote.
                */
						_.set(formikProps.values, 'cup.losses', _.get(quote, 'cup.losses'));
						return (
							<Form id='screen'>
								<PageSection title='Losses' name='section_losses_cup' errors={formikProps.errors}>
									{this.visibility.noLosses
										? toSortedPairList(_.get(quote, 'cup.lossMessages', {})).map((message) => (
												<div className='lossMessage' key={message[0]}>
													{message[1].lexisNexisMessage}
												</div>
										  ))
										: ''}

									<div id='dashboardButtons' className='left'>
										<SimpleButton
											onClick={() =>
												this.lossHistory.current.handleOpen(
													'NEW',
													{},
													this.callback,
													this.props.location,
													this.props.history,
												)
											}
											primary
											content='Add Loss'
										/>
									</div>

									<div className='lossHistoryDashboard'>
										<Field
											name='cup.noLosses'
											label='No Losses in the past 3 years'
											component={RadioToggle}
											className='singleCheckbox'
											fieldDisplay={this.visibility.noLosses}
										/>
										{!this.visibility.noLosses && (
											<React.Fragment>
												<DisplayTable
													display={this.state.lossList}
													handleSort={this.handleSort}
													{...this.state.sorting}
													handleDelete={this.handleDelete}
													reference={this.lossHistory}
													callBack={this.callback}
													columns={[
														{
															name: 'lossDescription',
															display: 'Description',
															truncate: 48,
														},
														{ name: 'claimNumber', display: 'Claim Number' },
														{ name: 'dateOfClaim', display: 'Date Of Loss' },
														{
															name: 'status',
															display: 'Status',
															transform: getClaimStatus,
														},
														{
															name: 'totalAmountPaid',
															display: 'Total Paid Amount',
															type: 'currency',
														},
														{
															name: 'totalReserveAmount',
															display: 'Total Reserve Amount',
															type: 'currency',
														},
														{
															name: '',
															deletable: 'fromLexisNexis',
															noSort: true,
														},
													]}
													errors={formikProps.errors}
													location={this.props.location}
													history={this.props.history}
												/>
											</React.Fragment>
										)}
									</div>
								</PageSection>
								<NavigationButtons
									formikProps={formikProps}
									back
									location={this.props.location}
									history={this.props.history}
								/>
							</Form>
						);
					}}
					initialValues={
						quote.cup
							? {
									cup: {
										...quote.cup,
										noLosses: quote.cup.noLosses || false,
									},
							  }
							: {}
					}
					onSubmit={(values, formikActions) => this.context.onSubmit(values, this.dirty, false, false, this.props)}
					validate={(values) => {
						checkReferrals(this.context, values, CupLossesDashboardRules, this.visibility);
						const validResults = validate(
							values,
							CupLossesDashboardRules.rules(quote, values, this.visibility),
							duplicate(CupLossesDashboardRules.requiredStructure),
						);
						errorStructure = runAllCupLossRules(this.context.quote, true);
						_.merge(validResults, errorStructure);
						logPageErrors(validResults, this.formProps.touched, 'cup');
						return validResults;
					}}
				/>
			</React.Fragment>
		);
	}
}
