import { getFieldDisplayArray } from 'data/FieldVisibility';
import _ from 'lodash';
import { getVisibility } from 'utils/ScreenFunctions';

class CupLossesDashboardRules {
	static requiredStructure = {
		section_losses_cup: '',
		cup: { noLosses: false },
	};

	static rules(quote, values, visibility) {
		// use values for current page validation
		// use quote for external page validation
		if (!visibility) {
			visibility = getVisibility(getFieldDisplayArray('commercialUmbrellaLosses'), quote, values);
		}

		return {
			cup: {
				noLosses: [
					[
						(value) => value || !visibility.noLosses,
						'Please verify there have been no losses in the past three years. If no losses, please check the box stating this to continue with this quote.',
					],
				],
			},
		};
	}

	static referrals(context, values) {
		return {
			section_losses_cup: [
				[(value) => _.size(_.get(context, 'quote.cup.losses', {})) < 3, 'UML01'],
				[(value) => getTotalPaidAmount(context.quote) < 10000, 'UML02'],
			],
		};
	}

	static name() {
		return 'cupLossesDashboard';
	}
}

function getTotalPaidAmount(quote) {
	const losses = _.get(quote, 'cup.losses', {});
	let totalAmountPaid = 0;

	Object.keys(losses).forEach((key) => {
		totalAmountPaid += losses[key].totalAmountPaid;
	});

	return totalAmountPaid;
}

export default CupLossesDashboardRules;
