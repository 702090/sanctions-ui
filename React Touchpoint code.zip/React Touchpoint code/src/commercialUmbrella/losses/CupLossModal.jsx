import CupLossForm from 'commercialUmbrella/losses/CupLossForm';
import { ModalStepper } from 'components/shared/navigation/ModalStepper';
import QuoteContext from 'context/quoteContext';
import React, { Component } from 'react';
import { Modal } from 'semantic-ui-react';
import { pageAnalytics } from 'utils/ScreenFunctions';
import { replaceReferrals } from 'validation/RunReferrals';

export class CupLossModal extends Component {
	static contextType = QuoteContext;

	constructor() {
		super();
		this.state = {
			isOpen: false,
		}; // state to control the state of popup
	}

	handleOpen = (lossId, lossHistory, callBack, location, history) => {
		this.setState({
			isOpen: true,
			lossId,
			lossHistory,
			callBack,
			location,
			history,
		});
		pageAnalytics(location.pathname + '/CupLossModal', true);
	};

	handleClose = () => {
		this.state.callBack();
		replaceReferrals(this.context);
		pageAnalytics(this.state.location.pathname);
		this.setState({ isOpen: false });
	};

	render() {
		const { lossId, lossHistory, location, history } = this.state;
		return (
			<Modal closeIcon open={this.state.isOpen} closeOnDimmerClick={false} onClose={this.handleClose}>
				<ModalStepper currentModal='cupLosses' handleClose={this.handleClose} />
				<Modal.Content>
					<CupLossForm
						id={lossId}
						lossHistory={lossHistory}
						handleClose={this.handleClose}
						location={location}
						history={history}
					/>
				</Modal.Content>
			</Modal>
		);
	}
}
