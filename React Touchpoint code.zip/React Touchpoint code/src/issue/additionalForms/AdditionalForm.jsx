import { isBlank } from '@columbiainsurance/functions-js';
import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import React, { useRef, useContext } from 'react';
import { Message } from 'semantic-ui-react';
import _ from 'lodash';
import quoteContext from 'context/quoteContext';

const AdditionalForm = ({
	form,
	downloadFile,
	handleUploadNow,
	handleDelete,
	handleUploadLater,
	formikProps,
	...props
}) => {
	const context = useContext(quoteContext);
	const inputReference = useRef();
	return (
		<div className='additionalFormFlex' key={form[0]}>
			<a href={form[1].pdfPath} target='_blank' rel='noopener noreferrer'>
				{form[1].formTitle}
			</a>
			{isBlank(form[1].attachmentURL) ? (
				<React.Fragment>
					<input
						type='file'
						ref={inputReference}
						onChange={(value) => handleUploadNow(value, form[1].quotePath, formikProps)}
						style={{ display: 'none' }}
					/>
					{_.get(formikProps, `values.${form[1].quotePath}.uploadStatus`, '') === 'Will Upload' ? (
						<div>
							<span>Changed your mind?</span>
							<SimpleButton onClick={(e) => inputReference.current.click()} content='Upload Now' type='button' />
						</div>
					) : (
						<div>
							<Message negative size='mini'>
								<p>Please select whether to upload now or later.</p>
							</Message>
							<SimpleButton onClick={(e) => inputReference.current.click()} content='Upload Now' type='button' />
							<SimpleButton
								onClick={(e) => handleUploadLater(form[1].quotePath, formikProps)}
								content='Upload Later'
								type='button'
							/>
						</div>
					)}
				</React.Fragment>
			) : (
				<React.Fragment>
					{_.toPairs(form[1].attachmentURL).map((attachment) => (
						<div key={attachment[0]}>
							<span
								className='attachmentText'
								onClick={(e) => downloadFile(attachment[0], context, `${form[1].quotePath}.attachments`)}
							>
								{attachment[1].name}
							</span>
							<SimpleButton
								className='delete'
								content=''
								onClick={(e) => handleDelete(e, attachment[0], form[1].quotePath, formikProps)}
								id={attachment[0]}
								icon='delete'
							/>
						</div>
					))}
				</React.Fragment>
			)}
		</div>
	);
};

export default AdditionalForm;
