import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import quoteContext from 'context/quoteContext';
import additionalFormsJson from 'data/AdditionalForms';
import { Form, Formik } from 'formik';
import _ from 'lodash';
import React, { useContext, useEffect } from 'react';
import { getPredState } from 'utils/BusinessFunctions';
import {
	needsCupTerrorismExclusion,
	needsILMineSubsidenceRejection,
	needsMOEPLIAcknowledgement,
	needsSfgTerrorismExclusion,
} from 'utils/FieldDisplay';
import { deleteFile, downloadFile, uploadFile } from 'utils/FileFunctions';
import { cleanValues, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import AdditionalForm from './AdditionalForm';

const AdditionalForms = (props) => {
	const context = useContext(quoteContext);
	const { quote } = context;

	let dirty = false;
	let formProps;

	const { additionalForms } = additionalFormsJson;

	const defaultValues = {
		additionalForms: {
			ilMineSubsidence: {
				uploadStatus: '',
				diaryLength: '',
				attachments: {},
				prod: 'sfg',
			},
			sfgTerrorismExclusion: {
				uploadStatus: '',
				diaryLength: '',
				attachments: {},
				prod: 'sfg',
			},
			cupTerrorismExclusion: {
				uploadStatus: '',
				diaryLength: '',
				attachments: {},
				prod: 'cup',
			},
			moEPLIAcknowledgement: {
				uploadStatus: '',
				diaryLength: '',
				attachments: {},
				prod: 'sfg',
			},
		},
	};

	useEffect(() => {
		// If the form is not empty, trigger validation
		runRulesOnLoad(formProps, formProps.initialValues, ['id']);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	async function handleUploadNow(event, storePath, formikProps) {
		try {
			// This is a bit redundant but easier. The first bit sets to the quote, the second to the form for nav purposes
			const additionalInfo = {
				uploadStatus: 'Uploaded',
				diaryLength: 5,
				prod: _.get(defaultValues, `${storePath}.prod`, ''),
			};
			const didUpload = await uploadFile(event, context, storePath, additionalInfo);
			if (didUpload) {
				formikProps.setFieldValue(`${storePath}.uploadStatus`, 'Uploaded');
				formikProps.setFieldValue(`${storePath}.diaryLength`, 5);
				formikProps.setFieldValue(`${storePath}.prod`, _.get(defaultValues, `${storePath}.prod`, ''));
				dirty = true;
			}
		} catch (err) {
			console.error('Error: ', err);
			formikProps.setFieldValue(`${storePath}.attachments`, {});
		}
	}

	function handleUploadLater(storePath, formikProps) {
		formikProps.setFieldValue(`${storePath}.uploadStatus`, 'Will Upload');
		formikProps.setFieldValue(`${storePath}.diaryLength`, 30);
		formikProps.setFieldValue(`${storePath}.prod`, _.get(defaultValues, `${storePath}.prod`, ''));
		dirty = true;
	}

	async function handleDelete(event, id, storePath, formikProps) {
		try {
			await deleteFile(id, context, `${storePath}.attachments`);
			formikProps.setFieldValue(`${storePath}.attachments`, {});
			formikProps.setFieldValue(`${storePath}.uploadStatus`, '');
			formikProps.setFieldValue(`${storePath}.diaryLength`, 30);
			formikProps.setFieldValue(`${storePath}.prod`, _.get(defaultValues, `${storePath}.prod`, ''));
			dirty = true;
		} catch (err) {
			console.error('Error: ', err);
			formikProps.setFieldValue(`${storePath}.attachments`, _.get(context, `quote.${storePath}.attachments`, {}));
		}
	}

	// Used to determine if forms should be displayed on the screen
	function includeForms() {
		let formArray = [];
		const stateLookup = getPredState(quote);
		const baseURL = 'https://portal.colinsgrp.com/pdfs/';
		let pdfPath;

		if (needsILMineSubsidenceRejection(quote)) {
			pdfPath = `${baseURL}${additionalForms[stateLookup].ilMineSubsidence.sfg}`;
			formArray.push({
				formTitle: 'Illinois Notice and Waiver of Mine Subsidence Coverage',
				quotePath: 'additionalForms.ilMineSubsidence',
				pdfPath,
				attachmentURL: _.get(quote, 'additionalForms.ilMineSubsidence.attachments', {}),
			});
		}
		if (needsSfgTerrorismExclusion(quote)) {
			pdfPath = `${baseURL}${additionalForms[stateLookup].terrorismExclusion.sfg}`;
			formArray.push({
				formTitle: 'Safeguard Terrorism Exclusion',
				quotePath: 'additionalForms.sfgTerrorismExclusion',
				pdfPath,
				attachmentURL: _.get(quote, 'additionalForms.sfgTerrorismExclusion.attachments', {}),
			});
		}
		if (needsCupTerrorismExclusion(quote)) {
			pdfPath = `${baseURL}${additionalForms[stateLookup].terrorismExclusion.cup}`;
			formArray.push({
				formTitle: 'Commercial Umbrella Terrorism Exclusion',
				quotePath: 'additionalForms.cupTerrorismExclusion',
				pdfPath,
				attachmentURL: _.get(quote, 'additionalForms.cupTerrorismExclusion.attachments', {}),
			});
		}
		if (needsMOEPLIAcknowledgement(quote)) {
			pdfPath = `${baseURL}${additionalForms[stateLookup].epliAcknowledgement.sfg}`;
			formArray.push({
				formTitle: 'Missouri EPLI Acknowledgement of Defense Costs',
				quotePath: 'additionalForms.moEPLIAcknowledgement',
				pdfPath,
				attachmentURL: _.get(quote, 'additionalForms.moEPLIAcknowledgement.attachments', {}),
			});
		}

		return formArray;
	}

	function disableNext(formikProps) {
		return (
			(needsILMineSubsidenceRejection(quote) &&
				isBlank(_.get(formikProps, 'values.additionalForms.ilMineSubsidence.uploadStatus', ''))) ||
			(needsSfgTerrorismExclusion(quote) &&
				isBlank(_.get(formikProps, 'values.additionalForms.sfgTerrorismExclusion.uploadStatus', ''))) ||
			(needsCupTerrorismExclusion(quote) &&
				isBlank(_.get(formikProps, 'values.additionalForms.cupTerrorismExclusion.uploadStatus', ''))) ||
			(needsMOEPLIAcknowledgement(quote) &&
				isBlank(_.get(formikProps, 'values.additionalForms.moEPLIAcknowledgement.uploadStatus', '')))
		);
	}

	function clearUnneededForms(values) {
		if (!needsILMineSubsidenceRejection(quote)) {
			_.unset(values, 'additionalForms.ilMineSubsidence');
			_.unset(quote, 'additionalForms.ilMineSubsidence');
		}
		if (!needsSfgTerrorismExclusion(quote)) {
			_.unset(values, 'additionalForms.sfgTerrorismExclusion');
			_.unset(quote, 'additionalForms.sfgTerrorismExclusion');
		}
		if (!needsCupTerrorismExclusion(quote)) {
			_.unset(values, 'additionalForms.cupTerrorismExclusion');
			_.unset(quote, 'additionalForms.cupTerrorismExclusion');
		}
		if (!needsMOEPLIAcknowledgement(quote)) {
			_.unset(values, 'additionalForms.moEPLIAcknowledgement');
			_.unset(quote, 'additionalForms.moEPLIAcknowledgement');
		}
	}

	return (
		<Formik
			render={(formikProps) => {
				formProps = formikProps;
				cleanValues(formikProps.values, []);
				dirty = dirty || formikProps.dirty;
				const formArray = includeForms();
				return (
					<Form id='screen'>
						<PageSection title='Additional Forms Required'>
							{_.toPairs(formArray).map((form) => {
								return (
									<AdditionalForm
										form={form}
										downloadFile={downloadFile}
										handleUploadNow={handleUploadNow}
										handleDelete={handleDelete}
										handleUploadLater={handleUploadLater}
										key={form[0]}
										formikProps={formikProps}
									/>
								);
							})}
							<hr noshade />
						</PageSection>
						<NavigationButtons
							formikProps={formikProps}
							back
							location={props.location}
							history={props.history}
							disableNext={disableNext(formikProps)}
						/>
					</Form>
				);
			}}
			initialValues={{
				additionalForms: _.merge(defaultValues.additionalForms, quote.additionalForms),
			}}
			onSubmit={(values, formikActions) => {
				cleanValues(values, []);
				clearUnneededForms(values);
				context.onSubmit(values, dirty, false, false, props);
			}}
		/>
	);
};

export default AdditionalForms;
