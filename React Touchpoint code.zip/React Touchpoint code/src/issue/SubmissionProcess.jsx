import { InformationMessage } from 'components/shared/messages/InformationMessage';
import { MultiProgressBar, processSteps } from 'components/shared/progress/MultiProgressBar';
import QuoteContext from 'context/quoteContext';
import submissionStepsJson from 'data/SubmissionSteps';
import { kickoffProcess } from 'issue/SubmissionHelper';
import _ from 'lodash';
import React, { useContext, useEffect, useState } from 'react';
import { getProdIcon } from 'utils/BusinessFunctions';
import { duplicate } from 'utils/ObjectFunctions';

const SubmissionProcess = (props) => {
	const context = useContext(QuoteContext);
	const { quote } = context;
	const { submissionSteps } = submissionStepsJson;

	const [progressSFG, setProgressSFG] = useState({
		step: 1,
		label: 'Generating Policy #',
		error: false,
	});
	const [progressCAP, setProgressCAP] = useState({
		step: 0,
		label: 'Waiting to Start',
		error: false,
	});
	const [progressWCP, setProgressWCP] = useState({
		step: 0,
		label: 'Waiting to Start',
		error: false,
	});
	const [progressCUP, setProgressCUP] = useState({
		step: 0,
		label: 'Waiting to Start',
		error: false,
	});
	const [bars, setBars] = useState([]);
	const [started, setStarted] = useState(false);
	const steps = processSteps(submissionSteps);

	const advanceBar = (prod, skip, message) => {
		switch (prod) {
			case 'sfg':
				progressSFG.step = progressSFG.step + 1 + (skip ? skip : 0);
				progressSFG.label = steps[progressSFG.step].label;
				if (message) {
					progressSFG.error = message;
				}
				setProgressSFG(duplicate(progressSFG));
				break;
			case 'cap':
				progressCAP.step = progressCAP.step + 1 + (skip ? skip : 0);
				progressCAP.label = steps[progressCAP.step].label;
				if (message) {
					progressCAP.error = message;
				}
				setProgressCAP(duplicate(progressCAP));
				break;
			case 'wcp':
				progressWCP.step = progressWCP.step + 1 + (skip ? skip : 0);
				progressWCP.label = steps[progressWCP.step].label;
				if (message) {
					progressWCP.error = message;
				}
				setProgressWCP(duplicate(progressWCP));
				break;
			case 'cup':
				progressCUP.step = progressCUP.step + 1 + (skip ? skip : 0);
				progressCUP.label = steps[progressCUP.step].label;
				if (message) {
					progressCUP.error = message;
				}
				setProgressCUP(duplicate(progressCUP));
				break;
			default:
		}
	};

	useEffect(() => {
		if (!started && quote.id) {
			kickoffProcess(props, context, quote, advanceBar);
			setStarted(true);
		}

		let newBars = [
			{
				name: 'sfg',
				prod: getProdIcon('sfg', 'big'),
				label: steps[progressSFG.step].label,
				step: steps[progressSFG.step].location,
				error: progressSFG.error,
			},
		];
		if (_.includes(quote.products, 'cap')) {
			newBars.push({
				name: 'cap',
				prod: getProdIcon('cap', 'big'),
				label: steps[progressCAP.step].label,
				step: steps[progressCAP.step].location,
				error: progressCAP.error,
			});
		}
		if (_.includes(quote.products, 'wcp')) {
			newBars.push({
				name: 'wcp',
				prod: getProdIcon('wcp', 'big'),
				label: steps[progressWCP.step].label,
				step: steps[progressWCP.step].location,
				error: progressWCP.error,
			});
		}
		if (_.includes(quote.products, 'cup')) {
			newBars.push({
				name: 'cup',
				prod: getProdIcon('cup', 'big'),
				label: steps[progressCUP.step].label,
				step: steps[progressCUP.step].location,
				error: progressCUP.error,
			});
		}
		setBars(newBars);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [progressSFG, progressCAP, progressWCP, progressCUP, quote.products]);

	return (
		<React.Fragment>
			<InformationMessage
				key='dontcloseme'
				message='Please do NOT close or refresh this page. If you do your policy may not be processed. This process can take up to several minutes per product to complete.'
				fieldDisplay
			/>
			<MultiProgressBar
				id='stpProgress'
				bars={bars}
				steps={['Policy Set Up', 'Policy Bound', 'Policy Verified', 'Policy Issued']}
			/>
		</React.Fragment>
	);
};

export default SubmissionProcess;
