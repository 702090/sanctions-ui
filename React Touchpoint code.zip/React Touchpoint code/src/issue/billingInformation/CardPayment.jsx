import { getPage } from 'components/shared/navigation/NavigationFunctions';
import QuoteContext from 'context/quoteContext';
import _ from 'lodash';
import React, { Component } from 'react';
import { cashSlipStatus, downpaymentCard } from 'services/downpaymentService';

export default class CardPayment extends Component {
	static contextType = QuoteContext;

	dirty = false;

	state = { downPaymentInfo: null };

	cardCheck = {};

	handlePaymentReturn = (quote, slipInfo, bankMessage, direction) => {
		clearInterval(this.cardCheck);
		quote.billing.cashSlip = slipInfo;
		quote.billing.bankMessage = bankMessage;

		this.context.updateQuoteState(quote);

		const moveToPage = getPage(this.props.location.pathname, direction, this.context.navigation.navItems);
		this.props.history.push(moveToPage);
	};

	async componentDidMount() {
		const { quote } = this.context;

		const paymentData = await downpaymentCard(quote);
		const jsonStr = JSON.stringify(paymentData);
		const encode = encodeURI(jsonStr);

		const downPaymentInfo = encode;

		this.setState({
			downPaymentInfo,
		});

		this.cardCheck = setInterval(async () => {
			const slipInfo = await cashSlipStatus(paymentData.referenceNo);
			const paymentStatus = _.get(slipInfo, 'status', '');
			const bankMessage = _.get(slipInfo, 'bankMessage', '');
			if (paymentStatus === 'Approval') {
				this.handlePaymentReturn(quote, slipInfo, bankMessage, 'progress');
			} else if (paymentStatus === 'Failure') {
				this.handlePaymentReturn(quote, slipInfo, bankMessage, 'cardDeclined');
			}
		}, 1500);
	}

	componentWillUnmount() {
		clearInterval(this.cardCheck);
		this.cardCheck = 0;
	}

	render() {
		const { downPaymentInfo } = this.state;

		if (!downPaymentInfo) {
			return <div />;
		}
		const bankUrl = `${process.env.REACT_APP_CARD_FRAME}?downPaymentInfo=${downPaymentInfo}`;

		return (
			<iframe name='myFrame' title='myFrame' id='myFrame' frameBorder='0' src={bankUrl} width='100%' height='1100' />
		);
	}
}
