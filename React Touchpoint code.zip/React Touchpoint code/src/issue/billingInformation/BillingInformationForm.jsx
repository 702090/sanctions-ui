import { InputAddress } from 'components/shared/form/inputs/InputAddress';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputText } from 'components/shared/form/inputs/InputText';
import { RadioButton } from 'components/shared/form/RadioButton';
import { InformationMessage } from 'components/shared/messages/InformationMessage';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import { Spinner } from 'components/shared/wait/Spinner';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import productNamesJson from 'data/ProductNames';
import selectOptionsJson from 'data/SelectOptions';
import { Field, Form, Formik } from 'formik';
import BillingInformationRules from 'issue/billingInformation/BillingInformationRules';
import _ from 'lodash';
import React, { Component } from 'react';
import { validateBankAccountRoutingNumber } from 'services/downpaymentService';
import { isAccountValid } from 'services/verifyAccountService';
import { getMinimumDownPayment } from 'utils/BusinessFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import { cleanValues, getVisibility, logPageErrors, parseAddress } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { validate } from 'validation/Validate';

let visibility = {};
let formProps;

const { billing_billingType, billing_checkingSavings, billing_downPaymentMethod } = selectOptionsJson;
const { productNames } = productNamesJson;

export default class BillingInformationForm extends Component {
	static contextType = QuoteContext;

	dirty = false;
	initialValues = {};
	billingTypeOptions = [];
	downPaymentMethodOptions = [];
	accountRoutingValidationResults = {};
	state = { gettingCashSlip: false, waitingForBillingValidation: false };

	verifyAccountBill = async (e, formikProps) => {
		const validAccount = await isAccountValid(_.get(formikProps, 'values.billing.accountBillNumber', '').toUpperCase());
		formikProps.setFieldValue('billing.accountBillNumberValid', validAccount);
	};

	validateAccountRoutingNumber = async (e, formikProps) => {
		if (formikProps.dirty) {
			let bankAccount;
			let routingNumber;
			if (visibility['billing.bankAccountNumber']) {
				bankAccount = _.get(formikProps, 'values.billing.bankAccountNumber', '');
				routingNumber = _.get(formikProps, 'values.billing.bankRoutingNumber', '');
			} else {
				bankAccount = _.get(formikProps, 'values.billing.downPayment.accountNumber', '');
				routingNumber = _.get(formikProps, 'values.billing.downPayment.routingNumber', '');
			}
			if (!isBlank(bankAccount) && !isBlank(routingNumber)) {
				this.context.updateServiceStatus('runningAccountRoutingNumberValidation', true);
				try {
					this.accountRoutingValidationResults = await validateBankAccountRoutingNumber({ bankAccount, routingNumber });
					formikProps.validateForm(formikProps.values);
				} catch (err) {
					console.error(err);
				}
				this.context.updateServiceStatus('runningAccountRoutingNumberValidation', false);
				this.setState({ ...this.state, waitingForBillingValidation: false });
			}
		}
	};

	UNSAFE_componentWillMount() {
		const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));

		this.billingTypeOptions = _.filter(billing_billingType, (option) => {
			let returnValue = true;

			if (returnValue && agent.branch === '03' && (option.value === 'A01' || option.value === 'AAQ')) {
				returnValue = false;
			}

			if (returnValue && !agent.isAllowAgencyBill && (option.value === 'A01' || option.value === 'AAQ')) {
				returnValue = false;
			}

			return returnValue;
		});

		this.downPaymentMethodOptions = _.filter(billing_downPaymentMethod, (option) => {
			let returnValue = true;

			if (returnValue && !agent.isHasSweepAccount && option.value === 'A') {
				returnValue = false;
			}

			if (returnValue && !agent.isAllowBillableDownpayment && option.value === 'B') {
				returnValue = false;
			}

			// if (returnValue && option.value === 'ICard' && isEmployee()) {
			// 	returnValue = false;
			// }

			return returnValue;
		});
	}

	assignMinimumDownPaymentAmount = (quote, product, billingType) => {
		let downPaymentMin;
		switch (product) {
			case 'sfg':
				downPaymentMin = duplicate(_.get(quote, 'billing.sfgDownPaymentAmount', 0));
				if (isBlank(downPaymentMin) || billingType) {
					downPaymentMin = getMinimumDownPayment(
						quote,
						billingType || _.get(quote, 'billing.billingType', ''),
						product,
					);
				}

				break;

			case 'cap':
				downPaymentMin = duplicate(_.get(quote, 'billing.capDownPaymentAmount', 0));
				if (isBlank(downPaymentMin) || billingType) {
					downPaymentMin = getMinimumDownPayment(
						quote,
						billingType || _.get(quote, 'billing.billingType', ''),
						product,
					);
				}

				break;

			case 'wcp':
				downPaymentMin = duplicate(_.get(quote, 'billing.wcpDownPaymentAmount', 0));

				if (isBlank(downPaymentMin) || billingType) {
					downPaymentMin = getMinimumDownPayment(
						quote,
						billingType || _.get(quote, 'billing.billingType', ''),
						product,
					);
				}

				break;

			case 'cup':
				downPaymentMin = duplicate(_.get(quote, 'billing.cupDownPaymentAmount', 0));
				if (isBlank(downPaymentMin) || billingType) {
					downPaymentMin = getMinimumDownPayment(
						quote,
						billingType || _.get(quote, 'billing.billingType', ''),
						product,
					);
				}

				break;

			default:
				break;
		}

		return downPaymentMin;
	};

	render() {
		const { quote } = this.context;

		if (this.state.gettingCashSlip === true) {
			return (
				<div>
					<Spinner label='Loading Quote...' />
				</div>
			);
		}

		return (
			<Formik
				render={(formikProps) => {
					this.dirty = formikProps.dirty;
					formProps = formikProps;
					visibility = getVisibility(getFieldDisplayArray('billingInformation'), quote, formikProps.values);
					const routingCallRequired =
						visibility['billing.bankRoutingNumber'] || visibility['billing.downPayment.routingNumber'];

					cleanValues(formikProps.values, visibility);

					return (
						<Form id='screen'>
							<PageSection title='Billing Details'>
								<Field
									name='billing.billingType'
									label='Billing Type'
									component={RadioButton}
									options={this.billingTypeOptions}
									additionalOnChange={(value, setFieldValue) => {
										const downPaymentMinSFG = this.assignMinimumDownPaymentAmount(quote, 'sfg', value);
										setFieldValue('billing.sfgDownPaymentAmount', downPaymentMinSFG, false);

										if (_.includes(quote.products, 'cap')) {
											const downPaymentMinCAP = this.assignMinimumDownPaymentAmount(quote, 'cap', value);
											setFieldValue('billing.capDownPaymentAmount', downPaymentMinCAP, false);
										}
										if (_.includes(quote.products, 'wcp')) {
											const downPaymentMinWCP = this.assignMinimumDownPaymentAmount(quote, 'wcp', value);
											setFieldValue('billing.wcpDownPaymentAmount', downPaymentMinWCP, false);
										}
										if (_.includes(quote.products, 'cup')) {
											const downPaymentMinCUP = this.assignMinimumDownPaymentAmount(quote, 'cup', value);
											setFieldValue('billing.cupDownPaymentAmount', downPaymentMinCUP, false);
										}
									}}
								/>
								<InformationMessage
									message='Please complete the Authorization Agreement for Payment by Electronic Funds Transfer, have the insured sign this form and keep in your agent file. '
									fieldDisplay={_.get(formikProps, 'values.billing.billingType', '') === 'E010E'}
									url={{
										href: 'https://portal.colinsgrp.com/pdfs/EFT%20Form%20Fillable.pdf',
										className: 'documentLink',
										label: 'FORM LINK',
									}}
								/>
								<Field
									name='billing.existingAccountBill'
									label='Existing Account with CIG'
									component={RadioButton}
									fieldDisplay={visibility['billing.existingAccountBill']}
								/>
								<Field
									name='billing.accountBillNumber'
									label='Account Number'
									maxLength='10'
									component={InputText}
									fieldDisplay={visibility['billing.accountBillNumber']}
									additionalOnBlur={(e) => this.verifyAccountBill(e, formikProps)}
								/>
							</PageSection>
							{visibility['billing.billingSameAsApplicant'] && (
								<PageSection title='Billing Party'>
									<Field
										name='billing.billingSameAsApplicant'
										label='Billing Party Same As Applicant'
										component={RadioButton}
										fieldDisplay={visibility['billing.billingSameAsApplicant']}
									/>
									<Field
										name='billing.name.firstName'
										label='First Name'
										maxLength='20'
										component={InputText}
										fieldDisplay={visibility['billing.name.firstName']}
									/>
									<Field
										name='billing.name.middleInitial'
										label='Middle Initial'
										maxLength='1'
										width='small'
										optional
										component={InputText}
										fieldDisplay={visibility['billing.name.middleInitial']}
									/>
									<Field
										name='billing.name.lastName'
										label='Last Name'
										maxLength='60'
										component={InputText}
										fieldDisplay={visibility['billing.name.lastName']}
									/>
									<Field
										name='billing.address.fullAddress'
										label='Billing Address'
										component={InputAddress}
										className='geo'
										addressName='billing.address'
										additionalOnChange={parseAddress}
										formikProps={formikProps}
										fieldDisplay={visibility['billing.address.fullAddress']}
									/>
								</PageSection>
							)}
							{visibility['billing.bankAccountType'] && (
								<PageSection title='Monthly Acount Bill Bank Information'>
									<Field
										name='billing.bankAccountType'
										label='Checking or Savings'
										component={RadioButton}
										options={billing_checkingSavings}
										fieldDisplay={visibility['billing.bankAccountType']}
									/>
									<Field
										name='billing.bankName'
										label='Bank Name'
										maxLength='30'
										component={InputText}
										fieldDisplay={visibility['billing.bankName']}
									/>
									<Field
										name='billing.bankRoutingNumber'
										label='Bank Routing Number'
										width='small'
										maxLength='9'
										component={InputText}
										fieldDisplay={visibility['billing.bankRoutingNumber']}
										additionalOnBlur={(e) => {
											this.setState({ ...this.state, waitingForBillingValidation: true });
											this.validateAccountRoutingNumber(e, formikProps);
										}}
										disabled={this.context.serviceStatus.runningAccountRoutingNumberValidation}
									/>
									<Field
										name='billing.bankAccountNumber'
										label='Bank Account Number'
										width='small'
										maxLength='17'
										component={InputText}
										fieldDisplay={visibility['billing.bankAccountNumber']}
										additionalOnBlur={(e) => {
											this.setState({ ...this.state, waitingForBillingValidation: true });
											this.validateAccountRoutingNumber(e, formikProps);
										}}
										disabled={this.context.serviceStatus.runningAccountRoutingNumberValidation}
									/>
								</PageSection>
							)}
							{visibility['billing.downPaymentMethod'] && (
								<PageSection title='Down Payment Information'>
									<Field
										name='billing.downPaymentMethod'
										label='Down Payment Method'
										component={RadioButton}
										options={this.downPaymentMethodOptions}
										fieldDisplay={visibility['billing.downPaymentMethod']}
									/>
									<Field
										name='billing.sfgDownPaymentAmount'
										label={'Down Payment - ' + productNames.sfg}
										maxLength='10'
										component={InputNumber}
										type='currency'
										decimalScale={2}
										fieldDisplay={visibility['billing.sfgDownPaymentAmount']}
										width='small'
									/>
									<Field
										name='billing.capDownPaymentAmount'
										label={'Down Payment - ' + productNames.cap}
										maxLength='10'
										component={InputNumber}
										type='currency'
										decimalScale={2}
										fieldDisplay={visibility['billing.capDownPaymentAmount']}
										width='small'
									/>
									<Field
										name='billing.wcpDownPaymentAmount'
										label={'Down Payment - ' + productNames.wcp}
										maxLength='10'
										component={InputNumber}
										type='currency'
										decimalScale={2}
										fieldDisplay={visibility['billing.wcpDownPaymentAmount']}
										width='small'
									/>
									<Field
										name='billing.cupDownPaymentAmount'
										label={'Down Payment - ' + productNames.cup}
										maxLength='10'
										component={InputNumber}
										type='currency'
										decimalScale={2}
										fieldDisplay={visibility['billing.cupDownPaymentAmount']}
										width='small'
									/>
									<Field
										name='billing.bankAccountSame'
										label='Use Above Bank Account for Downpayment'
										component={RadioButton}
										fieldDisplay={visibility['billing.bankAccountSame']}
									/>
									<Field
										name='billing.downPayment.bankAccountType'
										label='Checking or Savings'
										component={RadioButton}
										options={billing_checkingSavings}
										fieldDisplay={visibility['billing.downPayment.bankAccountType']}
									/>
									<Field
										name='billing.downPayment.bankName'
										label='Down Payment Bank Name'
										maxLength='30'
										component={InputText}
										fieldDisplay={visibility['billing.downPayment.bankName']}
									/>
									<Field
										name='billing.downPayment.routingNumber'
										label='Down Payment Bank Routing Number'
										maxLength='9'
										component={InputText}
										fieldDisplay={visibility['billing.downPayment.routingNumber']}
										additionalOnBlur={(e) => {
											this.setState({ ...this.state, waitingForBillingValidation: true });
											this.validateAccountRoutingNumber(e, formikProps);
										}}
										disabled={this.context.serviceStatus.runningAccountRoutingNumberValidation}
									/>
									<Field
										name='billing.downPayment.accountNumber'
										label='Down Payment Bank Account Number'
										maxLength='17'
										component={InputText}
										fieldDisplay={visibility['billing.downPayment.accountNumber']}
										additionalOnBlur={(e) => {
											this.setState({ ...this.state, waitingForBillingValidation: true });
											this.validateAccountRoutingNumber(e, formikProps);
										}}
										disabled={this.context.serviceStatus.runningAccountRoutingNumberValidation}
									/>
								</PageSection>
							)}
							<NavigationButtons
								formikProps={formikProps}
								back
								completeIssue
								issuing
								location={this.props.location}
								history={this.props.history}
								disableNext={routingCallRequired && this.state.waitingForBillingValidation}
							/>
						</Form>
					);
				}}
				initialValues={{
					billing: {
						billingType: _.get(this.context, 'quote.billing.billingType', ''),
						existingAccountBill: _.get(this.context, 'quote.billing.existingAccountBill', ''),
						accountBillNumber: _.get(this.context, 'quote.billing.accountBillNumber', ''),
						accountBillNumberValid: _.get(this.context, 'quote.billing.accountBillNumberValid', ''),
						billingSameAsApplicant: _.get(this.context, 'quote.billing.billingSameAsApplicant', ''),
						name: {
							firstName: _.get(this.context, 'quote.billing.name.firstName', ''),
							lastName: _.get(this.context, 'quote.billing.name.lastName', ''),
						},
						address: {
							fullAddress: _.get(this.context, 'quote.billing.address.fullAddress', ''),
						},
						bankAccountType: _.get(this.context, 'quote.billing.bankAccountType', ''),
						bankName: _.get(this.context, 'quote.billing.bankName', ''),
						bankRoutingNumber: _.get(this.context, 'quote.billing.bankRoutingNumber', ''),
						bankAccountNumber: _.get(this.context, 'quote.billing.bankAccountNumber', ''),
						downPaymentMethod: _.get(this.context, 'quote.billing.downPaymentMethod', ''),
						sfgDownPaymentAmount: _.get(this.context, 'quote.billing.sfgDownPaymentAmount', ''),
						capDownPaymentAmount: _.get(
							this.context,
							'quote.billing.capDownPaymentAmount',
							_.includes(quote.products, 'cap') ? this.assignMinimumDownPaymentAmount(this.context.quote, 'cap') : '',
						),
						wcpDownPaymentAmount: _.get(
							this.context,
							'quote.billing.wcpDownPaymentAmount',
							_.includes(quote.products, 'wcp') ? this.assignMinimumDownPaymentAmount(this.context.quote, 'wcp') : '',
						),
						cupDownPaymentAmount: _.get(
							this.context,
							'quote.billing.cupDownPaymentAmount',
							_.includes(quote.products, 'cup') ? this.assignMinimumDownPaymentAmount(this.context.quote, 'cup') : '',
						),
						bankAccountSame: _.get(this.context, 'quote.billing.bankAccountSame', ''),
						downPayment: {
							bankAccountType: _.get(this.context, 'quote.billing.downPayment.bankAccountType', ''),
							bankName: _.get(this.context, 'quote.billing.downPayment.bankName', ''),
							routingNumber: _.get(this.context, 'quote.billing.downPayment.routingNumber', ''),
							accountNumber: _.get(this.context, 'quote.billing.downPayment.accountNumber', ''),
						},
					},
				}}
				onSubmit={(values, formikActions) => {
					if (_.get(values, 'billing.accountBillNumber')) {
						_.set(values, 'billing.accountBillNumber', _.get(values, 'billing.accountBillNumber', '').toUpperCase());
					}
					cleanValues(values, visibility);
					return this.context.onSubmit(values, this.dirty, 'billingInformation', false, this.props);
				}}
				validate={(values) => {
					const validResults = validate(
						values,
						BillingInformationRules.rules(this.context.quote, values, visibility, this.accountRoutingValidationResults),
						duplicate(BillingInformationRules.requiredStructure),
					);
					logPageErrors(validResults, formProps.touched, 'all');

					return validResults;
				}}
			/>
		);
	}
}
