import ruleMessagesJson from 'data/RuleMessages';
import _ from 'lodash';
import { getMinimumDownPayment } from 'utils/BusinessFunctions';
import { isBlank } from 'utils/StringFunctions';

const { requiredMessageText } = ruleMessagesJson;

class BillingInformationRules {
	static requiredStructure = {
		billing: {
			billingType: '',
			existingAccountBill: '',
			accountBillNumber: '',
			billingSameAsApplicant: '',
			name: {
				firstName: '',
				lastName: '',
			},
			address: {
				fullAddress: '',
			},
			bankAccountType: '',
			bankName: '',
			bankRoutingNumber: '',
			bankAccountNumber: '',
			downPaymentMethod: '',
			sfgDownPaymentAmount: '',
			capDownPaymentAmount: '',
			wcpDownPaymentAmount: '',
			cupDownPaymentAmount: '',
			bankAccountSame: '',
			downPayment: {
				bankAccountType: '',
				bankName: '',
				routingNumber: '',
				accountNumber: '',
			},
		},
	};

	static rules(quote, values, visibility, accountRoutingValidationResults) {
		// use values for current page validation
		// use quote for external page validation
		const sfgMinDownPayment = getMinimumDownPayment(quote, _.get(values, 'billing.billingType', ''), 'sfg');
		const capMinDownPayment = getMinimumDownPayment(quote, _.get(values, 'billing.billingType', ''), 'cap');
		const wcpMinDownPayment = getMinimumDownPayment(quote, _.get(values, 'billing.billingType', ''), 'wcp');
		const cupMinDownPayment = getMinimumDownPayment(quote, _.get(values, 'billing.billingType', ''), 'cup');

		return {
			billing: {
				billingType: [[(value) => !isBlank(value), 'Billing Details is required.']],
				existingAccountBill: [
					[(value) => !isBlank(value) || !visibility['billing.existingAccountBill'], requiredMessageText],
				],
				accountBillNumber: [
					[(value) => !isBlank(value) || !visibility['billing.accountBillNumber'], requiredMessageText],
					[
						(value) =>
							_.get(values, 'billing.accountBillNumberValid', true) || !visibility['billing.accountBillNumber'],
						'The account number you entered is not valid.  Please provide a valid number.',
					],
				],
				billingSameAsApplicant: [
					[(value) => !isBlank(value) || !visibility['billing.billingSameAsApplicant'], requiredMessageText],
				],
				name: {
					firstName: [[(value) => !isBlank(value) || !visibility['billing.name.firstName'], requiredMessageText]],
					lastName: [[(value) => !isBlank(value) || !visibility['billing.name.lastName'], requiredMessageText]],
				},
				address: {
					fullAddress: [
						[(value) => !isBlank(value) || !visibility['billing.address.fullAddress'], requiredMessageText],
					],
				},
				bankAccountType: [[(value) => !isBlank(value) || !visibility['billing.bankAccountType'], requiredMessageText]],
				bankName: [[(value) => !isBlank(value) || !visibility['billing.bankName'], requiredMessageText]],
				bankRoutingNumber: [
					[(value) => !isBlank(value) || !visibility['billing.bankRoutingNumber'], requiredMessageText],
					[
						(value) =>
							!visibility['billing.bankRoutingNumber'] ||
							isBlank(accountRoutingValidationResults) ||
							(accountRoutingValidationResults.valid && isBlank(accountRoutingValidationResults.routingNumber)),
						accountRoutingValidationResults.routingNumber,
					],
				],
				bankAccountNumber: [
					[(value) => !isBlank(value) || !visibility['billing.bankAccountNumber'], requiredMessageText],
					[
						(value) =>
							!visibility['billing.bankAccountNumber'] ||
							isBlank(accountRoutingValidationResults) ||
							(accountRoutingValidationResults.valid && isBlank(accountRoutingValidationResults.bankAccount)),
						accountRoutingValidationResults.bankAccount,
					],
				],
				downPaymentMethod: [
					[(value) => !isBlank(value) || !visibility['billing.downPaymentMethod'], requiredMessageText],
				],
				sfgDownPaymentAmount: [
					[(value) => !isBlank(value) || !visibility['billing.sfgDownPaymentAmount'], requiredMessageText],
					[
						(value) =>
							(sfgMinDownPayment <= value && value <= _.get(quote, 'rates.sfg')) ||
							!visibility['billing.sfgDownPaymentAmount'],
						`Amount must be between $${sfgMinDownPayment} and $${_.get(quote, 'rates.sfg')}.`,
					],
				],
				capDownPaymentAmount: [
					[(value) => !isBlank(value) || !visibility['billing.capDownPaymentAmount'], requiredMessageText],
					[
						(value) =>
							(capMinDownPayment <= value && value <= _.get(quote, 'rates.cap')) ||
							!visibility['billing.capDownPaymentAmount'],
						`Amount must be between $${capMinDownPayment} and $${_.get(quote, 'rates.cap')}.`,
					],
				],
				wcpDownPaymentAmount: [
					[(value) => !isBlank(value) || !visibility['billing.wcpDownPaymentAmount'], requiredMessageText],
					[
						(value) =>
							(wcpMinDownPayment <= value && value <= _.get(quote, 'rates.wcp')) ||
							!visibility['billing.wcpDownPaymentAmount'],
						`Amount must be between $${wcpMinDownPayment} and $${_.get(quote, 'rates.wcp')}.`,
					],
				],
				cupDownPaymentAmount: [
					[(value) => !isBlank(value) || !visibility['billing.cupDownPaymentAmount'], requiredMessageText],
					[
						(value) =>
							(cupMinDownPayment <= value && value <= _.get(quote, 'rates.cup')) ||
							!visibility['billing.cupDownPaymentAmount'],
						`Amount must be between $${cupMinDownPayment} and $${_.get(quote, 'rates.cup')}.`,
					],
				],
				bankAccountSame: [[(value) => !isBlank(value) || !visibility['billing.bankAccountSame'], requiredMessageText]],
				downPayment: {
					bankAccountType: [
						[(value) => !isBlank(value) || !visibility['billing.downPayment.bankAccountType'], requiredMessageText],
					],
					bankName: [[(value) => !isBlank(value) || !visibility['billing.downPayment.bankName'], requiredMessageText]],
					routingNumber: [
						[(value) => !isBlank(value) || !visibility['billing.downPayment.routingNumber'], requiredMessageText],
						[
							(value) =>
								!visibility['billing.downPayment.routingNumber'] ||
								isBlank(accountRoutingValidationResults) ||
								(accountRoutingValidationResults.valid && isBlank(accountRoutingValidationResults.routingNumber)),
							accountRoutingValidationResults.routingNumber,
						],
					],
					accountNumber: [
						[(value) => !isBlank(value) || !visibility['billing.downPayment.accountNumber'], requiredMessageText],
						[
							(value) =>
								!visibility['billing.downPayment.accountNumber'] ||
								isBlank(accountRoutingValidationResults) ||
								(accountRoutingValidationResults.valid && isBlank(accountRoutingValidationResults.bankAccount)),
							accountRoutingValidationResults.bankAccount,
						],
					],
				},
			},
		};
	}
}
export default BillingInformationRules;
