import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { getPage } from 'components/shared/navigation/NavigationFunctions';
import QuoteContext from 'context/quoteContext';
import { Form, Formik } from 'formik';
import React, { Component } from 'react';

export default class CardPaymentDecline extends Component {
	static contextType = QuoteContext;

	dirty = false;

	async componentDidMount() {
		const { quote } = this.context;
		quote.blockAgentEdit = false;
		this.context.updateQuoteState(quote);
	}

	paymentRetry = (type) => {
		if (type === 'r') {
			const moveToPage = getPage(this.props.location.pathname, 'paymentRetry', this.context.navigation.navItems);
			this.props.history.push(moveToPage);
		} else {
			const moveToPage = getPage(this.props.location.pathname, 'quoteList', this.context.navigation.navItems);
			this.props.history.push(moveToPage);
		}
	};

	render() {
		const { quote } = this.context;
		if (!quote.id) {
			return null;
		}

		return (
			<Formik
				render={(formikProps) => (
					<Form id='screen'>
						<div id='cardDecline'>
							<div id='cardDeclineHeader'>
								<span>Oops!</span>
								We're surprised your payment didn't work too.
							</div>
							<div id='cardDeclineMessage'>{quote.billing.bankMessage}</div>
							<div>
								<span>
									<img alt='surprisedAlien' src={require('images/surprisedAlienTeal.png')} />
								</span>
							</div>
							<NavigationButtons paymentRetry={this.paymentRetry} />
						</div>
					</Form>
				)}
			/>
		);
	}
}
