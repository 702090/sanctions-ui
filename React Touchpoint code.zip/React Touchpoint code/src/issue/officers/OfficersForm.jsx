import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { SubmitButton } from 'components/shared/buttons/SubmitButton';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputText } from 'components/shared/form/inputs/InputText';
import { RadioButton } from 'components/shared/form/RadioButton';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import selectOptionsJson from 'data/SelectOptions';
import { Field, Form, Formik } from 'formik';
import OfficersRules from 'issue/officers/OfficersRules';
import _ from 'lodash';
import React, { useContext, useEffect } from 'react';
import { cleanValues, getVisibility, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { v4 as uuidv4 } from 'uuid';
import { validate } from 'validation/Validate';

const OfficersForm = (props) => {
	const context = useContext(QuoteContext);

	let visibility = {};
	let dirty = false;
	let formProps;

	const { quote } = context;
	let { id } = props;

	const { wcp_includedExcluded, wcp_title } = selectOptionsJson;

	useEffect(() => {
		// If the form is not empty, trigger validation
		runRulesOnLoad(formProps, formProps.initialValues, ['id']);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	return (
		<Formik
			render={(formikProps) => {
				formProps = formikProps;
				dirty = formikProps.dirty;
				if (id === 'NEW') {
					id = formikProps.values.id;
				}

				visibility = getVisibility(getFieldDisplayArray('officers'), quote, formikProps.values);
				cleanValues(formikProps.values, visibility);

				let title = wcp_title;
				if (formikProps.values.includedExcluded !== 'INC') {
					title = _.filter(wcp_title, (option) => {
						return option.value !== 'SOLE';
					});
				}

				return (
					<Form id='screen'>
						<PageSection title='Executive Officers'>
							<Field name='name' label='Name' component={InputText} maxLength='50' />
							<Field
								name='includedExcluded'
								label='Included / Excluded'
								component={RadioButton}
								options={wcp_includedExcluded}
							/>
							<Field name='title' label='Title' component={RadioButton} options={title} />
							<Field
								name='titleDescription'
								label='Title Description'
								component={InputText}
								fieldDisplay={visibility.titleOther}
							/>
							<Field name='ownershipPercent' label='Ownership Percent' component={InputNumber} maxLength='3' />
						</PageSection>
						<SimpleButton content='Cancel' onClick={props.handleClose} />
						<SubmitButton content='Save' error={Object.keys(formikProps.errors).length > 0} />
					</Form>
				);
			}}
			initialValues={{
				id: id && id !== 'NEW' ? id : uuidv4(),
				name: _.get(quote, `wcp.officers.${id}.name`, ''),
				includedExcluded: _.get(quote, `wcp.officers.${id}.includedExcluded`, ''),
				title: _.get(quote, `wcp.officers.${id}.title`, ''),
				titleDescription: _.get(quote, `wcp.officers.${id}.titleDescription`, ''),
				ownershipPercent: _.get(quote, `wcp.officers.${id}.ownershipPercent`, ''),
			}}
			onSubmit={(values, formikActions) => {
				cleanValues(values, visibility);
				context.onWcpOfficersModalSubmit(values, dirty, props, 'officers');
				props.handleClose();
				formikActions.setSubmitting(false);
			}}
			validate={(values) => {
				const validResults = validate(
					values,
					OfficersRules.rules(context.quote, values, visibility),
					OfficersRules.requiredStructure,
				);
				logPageErrors(validResults, formProps.touched, 'wcp');

				return validResults;
			}}
		/>
	);
};

export default OfficersForm;
