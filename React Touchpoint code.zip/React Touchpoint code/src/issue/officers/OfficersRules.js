import { requiredQuestionMessage } from 'data/FieldVisibility';
import { isBlank } from 'utils/StringFunctions';
import _ from 'lodash';

class ContactRules {
	static requiredStructure = {
		name: '',
		includedExcluded: '',
		title: '',
		titleDescription: '',
		ownershipPercent: '',
	};

	static rules(quote, values, visibility) {
		// use values for current page validation
		// use quote for external page validation
		return {
			name: [[(value) => !isBlank(value), requiredQuestionMessage]],
			includedExcluded: [
				[(value) => !isBlank(value), requiredQuestionMessage],
				[
					(value) => !(value === 'INC' && _.get(quote, 'wcp.officersIncluded', '') === 'N'),
					"This policy was indicated as having no sole proprietors, partners or executive officers included. If you need to add an included officer, please return to the Worker's Compensation page first to indicate officers are included.",
				],
			],
			title: [[(value) => !isBlank(value), requiredQuestionMessage]],
			titleDescription: [[(value) => !isBlank(value) || !visibility.titleOther, requiredQuestionMessage]],
			ownershipPercent: [[(value) => !isBlank(value), requiredQuestionMessage]],
		};
	}
}
export default ContactRules;
