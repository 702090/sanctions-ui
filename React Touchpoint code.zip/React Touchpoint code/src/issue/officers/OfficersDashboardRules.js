import ruleMessagesJson from 'data/RuleMessages';
import _ from 'lodash';
import { isBlank } from '@columbiainsurance/functions-js';

const { requiredMessageText } = ruleMessagesJson;

class OfficersDashboardRules {
	static requiredStructure = {
		section_officers: '',
	};

	static rules(quote, values) {
		const officerEnteredCount = _.filter(_.get(quote, 'wcp.officers', {}), { includedExcluded: 'INC' }).length || 0;
		let officersIncluded = _.get(quote, 'wcp.numberOfOfficersIncluded');
		if (isBlank(officersIncluded)) {
			officersIncluded = 0;
		}
		const countBasedMessage =
			officerEnteredCount > officersIncluded
				? 'Please remove any entries for included officers'
				: 'Please enter a record for each included officer';
		return {
			section_officers: [
				[
					(value) => officersIncluded === officerEnteredCount,
					`This policy was indicated as having ${
						officersIncluded > 0 ? officersIncluded : 'no'
					} sole proprietors, partners or executive officers included. ${countBasedMessage} or return to the Worker's Compensation page to adjust the number of officers included.`,
				],
			],
		};
	}
}

export default OfficersDashboardRules;
