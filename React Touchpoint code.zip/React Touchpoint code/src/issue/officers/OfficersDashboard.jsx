import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { DisplayTable } from 'components/shared/displayTable';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { toSortedPairList } from 'components/shared/navigation/NavigationFunctions';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import { Form, Formik } from 'formik';
import _ from 'lodash';
import React, { Component } from 'react';
import { insurityCall } from 'services/insurityService';
import { cleanValues, getVisibility, logPageErrors } from 'utils/ScreenFunctions';

import { isBlank } from 'utils/StringFunctions';
import { validate } from 'validation/Validate';
import OfficersDashboardRules from './OfficersDashboardRules';
import { OfficersModal } from './OfficersModal';

export default class OfficersDashboard extends Component {
	static contextType = QuoteContext;

	visibility = {};
	dirty = false;
	formProps;

	state = {
		sorting: { column: null, direction: null },
		updated: false,
		activePage: 1,
	};

	rulesOnLoad = false;

	constructor() {
		super();
		this.officer = React.createRef();
	}

	UNSAFE_componentWillMount() {
		const officers = _.get(this.context.quote, 'wcp.officers', {});

		this.setState({
			officers,
			officerList: _.toPairs(officers),
		});
	}

	handleSort = (clickedColumn, defaultDirection) => () => {
		let { column, direction } = this.state.sorting;
		let { officerList } = this.state;
		const { quote } = this.context;

		if (defaultDirection || column !== clickedColumn) {
			direction = defaultDirection || 'ascending';
			switch (clickedColumn) {
				case 'name':
					officerList = toSortedPairList(quote.wcp.officers, 'name');
					break;
				case 'includedExcluded':
					officerList = toSortedPairList(quote.wcp.officers, 'includedExcluded');
					break;
				case 'title':
					officerList = toSortedPairList(quote.wcp.officers, 'title');
					break;
				case 'ownershipPercent':
					officerList = toSortedPairList(quote.wcp.officers, 'ownershipPercent');
					break;
				default:
					officerList = _.toPairs(quote.wcp.officers);
			}
		} else {
			officerList = officerList.reverse();
			direction = direction === 'ascending' ? 'descending' : 'ascending';
		}
		this.setState({
			officerList,
			sorting: {
				direction,
				column: clickedColumn,
			},
		});
	};

	handleDelete = (id) => {
		const updatedQuote = this.context.quote;
		_.unset(updatedQuote.wcp.officers, id);

		this.context.updateQuote(updatedQuote, this.props);
		insurityCall(updatedQuote, 'officers');

		this.setState({
			officerList: _.toPairs(updatedQuote.wcp.officers),
		});
	};

	callback = () => {
		this.rulesOnLoad = false;
		this.handleSort(this.state.sorting.column, this.state.sorting.direction || true)();
	};

	render() {
		const { quote } = this.context;

		return (
			<>
				<OfficersModal onSubmit={this.context.onWcpOfficersModalSubmit} ref={this.officer} />
				<Formik
					render={(formikProps) => {
						this.formProps = formikProps;
						this.dirty = formikProps.dirty;
						this.visibility = getVisibility(getFieldDisplayArray('officers'), quote, formikProps.values);
						cleanValues(formikProps.values, this.visibility);
						if (!this.rulesOnLoad && !isBlank(_.get(quote, 'wcp.officers', {}))) {
							formikProps.validateForm(formikProps.values);
							this.rulesOnLoad = true;
						}
						return (
							<Form id='screen'>
								<PageSection title='Workers Compensation Officers' name='section_officers' errors={formikProps.errors}>
									<div id='dashboardButtons' className='left'>
										<SimpleButton
											content='Add Officer'
											className='add'
											onClick={() =>
												this.officer.current.handleOpen(
													'NEW',
													{},
													this.callback,
													this.props.location,
													this.props.history,
												)
											}
										/>
									</div>
									{!isBlank(_.get(quote, 'wcp.officers', {})) && (
										<DisplayTable
											display={this.state.officerList}
											handleSort={this.handleSort}
											{...this.state.sorting}
											handleDelete={(interestId) => {
												this.handleDelete(interestId);
												formikProps.validateForm(formikProps.values);
											}}
											errors={formikProps.errors}
											callBack={this.callback}
											reference={this.officer}
											columns={[
												{
													name: 'name',
													display: 'Name',
													truncate: 48,
												},
												{
													name: 'includedExcluded',
													display: 'Included/Excluded',
												},
												{ name: 'title', display: 'Title' },
												{
													name: 'ownershipPercent',
													display: 'Ownership Percent',
												},
												{
													name: '',
												},
											]}
											location={this.props.location}
											history={this.props.history}
										/>
									)}
								</PageSection>
								<NavigationButtons
									formikProps={formikProps}
									back
									location={this.props.location}
									history={this.props.history}
								/>
							</Form>
						);
					}}
					initialValues={{}}
					onSubmit={(values, formikActions) => {
						cleanValues(values, this.visibility);
						// return
						this.context.onSubmit(values, this.dirty, false, false, this.props);
						this.rulesOnLoad = true;
					}}
					validate={(values) => {
						const validResults = validate(
							values,
							OfficersDashboardRules.rules(this.context.quote, values, this.visibility),
							OfficersDashboardRules.requiredStructure,
						);
						logPageErrors(validResults, this.formProps.touched, 'all');
						// errorStructure = runAllAdditionalInterestRules(this.context.quote);
						// _.merge(validResults, errorStructure);
						return validResults;
					}}
				/>
			</>
		);
	}
}
