import { requiredQuestionMessage } from 'data/FieldVisibility';
import { isBlank } from 'utils/StringFunctions';
import _ from 'lodash';
import { validEmail } from 'helper/Validation';

class ContactRules {
	static requiredStructure = {
		contacts: {
			accounting: {
				lastName: '',
				phone: '',
				email: '',
			},
			inspection: {
				phone: '',
				email: '',
			},
			claims: {
				phone: '',
				email: '',
			},
			other: {
				phone: '',
				email: '',
			},
		},
	};

	static rules(quote, values) {
		// use values for current page validation
		// use quote for external page validation
		return {
			contacts: {
				accounting: {
					lastName: [[(value) => !isBlank(value), requiredQuestionMessage]],
					phone: [
						[(value) => !isBlank(value), requiredQuestionMessage],
						[(value) => _.toString(value).length === 10, 'Invalid phone number.'],
					],
					email: [
						[(value) => isBlank(value) || validEmail(value), 'Must be a valid email address ex. name@address.com'],
					],
				},
				inspection: {
					phone: [[(value) => isBlank(value) || _.toString(value).length === 10, 'Invalid phone number.']],
					email: [
						[(value) => isBlank(value) || validEmail(value), 'Must be a valid email address ex. name@address.com'],
					],
				},
				claims: {
					phone: [[(value) => isBlank(value) || _.toString(value).length === 10, 'Invalid phone number.']],
					email: [
						[(value) => isBlank(value) || validEmail(value), 'Must be a valid email address ex. name@address.com'],
					],
				},
				other: {
					phone: [[(value) => isBlank(value) || _.toString(value).length === 10, 'Invalid phone number.']],
					email: [
						[(value) => isBlank(value) || validEmail(value), 'Must be a valid email address ex. name@address.com'],
					],
				},
			},
		};
	}
}
export default ContactRules;
