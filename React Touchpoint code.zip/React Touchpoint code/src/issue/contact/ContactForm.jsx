import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputText } from 'components/shared/form/inputs/InputText';
import { RadioButton } from 'components/shared/form/RadioButton';
import { InformationMessage } from 'components/shared/messages/InformationMessage';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import { Field, Form, Formik } from 'formik';
import ContactRules from 'issue/contact/ContactRules';
import _ from 'lodash';
import React, { Component } from 'react';
import { cleanValues, getVisibility, logPageErrors, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { validate } from 'validation/Validate';

let visibility = {};
let hasPrefillData = false;

export default class ContactForm extends Component {
	static contextType = QuoteContext;

	dirty = false;
	componentDidMount() {
		// If the form is not empty, trigger validation
		runRulesOnLoad(this.formProps, this.formProps.initialValues, ['']);

		let accountingNamePrefill;
		_.forIn(_.get(this.context, 'quote.sfg.locations', {}), (location, locId) => {
			if (location.order === 1) {
				accountingNamePrefill = _.get(location, 'prefillData.verisk.accountingContact', '');
				hasPrefillData = true;
			}
		});
		if (isBlank(_.get(this.formProps, 'values.contacts.accounting.lastName', ''))) {
			if (!isBlank(accountingNamePrefill)) {
				const nameArray = accountingNamePrefill.split(/ (.*)/);
				if (nameArray.length > 1 && !isBlank(nameArray[1])) {
					this.formProps.setFieldValue('contacts.accounting.firstName', nameArray[0]);
					this.formProps.setFieldValue('contacts.accounting.lastName', nameArray[1]);
				} else {
					this.formProps.setFieldValue('contacts.accounting.lastName', accountingNamePrefill);
				}
			}
		}
	}

	getPrefillToolTips = () => {
		const noCallVeriskMessage = 'Verisk has never been called.';
		const noReturnVeriskMessage = 'The Verisk call returned no data.';

		let prefillObject = {
			accountingContact: noCallVeriskMessage,
		};

		const locations = _.get(this.context, 'quote.sfg.locations', {});

		if (!isBlank(locations)) {
			const location = _.find(locations, (locationObject) => {
				return locationObject.order === 1;
			});
			if (_.has(location, 'prefillData.verisk')) {
				prefillObject.accountingContact = isBlank(location.prefillData.verisk.accountingContact)
					? noReturnVeriskMessage
					: location.prefillData.verisk.accountingContact;
			}
		}

		return prefillObject;
	};

	render() {
		const { quote } = this.context;

		return (
			<Formik
				render={(formikProps) => {
					this.formProps = formikProps;
					this.dirty = formikProps.dirty;
					visibility = getVisibility(getFieldDisplayArray('contact'), quote, formikProps.values);
					cleanValues(formikProps.values, visibility);
					const prefillToolTips = this.getPrefillToolTips();
					return (
						<Form id='screen'>
							<InformationMessage
								message='Select information on this page has been pre-filled by a third-party service.'
								fieldDisplay={hasPrefillData}
							/>
							<PageSection title='Accounting Contact'>
								<Field
									name='contacts.accounting.firstName'
									label='First Name'
									component={InputText}
									maxLength='50'
									optional
									labelPrefillHoverMessage={prefillToolTips.accountingContact}
								/>
								<Field name='contacts.accounting.lastName' label='Last Name' component={InputText} maxLength='50' />
								<Field
									name='contacts.accounting.phone'
									label='Phone'
									component={InputNumber}
									format='(###) ###-####'
									mask='_'
									width='small'
								/>
								<Field name='contacts.accounting.email' label='Email' component={InputText} maxLength='50' optional />
								<Field
									name='contacts.allContactsSame'
									label='All contact information is the same'
									component={RadioButton}
								/>
							</PageSection>
							{visibility['contacts.inspection.firstName'] ? (
								<PageSection title='Inspection Contact'>
									<Field
										name='contacts.inspection.firstName'
										label='First Name'
										component={InputText}
										maxLength='50'
										fieldDisplay={visibility['contacts.inspection.firstName']}
										optional
									/>
									<Field
										name='contacts.inspection.lastName'
										label='Last Name'
										component={InputText}
										maxLength='50'
										fieldDisplay={visibility['contacts.inspection.lastName']}
										optional
									/>
									<Field
										name='contacts.inspection.phone'
										label='Phone'
										component={InputNumber}
										format='(###) ###-####'
										mask='_'
										width='small'
										fieldDisplay={visibility['contacts.inspection.phone']}
										optional
									/>
									<Field
										name='contacts.inspection.email'
										label='Email'
										component={InputText}
										maxLength='50'
										fieldDisplay={visibility['contacts.inspection.email']}
										optional
									/>
								</PageSection>
							) : (
								''
							)}
							{visibility['contacts.claims.firstName'] ? (
								<PageSection title='Claims Contact'>
									<Field
										name='contacts.claims.firstName'
										label='First Name'
										component={InputText}
										maxLength='50'
										fieldDisplay={visibility['contacts.claims.firstName']}
										optional
									/>
									<Field
										name='contacts.claims.lastName'
										label='Last Name'
										component={InputText}
										maxLength='50'
										fieldDisplay={visibility['contacts.claims.lastName']}
										optional
									/>
									<Field
										name='contacts.claims.phone'
										label='Phone'
										component={InputNumber}
										format='(###) ###-####'
										mask='_'
										width='small'
										fieldDisplay={visibility['contacts.claims.phone']}
										optional
									/>
									<Field
										name='contacts.claims.email'
										label='Email'
										component={InputText}
										maxLength='50'
										fieldDisplay={visibility['contacts.claims.email']}
										optional
									/>
								</PageSection>
							) : (
								''
							)}
							{visibility['contacts.other.firstName'] ? (
								<PageSection title='Other Contact'>
									<Field
										name='contacts.other.firstName'
										label='First Name'
										component={InputText}
										maxLength='50'
										fieldDisplay={visibility['contacts.other.firstName']}
										optional
									/>
									<Field
										name='contacts.other.lastName'
										label='Last Name'
										component={InputText}
										maxLength='50'
										fieldDisplay={visibility['contacts.other.lastName']}
										optional
									/>
									<Field
										name='contacts.other.phone'
										label='Phone'
										component={InputNumber}
										format='(###) ###-####'
										mask='_'
										width='small'
										fieldDisplay={visibility['contacts.other.phone']}
										optional
									/>
									<Field
										name='contacts.other.email'
										label='Email'
										component={InputText}
										maxLength='50'
										fieldDisplay={visibility['contacts.other.email']}
										optional
									/>
								</PageSection>
							) : (
								''
							)}
							<NavigationButtons
								formikProps={formikProps}
								back
								insurityPush='contact'
								location={this.props.location}
								history={this.props.history}
							/>
						</Form>
					);
				}}
				initialValues={{
					contacts: quote.contacts || {
						accounting: {
							firstName: '',
							lastName: '',
							phone: '',
							email: '',
						},
						inspection: {
							firstName: '',
							lastName: '',
							phone: '',
							email: '',
						},
						claims: {
							firstName: '',
							lastName: '',
							phone: '',
							email: '',
						},
						other: {
							firstName: '',
							lastName: '',
							phone: '',
							email: '',
						},
						allContactsSame: '',
					},
				}}
				onSubmit={(values, formikActions) => {
					cleanValues(values, visibility);
					return this.context.onSubmit(values, this.dirty, 'contact', false, this.props);
				}}
				validate={(values) => {
					const validResults = validate(
						values,
						ContactRules.rules(this.context.quote, values),
						ContactRules.requiredStructure,
					);

					logPageErrors(validResults, this.formProps.touched, 'all');
					return validResults;
				}}
			/>
		);
	}
}
