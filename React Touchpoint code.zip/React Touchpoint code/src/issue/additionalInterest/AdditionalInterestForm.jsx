import { IconButton } from 'components/shared/buttons/IconButton';
import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { SubmitButton } from 'components/shared/buttons/SubmitButton';
import { CheckboxGroup } from 'components/shared/form/CheckboxGroup';
import { InputAddress } from 'components/shared/form/inputs/InputAddress';
import { InputText } from 'components/shared/form/inputs/InputText';
import { RadioButton } from 'components/shared/form/RadioButton';
import { Select } from 'components/shared/form/Select';
import { toSortedPairList } from 'components/shared/navigation/NavigationFunctions';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import selectOptionsJson from 'data/SelectOptions';
import { Field, Form, Formik } from 'formik';
import AdditionalInterestRules from 'issue/additionalInterest/AdditionalInterestRules';
import _ from 'lodash';
import React, { Component } from 'react';
import { getBuildingList } from 'utils/BusinessFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import { cleanValues, getVisibility, logPageErrors, parseAddress, runRulesOnLoad } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { v4 as uuidv4 } from 'uuid';
import { validate } from 'validation/Validate';

let visibility = {};
const { cap_InterestType, sfg_provisionApplicable } = selectOptionsJson;

export default class AdditionalInterestForm extends Component {
	static contextType = QuoteContext;

	dirty = false;
	state = {};
	rulesOnLoad = false;

	componentDidMount() {
		// If the form is not empty, trigger validation
		runRulesOnLoad(this.formProps, this.formProps.initialValues, ['id']);
	}

	updateInterestTypeCode = (value, setFieldValue) => {
		let sfgInterestTypeValue = '';
		switch (value) {
			case 'BP1203 – Loss Payee':
				sfgInterestTypeValue = '03';
				break;
			case 'BP0409 – Mortgagee/Assignee':
				sfgInterestTypeValue = '05';
				break;
			case 'BP1231 – Building Owner':
				sfgInterestTypeValue = '31';
				break;
			// all others mapped to additional insured
			default:
				sfgInterestTypeValue = '04';
		}

		if (value === '') {
			sfgInterestTypeValue = '';
		}

		setFieldValue('sfgInterestType', sfgInterestTypeValue, false);
	};

	vehicleListOptions = () => {
		const vehicleList = [];
		const vehicles = toSortedPairList(_.get(this.context.quote, 'cap.vehicles', {}));
		vehicles.forEach((vehiclePair) => {
			const vehicle = vehiclePair[1];
			const vehicleId = vehiclePair[0];
			vehicleList.push({
				value: vehicleId,
				text: `${_.get(vehicle, 'vehYear', '')} ${_.get(vehicle, 'vehMake', '')} ${_.get(
					vehicle,
					'vehModel',
					'',
				)} ${_.get(vehicle, 'vin', '')}`,
			});
		});
		return vehicleList;
	};

	render() {
		const { quote } = this.context;
		let { id, aiListOptions } = this.props;

		return (
			<Formik
				render={(formikProps) => {
					this.formProps = formikProps;
					this.dirty = formikProps.dirty;
					if (id === 'NEW') {
						id = formikProps.values.id;
					}
					visibility = getVisibility(getFieldDisplayArray('additionalInterest'), quote, formikProps.values);
					cleanValues(formikProps.values, visibility);
					if (!this.rulesOnLoad && !isBlank(_.get(this.context, `quote.additionalInterests.${id}`, {}))) {
						formikProps.validateForm(formikProps.values);
						this.rulesOnLoad = true;
					}
					const buildingList = getBuildingList(quote, 'AI');
					const vehicleSelect = this.vehicleListOptions();
					return (
						<Form id='screen'>
							<PageSection title='Primary Name'>
								<div className='flexFields'>
									<Field
										name='primaryName.firstName'
										label='First Name'
										component={InputText}
										maxLength='20'
										optional
										width='medium'
									/>
									<Field
										name='primaryName.middleInitial'
										label='Middle Initial'
										component={InputText}
										maxLength='1'
										width='tiny'
										optional
									/>
								</div>
								<Field name='primaryName.lastName' label='Company or Last Name' component={InputText} maxLength='60' />
							</PageSection>
							<PageSection title='Secondary Name'>
								<div className='flexFields'>
									<Field
										name='secondaryName.firstName'
										label='First Name'
										component={InputText}
										maxLength='20'
										optional
										width='medium'
									/>
									<Field
										name='secondaryName.middleInitial'
										label='Middle Initial'
										component={InputText}
										maxLength='1'
										width='tiny'
										optional
									/>
								</div>
								<Field
									name='secondaryName.lastName'
									label='Company or Last Name'
									component={InputText}
									maxLength='60'
									optional
								/>
							</PageSection>
							<PageSection title='Additional Interest Details'>
								<Field
									name='address.fullAddress'
									label='Address'
									component={InputAddress}
									className='geo'
									addressName='address'
									additionalOnChange={parseAddress}
									formikProps={formikProps}
								/>
							</PageSection>
							{!isBlank(aiListOptions) && (
								<PageSection
									title='Additional Interest Property'
									name='section_interestBuilding'
									errors={formikProps.errors}
								>
									<Field
										name='sfgInterestDescription'
										label='Safeguard Interest Type'
										component={Select}
										options={aiListOptions}
										additionalOnChange={this.updateInterestTypeCode}
										width='medium'
									/>
									<Field
										name='sfgProvisionApplicable'
										label='Provision Applicable'
										component={RadioButton}
										options={sfg_provisionApplicable}
										fieldDisplay={visibility['sfgProvisionApplicable']}
									/>
									<Field
										name='sfgDescriptionOfProperty'
										label='Description Of Property'
										component={InputText}
										maxLength='40'
										fieldDisplay={visibility['sfgDescriptionOfProperty']}
									/>
									<IconButton
										label={"Don't see your building?"}
										iconName='fal fa-question-circle'
										alt='To add an Additional Interest, Mortgagee or Loss Payee, please go to the appropriate building and indicate which type of Additional Interest applies.'
										size='small'
									/>
									<Field
										name='interestBuilding'
										label='Interest in Building(s)'
										component={CheckboxGroup}
										options={buildingList}
									/>
								</PageSection>
							)}
							{_.includes(_.get(quote, 'products', ['sfg']), 'cap') && (
								<PageSection
									title='Additional Interest Vehicle'
									name='section_interestVehicle'
									errors={formikProps.errors}
								>
									<Field
										name='capInterestType'
										label='Commercial Auto Interest Type'
										component={Select}
										options={cap_InterestType}
										width='medium'
									/>
									<Field
										name='interestVehicle'
										label='Interest in Vehicles(s)'
										component={CheckboxGroup}
										options={vehicleSelect}
									/>
								</PageSection>
							)}
							<SimpleButton content='Cancel' onClick={this.props.handleClose} />
							<SubmitButton content='Save' error={Object.keys(formikProps.errors).length > 0} />
						</Form>
					);
				}}
				initialValues={{
					id: id && id !== 'NEW' ? id : uuidv4(),
					primaryName: _.get(quote, `additionalInterests.${id}.primaryName`, {
						firstName: '',
						lastName: '',
						middleInitial: '',
					}),
					secondaryName: _.get(quote, `additionalInterests.${id}.secondaryName`, {
						firstName: '',
						lastName: '',
						middleInitial: '',
					}),
					address: _.get(quote, `additionalInterests.${id}.address`, {
						fullAddress: '',
					}),
					sfgInterestType: _.get(quote, `additionalInterests.${id}.sfgInterestType`, ''),
					sfgInterestDescription: _.get(quote, `additionalInterests.${id}.sfgInterestDescription`, ''),
					capInterestType: _.get(quote, `additionalInterests.${id}.capInterestType`, ''),
					interestBuilding: _.get(quote, `additionalInterests.${id}.interestBuilding`, []),
					interestVehicle: _.get(quote, `additionalInterests.${id}.interestVehicle`, []),
					sfgProvisionApplicable: _.get(quote, `additionalInterests.${id}.sfgProvisionApplicable`, ''),
					sfgDescriptionOfProperty: _.get(quote, `additionalInterests.${id}.sfgDescriptionOfProperty`, ''),
				}}
				onSubmit={(values, formikActions) => {
					cleanValues(values, visibility);
					this.context.onAdditionalInterestModalSubmit(values, this.dirty, 'interest');
					this.props.handleClose();
					formikActions.setSubmitting(false);
				}}
				validate={(values) => {
					const validResults = validate(
						values,
						AdditionalInterestRules.rules(quote, values, aiListOptions, visibility),
						duplicate(AdditionalInterestRules.requiredStructure),
					);
					logPageErrors(validResults, this.formProps.touched, 'all');
					return validResults;
				}}
			/>
		);
	}
}
