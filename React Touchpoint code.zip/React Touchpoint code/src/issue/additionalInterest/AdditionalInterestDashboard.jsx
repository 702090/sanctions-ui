import { SimpleButton } from 'components/shared/buttons/SimpleButton';
import { DisplayTable } from 'components/shared/displayTable';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { toSortedPairList } from 'components/shared/navigation/NavigationFunctions';
import { PageSection } from 'components/shared/sections/PageSection';
import QuoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import { Form, Formik } from 'formik';
import { runAllAdditionalInterestRules } from 'helper/Validation';
import AdditionalInterestDashboardRules from 'issue/additionalInterest/AdditionalInterestDashboardRules';
import { AdditionalInterestModal } from 'issue/additionalInterest/AdditionalInterestModal';
import _ from 'lodash';
import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { insurityCall } from 'services/insurityService';
import { getAdditionalInterestTypes } from 'utils/BusinessFunctions';
import { cleanValues, getVisibility, logPageErrors } from 'utils/ScreenFunctions';
import { isBlank } from 'utils/StringFunctions';
import { validate } from 'validation/Validate';

let visibility = {};

export default class AdditionalInterests extends Component {
	static contextType = QuoteContext;

	dirty = false;
	formProps;

	state = {
		sorting: { column: null, direction: null },
		updated: false,
		activePage: 1,
	};

	rulesOnLoad = false;

	constructor() {
		super();
		this.additionalInterest = React.createRef();
	}

	UNSAFE_componentWillMount() {
		const additionalInterests = _.get(this.context, 'quote.additionalInterests', {});

		const additionalInterestListFilter = this.filterAdditionalInterests(additionalInterests);

		this.setState({
			additionalInterests,
			additionalInterestList: additionalInterestListFilter,
		});
	}

	filterAdditionalInterests = (additionalInterests) => {
		let ais;
		if (additionalInterests) {
			if (_.isArray(additionalInterests)) {
				ais = additionalInterests;
			} else {
				ais = _.toPairs(additionalInterests);
			}
		} else {
			ais = _.toPairs(_.get(this.context, 'quote.additionalInterests', {}));
		}

		const filteredList = _.filter(ais, (additionalInterest) => {
			return (
				_.includes(_.get(this.context.quote, 'products', ['sfg']), 'cap') ||
				_.get(additionalInterest[1], 'sfgInterestType', '') !== ''
			);
		});
		this.setState({
			additionalInterestList: filteredList,
		});

		return filteredList;
	};

	handleSort = (clickedColumn, defaultDirection) => () => {
		let { column, direction } = this.state.sorting;
		let { additionalInterestList } = this.state;
		if (defaultDirection || column !== clickedColumn) {
			direction = defaultDirection || 'ascending';
			switch (clickedColumn) {
				case 'primaryName.lastName':
					additionalInterestList = toSortedPairList(this.context.quote.additionalInterests, 'primaryName.lastName');
					break;
				case 'address.city':
					additionalInterestList = toSortedPairList(this.context.quote.additionalInterests, 'address.city');
					break;
				case 'address.state':
					additionalInterestList = toSortedPairList(this.context.quote.additionalInterests, 'address.state');
					break;
				case 'address.zip':
					additionalInterestList = toSortedPairList(this.context.quote.additionalInterests, 'address.zip');
					break;
				default:
					additionalInterestList = _.toPairs(this.context.quote.additionalInterests);
			}
		} else {
			additionalInterestList = additionalInterestList.reverse();
			direction = direction === 'ascending' ? 'descending' : 'ascending';
		}
		this.setState({
			additionalInterestList: this.filterAdditionalInterests(additionalInterestList),
			sorting: {
				direction,
				column: clickedColumn,
			},
		});
	};

	handleDelete = (id) => {
		const updatedQuote = this.context.quote;
		_.unset(updatedQuote.additionalInterests, id);

		this.context.updateQuote(updatedQuote, this.props);
		insurityCall(updatedQuote, 'interest');

		this.setState({
			additionalInterestList: _.toPairs(updatedQuote.additionalInterests),
		});
	};

	callback = () => {
		this.rulesOnLoad = false;
		this.handleSort(this.state.sorting.column, this.state.sorting.direction || true)();
		this.filterAdditionalInterests();
	};

	render() {
		const { quote } = this.context;
		const additionalInterestListOptions = getAdditionalInterestTypes(quote);
		let errorStructure = {};

		return (
			<React.Fragment>
				<AdditionalInterestModal
					onSubmit={this.context.onAdditionalInterestModalSubmit}
					ref={this.additionalInterest}
				/>
				<Formik
					render={(formikProps) => {
						this.formProps = formikProps;
						this.dirty = formikProps.dirty;
						visibility = getVisibility(getFieldDisplayArray('additionalInterests'), quote, formikProps.values);
						cleanValues(formikProps.values, visibility);
						if (!this.rulesOnLoad && !isBlank(_.get(this.context, 'quote.additionalInterests', {}))) {
							formikProps.validateForm(formikProps.values);
							this.rulesOnLoad = true;
						}
						return (
							<Form id='screen'>
								<PageSection title='Additional Interest' name='section_additionalInterest' errors={formikProps.errors}>
									<div id='dashboardButtons' className='left'>
										<SimpleButton
											content='Add Additional Interest'
											className='add'
											onClick={() =>
												this.additionalInterest.current.handleOpen(
													'NEW',
													{},
													this.callback,
													this.props.location,
													this.props.history,
													additionalInterestListOptions,
												)
											}
											disabled={
												isBlank(additionalInterestListOptions) && !_.includes(_.get(quote, 'products', ['sfg']), 'cap')
											}
										/>
									</div>
									{isBlank(additionalInterestListOptions) && (
										<React.Fragment>
											<p>
												No buildings were indicated to have an additional interest, loss payee or mortgagee. Please edit
												and add the number of mortgagees or loss payees, or additional interest to the appropriate
												building to be able to add an additional interest
											</p>
											<NavLink to='/quote/safeguard/locations'>Return to locations</NavLink>
										</React.Fragment>
									)}
									{isBlank(additionalInterestListOptions) && _.includes(_.get(quote, 'products', ['sfg']), 'cap') && (
										<p>A commercial auto vehicle interest can still be added.</p>
									)}
									{!isBlank(this.state.additionalInterestList) && (
										<DisplayTable
											display={this.state.additionalInterestList}
											handleSort={this.handleSort}
											{...this.state.sorting}
											handleDelete={(interestId) => {
												this.handleDelete(interestId);
												formikProps.validateForm(formikProps.values);
											}}
											errors={formikProps.errors}
											callBack={this.callback}
											listOptions={additionalInterestListOptions}
											reference={this.additionalInterest}
											columns={[
												{
													name: 'primaryName.lastName',
													display: 'Interest Name',
													truncate: 48,
												},
												{ name: 'address.city', display: 'City' },
												{ name: 'address.state', display: 'State' },
												{
													name: 'address.zip',
													display: 'Zip Code',
												},
												{
													name: '',
												},
											]}
											location={this.props.location}
											history={this.props.history}
										/>
									)}
								</PageSection>
								<NavigationButtons
									formikProps={formikProps}
									back
									location={this.props.location}
									history={this.props.history}
								/>
							</Form>
						);
					}}
					initialValues={{}}
					onSubmit={(values, formikActions) => {
						cleanValues(values, visibility);
						// return
						this.context.onSubmit(values, this.dirty, false, false, this.props);
						this.rulesOnLoad = true;
					}}
					validate={(values) => {
						_.set(AdditionalInterestDashboardRules.requiredStructure, 'interestBuilding', []);
						const validResults = validate(
							values,
							AdditionalInterestDashboardRules.rules(
								this.context.quote,
								values,
								additionalInterestListOptions,
								visibility,
							),
							AdditionalInterestDashboardRules.requiredStructure,
						);
						errorStructure = runAllAdditionalInterestRules(this.context.quote);
						_.merge(validResults, errorStructure);
						logPageErrors(validResults, this.formProps.touched, 'all');
						return validResults;
					}}
				/>
			</React.Fragment>
		);
	}
}
