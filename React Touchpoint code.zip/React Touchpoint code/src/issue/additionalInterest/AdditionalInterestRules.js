import { toSortedPairList } from 'components/shared/navigation/NavigationFunctions';
import { requiredQuestionMessage } from 'data/FieldVisibility';
import _ from 'lodash';
import { isHasBP1203, isHasBP1203orBP1231 } from 'utils/FieldDisplay';
import { isBlank } from 'utils/StringFunctions';

class AdditionalInterestRules {
	static requiredStructure = {
		primaryName: {
			last: '',
		},
		secondaryName: {
			lastName: '',
		},
		address: {
			fullAddress: '',
		},
		sfgInterestType: '',
		sfgInterestDescription: '',
		capInterestType: '',
		interestBuilding: [],
		interestVehicle: [],
		section_interestBuilding: '',
		section_interestVehicle: '',
		sfgProvisionApplicable: '',
		sfgDescriptionOfProperty: '',
	};

	static rules(quote, values, aiListOptions) {
		// use values for current page validation
		// use quote for external page validation

		const buildingsToTest = [];
		const vehiclesToTest = [];

		const locations = _.get(quote, 'sfg.locations', {});
		let aiVisibility = '';
		if (!isBlank(aiListOptions)) {
			if (_.includes(_.get(quote, 'products', ['sfg']), 'cap')) {
				aiVisibility = 'both';
			} else {
				aiVisibility = 'sfgOnly';
			}
		} else if (_.includes(_.get(quote, 'products', ['sfg']), 'cap')) {
			aiVisibility = 'capOnly';
		}
		testValidBuildings(quote, values, locations, aiListOptions, buildingsToTest);

		checkPhysicalDamage(quote, values, vehiclesToTest);

		return {
			section_interestBuilding: [
				[
					(value) =>
						!(
							_.includes(['03', '05'], values.sfgInterestType) &&
							isBlank(values.interestBuilding) &&
							!isBlank(aiListOptions)
						),
					'You must select an interest building for a mortgagee or loss payee',
				],
			],
			primaryName: {
				lastName: [[(value) => !isBlank(value), requiredQuestionMessage]],
			},
			secondaryName: {
				lastName: [
					[
						(value) =>
							isBlank(_.get(values, 'secondaryName.firstName')) ||
							(!isBlank(value) && !isBlank(_.get(values, 'secondaryName.firstName'))),
						'A last name is required when entering a first name of a secondary insured.',
					],
				],
			},
			address: {
				fullAddress: [
					[(value) => !isBlank(value), requiredQuestionMessage],
					[(value) => _.get(values, 'address.zip', '') !== '00000', 'This address must include a valid zipcode.'],
					[
						(value) =>
							_.get(values, 'address.ruralRoute') ||
							((_.get(values, 'address.poBox') ||
								(!isBlank(_.get(values, 'address.streetNumber', '')) &&
									!isBlank(_.get(values, 'address.streetName', '')))) &&
								!isBlank(_.get(values, 'address.city', '')) &&
								!isBlank(_.get(values, 'address.state', ''))),

						'Please make sure you have entered a street address or PO box with a city and state',
					],
				],
			},
			sfgInterestDescription: [
				[
					(value) =>
						!(isBlank(value) && aiVisibility === 'sfgOnly') ||
						aiVisibility === 'capOnly' ||
						//this is if the interest is being hidden because commercial auto was toggled off
						(aiVisibility === 'sfgOnly' && values.capInterestType !== ''),
					'You must choose an additional interest type',
				],
				[
					(value) => !(isBlank(value) && !isBlank(values.interestBuilding)),
					'You must choose an additional interest type',
				],
				[
					(value) =>
						!(
							isBlank(value) &&
							isBlank(values.capInterestType) &&
							isBlank(values.interestVehicle) &&
							aiVisibility === 'both'
						),
					'You must choose either a Safeguard or Commercial Auto interest type',
				],
				...buildingsToTest,
			],
			capInterestType: [
				[
					// Value 02 was removed - error existing quotes
					(value) => !(aiVisibility === 'capOnly' && (isBlank(value) || value === '02')) || aiVisibility === 'sfgOnly',
					'You must choose an interest type',
				],
				[(value) => !(isBlank(value) && !isBlank(values.interestVehicle)), 'You must choose an interest type'],
				[
					(value) =>
						!(
							isBlank(value) &&
							isBlank(values.sfgInterestDescription) &&
							isBlank(values.interestBuilding) &&
							aiVisibility === 'both'
						),
					'You must choose either a Safeguard or Commercial Auto interest type',
				],
			],
			section_interestVehicle: vehiclesToTest,
			interestVehicle: [
				[(value) => !(isBlank(value) && !isBlank(values.capInterestType)), 'You must choose a vehicle'],
			],
			sfgProvisionApplicable: [[(value) => !(isBlank(value) && isHasBP1203(quote, values)), requiredQuestionMessage]],
			sfgDescriptionOfProperty: [
				[(value) => !(isBlank(value) && isHasBP1203orBP1231(quote, values)), requiredQuestionMessage],
			],
		};
	}
}

function testValidBuildings(quote, values, locations, aiListOptions, buildingsToTest) {
	let aiValidBuildings = 'This form is only valid for the following building(s)';
	let choseInvalidBuilding = false;
	if (!isBlank(locations) && !isBlank(values.sfgInterestDescription)) {
		toSortedPairList(locations).forEach((locationPair) => {
			const location = locationPair[1];
			const locId = locationPair[0];
			const { buildings } = location;
			if (!isBlank(buildings)) {
				toSortedPairList(buildings).forEach((buildingPair) => {
					const building = buildingPair[1];
					const bldgId = buildingPair[0];

					const buildingAI = _.get(quote, `sfg.locations.${locId}.buildings.${bldgId}.additionalInsuredType`, []);

					let aiTypeKeys = [];
					_.forIn(buildingAI, (aiCode) => {
						const aiValue = _.find(aiListOptions, ['key', aiCode]);
						if (aiValue) {
							aiTypeKeys.push(aiValue.value);
						}
					});
					if (_.includes(aiTypeKeys, values.sfgInterestDescription)) {
						aiValidBuildings = aiValidBuildings.concat(
							` [${quote.addresses[locId].fullAddress}, Building ${building.order}]`,
						);
					}

					if (
						!_.includes(aiTypeKeys, values.sfgInterestDescription) &&
						_.includes(values.interestBuilding, `${locId}_${bldgId}`)
					) {
						choseInvalidBuilding = true;
					}
				});
			}
		});

		if (choseInvalidBuilding) {
			buildingsToTest.push([() => false, aiValidBuildings]);
		}
	}
}

function checkPhysicalDamage(quote, values, vehiclesToTest) {
	if (values.interestVehicle) {
		_.forIn(values.interestVehicle, (vehicle) => {
			let hasColl = false;
			if (_.get(quote, `cap.vehicles.${vehicle}.collCoverage`, '') === 'Y') {
				hasColl = true;
			}

			const vehicleInfo = _.get(quote, `cap.vehicles.${vehicle}`, {});

			if (!hasColl && _.includes(['12', '07'], values.capInterestType)) {
				vehiclesToTest.push([
					() => false,
					`${_.get(vehicleInfo, 'vehYear', '')} ${_.get(vehicleInfo, 'vehMake', '')} ${_.get(
						vehicleInfo,
						'vehModel',
						'',
					)} ${_.get(
						vehicleInfo,
						'vin',
						'',
					)} does not have physical damage coverage and therefore cannot have a loss payee or additional insured - lessor interest type.`,
				]);
			}
		});
	}
}

export default AdditionalInterestRules;
