import QuoteContext from 'context/quoteContext';
import AdditionalInterestForm from 'issue/additionalInterest/AdditionalInterestForm';
import React, { Component } from 'react';
import { Modal } from 'semantic-ui-react';
import { pageAnalytics } from 'utils/ScreenFunctions';

export class AdditionalInterestModal extends Component {
	static contextType = QuoteContext;

	constructor() {
		super();
		this.state = {
			isOpen: false,
		}; // state to control the state of popup
	}

	handleOpen = (
		additionalInterestId,
		additionalInterest,
		callBack,
		location,
		history,
		additionalInterestListOptions,
	) => {
		this.setState({
			isOpen: true,
			additionalInterestId,
			additionalInterest,
			additionalInterestListOptions,
			callBack,
			location,
			history,
		});
		pageAnalytics(location.pathname + '/AdditionalInterestModal', true);
	};

	handleClose = () => {
		this.state.callBack();
		this.setState({ isOpen: false });
		pageAnalytics(this.state.location.pathname);
	};

	render() {
		const { additionalInterestId, additionalInterest, additionalInterestListOptions, location, history } = this.state;
		return (
			<Modal closeIcon open={this.state.isOpen} closeOnDimmerClick={false} onClose={this.handleClose}>
				<Modal.Header>Additional Interest Information</Modal.Header>
				<Modal.Content>
					<AdditionalInterestForm
						id={additionalInterestId}
						additionalInterest={additionalInterest}
						handleClose={this.handleClose}
						aiListOptions={additionalInterestListOptions}
						location={location}
						history={history}
					/>
				</Modal.Content>
			</Modal>
		);
	}
}
