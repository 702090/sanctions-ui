import { toSortedPairList } from 'components/shared/navigation/NavigationFunctions';
import sfg_premisesRequiredInterestJson from 'data/RulesValues';
import _ from 'lodash';
import { isBlank } from 'utils/StringFunctions';

const { sfg_premisesRequiredInterest } = sfg_premisesRequiredInterestJson;

class AdditionalInterestsRules {
	static requiredStructure = {
		section_additionalInterest: '',
	};

	static rules(quote, values, aiListOptions) {
		// use values for current page validation
		// use quote for external page validation
		const buildingsToTest = [];
		const vehiclesToTest = [];
		let aiValues = [];
		const locations = _.get(quote, 'sfg.locations', {});
		const vehicles = _.get(quote, 'cap.vehicles', {});
		const additionalInterests = _.get(quote, 'additionalInterests', {});

		_.forIn(aiListOptions, (aiListOption) => {
			if (!_.includes(sfg_premisesRequiredInterest, aiListOption.key)) {
				aiValues.push(aiListOption.value);
			}
		});

		const aiToTest = [];
		aiEnteredComparison(additionalInterests, aiValues, aiToTest);

		if (_.includes(_.get(quote, 'products', ['sfg']), 'cap')) {
			testVehicles(vehicles, additionalInterests, quote, vehiclesToTest);
		}

		testBuildings(locations, additionalInterests, quote, buildingsToTest, aiListOptions);

		return {
			section_additionalInterest: [...buildingsToTest, ...aiToTest, ...vehiclesToTest],
		};
	}
}

function aiEnteredComparison(additionalInterests, aiValues, aiToTest) {
	const additonalInterestsEntered = [];

	_.forIn(additionalInterests, (additionalInterest) => {
		if (!_.includes(additonalInterestsEntered, additionalInterest.sfgInterestDescription)) {
			additonalInterestsEntered.push(additionalInterest.sfgInterestDescription);
		}
	});

	const additionalInterestsMissing = _.difference(aiValues, additonalInterestsEntered);

	additionalInterestsMissing.forEach((value) => {
		aiToTest.push([() => false, `An additional interest entry is required for ${value}.`]);
	});
}

function testBuildings(locations, additionalInterests, quote, buildingsToTest, aiListOptions) {
	if (!isBlank(locations)) {
		toSortedPairList(locations).forEach((locationPair) => {
			const location = locationPair[1];
			const locId = locationPair[0];
			const { buildings } = location;
			if (!isBlank(buildings)) {
				toSortedPairList(buildings).forEach((buildingPair) => {
					const building = buildingPair[1];
					const bldgId = buildingPair[0];

					const additionalInterestToTest = _.intersection(building.additionalInsuredType, sfg_premisesRequiredInterest);

					const additionalInterestRequired = additionalInterestToTest.map(
						(interestCode) => _.find(aiListOptions, (c) => interestCode === c.key).text,
					);

					if (additionalInterestRequired.length > 0) {
						let additionalInterestsFound = [];

						_.forIn(additionalInterests, (additionalInterest) => {
							if (_.includes(additionalInterest.interestBuilding, `${locId}_${bldgId}`)) {
								additionalInterestsFound.push(additionalInterest.sfgInterestDescription);
							}
						});

						const missingInterests = _.without(additionalInterestRequired, ...additionalInterestsFound);

						if (missingInterests.length > 0) {
							buildingsToTest.push([
								() => false,
								`${quote.addresses[locId].fullAddress}, Building ${building.order} requires an entry for ${missingInterests}`,
							]);
						}
					}
				});
			}
		});
	}
}

function testVehicles(vehicles, additionalInterests, quote, vehiclesToTest) {
	if (!isBlank(vehicles)) {
		toSortedPairList(vehicles).forEach((vehiclePair) => {
			let vehicleInterestFound = false;
			const vehicle = vehiclePair[1];
			const vehId = vehiclePair[0];
			if (vehicle.leasedVeh === 'Y') {
				_.forIn(additionalInterests, (additionalInterest) => {
					if (_.includes(additionalInterest.interestVehicle, vehId)) {
						vehicleInterestFound = true;
					}
				});

				if (!vehicleInterestFound) {
					vehiclesToTest.push([
						() => false,
						`${_.get(vehicle, 'vehYear', '')} ${_.get(vehicle, 'vehMake', '')} ${_.get(
							vehicle,
							'vehModel',
							'',
						)} ${_.get(vehicle, 'vin', '')} requires an additional interest entry.`,
					]);
				}
			}
		});
	}
}

export default AdditionalInterestsRules;
