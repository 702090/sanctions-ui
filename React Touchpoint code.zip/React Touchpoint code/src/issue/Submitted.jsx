import { BRANCH_PHONE_NUMBER } from '@columbiainsurance/constants-js';
import { isBlank } from '@columbiainsurance/functions-js';
import { Spinner } from 'components/shared/wait/Spinner';
import QuoteContext from 'context/quoteContext';
import proposalOptionsJson from 'data/ProposalOptions';
import _ from 'lodash';
import moEpliJson from 'print/Attachments';
import React, { Fragment, useContext, useEffect, useState } from 'react';
import NumberFormat from 'react-number-format';
import { toast } from 'react-toastify';
import { Popup } from 'semantic-ui-react';
import { getApplicationPdf, getProposalPdf } from 'services/applicationPDFService';
import { getAttachment } from 'services/attachmentService';
import { insurityProposal, sendFillinForms } from 'services/insurityService';
import { getNewPolicyNumber, insertArchiveRecord } from 'services/issueService';
import { mergePDFs } from 'services/mergePDFService';
import { saveQuote } from 'services/quoteService';
import { getReceipt } from 'services/receiptService';
import { allowSTP } from 'services/ruleService';
import {
	addEpliForm,
	displayPolicyNumber,
	displayQuoteNumber,
	getFullInsuredName,
	getProdIcon,
} from 'utils/BusinessFunctions';
import { formatDate } from 'utils/DateFunctions';
import { base64toBlob, saveOrOpen } from 'utils/ScreenFunctions';

export const Submitted = (props) => {
	const context = useContext(QuoteContext);

	const { moEpli } = moEpliJson;
	const { proposalOptions } = proposalOptionsJson;

	const [processing, setProcessing] = useState(true);
	const [Receipt, setReceipt] = useState(false);
	const [Proposal, setProposal] = useState(false);
	const [Application, setApplication] = useState(false);

	const [policyDecSfg, setPolicyDecSfg] = useState(false);
	const [policyDecCap, setPolicyDecCap] = useState(false);
	const [policyDecWcp, setPolicyDecWcp] = useState(false);
	const [policyDecCup, setPolicyDecCup] = useState(false);

	const [prodProposalSfg, setProdProposalSfg] = useState(false);
	const [prodProposalCap, setProdProposalCap] = useState(false);
	const [prodProposalWcp, setProdProposalWcp] = useState(false);
	const [prodProposalCup, setProdProposalCup] = useState(false);

	const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));

	useEffect(() => {
		async function load() {
			const { quote, quoteStatus } = context;
			console.info('quote', quote);
			if (!isBlank(quote)) {
				// Quote is bound
				if (quote.status === 'b' || quote.status === 'c') {
					// If the quote doesn't have a policy number we need to generate a new one
					if (isBlank(quote.policyNumber)) {
						await getNewPolicyNumber()
							.then((policyNumberResult) => {
								if (!policyNumberResult.error) {
									quote.policyNumber = policyNumberResult.policyNumber;
									saveQuote(quote);
								}
							})
							.catch((err) => {
								props.history.push('/systemError');
							});
					}
				} else if (quoteStatus.status === 'b' || quoteStatus.status === 'c') {
					// Quote is being bound for the first time
					quote.status = quoteStatus.status;
					quote.blockAgentEdit = true;
					saveQuote(quote);

					// creating the archive record
					insertArchiveRecord(quote);
				} else {
					// This is an unbound submission
					let fillinPromises = [];
					_.forEach(quote.products, (prod) => {
						fillinPromises.push(sendFillinForms(quote, prod));
					});

					Promise.all(fillinPromises).then((resultArray) => {
						// make sure that a status has been set in the session
						if (!isBlank(quoteStatus.status)) {
							quote.status = quoteStatus.status;
						}

						if (process.env.REACT_APP_ENVIRONMENT_NAME !== 'prod' && !isBlank(quote.id)) {
							allowSTP(quote)
								.then((ruleResult) => {
									quote.stpResults = ruleResult.messages;
									saveQuote(quote);
								})
								.catch((err) => {
									console.error('Error', err);
								});
						}

						//TODO: if WCP we need to re-rate it because of Insurity dumbness with the Quote Proposal.

						quote.blockAgentEdit = true;
						saveQuote(quote);

						// creating the archive record
						insertArchiveRecord(quote);
						setProcessing(false);
					});
				}

				setProcessing(false);
			}
		}

		load();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	function getPolicyNumDisplay(quote, prod) {
		let prefix = prod.toUpperCase();
		if (prod === 'sfg') {
			if (quote.status === 'u') {
				prefix = 'BOP';
			} else {
				prefix = 'BPP';
			}
		}
		if (quote.status === 'u') {
			return displayQuoteNumber(quote, prefix);
		} else {
			return displayPolicyNumber(quote, prefix);
		}
	}

	const updatePolicyDecState = (prod, value) => {
		switch (prod) {
			case 'sfg':
				setPolicyDecSfg(value);
				break;
			case 'cap':
				setPolicyDecCap(value);
				break;
			case 'wcp':
				setPolicyDecWcp(value);
				break;
			case 'cup':
				setPolicyDecCup(value);
				break;
			default:
				break;
		}
	};

	const isPolicyDecRunning = (prod) => {
		switch (prod) {
			case 'sfg':
				return policyDecSfg;
			case 'cap':
				return policyDecCap;
			case 'wcp':
				return policyDecWcp;
			case 'cup':
				return policyDecCup;
			default:
				break;
		}
		return false;
	};
	const updateProdProposalState = (prod, value) => {
		switch (prod) {
			case 'sfg':
				setProdProposalSfg(value);
				break;
			case 'cap':
				setProdProposalCap(value);
				break;
			case 'wcp':
				setProdProposalWcp(value);
				break;
			case 'cup':
				setProdProposalCup(value);
				break;
			default:
				break;
		}
	};

	const isProdProposalRunning = (prod) => {
		switch (prod) {
			case 'sfg':
				return prodProposalSfg;
			case 'cap':
				return prodProposalCap;
			case 'wcp':
				return prodProposalWcp;
			case 'cup':
				return prodProposalCup;
			default:
				break;
		}
		return false;
	};

	const showS3File = async (prod, fileName) => {
		updatePolicyDecState(prod, true);

		let response = await getAttachment({
			s3Bucket: process.env.REACT_APP_STP_DOCUMENT_BUCKET,
			fileName,
		});
		const file = new Blob([new Uint8Array(response.Body.data)], {
			type: response.ContentType,
		});

		saveOrOpen(file, fileName);

		updatePolicyDecState(prod, false);
	};

	const showFile = async (quote, getter, namePrefix, setter) => {
		setter(true);
		getter(quote)
			.then(async (returned) => {
				// Add attachments if necessary
				if (addEpliForm(quote)) {
					const pdfs = [returned.data.base64, moEpli];
					const mergedPdf = await mergePDFs(pdfs);
					returned.data.base64 = mergedPdf.data.base64;
				}

				const fileName = `${namePrefix}_${
					quote.policyNumber ? displayPolicyNumber(quote, '') : displayQuoteNumber(quote, '')
				}_${Date.now()}.pdf`;

				saveOrOpen(base64toBlob(returned.data.base64), fileName);

				setter(false);
			})
			.catch((error) => {
				toast.error(`Could not retrieve ${namePrefix}`);
				console.error('Error', error);

				setter(false);
			});
	};

	if (processing) {
		return <Spinner />;
	}

	const { quote } = context;
	let stCount = 0;
	const products = _.get(quote, 'products', ['sfg']);
	products.forEach((prod) => {
		if (_.get(quote, 'stpDocuments.' + prod)) {
			stCount++;
		}
	});
	let allST = stCount === products.length;

	const branchPhoneNumber = BRANCH_PHONE_NUMBER[agent.branch].replace(/\s/g, '');

	return (
		<Fragment>
			<div id='submittedTitle'>
				{allST
					? `Your polic${products.length > 1 ? 'ies have' : 'y has'} been issued!`
					: 'Thank you for your submission!'}
			</div>
			<p id='insured' className='submitted'>
				{getFullInsuredName(quote)}
				<br />
				Effective Date: {formatDate(quote.effectiveDate, 'text')}
			</p>
			<div className='buttonSection'>
				<div
					className={`documentButton ${Application ? 'active' : ''}`}
					onClick={() => {
						if (!Application) {
							showFile(quote, getApplicationPdf, 'Application', setApplication);
						}
					}}
				>
					<Popup trigger={<i className='far fa-print' />} content='View the Application' position='bottom center' />
					<span>Application</span>
				</div>
				{!allST && !_.includes(['b', 'c'], quote.status) && (
					<div
						className={`documentButton ${Proposal ? 'active' : ''}`}
						onClick={() => {
							if (!Proposal) {
								context.optionModal.current.handleOpen(
									{
										name: 'Proposal Options',
										label: 'Select Proposal type below.',
										options: proposalOptions,
									},
									(v, sfv, fv) => {
										showFile(quote, v === '1' ? insurityProposal : getProposalPdf, 'Proposal', setProposal);
									},
									true,
								);
							}
						}}
					>
						<Popup trigger={<i className='far fa-print' />} content='View the Proposal' position='bottom center' />
						<span>Policy Proposal</span>
					</div>
				)}
				{quote.status !== 'u' &&
					_.get(quote, 'billing.billingType') !== 'A01' &&
					_.get(quote, 'billing.billingType') !== 'AAQ' &&
					_.get(quote, 'billing.downPaymentMethod') !== 'A' &&
					_.get(quote, 'billing.downPaymentMethod') !== 'B' && (
						<div
							className={`documentButton ${Receipt ? 'active' : ''}`}
							onClick={() => {
								showFile(quote, getReceipt, 'Receipt', setReceipt);
							}}
						>
							<Popup trigger={<i className='far fa-print' />} content='View your Receipt' position='bottom center' />
							<span>Receipt</span>
						</div>
					)}
			</div>
			<div id='submittedProducts' className='final'>
				<div id='detailsHeader'>
					{allST && <img alt='TouchPoint Now' src={require('images/TouchPointNowLogo.png')} />}
					{!allST && <span>Your application has been submitted to your underwriting team for review.</span>}
				</div>
				{_.get(quote, 'products', ['sfg']).map((prod) => (
					<div key={prod} className='prodDisplay'>
						<div className='prodLabel'>{getProdIcon(prod)}</div>
						<div className='ids'>
							{getPolicyNumDisplay(quote, prod)}
							<br />
							SAN
							<span className='highlight'>{_.get(quote, `${prod}.san`)}</span>
						</div>
						{_.includes(['b', 'c'], quote.status) ? (
							allST && (
								<div
									className={`documentButton ${isPolicyDecRunning(prod) ? 'active' : ''}`}
									onClick={() => {
										if (!isPolicyDecRunning(prod)) {
											showS3File(prod, _.get(quote, 'stpDocuments.' + prod));
										}
									}}
								>
									<Popup
										trigger={<i className='far fa-print' />}
										content='View the Policy DEC'
										position='bottom center'
									/>
									<span>DEC</span>
								</div>
							)
						) : (
							<div
								className={`documentButton ${isProdProposalRunning(prod) ? 'active' : ''}`}
								onClick={() => {
									updateProdProposalState(prod, true);
									insurityProposal(quote, prod).then((returned) => {
										if (returned.data.base64) {
											const fileName = `Proposal_${
												quote.policyNumber ? displayPolicyNumber(quote, '') : displayQuoteNumber(quote, '')
											}_${Date.now()}.pdf`;

											saveOrOpen(base64toBlob(returned.data.base64), fileName);
										}

										updateProdProposalState(prod, false);
									});
								}}
							>
								<Popup trigger={<i className='far fa-print' />} content='View the Proposal' position='bottom center' />
								<span>Proposal</span>
							</div>
						)}
						<div className='rates'>
							<NumberFormat
								value={Math.floor(_.get(quote, `rates.${prod}`, 0))}
								displayType='text'
								thousandSeparator={true}
								prefix='$'
							/>
							<span className='decimalPart'>{('00' + (_.get(quote, `rates.${prod}`, 0) % 1)).slice(-2)}</span>
						</div>
					</div>
				))}
				<div id='submittedPremium'>
					<span className='premLabel'>Total Premium</span>
					<div>
						<NumberFormat
							value={Math.floor(
								_.toNumber(_.get(quote, 'rates.sfg', 0)) +
									_.toNumber(_.get(quote, 'rates.wcp', 0)) +
									_.toNumber(_.get(quote, 'rates.cap', 0)) +
									_.toNumber(_.get(quote, 'rates.cup', 0)),
							)}
							displayType='text'
							thousandSeparator={true}
							prefix='$'
						/>
						<span className='decimalPart'>
							{(
								'00' +
								((_.toNumber(_.get(quote, 'rates.sfg', 0)) +
									_.toNumber(_.get(quote, 'rates.wcp', 0)) +
									_.toNumber(_.get(quote, 'rates.cap', 0)) +
									_.toNumber(_.get(quote, 'rates.cup', 0))) %
									1)
							).slice(-2)}
						</span>
					</div>
				</div>
			</div>
			<p className='submitted'>
				Should you have any questions, your Underwriter or Underwriting Assistant would be happy to help.
				<br />
				Underwriter: {agent.underwriterName},&nbsp;
				<span className='toLower'>{agent.underwriterEmail}</span>,&nbsp;
				{agent.underwriterPhoneNumber ? agent.underwriterPhoneNumber.replace(/\s/g, '') : branchPhoneNumber}
				<br />
				{!isBlank(agent.underwriterAssistantName) && (
					<>
						Underwriter Assistant: {agent.underwriterAssistantName},&nbsp;
						<span className='toLower'>{agent.underwriterAssistantEmail}</span>,&nbsp;
						{agent.underwriterAssistantPhoneNumber
							? agent.underwriterAssistantPhoneNumber.replace(/\s/g, '')
							: branchPhoneNumber}
					</>
				)}
			</p>
		</Fragment>
	);
};
