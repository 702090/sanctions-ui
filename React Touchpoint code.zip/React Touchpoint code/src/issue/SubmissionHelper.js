import { isBlank } from '@columbiainsurance/functions-js';
import productNamesJson from 'data/ProductNames';
import _ from 'lodash';
import { downpaymentCheck } from 'services/downpaymentService';
import { sendFillinForms } from 'services/insurityService';
import {
	convertPolicy,
	getNewAccountBillNumber,
	getNewPolicyNumber,
	getPolicyDec,
	getWriteStpToWINS,
	issuePolicy,
	loadWFile,
	mvrRecord,
	newbindPolicy,
	runWinsEdits,
	savePolicyDec,
} from 'services/issueService';
import logger from 'services/logService';
import { saveQuote } from 'services/quoteService';
import { allowSTP } from 'services/ruleService';
import { getPredState } from 'utils/BusinessFunctions';

const { productNames } = productNamesJson;
let logCounter = 1;
export const kickoffProcess = async (props, context, quote, advanceBar) => {
	logCounter = 1;
	let errorMessages = false;
	let eligible = {};
	const quoteNumber = quote.quoteNumber;
	const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));

	await logger.logDebug(quoteNumber, '********** Starting Issue Process **********');
	await logger.logDebug(quoteNumber, `${logCounter++} getting a new Policy Number`);
	getNewPolicyNumber()
		.then(async (policyNumberResults) => {
			await logger.logDebug(
				quoteNumber,
				`${logCounter++} New Policy Number retrieved ${JSON.stringify(policyNumberResults)}`,
			);
			quote.policyNumber = policyNumberResults.policyNumber;

			await logger.logDebug(quoteNumber, `${logCounter++} Saving Quote`);
			saveQuote(quote);
			await logger.logDebug(quoteNumber, `${logCounter++} Advancing bar sfg`);
			advanceBar('sfg');

			await logger.logDebug(quoteNumber, `${logCounter++} getting Account Number`);
			await getAccountNumber(quote, errorMessages);
			await logger.logDebug(quoteNumber, `${logCounter++} Saving Quote`);
			saveQuote(quote);

			// If CAP is being quoted run MVR - needs to be done before Decisions rules
			if (_.includes(quote.products, 'cap')) {
				await logger.logDebug(quoteNumber, `${logCounter++} Advancing bar sfg`);
				advanceBar('sfg'); //move to mvr call position

				await logger.logDebug(quoteNumber, `${logCounter++} getting MVR Report`);
				await getMvrReport(quote, errorMessages);
				await logger.logDebug(quoteNumber, `${logCounter++} Saving Quote`);
				saveQuote(quote);
				await logger.logDebug(quoteNumber, `${logCounter++} Advancing bar sfg`);
				advanceBar('sfg'); //move to stpRules position
			} else {
				await logger.logDebug(quoteNumber, `${logCounter++} Advancing bar sfg - skipping CAP`);
				advanceBar('sfg', 1); //skip mvr position and go straight to stpRules position
			}

			// run Decisions rules

			await logger.logDebug(quoteNumber, `${logCounter++} Running Decisions Rules`);
			await runSTPRules(quote, eligible, agent, advanceBar);
			await logger.logDebug(quoteNumber, `${logCounter++} Saving Quote`);
			saveQuote(quote);
			await logger.logDebug(quoteNumber, `${logCounter++} Advancing bar sfg`);
			advanceBar('sfg');

			let documentId = false;
			let promiseGroup1 = [];
			if (eligible.sfg) {
				await logger.logDebug(quoteNumber, `${logCounter++} Start SFG`);
				let productReturn = await runProduct('sfg', quote, advanceBar, agent);
				documentId = productReturn.documentId;
				await logger.logDebug(quoteNumber, `${logCounter++} Getting Document - SFG`);
				promiseGroup1.push(
					getDocument('sfg', quote, advanceBar, agent, documentId)
						.then(async (result) => {
							await logger.logDebug(quoteNumber, `${logCounter++} Done getting document ${result}`);
							await logger.logDebug(quoteNumber, `${logCounter++} Advancing bar sfg`);
							advanceBar('sfg');
							return result;
						})
						.catch(async (err) => {
							await logger.logError(quoteNumber, `${logCounter++} Error getting sfg documents ${err}`);
							advanceBar('sfg', -1, _.get(err, 'response.data.errors', err.message));
							return false;
						}),
				);
			}

			await logger.logDebug(quoteNumber, `${logCounter++} Kicking off other products`);
			promiseGroup1.push(triggerOtherProducts(quote, advanceBar, agent, documentId, eligible));
			Promise.all(promiseGroup1).then(async (results) => {
				await logger.logDebug(quoteNumber, `${logCounter++} All products are done.`);
				await logger.logDebug(quoteNumber, '********** Issue Process Complete **********');
				props.history.push('/quote/issue/submitted');
			});
		})
		.catch(async (err) => {
			await logger.logError(quoteNumber, `${logCounter++} Error getting new Policy Number ${new Error(err)}`);
			props.history.push('/systemError');
		});
};

const runProduct = async (prod, quote, advanceBar, agent) => {
	let documentUid = '';
	const fullPolicyNumber = (prod === 'sfg' ? 'bpp' : prod).toUpperCase() + getPredState(quote) + quote.policyNumber;
	let san = _.get(quote, prod + '.san');
	const quoteNumber = quote.quoteNumber;

	await logger.logDebug(quoteNumber, `${logCounter++} ${prod} - Send Fillin Forms`);
	await sendFillinForms(quote, prod)
		.then(async (result) => {
			await logger.logDebug(quoteNumber, `${logCounter++} Filling Form result - ${JSON.stringify(result)}`);
			await logger.logDebug(quoteNumber, `${logCounter++} Advance bar ${prod}`);
			advanceBar(prod);
			await logger.logDebug(quoteNumber, `${logCounter++} Convert to Issue - ${prod}`);
			return convertPolicy(
				san,
				process.env.REACT_APP_ENVIRONMENT_NAME,
				quoteNumber,
				process.env.REACT_APP_LOG_LEVEL,
				'ISSUE',
			);
		})
		.then(async (result) => {
			await logger.logDebug(quoteNumber, `${logCounter++} Convert Policy result - ${JSON.stringify(result)}`);
			await logger.logDebug(quoteNumber, `${logCounter++} Advance bar ${prod}`);
			advanceBar(prod);
			await logger.logDebug(quoteNumber, `${logCounter++} Bind Policy - ${prod}`);
			return newbindPolicy(
				agent,
				quote,
				prod,
				san,
				process.env.REACT_APP_ENVIRONMENT_NAME,
				quoteNumber,
				process.env.REACT_APP_LOG_LEVEL,
			);
		})
		.then(async (result) => {
			await logger.logDebug(quoteNumber, `${logCounter++} Bind Policy result - ${JSON.stringify(result)}`);
			await logger.logDebug(quoteNumber, `${logCounter++} Advance bar ${prod}`);
			advanceBar(prod);
			await logger.logDebug(quoteNumber, `${logCounter++} Issue Policy - ${prod}`);
			return issuePolicy(
				san,
				process.env.REACT_APP_ENVIRONMENT_NAME,
				quoteNumber,
				process.env.REACT_APP_LOG_LEVEL,
				'ISSUE',
			);
		})
		.then(async (result) => {
			await logger.logDebug(quoteNumber, `${logCounter++} Issue Policy result - ${JSON.stringify(result)}`);
			await logger.logDebug(quoteNumber, `${logCounter++} Advance bar ${prod}`);
			advanceBar(prod);
			await logger.logDebug(quoteNumber, `${logCounter++} Load W File - ${prod}`);
			return loadWFile(san);
		})
		.then(async (result) => {
			await logger.logDebug(quoteNumber, `${logCounter++} Load W File result - ${JSON.stringify(result)}`);
			await logger.logDebug(quoteNumber, `${logCounter++} Advance bar ${prod}`);
			advanceBar(prod);
			documentUid = _.get(result, 'documentUid');
			await logger.logDebug(quoteNumber, `${logCounter++} Run WINS Edits - ${prod}`);
			return runWinsEdits(fullPolicyNumber, quote.effectiveDate.replace(/-/g, ''));
		})
		.then(async (result) => {
			await logger.logDebug(quoteNumber, `${logCounter++} Run WINS Edits result - ${JSON.stringify(result)}`);
			await logger.logDebug(quoteNumber, `${logCounter++} Advance bar ${prod}`);
			advanceBar(prod);
			await logger.logDebug(quoteNumber, `${logCounter++} Write STP to WINS - ${prod}`);
			getWriteStpToWINS(fullPolicyNumber, quote.effectiveDate.replace(/-/g, ''))
				.then(async (r) => {
					await logger.logDebug(quoteNumber, `${logCounter++} Write STP to WINS result - ${JSON.stringify(r)}`);
					if (!r.stpPolicyToWinsSuccess) {
						await logger.logError(quoteNumber, `${logCounter++} Something blew up writing STP to WINS`);
						// TODO: need to notify someone that this policy & effective date needs to be written to WINS so we can accurately indicate it was a TouchPoint Now Policy
					}
				})
				.catch(async (error) => {
					await logger.logError(quoteNumber, `${logCounter++} Error writing STP to WINS ${error} `);
					// TODO: need to notify someone that this policy & effective date needs to be written to WINS so we can accurately indicate it was a TouchPoint Now Policy
				});
		})
		.catch(async (err) => {
			let message = err.message;
			if (_.isArray(message)) {
				message = message[0].message;
			}
			advanceBar(prod, -1, _.get(err, 'response.data.errors', message));
			await logger.logError(quoteNumber, `${logCounter++} ERROR!!! ${JSON.stringify(err)} Advance bar ${prod}`);
		});

	if (!isBlank(documentUid)) {
		return { prod: prod, documentId: documentUid };
	} else {
		await logger.logDebug(quoteNumber, `${logCounter++} Blank documentUid ${prod}`);
		return false;
	}
};

const triggerOtherProducts = async (quote, advanceBar, agent, sfgCompleted, eligible) => {
	const hasCAP = _.includes(quote.products, 'cap');
	const hasWCP = _.includes(quote.products, 'wcp');
	const hasCUP = _.includes(quote.products, 'cup');
	let promiseGroup2 = [];
	const quoteNumber = quote.quoteNumber;

	if (sfgCompleted) {
		if (hasCAP) {
			if (eligible.cap) {
				await logger.logDebug(quoteNumber, `${logCounter++} Advance bar cap`);
				advanceBar('cap', 4);
				await logger.logDebug(quoteNumber, `${logCounter++} Starting CAP`);
				promiseGroup2.push(runProduct('cap', quote, advanceBar, agent));
			} else {
				await logger.logDebug(quoteNumber, `${logCounter++} Sending Fill In Forms - CAP`);
				await sendFillinForms(quote, 'cap');
			}
		}
		if (hasWCP) {
			if (eligible.wcp) {
				await logger.logDebug(quoteNumber, `${logCounter++} Advance bar wcp`);
				advanceBar('wcp', 4);
				await logger.logDebug(quoteNumber, `${logCounter++} Starting WCP`);
				promiseGroup2.push(runProduct('wcp', quote, advanceBar, agent));
			} else {
				await logger.logDebug(quoteNumber, `${logCounter++} Sending Fill In Forms - WCP`);
				await sendFillinForms(quote, 'wcp');
			}
		}
	} else {
		if (hasCAP) {
			await logger.logDebug(quoteNumber, `${logCounter++} Advance bar cap - NOT Eligible`);
			advanceBar(
				'cap',
				-1,
				`${productNames.cap} is not eligible for TouchPoint Now because there was a problem with Safeguard`,
			);
		}
		if (hasWCP) {
			await logger.logDebug(quoteNumber, `${logCounter++} Advance bar wcp - NOT Eligible`);
			advanceBar(
				'wcp',
				-1,
				`${productNames.wcp} is not eligible for TouchPoint Now because there was a problem with Safeguard`,
			);
		}
		if (hasCUP) {
			await logger.logDebug(quoteNumber, `${logCounter++} Advance bar cup - NOT Eligible`);
			advanceBar(
				'cup',
				-1,
				`${logCounter++} ${
					productNames.cup
				} is not eligible for TouchPoint Now because there was a problem with Safeguard`,
			);
		}
	}
	let pGroup2Results = await Promise.all(promiseGroup2);
	let promiseGroup3 = [];
	pGroup2Results.forEach(async (result) => {
		if (result) {
			await logger.logDebug(quoteNumber, `${logCounter++} Getting Document - ${result.prod}`);
			promiseGroup3.push(getDocument(result.prod, quote, advanceBar, agent, result.documentId));
		}
	});

	if (hasCUP) {
		if (!_.includes(pGroup2Results, false) && sfgCompleted) {
			if (eligible.cup) {
				await logger.logDebug(quoteNumber, `${logCounter++} Advance bar cup`);
				advanceBar('cup', 4);
				await logger.logDebug(quoteNumber, `${logCounter++} Starting CUP`);
				promiseGroup3.push(runProduct('cup', quote, advanceBar, agent));
			} else {
				await logger.logDebug(quoteNumber, `${logCounter++} Sending Fill In Forms - CUP`);
				await sendFillinForms(quote, 'cup');
			}
		} else {
			await logger.logDebug(quoteNumber, `${logCounter++} Advance bar cup - NOT Eligible`);
			advanceBar(
				'cup',
				-1,
				`${logCounter++} ${
					productNames.cup
				} is not eligible for TouchPoint Now because there was a problem with an underlying policy`,
			);
		}
	}
	let pGroup3Results = await Promise.all(promiseGroup3);

	if (hasCUP) {
		let cupResults = pGroup3Results[pGroup3Results.length - 1];
		if (cupResults && cupResults.documentId) {
			await logger.logDebug(quoteNumber, `${logCounter++} Get Document CUP`);
			await getDocument('cup', quote, advanceBar, agent, cupResults.documentId);
		}
	}

	return Promise.resolve({ message: 'done' });
};

const getDocument = async (prod, quote, advanceBar, agent, documentUid) => {
	const fullPolicyNumber = (prod === 'sfg' ? 'bpp' : prod).toUpperCase() + getPredState(quote) + quote.policyNumber;
	await logger.logDebug(
		quote.quoteNumber,
		`${logCounter++} Calling getPolicyDec with fullPolicyNumber ${fullPolicyNumber} and documentId ${documentUid}`,
	);
	return getPolicyDec(fullPolicyNumber, documentUid, quote.quoteNumber)
		.then(async (result) => {
			await logger.logDebug(quote.quoteNumber, `${logCounter++} Advance bar ${prod}`);
			advanceBar(prod);
			_.set(quote, 'stpDocuments.' + prod, result.fileName);
			await logger.logDebug(quote.quoteNumber, `${logCounter++} Saving Quote ${prod}`);
			saveQuote(quote);
			await logger.logDebug(quote.quoteNumber, `${logCounter++} Saving Policy Dec ${prod}`);
			return savePolicyDec(result.fileName, result.base64);
		})
		.catch(async (err) => {
			await logger.logError(quote.quoteNumber, `${logCounter++} Error getting policy dec ${new Error(err)}`);
			saveQuote(quote);
		});
};

const getAccountNumber = async (quote, errorMessages) => {
	if (_.get(quote, 'billing.downPaymentMethod') === 'ICheck') {
		await logger.logDebug(quote.quoteNumber, `${logCounter++} Payment Method is Check`);
		const cashSlip = await downpaymentCheck(quote);

		await logger.logDebug(quote.quoteNumber, `${logCounter++} Cash Slip has been found ${JSON.stringify(cashSlip)}`);
		_.set(quote, 'billing.cashSlip', cashSlip);
	}

	const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));

	// Account Number Generation
	if (
		_.get(quote, 'billing.existingAccountBill', 'N') === 'N' &&
		(_.get(quote, 'billing.billingType', 'N') === 'E010M' || _.get(quote, 'billing.billingType', 'N') === 'E010E')
	) {
		await logger.logDebug(quote.quoteNumber, `${logCounter++} Generating a new Account Number`);
		const accountNumberReturn = await getNewAccountBillNumber({ agent, quote });
		await logger.logDebug(
			quote.quoteNumber,
			`${logCounter++} New Account Number return ${JSON.stringify(accountNumberReturn)}`,
		);
		if (accountNumberReturn.errorMessages && accountNumberReturn.errorMessages.length > 0) {
			errorMessages = accountNumberReturn.errorMessages;
		} else if (!isBlank(accountNumberReturn.accountBillNumber)) {
			quote.billing.accountBillNumber = accountNumberReturn.accountBillNumber;
		}
	}
};

const getMvrReport = async (quote, errorMessages) => {
	const mvrReport = await mvrRecord(_.get(quote, 'cap.san', ''));

	if (mvrReport.mvrRetrieved) {
		await logger.logDebug(quote.quoteNumber, `${logCounter++} MVR Report - ${JSON.stringify(mvrReport)}`);
		const mvrReportDrivers = mvrReport.drivers;
		const capDrivers = _.get(quote, 'cap.drivers', {});

		_.forEach(mvrReportDrivers, (driver) => {
			const qDriver = _.find(capDrivers, (quoteDriver) => {
				return quoteDriver.licenseNumber === driver.licenseNumber;
			});
			if (qDriver) {
				qDriver.mvrData = driver.mvrData;
			}
		});
	} else {
		// TODO: Something blew up and we need to notify someone
		await logger.logError(quote.quoteNumber, `${logCounter++} MVR Report - ${JSON.stringify(mvrReport)}`);
	}
};

const runSTPRules = async (quote, eligible, agent, advanceBar) => {
	await allowSTP(quote)
		.then(async (ruleResult) => {
			await logger.logDebug(quote.quoteNumber, `${logCounter++} Decisions results ${JSON.stringify(ruleResult)}`);
			quote.stpResults = ruleResult.messages;
			_.forEach(quote.products, async (product) => {
				eligible[product] = !_.find(quote.stpResults, (rule) => {
					return (rule.product === product && rule.block > 0) || (!rule.product && rule.block > 0);
				});

				if (!eligible[product] || !eligible.sfg) {
					await logger.logDebug(
						quote.quoteNumber,
						`${logCounter++} Advancing bar sfg - ${productNames[product]} is not eligible for TouchPoint Now`,
					);
					advanceBar(product, -1, `${productNames[product]} is not eligible for TouchPoint Now`);
					await logger.logDebug(quote.quoteNumber, `${logCounter++} Sending Fillin Forms`);
					await sendFillinForms(quote, product);
					await logger.logDebug(quote.quoteNumber, `${logCounter++} Binding Non-Straight Through Policy ${product}`);
					newbindPolicy(
						agent,
						quote,
						product,
						_.get(quote, product + '.san'),
						process.env.REACT_APP_ENVIRONMENT_NAME,
						quote.quoteNumber,
						process.env.REACT_APP_LOG_LEVEL,
					);
				}
			});
		})
		.catch(async (err) => {
			await logger.logError(quote.quoteNumber, `${logCounter++} Run STP Rules error ${err}`);
			_.forEach(quote.products, (product) => {
				eligible[product] = false;
			});
		});
};

// async function delay(delayInms) {
// 	return new Promise((resolve) => {
// 		setTimeout(() => {
// 			resolve(2);
// 		}, delayInms);
// 	});
// }
