import { requiredQuestionMessage } from 'data/FieldVisibility';
import _ from 'lodash';
import {
	hasFormBP0416,
	hasFormBP0447,
	hasFormBP0450,
	hasFormBP0497,
	hasFormBP1417,
	hasFormBP1418,
	hasFormBP1420,
	hasFormBP1479,
	hasFormIL375,
	isAddBp0412Form,
} from 'utils/FieldDisplay';
import { isBlank } from 'utils/StringFunctions';
import { distillBuildings } from 'utils/BusinessFunctions';

class FillinFormRules {
	static requiredStructure = {
		fillinForms: {
			bp0412: {
				addForm: 'N',
				premises: '',
				project: '',
			},
			il375: {
				daysNotice: '',
				name1: '',
				address1: {
					fullAddress: '',
				},
				name2: '',
				address2: {
					fullAddress: '',
				},
				name3: '',
				address3: {
					fullAddress: '',
				},
			},
			bp0497: {
				name1: '',
				name2: '',
				name3: '',
			},
			bp0416: {
				description1: '',
			},
			bp1479: {
				type1: '',
			},
			bp0447: {
				description1: '',
			},
			bp1417: {
				location1: '',
			},
			bp1418: {
				project1: '',
			},
			bp1420: {
				description1: '',
			},
			bp0450: {
				location1: '',
			},
		},
	};

	static rules(quote, values) {
		// use values for current page validation
		// use quote for external page validation
		const buildings = distillBuildings(_.get(quote, 'sfg.locations', {}));
		const sfgCurrentCoverages = _.get(quote, 'sfg.coverages.currentCoverages', new Set());
		const needBP0416 = hasFormBP0416(quote, buildings);
		const needBP0447 = hasFormBP0447(quote, buildings);
		const needBP0450 = hasFormBP0450(quote, buildings);
		const needBP0497 = hasFormBP0497(quote, sfgCurrentCoverages);
		const needBP1417 = hasFormBP1417(quote, buildings);
		const needBP1418 = hasFormBP1418(quote, sfgCurrentCoverages);
		const needBP1420 = hasFormBP1420(quote, sfgCurrentCoverages);
		const needBP1479 = hasFormBP1479(quote, buildings);
		const needIL375 = hasFormIL375(quote, sfgCurrentCoverages);

		const numNamesRequiredBP0497 = needBP0497 ? _.get(quote, 'sfg.coverages.CDWS.exposure') : 0;
		const numNamesRequiredIL375 = needIL375 ? _.get(quote, 'sfg.coverages.CDCP.numAmendOfCP') : 0;

		const bp0412Required =
			_.get(values, 'fillinForms.bp0412.addForm') === 'Y' &&
			isBlank(_.get(values, 'fillinForms.bp0412.premises', '')) &&
			isBlank(_.get(values, 'fillinForms.bp0412.project', ''));

		return {
			fillinForms: {
				bp0412: {
					addForm: [[(value) => !isBlank(value), requiredQuestionMessage]],
					premises: [[(value) => !bp0412Required, 'You must enter either a Premises or a Project']],
					project: [[(value) => !bp0412Required, 'You must enter either a Premises or a Project']],
				},
				bp0416: {
					description1: [[(value) => !(needBP0416 && isBlank(value)), requiredQuestionMessage]],
				},
				bp0447: {
					description1: [[(value) => !(needBP0447 && isBlank(value)), requiredQuestionMessage]],
				},
				bp0450: {
					location1: [[(value) => !(needBP0450 && isBlank(value)), requiredQuestionMessage]],
				},
				bp0497: {
					name1: [[(value) => !(needBP0497 && isBlank(value)), requiredQuestionMessage]],
					name2: [[(value) => !(needBP0497 && isBlank(value) && numNamesRequiredBP0497 >= 2), requiredQuestionMessage]],
					name3: [[(value) => !(needBP0497 && isBlank(value) && numNamesRequiredBP0497 >= 3), requiredQuestionMessage]],
				},
				bp1417: {
					location1: [[(value) => !(needBP1417 && isBlank(value)), requiredQuestionMessage]],
				},
				bp1418: {
					project1: [[(value) => !(needBP1418 && isBlank(value)), requiredQuestionMessage]],
				},
				bp1420: {
					description1: [[(value) => !(needBP1420 && isBlank(value)), requiredQuestionMessage]],
				},
				bp1479: {
					type1: [[(value) => !(needBP1479 && isBlank(value)), requiredQuestionMessage]],
				},
				il375: {
					daysNotice: [
						[(value) => !(needIL375 && isBlank(value)), requiredQuestionMessage],
						[(value) => !(needIL375 && (value < 30 || value > 45)), 'Please enter a number between 30 - 45'],
					],
					name1: [[(value) => !(needIL375 && isBlank(value)), requiredQuestionMessage]],
					address1: {
						fullAddress: [[(value) => !(needIL375 && isBlank(value)), 'Address is required.']],
					},
					name2: [[(value) => !(needIL375 && isBlank(value) && numNamesRequiredIL375 >= 2), requiredQuestionMessage]],
					address2: {
						fullAddress: [
							[(value) => !(needIL375 && isBlank(value) && numNamesRequiredIL375 >= 2), 'Address is required.'],
						],
					},
					name3: [[(value) => !(needIL375 && isBlank(value) && numNamesRequiredIL375 >= 3), requiredQuestionMessage]],
					address3: {
						fullAddress: [
							[(value) => !(needIL375 && isBlank(value) && numNamesRequiredIL375 >= 3), 'Address is required.'],
						],
					},
				},
			},
		};
	}
	static referrals(context, values) {
		return {};
	}
	static name() {
		return 'fillinForms';
	}
}
export default FillinFormRules;
