import { isBlank } from '@columbiainsurance/functions-js';
import { DataDisplay } from 'components/shared/form/DataDisplay';
import { InputAddress } from 'components/shared/form/inputs/InputAddress';
import InputNumber from 'components/shared/form/inputs/InputNumber';
import { InputText } from 'components/shared/form/inputs/InputText';
import { InputTextArea } from 'components/shared/form/inputs/InputTextArea';
import { RadioButton } from 'components/shared/form/RadioButton';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import quoteContext from 'context/quoteContext';
import { getFieldDisplayArray } from 'data/FieldVisibility';
import { Field, Form, Formik } from 'formik';
import FillinFormRules from 'issue/fillinForms/FillinFormRules';
import _ from 'lodash';
import React, { useContext, useEffect } from 'react';
import { distillBuildings } from 'utils/BusinessFunctions';
import {
	hasFormBP0412,
	hasFormBP0416,
	hasFormBP0447,
	hasFormBP0450,
	hasFormBP0497,
	hasFormBP1417,
	hasFormBP1418,
	hasFormBP1420,
	hasFormBP1479,
	hasFormIL375,
} from 'utils/FieldDisplay';
import { duplicate } from 'utils/ObjectFunctions';
import { cleanValues, getVisibility, logPageErrors, parseAddress, runRulesOnLoad } from 'utils/ScreenFunctions';
import { validate } from 'validation/Validate';

const FillinForms = (props) => {
	const context = useContext(quoteContext);
	const { quote } = context;
	const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));
	const buildings = distillBuildings(_.get(quote, 'sfg.locations', {}));

	let visibility = {};
	let dirty = false;
	let formProps;
	let il375 = hasFormIL375(quote);
	let bp0497 = hasFormBP0497(quote);
	let bp0412 = hasFormBP0412(quote);
	let bp0416 = hasFormBP0416(quote, buildings);
	let bp1479 = hasFormBP1479(quote, buildings);
	let bp0447 = hasFormBP0447(quote, buildings);
	let bp1417 = hasFormBP1417(quote, buildings);
	let bp1418 = hasFormBP1418(quote);
	let bp1420 = hasFormBP1420(quote);
	let bp0450 = hasFormBP0450(quote, buildings);

	useEffect(() => {
		// If the form is not empty, trigger validation
		runRulesOnLoad(formProps, formProps.initialValues, ['id']);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	const numNamesRequiredIL375 = il375 ? _.get(quote, 'sfg.coverages.CDCP.numAmendOfCP') : 0;
	const numNamesRequiredBP0497 = bp0497 ? _.get(quote, 'sfg.coverages.CDWS.exposure') : 0;

	const initialValues = {
		fillinForms: quote.fillinForms || {
			bp0412: {
				addForm: 'N',
				premises: '',
				project: '',
			},
			bp0416: {
				description1: '',
				description2: '',
				description3: '',
			},
			bp0447: {
				description1: '',
				description2: '',
				description3: '',
				description4: '',
			},
			bp0450: {
				location1: '',
				location2: '',
				location3: '',
			},
			bp0497: {
				name1: '',
				name2: '',
				name3: '',
			},
			bp1417: {
				location1: '',
				location2: '',
				location3: '',
				location4: '',
				location5: '',
				location6: '',
				location7: '',
				location8: '',
			},
			bp1418: {
				project1: '',
				project2: '',
				project3: '',
				project4: '',
				project5: '',
				project6: '',
				project7: '',
				project8: '',
			},
			bp1420: {
				description1: '',
				description2: '',
				description3: '',
				description4: '',
				description5: '',
				description6: '',
				description7: '',
				description8: '',
			},
			bp1479: {
				type1: '',
				type2: '',
				type3: '',
			},
			il375: {
				daysNotice: '',
				name1: '',
				address1: { fullAddress: '' },
				name2: '',
				address2: { fullAddress: '' },
				name3: '',
				address3: { fullAddress: '' },
			},
		},
	};

	const setTransactionData = (form, field, value) => {
		// The answer to the question if you want this form is No so remove all transaction data associated with it.
		if (form === 'bp0412' && field === 'addForm' && value === 'N') {
			_.unset(quote, `transactionData.fillinForms[${form}]`);
		} else if (isBlank(value)) {
			// This field was blanked out so remove any transaction data for that field.
			_.unset(quote, `transactionData.fillinForms[${form}][${field}]`);
		} else {
			if (!agent.userId.startsWith('agt')) {
				_.set(quote, `transactionData.fillinForms[${form}].addForm.timestamp`, new Date());
				_.set(quote, `transactionData.fillinForms[${form}].addForm.changedBy`, agent.userId);
			}
			_.set(quote, `transactionData.fillinForms[${form}][${field}].timestamp`, new Date());
			_.set(quote, `transactionData.fillinForms[${form}][${field}].changedBy`, agent.userId);
		}
	};

	const isReadOnlyField = (form, field) => {
		const lastEditor = _.get(quote, `transactionData.fillinForms[${form}][${field}].changedBy`, '');

		if (!isBlank(lastEditor) && !lastEditor.startsWith('agt') && agent.userId.startsWith('agt')) {
			return true;
		}

		return false;
	};

	return (
		<Formik
			render={(formikProps) => {
				formProps = formikProps;
				dirty = formikProps.dirty;
				visibility = getVisibility(getFieldDisplayArray('fillinForms'), quote, formikProps.values);
				cleanValues(formikProps.values, visibility);

				return (
					<Form id='screen'>
						{bp0412 && (
							<PageSection
								className='formSection coverageSection'
								title='BP0412 Limitation of Coverage to Designated Premises or Project'
							>
								<Field
									name='fillinForms.bp0412.addForm'
									label='Would you like to add this Form?'
									component={isReadOnlyField('bp0412', 'addForm') ? DataDisplay : RadioButton}
									additionalOnChange={(value) => {
										setTransactionData('bp0412', 'addForm', value);
									}}
								></Field>
								<Field
									name='fillinForms.bp0412.premises'
									label='Premises'
									subLabel='(max 260 characters)'
									component={isReadOnlyField('bp0412', 'premises') ? DataDisplay : InputTextArea}
									maxLength={260}
									fieldDisplay={visibility['fillinForms.bp0412.premises']}
									additionalOnBlur={() => {
										setTransactionData(
											'bp0412',
											'premises',
											_.get(formikProps, 'values.fillinForms.bp0412.premises', ''),
										);
									}}
								/>
								<Field
									name='fillinForms.bp0412.project'
									label='Project'
									subLabel='(max 260 characters)'
									component={isReadOnlyField('bp0412', 'project') ? DataDisplay : InputTextArea}
									maxLength={260}
									fieldDisplay={visibility['fillinForms.bp0412.project']}
									additionalOnBlur={() => {
										setTransactionData(
											'bp0412',
											'project',
											_.get(formikProps, 'values.fillinForms.bp0412.project', ''),
										);
									}}
								/>
							</PageSection>
						)}
						{bp0416 && (
							<PageSection className='formSection coverageSection' title='BP0416 Lessor of Leased Equipment'>
								<Field
									name='fillinForms.bp0416.description1'
									label='Description of Leased Equipment'
									component={InputText}
									maxLength='60'
								/>
								<Field name='fillinForms.bp0416.description2' component={InputText} maxLength='60' />
								<Field name='fillinForms.bp0416.description3' component={InputText} maxLength='60' />
							</PageSection>
						)}
						{bp0447 && (
							<PageSection className='formSection coverageSection' title='BP0447 Additional Insured - Vendors'>
								<Field
									name='fillinForms.bp0447.description1'
									label='Description of Products'
									component={InputText}
									maxLength='65'
								/>
								<Field name='fillinForms.bp0447.description2' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp0447.description3' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp0447.description4' component={InputText} maxLength='65' />
							</PageSection>
						)}
						{bp0450 && (
							<PageSection
								className='formSection coverageSection'
								title='BP0450 Additional Insured – Owner/Lessee-Contractor-Schedule'
							>
								<Field
									name='fillinForms.bp0450.location1'
									label='Location of Covered Operations'
									component={InputText}
									maxLength='30'
								/>
								<Field name='fillinForms.bp0450.location2' component={InputText} maxLength='30' />
								<Field name='fillinForms.bp0450.location3' component={InputText} maxLength='30' />
							</PageSection>
						)}
						{bp0497 && (
							<PageSection className='formSection coverageSection' title='BP0497 Waiver of Subrogation'>
								<Field
									name='fillinForms.bp0497.name1'
									label='Name 1'
									component={InputText}
									maxLength='60'
									width='medium'
								/>
								{numNamesRequiredBP0497 >= 2 && (
									<Field
										name='fillinForms.bp0497.name2'
										label='Name 2'
										component={InputText}
										maxLength='60'
										width='medium'
									/>
								)}
								{numNamesRequiredBP0497 >= 3 && (
									<Field
										name='fillinForms.bp0497.name3'
										label='Name 3'
										component={InputText}
										maxLength='60'
										width='medium'
									/>
								)}
							</PageSection>
						)}
						{bp1417 && (
							<PageSection
								className='formSection coverageSection'
								title='BP1417 Designated Locations General Aggregate'
							>
								<Field
									name='fillinForms.bp1417.location1'
									label='Designated Locations'
									component={InputText}
									maxLength='65'
								/>
								<Field name='fillinForms.bp1417.location2' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1417.location3' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1417.location4' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1417.location5' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1417.location6' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1417.location7' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1417.location8' component={InputText} maxLength='65' />
							</PageSection>
						)}
						{bp1418 && (
							<PageSection
								className='formSection coverageSection'
								title='BP1418 Designated Construction Project Genl Agg Limit'
							>
								<Field
									name='fillinForms.bp1418.project1'
									label='Designated Construction Projects'
									component={InputText}
									maxLength='65'
								/>
								<Field name='fillinForms.bp1418.project2' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1418.project3' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1418.project4' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1418.project5' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1418.project6' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1418.project7' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1418.project8' component={InputText} maxLength='65' />
							</PageSection>
						)}
						{bp1420 && (
							<PageSection
								className='formSection coverageSection'
								title='BP1420 Excl – Dmg to work performed by Sub-Con Design'
							>
								<Field
									name='fillinForms.bp1420.description1'
									label='Description of Designated Site or Operation'
									component={InputText}
									maxLength='65'
								/>
								<Field name='fillinForms.bp1420.description2' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1420.description3' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1420.description4' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1420.description5' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1420.description6' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1420.description7' component={InputText} maxLength='65' />
								<Field name='fillinForms.bp1420.description8' component={InputText} maxLength='65' />
							</PageSection>
						)}
						{bp1479 && (
							<PageSection className='formSection coverageSection' title='BP1479 Specified BPP Temp Away from Premises'>
								<Field
									name='fillinForms.bp1479.type1'
									label='Type/Item of business personal property '
									component={InputText}
									maxLength='60'
								/>
								<Field name='fillinForms.bp1479.type2' component={InputText} maxLength='60' />
								<Field name='fillinForms.bp1479.type3' component={InputText} maxLength='60' />
							</PageSection>
						)}
						{il375 && (
							<PageSection className='formSection coverageSection' title='IL-375 Amendment of Cancellation Provisions'>
								<Field
									name='fillinForms.il375.daysNotice'
									label='Number Of Days Notice'
									component={InputNumber}
									maxLength='2'
									width='tiny'
								/>
								<PageSection title='Name of Person/Organization'>
									<div className='flexFields'>
										<Field
											name='fillinForms.il375.name1'
											label='Name 1'
											component={InputText}
											maxLength='60'
											width='medium'
										/>
										<Field
											name='fillinForms.il375.address1.fullAddress'
											label='Address 1'
											component={InputAddress}
											addressName='fillinForms.il375.address1'
											additionalOnChange={parseAddress}
											formikProps={formikProps}
										/>
									</div>
									{numNamesRequiredIL375 >= 2 && (
										<div className='flexFields'>
											<Field
												name='fillinForms.il375.name2'
												label='Name 2'
												component={InputText}
												maxLength='60'
												width='medium'
											/>
											<Field
												name='fillinForms.il375.address2.fullAddress'
												label='Address 2'
												component={InputAddress}
												addressName='fillinForms.il375.address2'
												additionalOnChange={parseAddress}
												formikProps={formikProps}
											/>
										</div>
									)}
									{numNamesRequiredIL375 >= 3 && (
										<div className='flexFields'>
											<Field
												name='fillinForms.il375.name3'
												label='Name 3'
												component={InputText}
												maxLength='60'
												width='medium'
											/>
											<Field
												name='fillinForms.il375.address3.fullAddress'
												label='Address 3'
												component={InputAddress}
												addressName='fillinForms.il375.address3'
												additionalOnChange={parseAddress}
												formikProps={formikProps}
											/>
										</div>
									)}
								</PageSection>
							</PageSection>
						)}

						<NavigationButtons formikProps={formikProps} back location={props.location} history={props.history} />
					</Form>
				);
			}}
			initialValues={initialValues}
			onSubmit={(values, formikActions) => {
				cleanValues(values, visibility);
				const aiPushRequired = !isBlank(_.get(values, 'fillinForms.il375', {})) ? 'interest' : false;
				return context.onSubmit(values, dirty, aiPushRequired, false, props);
			}}
			validate={(values) => {
				const validResults = validate(
					values,
					FillinFormRules.rules(context.quote, values),
					duplicate(FillinFormRules.requiredStructure),
				);
				logPageErrors(validResults, formProps.touched, 'all');
				return validResults;
			}}
		/>
	);
};

export default FillinForms;
