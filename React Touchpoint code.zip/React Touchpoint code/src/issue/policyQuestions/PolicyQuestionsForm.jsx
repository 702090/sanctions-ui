import { RadioButton } from 'components/shared/form/RadioButton';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import { UnderwritingQuestion } from 'components/UnderwritingQuestion';
import QuoteContext from 'context/quoteContext';
import capQuestionsJson from 'data/capPolicyQuestions';
import productNamesJson from 'data/ProductNames';
import sfgQuestionsJson from 'data/sfgPolicyQuestions';
import wcpQuestionsJson from 'data/wcpPolicyQuestions';
import { Field, Form, Formik } from 'formik';
import PolicyQuestionRules from 'issue/policyQuestions/PolicyQuestionRules';
import _ from 'lodash';
import React, { Component } from 'react';
import { getPredState } from 'utils/BusinessFunctions';
import { duplicate } from 'utils/ObjectFunctions';
import { cleanValues, logPageErrors } from 'utils/ScreenFunctions';
import { checkReferrals, validate } from 'validation/Validate';

const visibility = {};
const { productNames } = productNamesJson;
const { capQuestions } = capQuestionsJson;
const { sfgQuestions } = sfgQuestionsJson;
const { wcpQuestions } = wcpQuestionsJson;

export default class PolicyQuestions extends Component {
	static contextType = QuoteContext;

	dirty = false;
	formProps;

	initialValues = {
		policyQuestions: {
			reviewedCorrect: '',
		},
	};

	dependentQuestions = {};

	rulesOnLoad = false;

	UNSAFE_componentWillMount() {
		const quoteQuestions = _.get(this.context, 'quote.policyQuestions', {});
		this.hasWCP = _.includes(this.context.quote.products, 'wcp');
		this.hasCAP = _.includes(this.context.quote.products, 'cap');

		this.sfgDisplay = _.sortBy(this.getQuestionList(sfgQuestions), (q) => q.order);
		if (this.hasWCP) {
			this.wcpDisplay = _.sortBy(this.getQuestionList(wcpQuestions), (q) => q.order);
		}
		if (this.hasCAP) {
			this.capDisplay = _.sortBy(this.getQuestionList(capQuestions), (q) => q.order);
		}

		_.merge(this.initialValues.policyQuestions, quoteQuestions);
		this.initialValues.policyQuestions.reviewedCorrect = quoteQuestions.reviewedCorrect || '';

		_.forIn(this.dependentQuestions, (q, qid) => {
			this.updateVisibilities(qid, this.initialValues.policyQuestions[qid]);
		});
	}

	getQuestionList = (questionObj) => {
		const output = [];
		_.forIn(questionObj, (q, qid) => {
			q.id = qid;
			if (qid !== 'q950' || (qid === 'q950' && getPredState(this.context.quote) !== 'MO')) {
				output.push(q);
				this.initialValues.policyQuestions[qid] = output[qid] || q.d || '';
			}
			if (q.da) {
				const dependencyParts = _.split(q.da, '_');
				const dependencies = _.get(this.dependentQuestions, `${dependencyParts[0]}.${dependencyParts[1]}`, new Set());
				dependencies.add(qid);
				if (!this.dependentQuestions[dependencyParts[0]]) {
					this.dependentQuestions[dependencyParts[0]] = {};
				}
				this.dependentQuestions[dependencyParts[0]][dependencyParts[1]] = dependencies;
				if (questionObj[dependencyParts[0]] == dependencyParts[1]) {
					visibility[qid] = true;
				} else {
					visibility[qid] = false;
				}
			}
		});
		return output;
	};

	updateVisibilities = (qid, value) => {
		const dependencies = this.dependentQuestions[qid];
		_.forIn(dependencies, (qidSet, depAns) => {
			[...qidSet].forEach((dependentQid) => {
				// keep == instead of ===
				visibility[dependentQid] = depAns == value; /* eslint eqeqeq: [0] */
			});
		});
	};

	render() {
		const { quote } = this.context;
		return (
			<Formik
				render={(formikProps) => {
					this.dirty = formikProps.dirty;
					this.formProps = formikProps;

					cleanValues(formikProps.values, visibility);
					checkReferrals(this.context, formikProps.values, PolicyQuestionRules, visibility);
					if (!this.rulesOnLoad) {
						formikProps.validateForm(formikProps.values);
						this.rulesOnLoad = true;
					}
					return (
						<Form id='screen'>
							<PageSection title={productNames.sfg}>
								{this.sfgDisplay.map((question, qid) => (
									<UnderwritingQuestion
										key={qid}
										qid={question.id}
										dependentQuestions={this.dependentQuestions[qid]}
										updateVisibilities={this.updateVisibilities}
										visibility={visibility}
										questionIn={question}
									/>
								))}
							</PageSection>
							{this.hasCAP && (
								<PageSection title={productNames.cap}>
									{this.capDisplay.map((question, qid) => (
										<UnderwritingQuestion
											key={qid}
											qid={question.id}
											dependentQuestions={this.dependentQuestions[qid]}
											updateVisibilities={this.updateVisibilities}
											visibility={visibility}
											questionIn={question}
										/>
									))}
								</PageSection>
							)}
							{this.hasWCP && (
								<PageSection title={productNames.wcp}>
									{this.wcpDisplay.map((question, qid) => (
										<UnderwritingQuestion
											key={qid}
											qid={question.id}
											dependentQuestions={this.dependentQuestions[qid]}
											updateVisibilities={this.updateVisibilities}
											visibility={visibility}
											questionIn={question}
										/>
									))}
								</PageSection>
							)}
							<Field
								name='policyQuestions.reviewedCorrect'
								label='I have reviewed all questions and the answers I have provided are based on information provided by the insured or on my knowledge of the risk.'
								component={RadioButton}
								options={[
									{ text: 'I Agree', value: 'Y' },
									{ text: 'I Disagree', value: 'N' },
								]}
								ignoreTouched
							/>

							<NavigationButtons
								formikProps={formikProps}
								back
								location={this.props.location}
								history={this.props.history}
							/>
						</Form>
					);
				}}
				initialValues={this.initialValues}
				onSubmit={(values, formikActions) => {
					cleanValues(values, visibility);
					return this.context.onSubmit(values, this.dirty, false, false, this.props);
				}}
				validate={(values) => {
					checkReferrals(this.context, values, PolicyQuestionRules, visibility);
					const validResults = validate(
						values,
						PolicyQuestionRules.rules(quote, visibility),
						duplicate(PolicyQuestionRules.requiredStructure),
					);
					logPageErrors(validResults, this.formProps.touched, 'all');
					return validResults;
				}}
			/>
		);
	}
}
