import QuoteContext from 'context/quoteContext';
import capQuestionsJson from 'data/capPolicyQuestions';
import sfgQuestionsJson from 'data/sfgPolicyQuestions';
import wcpQuestionsJson from 'data/wcpPolicyQuestions';
import _ from 'lodash';
import { duplicate } from 'utils/ObjectFunctions';
import { buildReferral } from 'utils/ScreenFunctions';
import { isBlank, isBlankZ } from 'utils/StringFunctions';

const { capQuestions } = capQuestionsJson;
const { sfgQuestions } = sfgQuestionsJson;
const { wcpQuestions } = wcpQuestionsJson;

export default class PolicyQuestionRules {
	static contextType = QuoteContext;

	static requiredStructure = {
		policyQuestions: { reviewedCorrect: '' },
	};

	static rules(quote, visibility) {
		const questionsToTest = {
			policyQuestions: {},
		};

		_.forIn(sfgQuestions, (question, qid) => {
			questionsToTest.policyQuestions[qid] = [
				[
					(value) => !isBlankZ(value) || visibility[qid] === false, //Using = false because ony fields that have variable visibility have visibility so falsy doesn't work
					'This question is required.',
				],
				[
					(value) => {
						let thisOption = {};
						question.o.forEach((option) => {
							// loop over possible options for this question and get the selected option
							if (option.value === value || (option.value === -1 && option.r === 'J')) {
								thisOption = option;
							}
						});

						const number = value;
						let ok = true;
						if (thisOption.r === 'J' && visibility[qid] !== false) {
							//Using != false because ony fields that have variable visibility have visibility so falsy doesn't work
							switch (question.qy) {
								case 'D':
									ok = false;
									break;
								case 'P':
									if (number > 100) {
										ok = false;
									}
								// Fall through
								case 'I':
									if (number < 0) {
										ok = false;
									} else if (!(thisOption.mn === 0 && thisOption.mx === 0)) {
										if (thisOption.mx < thisOption.mn && thisOption.mx === 0) {
											// and up condition
											if (thisOption.mn > number) {
												ok = false;
											}
										} else if (thisOption.mn < thisOption.mx) {
											if (thisOption.mn <= number && number <= thisOption.mx) {
												ok = false;
											}
										} else {
											// ranges are not set up correctly, so reject
											ok = false;
										}
									}
									break;
								default: // T and S do not need testing
							}
						}
						return ok;
					},
					'Due to the answer to this question, you cannot proceed with this quote.',
				],
			];
		});
		questionsToTest.policyQuestions.reviewedCorrect = [
			[(value) => !isBlank(value), 'This question is required.'],
			[(value) => value === 'Y', 'To proceed with this quote, you must agree with this statement.'],
		];
		return questionsToTest;
	}

	static referrals(context, values, visibility) {
		const questionsToTest = {
			policyQuestions: {},
		};

		let combinedQuestions = duplicate(sfgQuestions);

		if (_.includes(_.get(context, 'quote.products', ['sfg']), 'wcp')) {
			_.merge(combinedQuestions, duplicate(wcpQuestions));
		}
		if (_.includes(_.get(context, 'quote.products', ['sfg']), 'cap')) {
			_.merge(combinedQuestions, duplicate(capQuestions));
		}

		_.forIn(sfgQuestions, (question, qid) => {
			questionsToTest.policyQuestions[qid] = buildReferral(question, qid, 'SPQ01');
		});
		_.forIn(wcpQuestions, (question, qid) => {
			questionsToTest.policyQuestions[qid] = buildReferral(question, qid, 'SPQ02');
		});
		_.forIn(capQuestions, (question, qid) => {
			questionsToTest.policyQuestions[qid] = buildReferral(question, qid, 'SPQ03');
		});
		return questionsToTest;
	}

	static name() {
		return 'policyQuestion';
	}
}
