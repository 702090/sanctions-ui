import { isBlank } from '@columbiainsurance/functions-js';
import { requiredQuestionMessage } from 'data/FieldVisibility';
import _ from 'lodash';
import { getLowRoofScoreLocationIDs } from 'utils/BusinessFunctions';

export default class AdditionalQuestionsRules {
	static requiredStructure(quote, values) {
		let outputStructure = {};
		const questionsRequired = getLowRoofScoreLocationIDs(quote);
		_.forIn(questionsRequired, (locId) => {
			_.set(outputStructure, `sfg.locations[${locId}].additionalQuestions.roofRecentlyUpdated`, '');
			_.set(outputStructure, `sfg.locations[${locId}].additionalQuestions.roofWorkVerifiable`, '');
		});

		return outputStructure;
	}

	static rules(quote, values, visibility) {
		let additionalQuestionsRules = {};
		const questionsRequired = getLowRoofScoreLocationIDs(quote);
		_.forIn(questionsRequired, (locId) => {
			_.set(additionalQuestionsRules, `sfg.locations[${locId}].additionalQuestions.roofRecentlyUpdated`, [
				[(value) => !isBlank(value), requiredQuestionMessage],
			]);
			_.set(additionalQuestionsRules, `sfg.locations[${locId}].additionalQuestions.roofWorkVerifiable`, [
				[
					(value) =>
						!(
							isBlank(value) &&
							_.get(values, `sfg.locations[${locId}].additionalQuestions.roofRecentlyUpdated`, '') === 'Y'
						),
					requiredQuestionMessage,
				],
			]);
		});
		return additionalQuestionsRules;
	}

	static name() {
		return 'additionalQuestions';
	}
}
