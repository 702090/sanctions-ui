import { RadioButton } from 'components/shared/form/RadioButton';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { PageSection } from 'components/shared/sections/PageSection';
import quoteContext from 'context/quoteContext';
import additionalQuestionsJson from 'data/AdditionalQuestions';
import { Field, Form, Formik } from 'formik';
import _ from 'lodash';
import React, { useContext } from 'react';
import { getLowRoofScoreLocationIDs } from 'utils/BusinessFunctions';
import { cleanValues } from 'utils/ScreenFunctions';
import { validateNew } from 'validation/Validate';
import AdditionalQuestionsRules from './AdditionalQuestionsRules';

const AdditionalQuestionsForm = (props) => {
	const context = useContext(quoteContext);
	const { quote } = context;
	const questionsRequired = getLowRoofScoreLocationIDs(quote);
	const { questions } = additionalQuestionsJson;
	let dirty;
	let fieldVisibility = {};
	let initialValueMap = {};

	const updateFieldVis = (value, locId) => {
		if (value === 'Y') {
			fieldVisibility[`sfg.locations.${locId}.additionalQuestions.roofWorkVerifiable`] = true;
		} else {
			fieldVisibility[`sfg.locations.${locId}.additionalQuestions.roofWorkVerifiable`] = false;
		}
	};

	_.forEach(questionsRequired, (locId) => {
		_.set(
			initialValueMap,
			`sfg.locations.${locId}.additionalQuestions.roofRecentlyUpdated`,
			_.get(quote, `sfg.locations.${locId}.additionalQuestions.roofRecentlyUpdated`, ''),
		);
		_.set(
			initialValueMap,
			`sfg.locations.${locId}.additionalQuestions.roofWorkVerifiable`,
			_.get(quote, `sfg.locations.${locId}.additionalQuestions.roofWorkVerifiable`, ''),
		);
	});

	return (
		<Formik
			render={(formikProps) => {
				dirty = formikProps.dirty;
				cleanValues(formikProps.values, fieldVisibility);
				return (
					<Form id='screen'>
						{questionsRequired.map((locId) => {
							updateFieldVis(
								_.get(formikProps, `values.sfg.locations.${locId}.additionalQuestions.roofRecentlyUpdated`),
								locId,
							);
							return (
								<PageSection title={_.get(quote, `addresses.${locId}.fullAddress`, '')} key={locId}>
									<Field
										name={`sfg.locations.${locId}.additionalQuestions.roofRecentlyUpdated`}
										label={questions.locationRoofQuestions.roofRecentlyUpdated}
										component={RadioButton}
										additionalOnChange={(value) => {
											updateFieldVis(value, locId);
										}}
									/>
									<Field
										name={`sfg.locations.${locId}.additionalQuestions.roofWorkVerifiable`}
										label={questions.locationRoofQuestions.roofWorkVerifiable}
										component={RadioButton}
										fieldDisplay={fieldVisibility[`sfg.locations.${locId}.additionalQuestions.roofWorkVerifiable`]}
									/>
								</PageSection>
							);
						})}
						<NavigationButtons formikProps={formikProps} back location={props.location} history={props.history} />
					</Form>
				);
			}}
			initialValues={initialValueMap}
			onSubmit={(values) => {
				cleanValues(values, fieldVisibility);
				return context.onSubmit(values, dirty, false, false, props);
			}}
			validate={(values) => {
				const validResults = validateNew(context.quote, values, AdditionalQuestionsRules);
				return validResults;
			}}
		/>
	);
};

export default AdditionalQuestionsForm;
