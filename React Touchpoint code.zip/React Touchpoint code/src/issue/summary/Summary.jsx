import { BRANCH_PHONE_NUMBER } from '@columbiainsurance/constants-js';
import { InformationMessage } from 'components/shared/messages/InformationMessage';
import NavigationButtons from 'components/shared/navigation/NavigationButtons';
import { getPage } from 'components/shared/navigation/NavigationFunctions';
import QuoteContext from 'context/quoteContext';
import productNamesJson from 'data/ProductNames';
import { getTime } from 'date-fns';
import _ from 'lodash';
import React, { Component } from 'react';
import { Popup } from 'semantic-ui-react';
import { saveQuote } from 'services/quoteService';
import { displayPolicyNumber, displayQuoteNumber, getFullInsuredName, getPredState } from 'utils/BusinessFunctions';
import { formatDate } from 'utils/DateFunctions';
import { getSet } from 'utils/ObjectFunctions';
import { pageEvent } from 'utils/ScreenFunctions';
import { isBlank, isBlankR } from 'utils/StringFunctions';

const { productNames } = productNamesJson;

export default class SummaryForm extends Component {
	static contextType = QuoteContext;

	componentDidMount() {
		this.context.updateQuoteStatus('');
	}

	getPolicyNumDisplay(quote, prod) {
		let prefix = '';
		switch (prod) {
			case 'sfg':
				if (quote.status === 'u') {
					prefix = 'BOP';
				} else {
					prefix = 'BPP';
				}
				break;
			case 'wcp':
				prefix = 'WCP';
				break;
			case 'cap':
				prefix = 'CAP';
				break;
			case 'cup':
				prefix = 'CUP';
				break;
			default:
		}
		if (isBlank(quote.status) || quote.status === 'u') {
			return displayQuoteNumber(quote, prefix);
		} else {
			return displayPolicyNumber(quote, prefix);
		}
	}

	submitIssue = (type) => () => {
		const { quote, navigation } = this.context;

		// creating the archive record only for Submit Unbound
		if (type === 'u') {
			pageEvent('Quote', 'Submit', 'Unbound');
			quote.blockAgentEdit = true;
			quote.status = type;
			saveQuote(quote);
			const moveToPage = getPage(this.props.location.pathname, 'submitted', navigation.navItems);
			this.props.history.push(moveToPage);
		} else {
			if (type === 'c') {
				pageEvent('Quote', 'Submit', 'Underwriter');
			} else {
				pageEvent('Quote', 'Submit', 'Bound');
			}
			this.context.updateQuoteStatus(type);
			const moveToPage = getPage(this.props.location.pathname, 'next', navigation.navItems);
			this.props.history.push(moveToPage);
		}
	};

	// 12/30/21 7:00 pm EST to 1/4/22 7:00 am EST
	isBindDisabled = () => {
		const { quote } = this.context;

		const predState = getPredState(quote);
		const hasCAP = getSet(_.get(quote, 'products', [])).has('cap');
		const startTime = getTime(new Date(2021, 11, 30, 18, 0, 0));
		const endTime = getTime(new Date(2022, 0, 4, 6, 0, 0));

		return hasCAP && predState === 'GA' && Date.now() >= startTime && Date.now() < endTime;
	};

	render() {
		const { quote } = this.context;
		const agent = JSON.parse(sessionStorage.getItem('agentJSONObject'));
		const branchPhoneNumber = BRANCH_PHONE_NUMBER[agent.branch].replace(/\s/g, '');

		return (
			<div id='submittedPage'>
				<div id='submittedTitle'>You're almost done!</div>
				<p className='submitted'>
					Should you have any questions, your Underwriter or Underwriting Assistant would be happy to help.
					<br />
					<span className='bold'>Underwriter:</span> {agent.underwriterName}
					<br />
					<span className='toLower'>{agent.underwriterEmail}</span>,&nbsp;
					{agent.underwriterPhoneNumber ? agent.underwriterPhoneNumber.replace(/\s/g, '') : branchPhoneNumber}
					<br />
					{!isBlank(agent.underwriterAssistantName) && (
						<>
							<span className='bold'>Underwriter Assistant:</span> {agent.underwriterAssistantName}
							<br />
							<span className='toLower'>{agent.underwriterAssistantEmail}</span>,&nbsp;
							{agent.underwriterAssistantPhoneNumber
								? agent.underwriterAssistantPhoneNumber.replace(/\s/g, '')
								: branchPhoneNumber}
						</>
					)}
				</p>
				<div>
					<span id='buttonHeader'>Submit this quote:</span>
					<div className='buttonSection'>
						<div className='documentButton' onClick={this.submitIssue('u')}>
							<Popup trigger={<i className='fal fa-file-alt' />} content='Submit Unbound' position='bottom center' />
							<span>Submit Unbound</span>
						</div>
						{!this.isBindDisabled() && (
							<>
								<div className='documentButton' onClick={this.submitIssue('c')}>
									<Popup
										trigger={<i className='fal fa-file-alt' />}
										content='Submit bound per underwriter conversation'
										position='bottom center'
									/>
									<span>Submit bound per underwriter conversation</span>
								</div>
								{isBlankR(quote.referrals) && (
									<div className='documentButton' onClick={this.submitIssue('b')}>
										<Popup
											trigger={<i className='fal fa-file-alt' />}
											content='Submit Bound'
											position='bottom center'
										/>

										<span>Submit Bound</span>
									</div>
								)}
							</>
						)}
						{this.isBindDisabled() && (
							<InformationMessage
								message={
									'Binding has been disabled temporarily due to 3rd Party Maintenance and will be re-enabled on January 4, 2022 6:00AM CST'
								}
								fieldDisplay
							/>
						)}
					</div>
				</div>
				<div id='submittedProducts'>
					<div id='detailsHeader'>
						{getFullInsuredName(quote)}
						<br />
						Effective Date: {formatDate(quote.effectiveDate, 'text')}
					</div>
					<div id='submittedDetails'>
						{_.get(quote, 'products', ['sfg']).map((prod) => (
							<div key={prod} className='detailsProduct'>
								<div className='detailsProdName'>{productNames[prod]}</div>
								<div className='detail'>
									SAN Number
									<br />
									{_.get(quote, `${prod}.san`)}
								</div>
								<div className='detail'>
									Quote Number
									<br />
									{this.getPolicyNumDisplay(quote, prod)}
								</div>
							</div>
						))}
					</div>
				</div>
				<NavigationButtons back issuing location={this.props.location} history={this.props.history} />
			</div>
		);
	}
}
